# Session Handoff — resume here

_Living scratchpad for picking work back up. Newest session on top. Not a release
changelog (that's `CHANGELOG.md` / README progression) — this is "where we left off"._

## 2026-09-01 — App deploy as a DAB job BUILT, not yet run/deployed (feat/app-deploy-job)

Made the App deploy/update **DAB-native** so it runs like every other resource, instead
of the manual `databricks sync` + `databricks apps deploy` CLI dance in
`APP_DEPLOY_RUNBOOK.md`. Adapted from a foreign reference notebook (`04_deploy_app.py`,
a "CMM" app) the user dropped at repo root — that reference is now removed.

### What was built (tooling only — NO app/library behavior change)
- **`src/alv-backend/deploy_app.py`** (notebook-source driver) — create/reuse the App,
  start compute, `w.apps.deploy` from the synced source path, floor the SQL-warehouse
  auto-stop (best-effort, default 60 min), and print the App-SP grants **filled in**.
- **`resources/alv_deploy_app.job.yml`** — job `alv_deploy_app` (serverless, `databricks-sdk`).
- **`databricks.yml`** — `sync.include` now also uploads `src/alv-frontend/backend/**`
  (excludes `.venv`/`tests`/`__pycache__`), so the job deploys from
  `<bundle_source_path>/src/alv-frontend/backend`. New `warehouse_id` var
  (dev `f399753196bda967`, prod `REPLACE_ME`).
- **Grants fixed for ALV** — the reference granted `system.*` (needs an **account admin**).
  ALV touches no `system.*`: the printed block is catalog/schema `USE`/`SELECT`/`MODIFY`
  + volume `READ/WRITE` (SQL, **UC admin**), warehouse `CAN_USE` + per-bound-job
  `CAN_MANAGE_RUN` (CLI). Job ids are read live from `alv_catalog`.

### Verified
- `databricks bundle validate -t dev` **OK**; `deploy_app.py` compiles; both YAMLs parse.
- **Not yet run.** `bundle deploy` + `bundle run alv_deploy_app` NOT executed.

### ▶ Next
- **Decision for Idris:** running this cuts the live app's source path over from
  `alv-frontend-src` to the bundle-synced path. On his go-ahead:
  `databricks bundle deploy -t dev -p fevm-lakebase` then
  `databricks bundle run alv_deploy_app -t dev -p fevm-lakebase`, validate in-browser,
  then commit + push `feat/app-deploy-job` (offer `/review` first).
- **Alternative not taken:** DAB has a native `resources.apps` type — could replace the
  notebook+job entirely later; kept the notebook+job per the request.

## 2026-08-19 — structured output paths + retention cleanup BUILT + DEPLOYED, awaiting validation (feat/structured-output-paths)

Branch `feat/structured-output-paths`, cut from `main`. **Git is Idris'** — nothing
committed/pushed yet; push to the feature branch only after he validates on the live app
and gives the go-ahead. Design + answered decisions: `docs/OUTPUT_PATH_LAYOUT_APPROACH.md`
(marked IMPLEMENTED).

### What was built (Job/library-layer only — NO App/frontend change)
- **Per-run output subfolders** replace the flat dir:
  `/Volumes/<cat>/<schema>/<vol>/<YYYYMMDD>/<alv_id>/<request_no>/<file>`. The **Job** owns
  the layout — stamps the date (in `report_timezone`) and composes the path from `alv_id` +
  `request_no` it already receives, so **no App change, no new job param** (`output_dir`
  dropped). `alv_id` is an opaque segment (never split).
- **Stand-in jobs write via Spark** `coalesce(1).write.csv(dir)`, glob the `part-*.csv`,
  return that single-file `output_path` → **Download + Preview unchanged**. Added
  `report_timezone` param to both jobs; dummy job gained `bundle_source_path`.
- **New pure helpers** in `dbx_alv_reports/common/utilities/output_path.py` (re-exported):
  `build_output_dir(base, alv_id, request_no, now)`, `expired_date_dirs`, `parse_date_dir`.
- **Daily retention cleanup job** `alv_output_cleanup` (`resources/alv_output_cleanup.job.yml`
  + `src/alv-backend/alv_output_cleanup.ipynb`) — deletes `<YYYYMMDD>` folders older than
  `output_retention_days` (new `databricks.yml` var, default 30); 01:00 Asia/Kolkata,
  auto-paused in dev, `dry_run` supported. Ignores non-`YYYYMMDD` entries.
- **No schema / migration / new grant.** (Prod: cleanup run-as SPN needs `WRITE VOLUME` —
  `APP_PREREQUISITES.md` §2b.)

### Tests / verification (all green)
- **106 library unit** (+26 in `src/tests/unit/test_output_path.py`), `compileall` clean,
  `databricks bundle validate -t dev` OK.
- **Live-smoke-tested on `fevm-lakebase`:** dummy → `…/20260819/retail_ledger__detail__agent_item/REQ-SMOKE-0001/part-*.csv`
  (3 rows); sample → `…/REQ-SMOKE-0002/part-*.csv` (200 rows, real Spark). Job ids
  unchanged (bindings intact). Cleanup: dry-run flagged today w/o deleting; real run
  (retention 30) deleted a seeded `20250101/` and kept `20260819/`. New job id
  `551050891330041`.

### ▶ Next
- **Idris validates on the live app** (submit a report → confirm nested path + Download +
  Preview work). On his go-ahead: commit + push `feat/structured-output-paths` (offer
  Isaac Review / `/review` first).
- Docs updated this session: CHANGELOG, README progression, `METADATA_TABLE.md` (output_path
  shape), `APP_PREREQUISITES.md` §2a/§2b, `CLAUDE.md` (key decision), the plan doc.
- Known/accepted: in-folder filename is the raw Spark `part-…c000.csv` (folder carries the
  request id); pre-existing flat `REQ-*_interactive.csv` test files on the volume are left
  untouched by cleanup (not date folders); `run_id="interactive"` cosmetic log remains.

## 2026-08-18 — output-file preview BUILT + DEPLOYED, awaiting validation (feat/output-file-preview)

Branch `feat/output-file-preview`, cut from **latest `main`** (result-cache-reuse is now
merged — PR #6, `main` @ `9e60186`). **Git is Idris'** — branch created this session at his
explicit request; nothing pushed yet.

### What was built
New **Preview** action on the Downloads page → an on-screen view of a completed run's
**output FILE** (read off the UC Volume). The read-only twin of Download; runs **no SQL**
(contrast the form's "Preview Sample Data"). Design + signed-off decisions in
`docs/OUTPUT_FILE_PREVIEW_APPROACH.md` (now marked BUILT + DEPLOYED).
- **Backend** `GET /api/requests/{request_no}/output-preview` (`main.py`) — same
  `_require_request_permission` gate + 409/422/502 guards as download; reads a bounded
  prefix, parses, returns capped rows.
- **`alv_app/output_preview.py`** (new, pure) — CSV parse / raw-text fallback / binary
  guard; drops the partial last line on byte-truncation.
- **`alv_app/databricks_client.py`** — `read_volume_prefix()` (bounded App-SP Volume read).
- **`models.py`** `OutputPreviewOut`; **`config.py`** `output_preview_max_rows=1000` /
  `output_preview_max_bytes=8 MiB`; commented `app.yaml` entries.
- **Frontend** — `useOutputPreview`, `OutputPreviewPage.tsx`, `PreviewAction` on the
  Downloads row, `outputPreviewPath()` + route in `App.tsx`, `.preview-text-block` CSS.
- **No schema / migration / grant change.**

### Tests (all green locally)
- **321 backend + 1 skipped** (`test_output_preview.py`: +14), **24 vitest**
  (`OutputPreview.test.tsx`: +5), `tsc -b` + `vite build` clean (JS `index-Bgne6J3F.js`,
  CSS `index-DNsI70ib.css`).

### Deployed
- CLI auth OK. `databricks sync src/alv-frontend/backend … alv-frontend-src --full` →
  `databricks apps deploy alv-bricks … -p fevm-lakebase` → **SUCCEEDED**, app RUNNING.
- Deleted the stale hashed assets (`index-BdAG6z97.js`, `index-vlLGmljV.css`) from the
  workspace static/assets (sync `--full` does not prune remote-only files).

### ▶ Next
1. **Idris validates** on the live app: https://alv-bricks-7474646826130163.aws.databricksapps.com
   — Downloads → a COMPLETED run → **Preview** (between Parameters and Download) → the
   screen shows the CSV. Try a `RUNNING`/no-output row (Preview disabled).
2. On his go-ahead → push `feat/output-file-preview` + open PR (git is his).
3. Task tracker row updated (Google Sheet, gid=255686714).
4. **Backlog:** multi-file preview — note added to `docs/MULTI_FILE_DOWNLOAD_APPROACH.md`.

## 2026-08-18 — result cache reuse (7.3) BUILT, awaiting deploy + validation (feat/result-cache-reuse)

### Repo state reconciled first (housekeeping)
- `feat/repo-reorg`, `feat/report-templates`, `feat/admin-console-user-permissions`, and
  **"add report from UI"** are all **merged into `main`** (`main` @ `80f7a78`). The
  add-report commit was pushed **straight to `main`** (no PR); accepted as-is (Idris'
  call), local `main` fast-forwarded, and the redundant `feat/add-report-from-ui` branch
  deleted. **11 stale merged local branches pruned** — only `main` + this feature branch remain.
- The `CHANGELOG` still has several `[Unreleased]` sections for already-merged work + no
  add-report entry — left as-is this session (Idris chose "just update the handoff" over a
  full changelog reconciliation). LICENSE stays removed (deleted with the add-report commit).

### What was built (task 7.3, on `feat/result-cache-reuse`)
Pre-submit result-cache lookup + reuse popup, to the approved defaults in
`docs/RESULT_CACHE_REUSE_APPROACH.md` (now marked IMPLEMENTED).
- **`alv_app/cache_source.py`** (new) — `build_cache_lookup_sql` (pure, bound, testable) +
  `find_cached_run`, same warehouse statement-exec seam / App SP as `downloads.py`. Hit =
  `COMPLETED` + `output_path` present + `expires_at > now()`. **Latest wins** (the added
  edge case): `ORDER BY generated_at DESC, submitted_at DESC, request_no DESC LIMIT 1`.
- **`POST /api/reports/{alv_id}/cache-check`** (`main.py`) — same `report_permissions`
  gate as submit (404 on deny, before any read); computes `param_hash` server-side via the
  submit builders; returns `{alv_id, param_hash, hit|null}`. Warehouse failure → `hit=null`
  (200), never blocks submit. Raw `output_path` never returned (only `has_output`).
- **`models.py`** — `CacheHitOut` / `CacheCheckOut`.
- **Frontend** — `useCacheCheck` runs on Submit before the run; a hit opens the new
  **`ReuseRunModal`** (Reuse output → downloads the existing run via the Downloads download
  endpoint; Run the job again → normal submit; Cancel). No hit / failed check → normal submit.
  New `CacheHit` / `CacheCheck` types.
- **No schema / migration / grant change** — `request_log` already has every column; App SP
  already SELECTs it.

### Tests (all green locally)
- **307 backend + 1 skipped** (`tests/test_cache_check.py`: +12), **19 vitest**
  (`ReuseRun.test.tsx`: +4), `tsc -b` clean, `vite build` clean (new JS
  `index-DTXWQndj.js`; CSS unchanged).

### ⛔ Deploy is BLOCKED — CLI auth expired
- `databricks apps get alv-bricks -p fevm-lakebase` → "refresh token is invalid". Idris must
  run `databricks auth login --profile fevm-lakebase`, then deploy per the runbook:
  build already done → upload `alv_app/main.py`, `alv_app/models.py`, NEW
  `alv_app/cache_source.py`, `static/index.html`, NEW `static/assets/index-DTXWQndj.js`;
  **delete** old `static/assets/index-BU7OYxD6.js`; then `databricks apps deploy`.
  (Or `databricks sync src/alv-frontend/backend <ws-src> --full` + deploy.)

### Validate on the live app (Idris)
1. Submit a report with parameters that already have a COMPLETED run → the **"Identical
   report run found"** popup appears, naming the original submitter + time. **Reuse output**
   downloads the existing file; **Run the job again** triggers a fresh run.
2. Submit brand-new parameters → no popup, submits directly (backward-compatible).
3. If two COMPLETED runs exist for the same params, the popup offers the **latest** file.

### On go-ahead
- Commit + push `feat/result-cache-reuse`, open a PR to `main`, mark tracker **7.3** Done +
  30-July **#3 (caching priority)** Done.

## 2026-08-11 — repository reorganization — DEPLOYED, awaiting UI validation (feat/repo-reorg)

Structural refactor only (no code behavior change). Branched from `main` (which already
carries templates — `main` == the deployed feature set). All work is on `feat/repo-reorg`.

### New layout
- **`src/alv-backend/`** — the metadata library (`dbx_alv_reports`) + the 6 driver notebooks
  (was `src/`).
- **`src/alv-frontend/`** — the whole Databricks App (was `app/`): `backend/` (FastAPI,
  the Apps deploy source root) + `frontend/` (React/Vite → `backend/static`).
- **`src/report_specs/`, `src/env_parameters/`, `src/tests/`** — moved under `src/`.

### What was edited (beyond the moves)
- `databricks.yml`: `sync.include` → `src/alv-backend/**`, `src/report_specs/**`,
  `src/env_parameters/**`; `framework_source_path` → `${workspace.file_path}/src/alv-backend`.
- Root `pyproject.toml`: `package-dir` / `packages.find` / `VERSION` path / pytest
  `pythonpath` → `src/alv-backend`; `norecursedirs` → `alv-frontend`.
- 5 driver notebooks: `sys.path` bootstrap `${bundle_source_path}/src` → `/src/alv-backend`.
- 3 seed job YAMLs: `manifest_path` → `${var.bundle_source_path}/src/report_specs/…`.
- `test_preview.py`: library at `<root>/src/alv-backend`, manifest at `<root>/src/report_specs`.
- Docs (this file, CLAUDE, README, app README, deploy runbook, contracts) path refs updated.

### Deploy (this session)
- App re-deployed to the **NEW workspace source path**
  `/Workspace/Users/idris.chakera@databricks.com/**alv-frontend-src**` (was `alv-bricks-src`);
  old path removed after cutover. App URL + SP unchanged.
- Recreate the App venv fresh after pulling this branch: the moved `.venv` had absolute
  paths baked to `app/backend` — `cd src/alv-frontend/backend && rm -rf .venv && uv sync`.

### Validate on the live app (Idris)
- The app should look/behave EXACTLY as before (templates + everything). This is a layout
  change only — confirm nothing regressed in the UI, then give the go-ahead for the PR.

### Tests (all green on the branch)
- Library 80 · App backend 279 (+1 skipped) · 12 vitest · frontend build clean ·
  `databricks bundle validate -t dev` OK.

### Next steps
- On go-ahead: PR `feat/repo-reorg` → `main`.
- The `git` history is clean renames (121 files at 100% rename detection) + the path edits.

## 2026-08-08 — DYNAMIC templates (relative dates) — DEPLOYED, awaiting validation (feat/report-templates)

Built ON TOP of the base templates feature, same branch. **All commits held** (decision 7):
the branch has the base-feature 3 commits + the Isaac-review doc, and the dynamic-templates
work is **uncommitted in the working tree** — commit + push everything together once Idris
validates.

### What was built + deployed (dynamic templates)
- **`alv_app/dynamic_values.py`** — 8-preset closed set (`TODAY`, `CUR_DATE_PLUS_N_DAYS`,
  first/last day of cur/next/prev month) + pure resolver (injected `now`) +
  `parse_value_kinds`. **No work-day logic** (dropped, decisions 9 & 11).
- **`alv_app/template_validation.py`** + **`alv_app/messages.py`** — server-side port of the
  frontend validation vocabulary + message catalogue, so **save-time validation** (decision
  10) returns the same messages. Save now validates BOTH static and dynamic templates (422
  with `{param: message}` on failure) — a change from the base feature's un-gated save.
- **`templates.py` / `models.py` / `main.py`** — `save` resolves+validates+writes
  `value_kinds_json`; `load` resolves dynamic presets to concrete dates (report tz) and
  returns the raw `value_kinds`; list carries `is_dynamic`.
- **`config.py` + `app.yaml`** — `REPORT_TIMEZONE` = `Asia/Kolkata` (decision 3).
- **Frontend** — `SaveTemplateModal.tsx` (name + per-date-field Static|Dynamic toggle +
  preset dropdown + n input + "from month start to today" shortcut + live preview +
  validate-before-save); `dynamicPresets.ts`; dynamic badge on the Templates list; hooks
  carry `value_kinds`.
- **Deployed** via `databricks sync src/alv-frontend/backend … --full` + `databricks apps deploy`
  (SUCCEEDED, RUNNING). **No table/migration/grant change** — only the reserved
  `value_kinds_json` column, already present. `provision` was NOT re-run this pass.

### Validate on the live app (Idris)
1. Static template still works (save with a valid date range → load → fills form).
2. **Save now blocks invalid values**: try saving a reversed / blank mandatory range → the
   modal pops the exact validation error and does NOT save.
3. **Dynamic**: Save as template → toggle the transaction-date range dynamic (or click "from
   month start to today") → save → **Load** → the dates fill relative to today (Asia/Kolkata).
   The Templates list shows a **"dynamic"** badge.
4. Confirm ± n days works (e.g. current date − 1).

### Tests (all green on the branch, uncommitted)
- 279 backend + 79 library + 11 vitest; tsc + vite build clean.

### Known limitation (documented)
- A dynamic template is validated at save against **today's** resolved dates; it can still
  resolve to a validation failure in a later month (surfaced at submit by the form validation).

### Follow-up fixes (2026-08-08, later — deployed)
- **Templates screen is now REPORT-WIDE** (Idris' request): lists every template for the
  whole `report_key`, with **Selection** + **Report** columns; **Load** jumps to each row's
  own report type. Backend `list_templates_for_report` (JSON-array bind); `TemplateSummaryOut`
  gained `alv_id` + labels; rename/delete use the row's alv_id.
- **Fixed the "Retail Ledger" breadcrumb dead-link** on the Templates page (it used a
  `#`-prefixed `to` under HashRouter). Now a plain path; regression vitest added.
- Redeployed (app-only; no schema change). **279 backend + 79 lib + 12 vitest pass.**

## 2026-08-08 — parameter templates (variants) — DEPLOYED, awaiting validation (feat/report-templates)

### Where we left off
- **Branch `feat/report-templates`** off `main`. TWO commits (slice 1 backend, slice 2
  frontend). **Deployed to the live app; awaiting Idris' validation before merge.**
- Approach doc: `docs/TEMPLATES_FEATURE_APPROACH.md` (decisions answered inline by Idris).
  Superseded the earlier `REPORT_INPUT_TEMPLATES_APPROACH.md` draft (deleted this session).

### What was built + deployed
1. **`report_templates` table** — single-source DDL (`metadata_tables.py`), in
   `PILOT_TABLES`. Created by re-running **`provision_alv_metadata`** (done — DESCRIBE
   confirms all 9 columns). **No migration** (new table). Grain (owner, alv_id,
   template_name); stores RAW form values; `value_kinds_json` reserved for later dynamic
   templates.
2. **Backend** `alv_app/templates.py` (owner-scoped bound-SQL App-SP seam) + 5 endpoints
   under `/api/reports/{alv_id}/templates` (list/save/load/rename/delete). Report gate
   THEN owner gate; 404 on deny / no-email. Models added.
3. **Frontend** — contextual **Templates** left-nav item (shown while a report is open) →
   Templates screen (`/report/:reportKey/:alvId/templates`, scoped to the report type):
   list / Load (seeds FormDraft then navigates) / Rename / Delete. **Save as template**
   on the form (not validation-gated). **Validate button removed.**

### Deploy actions performed (for the record)
1. `databricks bundle deploy -t dev -p fevm-lakebase` (synced updated `src/`).
2. `databricks bundle run provision_alv_metadata -t dev -p fevm-lakebase` — **created
   `report_templates`** (SUCCESS; verified via DESCRIBE TABLE on warehouse
   `f399753196bda967`).
3. `databricks sync src/alv-frontend/backend <ws-src> -p fevm-lakebase --full` then
   `databricks apps deploy alv-bricks --source-code-path <ws-src> -p fevm-lakebase` —
   deploy **SUCCEEDED**, app **RUNNING**.
4. **No new grants** — App SP already has schema `MODIFY`/`SELECT`. **No `job_id` re-seed**
   this session (no `seed_alv_reports` run), so bindings are untouched.

### Validate on the live app (Idris)
1. Open a report → **Templates** appears in the left nav. Fill the form → **Save as
   template** → name it → save.
2. **Templates** screen lists it → **Load** → the form is filled from the template →
   Submit/Preview run as usual. **Rename** + **Delete** work.
3. **Owner isolation:** a second user must NOT see your templates (needs a second SSO
   user with access to the same report).
4. Confirm the **Validate** button is gone.

### Tests (all green on the branch)
- 259 backend + 80 library + 10 vitest; tsc + vite build clean.

### Open follow-ups (carried)
- 🔴 Output ownership check (Idris' idea); **7.3** result-cache; **8.4/8.5**; **9.4/9.5**;
  **12.x** governance. **Dynamic templates** (relative D-1/T-1hour) — future, column reserved.
- Tracker item "templates (variants)" → mark Done once validated.

## 2026-08-08 — admin console + ad-hoc user permissions (feat/admin-console-user-permissions) — BUILT, NOT deployed


### What was built (3 slices)
1. **Generalized `report_permissions`** — grain `(report_key, principal_type, principal_name)`,
   `principal_type` ∈ {group, user}, `group_name`→`principal_name`. One table for both grant
   kinds (Idris' call — more efficient than two tables). Gate unions group ∪ user grants;
   user grants match `X-Forwarded-Email` (work even with OBO off). Legacy `group_name`
   manifest still seeds.
2. **Admin backend** — `alv_app/admin.py`: `is_admin` (config `ALV_ADMINS` = emails and/or
   groups; fail closed), bound-SQL grant/revoke/list as the App SP. Endpoints under
   `/api/admin/*`, admin-gated (404 to non-admins), **cache cleared on every write**.
   `/api/me` gained `is_admin`.
3. **Admin UI** — left-nav Admin item (shown when `is_admin`), `AdminPage.tsx`: report
   dropdown + comma-separated principal input + current-grants table with revoke.

### ⚠️ BEFORE DEPLOY — one-time table migration (not automated)
`ensure_all()` only CREATEs, so the live `report_permissions` (2 group rows) needs, ONCE:
```sql
ALTER TABLE classic_stable_lakebase_catalog.alv_metadata.report_permissions RENAME COLUMN group_name TO principal_name;
ALTER TABLE classic_stable_lakebase_catalog.alv_metadata.report_permissions ADD COLUMN principal_type STRING;
UPDATE  classic_stable_lakebase_catalog.alv_metadata.report_permissions SET principal_type = 'group' WHERE principal_type IS NULL;
```
Run via `databricks api post /api/2.0/sql/statements -p fevm-lakebase` (the warehouse is
`f399753196bda967`). Preserves the existing group grants.

### Deploy steps (all 3 slices at once)
1. Run the migration above.
2. `databricks sync src/alv-frontend/backend /Workspace/Users/idris.chakera@databricks.com/alv-frontend-src -p fevm-lakebase`
3. `databricks apps deploy alv-bricks --source-code-path <that> -p fevm-lakebase`
4. `ALV_ADMINS` is already set in `app.yaml` to `idris.chakera@databricks.com`.
5. Validate: Admin item appears in the nav → pick a report → grant a user email → that user
   sees the report; revoke → it disappears.

### Gate facts (carried)
- App SP `4d3d8f3b-3358-4b75-9d32-855ae849ee9f`; warehouse `f399753196bda967`;
  catalog `classic_stable_lakebase_catalog.alv_metadata`; profile `fevm-lakebase`.
- Tests: 227 backend + 79 library + 7 vitest, all green on the branch.

## 2026-08-07 — report-routing fix deployed + `feat/report-group-permissions` MERGED to main

### Where we left off
- **`feat/report-group-permissions` MERGED to `main` and pushed** (merge commit `567087e`,
  `--no-ff`). `main` moved `f1b2d67` → `567087e`. The merge folds in **three** feature
  sets that had accumulated on that branch: report visibility by group, the Downloads
  filters/search/pagination + params view, **and** the new report-routing fix.
- **Report-routing fix deployed and validated by Idris on the live app.** The bug: every
  home card opened the same report (**Retail Ledger** card opened **CC Recharge Data**).
  Three independent defects, all fixed — dropped `reportKey` arg in `App.tsx openReport`,
  index-based auto-pick over the unscoped 28-row tree, and `build_catalogue` merging
  selections by `selection_id` alone. Now: `/report/:reportKey/:alvId?` scoped routing,
  `GET /api/reports?report_key=`, selections keyed by `(report_key, selection_id)`, and an
  explicit `report_key` sort tiebreak. The **entitlements gate is unchanged** — scoping
  narrows within `visible_reports`; unknown/unpermitted/unloaded key all 404.
- **Deployed via the source-code pattern**: `databricks sync src/alv-frontend/backend
  /Workspace/Users/idris.chakera@databricks.com/alv-frontend-src -p fevm-lakebase` then
  `databricks apps deploy alv-bricks --source-code-path <that> -p fevm-lakebase`. Deploy
  state SUCCEEDED / app RUNNING.
- **Code review (Claude, read-only) came back clean** — resolves the symptom for both
  reports, no remaining correctness gaps, tests genuinely guard the invariant (two-report
  backend fixture + Vitest black-box card→report suite; 5 fail against pre-fix code).

### Notes
- The 2026-08-04 gotcha "**the two cards open the SAME merged catalogue**" is now **RESOLVED**
  by this fix (per-report scoping of `/api/reports`).
- **No re-seed happened this session**, so `job_id` bindings are untouched (no re-bind needed).
- Branches `feat/cc-recharge-clone`, `feat/downloads-filters-params` etc. are now ancestors
  of `main` — safe to prune later.

### Open follow-ups (carried forward)
- 🔴 **Output ownership check** — Idris has his own idea; wants it next. `docs/SECURITY_AND_PERMISSIONS.md` §8.
- **7.3** result-cache lookup; **8.4/8.5** status-detail view + failure repair; **9.4/9.5**
  cross-user reuse + expiry; **12.x** governance controls.
- **Flat groups only** — `/Me` returns direct memberships; nesting not resolved.
- **Re-seed caveat** unchanged — any `seed_alv_reports` run nulls all `job_id`s; re-bind after.

## 2026-08-04 — CC Recharge clone + report visibility by group (OBO identity) → pushed, NOT merged

### Where we left off
- **TWO feature branches are pushed to origin but deliberately NOT merged to `main`.**
  `main` is still at `f1b2d67`. Idris wants the pilot fully tested before either merge.
  - **`feat/cc-recharge-clone`** (2 commits: `c94b80b`, `b820645`) — clones Retail Ledger
    into a second report **CC Recharge Data**, and makes the home-page active cards
    **data-driven** (they were hardcoded to a single `ACTIVE_REPORT_KEY`).
  - **`feat/report-group-permissions`** (3 commits: `b1ba148`, `ba95e9a`, `d515a01`) —
    branched **off `feat/cc-recharge-clone`**, so it contains the clone work too.
    Report visibility by workspace group.
- **Both are deployed to the live app and validated by Idris.** The permission gate was
  validated **two ways**: (a) `is_active = false` on a mapping, and (b) removing the user
  from the group itself. Both correctly hid the reports — (b) proves the gate reads the
  **end user's** groups via OBO, not the App SP's.

### The permission design (the important part)
**Selective OBO — user identity for authorization, App SP for data.**
- The user's OBO token (`X-Forwarded-Access-Token`, already injected) is validated
  server-side via **`/Me`**, which returns that user's own `groups` list and needs
  **no admin privilege**.
- The **App SP** still reads `report_permissions`, the catalogue, the preview query,
  the Jobs, `request_log`, and the Volume. Data access did not change.
- **Rejected:** `is_account_group_member()` / `is_member()` (they evaluate the *session*
  user = the SP, and read different group types — live-proved), and SCIM Groups/Users
  lookups (need **workspace admin**; for a non-admin SP the `members` field is
  **silently stripped**, so it would deny everyone quietly).
- `report_permissions` grain = (`report_key`, `group_name`), OR semantics,
  **deny-by-default**, denial returns **404 not 403**, enforced on **write paths too**.
- Full rationale + safeguards: **`docs/SECURITY_AND_PERMISSIONS.md`** (new this session).

### Deploy actions performed this session (for the record)
1. `databricks bundle deploy -t dev -p fevm-lakebase`.
2. `databricks bundle run provision_alv_metadata` — **creates `report_permissions`**
   (it is in `PILOT_TABLES`, so `ensure_all()` emits idempotent DDL).
3. `databricks bundle run seed_alv_report_permissions` — seeded 2 rows:
   `retail_ledger` and `cc_recharge` → **`alv-report_ledger_group`**.
   Verified the `job_id` bindings **survived** (26 → dummy, 2 → sample job, zero NULL).
4. Uploaded 10 runtime files to the app source dir, deleted the stale JS asset.
5. `databricks apps deploy alv-bricks` — startup log confirms `entitlements.py` +
   `permissions_source.py` loaded, cache = 28 reports, no errors.
6. **No `app.yaml` env var was needed, and `user_api_scopes` was NOT touched** (a PATCH
   can return 200 while silently purging the scopes — a documented trap).

### ⚠️ Gotchas for the next session
- **The CLI profile was renamed** from `fevm-classic-stable-lakebase` to **`fevm-lakebase`**.
  The *workspace/host name* is unchanged, so remaining doc references to
  `fevm-classic-stable-lakebase` are correct — only the `-p` flag changed.
- **The two cards open the SAME merged catalogue.** `GET /api/reports` is **not scoped by
  `report_key`**, so it merges all active rows from both reports. This was hidden while
  there was only one report. Needs a small backend fix (`report_key` filter + thread the
  key through the route) for the two cards to be meaningfully separate.
- **Re-seeding `alv_catalog` still nulls all `job_id`s** — re-bind afterwards
  (13+13 → dummy `1044615550343710`; each `agent_item` → `307243391542499`) and restart.
  `report_permissions` is unaffected (its own job).
- **Flat groups only** — `/Me` returns **direct** memberships; nesting is not resolved.

### Open follow-ups
- 🔴 **Output ownership check** — `download` and the request list check report permission
  but **not** `submitted_by`, so a user can fetch another user's output for a report they
  can see. **Idris has his own idea for this and wants to do it next.** No OBO needed.
  Documented in `docs/SECURITY_AND_PERMISSIONS.md` §8.
- Per-report scoping of `/api/reports` (see gotcha above).
- Merge both branches to `main` once the pilot is fully tested.
- Cross-vendor review is switched **off** by Idris' instruction until the pilot is ready.

## 2026-08-03 (later) — preview security hardening + agent_item download job → MERGED to main + deployed

### Where we left off
- **Branch `feat/sample-data-preview` MERGED to `main` and pushed to origin.** App
  deployed to `fevm-classic-stable-lakebase` and **validated end-to-end by Idris**
  (preview shows rows; Submit → Downloads → the downloaded CSV matches the preview).
- **Preview security hardening** (commit `0a0ee8d`): true bound-parameter queries (no
  string interpolation), identifier allowlist, explicit column projection (no `SELECT *`),
  `IN`-list cap, endpoint hygiene + audit log, and the **blocking JSON Schema fix** so the
  seed path accepts `sample_query`. **97 backend + 33 library tests pass.**
- **Coherent download** (commit `d26b9ea`): new Job `alv_sample_report_run`
  (**job_id `307243391542499`**) reads the same `sample_query` block, builds the same
  parameterized WHERE, queries `retail_ledger_sample`, writes CSV to `alv_outputs`, and
  returns the CONTRACT pointer. **Bound to `agent_item` only**; the 13 others stay on the
  dummy job. New Spark-free helper `src/alv-backend/dbx_alv_reports/sample_query/` (+14 unit tests).
  No `submit.py` change (App already sends `alv_id`/`request_no`).

### Deploy actions performed this session (for the record)
1. `databricks bundle deploy -t dev` (synced schema + new job resources).
2. Ran `seed_alv_reports` to load `sample_query` into `alv_catalog` — **this reset all
   14 `job_id`s to NULL** (seeder MERGEs placeholder NULLs).
3. Re-bound `job_id`: `agent_item` → `307243391542499`; the **other 13 → dummy
   `1044615550343710`** (had to restore them after the re-seed).
4. Granted the App SP **`CAN_MANAGE_RUN`** on job `307243391542499`.
5. `databricks apps deploy alv-bricks` to reload `cache.py` (picks up new job_id).

### ⚠️ Gotcha to remember
- **Any re-run of `seed_alv_reports` nulls every `job_id`.** After a re-seed you MUST
  re-apply bindings (13 → dummy, `agent_item` → sample job) and redeploy/restart the App.

### Inputs that return data (July 2026 seed)
- Date From `2026-07-01`, To `2026-07-31`; Agent `AG001` (or `AG001,AG002`);
  Transaction Type `CREDIT` or `DEBIT` (NOT `RECHARGE`). Date range capped at 31 days by
  spec validation.

### Open follow-ups still outstanding
- **7.3** result-cache lookup; **8.4/8.5** status-detail view + failure repair;
  **9.4/9.5** cross-user reuse + expiry; **12.x** governance controls.
- Feature requests (30 Jul): **#2** user auth/groups, **#3** caching (priority),
  **#4** speed/Lakebase, **#5** deploy-prereq guide, **#6** add-a-report worked example.
- Cosmetic: dummy notebook logs `run_id = 'interactive'` in one spot (display-only).

---

## 2026-08-03 — sample data preview + housekeeping on feat/sample-data-preview

### Where we left off

- **Branch:** `feat/sample-data-preview` (commit `8a331e4`). **Not yet pushed to origin / not yet deployed.**
- **Housekeeping done:** `poc/` deleted (work absorbed into production code). `CHANGELOG.md`
  and `CLAUDE.md` remain at repo root (correct per convention); other root directories
  (`app/`, `src/env_parameters/`, `src/report_specs/`, `tests/`) also stay at root per CLAUDE.md
  design intent.
- **New feature: sample data preview.** Full end-to-end implementation:
  - `src/alv-frontend/backend/alv_app/preview.py` (new) — query builder + executor (App SP, no OBO)
  - `POST /api/reports/{alv_id}/preview` endpoint in `main.py`
  - `cache.py`, `models.py`, `catalogue.py` updated to carry `sample_query` / `has_sample_query`
  - Frontend: `usePreviewReport` hook, Preview Sample Data button (validation-gated),
    paginated results table (rows-per-page: 10/25/50/100), CSS tokens
  - `src/report_specs/retail_ledger.input_fields.json`: `sample_query` block added to
    `retail_ledger__detail__agent_item` only (4 param_mappings: date range + agent IN +
    transaction_type IN; 9 display columns)
  - `src/alv-backend/seed_sample_data.ipynb` — DAB driver; creates + seeds `retail_ledger_sample`
    (300 deterministic telco rows: 5 agents, 6 item types, 4 circles, dates 2025-01-01
    to 2025-06-30)
  - `resources/seed_sample_data.job.yml` — DAB job for the seeder
  - **82 pytest pass** (9 new preview tests, all green)
  - Frontend `npm run build` clean

### What to do next
1. **Deploy** the feature: run `seed_sample_data` DAB job first (creates the table),
   then `databricks apps deploy alv-bricks` with the updated source.
2. **Validate** in the browser:
   - Go to Retail Ledger → Detail → Agent Item
   - Fill dates: `2025-01-01` to `2025-03-31`, agent: `AG001` (or `AG001,AG002`)
   - Click "Preview Sample Data" — should return ~45 rows
   - Other report types: button should be greyed (no sample_query defined)
3. **Push to feature branch** once validated: `git push origin feat/sample-data-preview`
4. **Merge to main** and update tracker.

### Input to give the sample table to get data back
- Transaction Date From: `2025-01-01`
- Transaction Date To: `2025-03-31`
- Agent: `AG001` (or comma-separated: `AG001,AG002,AG003`)
- Transaction Type: `CREDIT` (or `CREDIT,DEBIT`)
- Date range limited to 31 days by spec validation — stay within that.

### Open follow-ups still outstanding
- **7.3** result-cache lookup (deferred)
- **8.4/8.5** status-detail view, failure repair (deferred)
- **9.4/9.5** cross-user reuse, expiry (deferred)
- **12.x** governance controls (deferred)
- Cosmetic: dummy notebook logs `run_id = 'interactive'` in one spot (display-only)

---

## 2026-07-30 (later) — followups deployed + big UI pass, all on main

Follows the "Downloads page + UI polish" session below. This pass shipped the two
open followups **and** a second wave of UI work, all merged to `main` and deployed.

### Where we left off
- **Followups 1 & 2 built + merged** (`main` @ `c3d95a7`): (1) `submitted_by` now
  logs the **human email** (`_submitted_by(ident)` = `email or preferred_username or
  user_id`); (2) **status polling / task 8.x** — `get_run_status()` + `update_status()`
  + `GET /api/requests/{request_no}/status`, frontend `useRequestStatus` polls
  non-terminal Downloads rows so **QUEUED→SUCCESS advances live**. Built in isolated
  worktrees, merged conflict-free.
- **submitted_by regression caught + fixed by redeploy.** The `1e01a9a` UI deploy had
  been cut from *before* the followups, so deploying it **reverted** the email fix (live
  app briefly logged numeric ids again). Root cause = deploy lag, not a code bug.
  Re-deployed `main` so email + polling + UI are all live together.
- **Selection-in-main + nav pass merged** (`main` @ `4fc0522`): Selection moved from the
  left navbar **into the main page** (screenshot-2 style), left navbar repurposed for
  **Home/Downloads app nav** that is **collapsible** (icon rail) + **drag-resizable**
  (persisted), **auto-select** first selection+report, pilot notice text removed.
- **Routing + nav polish merged** (`main` @ `c325d75`, current tip): (1) collapse toggle
  **centered** in the rail; (2) default nav width **240→160px** (still resizable); (3)
  **breadcrumb** `Home › <report>` with Home clickable; (4) **URL routing** via
  `react-router-dom` **HashRouter** (browser Back/Forward walk views; no backend change
  since FastAPI serves the SPA) **+ preserved unsubmitted form state** (`FormDraftProvider`
  keyed by `alv_id` survives nav/unmount; TanStack cache prevents refetch flash).
- **Deployed & live** at https://alv-bricks-7474646826130163.aws.databricksapps.com
  (latest deployment from `c325d75`/`85d362c` tree). Health 200, runnable_count 14.
- **request_log cleaned** — purged the **6 test rows** with numeric `submitted_by`;
  kept the **2** real-email rows. (Old numeric rows were pre-fix; new submits log email.)
- **Git housekeeping** — merged-then-deleted `feat/ui-routing-nav-polish` (remote+local).
  `feat/ui-selection-in-main` (`e67d261`) and `feat/followups-1-2` (`339d552`) **confirmed
  merged** into `main` (safe to prune); `feat/app-skeleton-and-deploy` +
  `feat/ui-polish-darkmode` also merged and still on origin. Local `main` synced to origin.
- Gates through the pass: backend **55 pytest pass**; frontend `tsc`+`vite build` clean.

### Download functionality (task 9.x) — DONE, merged, deployed, live-tested
- **App-proxied UC-Volume download** shipped on `feat/download-functionality` (`9453876`),
  merged to `main` (merge `4dc0277`), deployed (`01f18bfe…`), and **live end-to-end
  tested by Idris** (submit → QUEUED → COMPLETED → download the CSV).
- Backend: new `GET /api/requests/{request_no}/download` streams the Volume file as the
  app SP via the SDK Files API (1MB chunks); `409` no-output / `422` non-Volume path /
  `502` read-fail / `404` missing row; only the basename is exposed. **Output capture is
  folded into the 8.x status seam** — when a poll resolves SUCCESS it resolves
  `tasks[0].run_id` → `get_run_output` → parses the `notebook.exit` JSON per CONTRACT,
  persists `output_path`/`row_count`/`generated_at`, and settles the row to **COMPLETED**
  (SUCCESS normalizes to COMPLETED at the endpoint boundary). Truncated/missing/FAILED →
  status FAILED, output null, never crashes. **73 pytest pass.**
- Frontend: Download button is now a real `<a download>`, enabled only when a row is
  COMPLETED with a captured `output_path`.
- App SP already had `READ_VOLUME` on `alv_outputs` — no new grants.
- **Tracker:** 8.1/8.2/8.3 + 9.1/9.2/9.3 marked Done.
- Note: the 2 pre-existing email rows have no `output_path` (submitted before capture
  existed) so their Download stays disabled; only new submits light it up.

### Worktree/branch housekeeping
- `feat/download-functionality` merged; its worktree removed. Local `main` synced.
- Merged branches still on origin: `feat/app-skeleton-and-deploy`, `feat/ui-polish-darkmode`,
  `feat/ui-selection-in-main`, `feat/followups-1-2` (all confirmed ancestors of `main`).
  `feat/ui-routing-nav-polish` + `feat/download-functionality` local task branches can be pruned.

### Open follow-ups (still open)
- Cosmetic: dummy notebook logs `run_id = 'interactive'` in one spot (display-only;
  real run_id captured in `request_log`).
- **7.3 result-cache lookup** still deferred.
- Governance controls **12.x** later.

---

## 2026-07-30 — Downloads page + UI polish + dark mode MERGED to main

Follows the "home cards + submit" session below. This pass added the **Downloads
page**, a **full UI polish** pass, and **dark mode**, then merged everything to
`main`.

### Where we left off
- **Downloads page** — backend `GET /api/requests` (recent `request_log` rows, cap
  100, same warehouse seam, degrade-to-empty) + a frontend table (Request No, Report,
  Status, Submitted By, Submitted At + a **disabled Download stub** — real proxy is 9.x).
- **Persistent top nav** — header now rendered **once at the app-shell level**, so its
  nav survives every view change and **back-navigation works from any view**. Nav links
  moved to the **right**, just before "Welcome, {user}", with **active-view
  highlighting**. Removed the **"Databricks SSO · SP ✓"** header text.
- **UI polish** — design tokens (color/type/spacing/radius/shadow) in `index.css`,
  Databricks **lava `#FF3621`** accent used sparingly, polished header/cards/form/
  downloads table, **QUEUED** badges, loading skeletons/spinners, empty states.
- **Dark mode** — sun/moon toggle top-right; token-based full theme inversion
  (`[data-theme="dark"]`); **localStorage-persisted** with a before-paint inline
  script in `index.html`. New `theme.ts` + `ThemeToggle.tsx`.
- **Git flow** — `feat/ui-polish-darkmode` merged into `feat/app-skeleton-and-deploy`,
  then merged into **`main`** (merge `1205eb2`). **`main` is now the mainline** — app
  skeleton, metadata read path, submit → `request_log`, downloads page, UI polish +
  dark mode. **Both feature branches retained on origin.**
- Verified locally: backend **37 pytest pass**; frontend `npm run build` passes;
  `backend/static` rebuilt.

### Open follow-ups (still open — not done)
- `submitted_by` logs the **numeric SSO subject, not the email** — resolve to email/UPN.
- **Status stays `QUEUED`** — no **status polling (8.x)** yet; **result-cache lookup
  (7.3)** and **output download/proxy (9.x)** still deferred (Download button is a stub).
- Cosmetic: the dummy notebook logs **`run_id = 'interactive'`** in one spot
  (display-only; the real `run_id` is captured in `request_log`).

---

## 2026-07-29 — home cards + submit DEPLOYED + live-tested

Follows the "build + local test" session below — the same commit is now **deployed
and live-tested end-to-end**.

### Where we left off
- **Read path** (catalogue + metadata-driven form): done + deployed.
- **Home cards + submit**: done + deployed + **live-tested** — a UI submit round-trips
  a `request_no`, the dummy job runs **SUCCESS**, and a CSV lands in the UC Volume.
- Branch `feat/app-skeleton-and-deploy` pushed at **`bae73a5`** (human pushes/merges).
- Workspace **fevm-classic-stable-lakebase**, warehouse **`f399753196bda967`**,
  catalog **`classic_stable_lakebase_catalog.alv_metadata`**.
- **App SP grants applied:** schema `MODIFY`, Volume `READ`/`WRITE` on `alv_outputs`,
  job `CAN_MANAGE_RUN`; all **14 `job_id`s bound** to the dummy job **`1044615550343710`**.
- A **Downloads page** is being added concurrently by another sub-agent on this same
  branch/worktree.

### Open follow-ups
- `submitted_by` logs the **numeric SSO subject, not the email** — resolve to email/UPN.
- **Status polling (8.x) not built**; **result-cache lookup (7.3)** deferred to later.
- Cosmetic: the dummy notebook logs **`run_id = 'interactive'`** in one spot (display-only bug).

---

## 2026-07-29 — home cards + submit (build + LOCAL test only, NOT deployed)

> Superseded by the session above — this pass built the code; it was subsequently
> deployed and live-tested. Kept for the build detail.

Built on `feat/app-skeleton-and-deploy` (no branch/PR/deploy — human deploys).

### Part 1 — Home page report cards
- Backend: `GET /api/report-groups` → distinct seeded reports
  `(report_key, report_label, runnable_count)` from the metadata cache (no SQL on
  render). `runnable_count` = active rows with a bound `job_id` (0 for all 14 now).
  `ReportGroupsOut` model; `cache.report_groups()` + `catalogue.build_report_groups()`.
- Frontend: new `HomePage` card grid (screenshot 1). Active **Retail Ledger** card is
  data-driven (from report-groups) → opens the existing catalogue UI, now one level
  down. Greyed non-clickable placeholders (frontend-static, names from screenshot 1):
  **BNP ABAP ALV - Spark Configuration Parameters**, **CI Recharge Data**,
  **Estel Recharge Data**, **CC Recharge Data**, **BLAI Wise Statement of Account - RJIL**.
  Simple view routing in `App.tsx` (home ↔ report); header brand links back home.

### Part 2 — Dummy job + submit
- **7.1/7.2/7.4/7.5** `POST /api/reports/{alv_id}/submit`: builds `{param:value}`
  payload (normalize/omit_if_blank/default) → canonical JSON + SHA-256 `param_hash`
  → INSERT `request_log` QUEUED row (warehouse statement-exec as app SP, parameterized)
  → `jobs run-now` on the bound `job_id` (SP WorkspaceClient) → UPDATE `run_id` →
  return `request_no`. **409** when `job_id` NULL. NO 7.3 cache check, NO 8.x polling.
  New modules: `submit.py`, `request_log.py`; `trigger_job_run` in `databricks_client.py`.
  `catalog_source`/`cache` now read `job_id`/`job_run_mode`. Frontend Submit wired
  (was disabled) → shows `request_no` + QUEUED; validation still gates submit.
- **Dummy job** (stand-in for RIL, ONE job for all 14 rows):
  `resources/alv_dummy_report_run.job.yml` (serverless, env v4) + `src/alv-backend/alv_dummy_report_run.ipynb`
  (six-step driver; parameterized catalog/schema/volume/output_dir — no hardcoded
  volume; writes dummy CSV to a UC Volume; returns pointer via `dbutils.notebook.exit`
  per CONTRACT.md). **Not deployed/run.**

### Part 3 — Prereqs doc
- `docs/APP_PREREQUISITES.md`: operator checklist. NEW grants this pass = schema
  **MODIFY** (request_log writes), **Volume READ/WRITE**, job **CAN_MANAGE_RUN**;
  already-applied = USE CATALOG/SCHEMA, SELECT, warehouse CAN_USE. Includes the exact
  `UPDATE alv_catalog SET job_id=<DUMMY_JOB_ID> WHERE report_key='retail_ledger'` (14 rows).

### Verified (local, no deploy)
- Backend `uv run pytest`: **35 passed** (20 baseline + 15 new: report-groups,
  submit payload/normalize/omit/default, param_hash canonicalization, request_log
  INSERT + run-now wiring, job_id-NULL 409). Warehouse exec + run-now mocked.
- Frontend `npm install --registry=<proxy>` + `npm run build` (tsc+vite): **pass**;
  `src/alv-frontend/backend/static` rebuilt (committed).
- `requirements.txt` unchanged — submit path adds only stdlib (hashlib/uuid/json) +
  the already-pinned databricks-sdk.

### Needs your decision / next
- Bind the 14 `job_id`s after deploying the dummy job (SQL in APP_PREREQUISITES.md) +
  apply the NEW grants, then restart the app so the cache reloads job_ids.
- Not built (out of scope this pass): 7.3 result-cache lookup, 8.x status polling,
  9.x output download/proxy. A later GET handles status.

## 2026-07-29 — end of day

### Deployed & live
- **Metadata framework** deployed to workspace `fevm-classic-stable-lakebase`
  (CLI profile `fevm-lakebase`), catalog `classic_stable_lakebase_catalog.alv_metadata`:
  `alv_catalog` (**14 rows**) + `request_log`; `provision` + `seed` jobs ran SUCCESS.
- **App** deployed via Databricks Apps **source-code** pattern (NOT git-source DABs —
  decided against). Live + RUNNING:
  **https://alv-bricks-7474646826130163.aws.databricksapps.com**
  (`/api/health` 200, `/` serves the React shell, `/api/me` resolves real SSO identity).
  - Deploy layout: source root = `src/alv-frontend/backend/`, Vite builds into `backend/static`,
    FastAPI mounts static at `/` after `/api`, binds `$DATABRICKS_APP_PORT`.
  - Apps gotchas applied: `requirements.txt` (Apps ignores uv.lock — keep in sync on
    dep bumps), NO root-level `package.json`, committed built assets, StaticFiles mount.

### Tasks done (tracker updated)
- **1.1, 1.2** — App skeleton (FastAPI+uv backend, React/Vite/TS+TanStack frontend, SSO identity).
- **2.1, 2.2, 2.4, 2.5, 2.6** — metadata layer (schema, alv_catalog, request_log, parser, seed 14 rows).
- **11** — Job→App path-return POC. Recommendation: Job ends with
  `dbutils.notebook.exit(json.dumps(pointer))`; App reads via `runs/get-output →
  notebook_output.result`. §4.2 = App-proxied download from a UC Volume. See
  `poc/job_path_return/CONTRACT.md`.
- **13.1–13.4** — (new tracker group "Project ops & deployment") docs convergence,
  framework deploy, app deploy, repo hygiene. 13.5 = keep requirements.txt/uv.lock in sync (ongoing).

### DONE (committed, awaiting review) — read path (tasks 3.1, 3.2, 4.1, 4.2, 5.1–5.4)
The read-path sub-agent finished and pushed itself. **Commit `a55671a`** on
`feat/app-skeleton-and-deploy` (working tree clean, in sync with origin).
- Backend: startup metadata cache + `GET /api/reports` (catalogue list) +
  `GET /api/reports/{alv_id}` (render-ready form def), served from cache.
  `catalog_source.py` (SDK statement-exec seam, env-configurable), `fields.py`
  (app-local parser honoring the same input_fields.schema.json — deliberately did
  NOT import dbx_alv_reports, since Apps deploy root = src/alv-frontend/backend/ only and the
  library pulls a Spark chain), `cache.py` (graceful lazy miss).
- Frontend: catalogue nav (selection → report type → form), metadata-driven render
  (controls per selection_type/data_type incl. composite ranges), client-side
  validation from the metadata `validations` vocab, message_key → text map.
  Submit is a DISABLED placeholder (run trigger = task 7.x); a "Validate" button runs checks.
- Verified: 20 pytest pass (14-row fixture, warehouse mocked); `npm run build` passes;
  `backend/static` rebuilt + committed; live-checked against warehouse f399753196bda967
  (14 rows, 4 selections 3/5/5/1, forms render, validation works).
- **NOT deployed** — deploy the App update after review.

**Two decisions the agent flagged (non-blocking) — for you to call on resume:**
1. `message_key` catalogue (task 2.2) isn't delivered yet — agent hardcoded the 6
   pilot keys in `frontend/src/messages.ts` with a graceful fallback. Keep as stopgap,
   or fetch from backend?
2. `allowed_values` dropdowns (5.3): the current contract has NO enumerated-options
   field (D-IFJ-8 removed the report_type radio), so all 14 rows are free-text/date/time —
   ZERO dropdowns in the pilot. Agent built a forward-looking `<select>` hook for if
   `allowed_values` ever appears. Confirm that's the intended contract.

On resume: cross-review is still DUE on this read-path commit, then deploy + smoke-test.

### Repo state
- Branch: `feat/app-skeleton-and-deploy` (pushed through `766a39a`; read-path commit
  lands on top when the agent finishes). No PR opened, nothing merged — human merges.
- Rules in force: Databricks-grounded (Claude skills), no branches/PRs or deploys
  without explicit ask, claude-only workers.

### Next up (recommended order)
1. Answer the two flagged decisions (message_key source, allowed_values contract).
2. Cross-review the read-path commit `a55671a`; deploy the App update (source-code
   pattern); smoke-test the catalogue + form against the live 14 rows.
3. Mark 3.1/3.2/4.1/4.2/5.1–5.4 done in the tracker.
4. Then submission/status/output path: 7.x → 8.x → 9.x (grounded on task 11's CONTRACT.md).
5. Governance controls 12.x later.
