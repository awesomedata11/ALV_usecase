# Output-file preview (view a completed run's result on-screen) — approach

> **Status: BUILT + DEPLOYED (2026-08-18).**
> On branch `feat/output-file-preview` (from `main`). All `[DECIDE]` items signed off
> (§7). Deployed to `fevm-classic-stable-lakebase`; **awaiting live validation** before
> merge. Decisions applied: button label **"Preview"**; row cap **1000** / byte ceiling
> **8 MiB**; CSV parse with **raw-text fallback** (+ a **binary** notice); a **routed
> screen** (`/downloads/:requestNo/preview`); a **dedicated `OutputPreviewOut`** shape
> (PreviewOut fields + `format`/`text`/`filename`). Multi-file is **backlog** — see
> `MULTI_FILE_DOWNLOAD_APPROACH.md`.

## Goal

Today a completed run on the Downloads page offers two actions: **Parameters** (the
effective job payload) and **Download** (stream the output file to the browser). There
is no way to *look at* the result without downloading it and opening it locally.

Add a third action — a compact **"View Sample Data"**-style button placed **between
Parameters and Download** — that opens a new screen showing the first rows of the run's
generated output file, read straight off the UC Volume.

---

## 1. What this is NOT — the existing "Preview Sample Data" is a different feature

There is already a **Preview Sample Data** button, but it is a fundamentally different
mechanism and must not be confused with this one:

| | Existing "Preview Sample Data" (on the report FORM) | This feature (on the DOWNLOADS page) |
|---|---|---|
| **Where** | Report form, before submitting | Downloads row, after a run COMPLETED |
| **Data source** | A **parameterized SQL SELECT** against a shared dummy table `retail_ledger_sample` | The **actual output file** the run wrote to the UC Volume (`request_log.output_path`) |
| **What it shows** | What the report *would* return for the entered filters (an illustrative sample) | What this specific run *did* return — the real deliverable |
| **Backend** | `alv_app/preview.py` → `build_preview_sql` → warehouse `execute_statement` | Reads the Volume file via the Files API (like the download path) |
| **Gate** | `report_permissions` on the `alv_id` | `report_permissions` on the run's report (`_require_request_permission`) |
| **Config dependency** | Requires a `sample_query` block in `input_fields_json` (present on 1 of 14 rows) | None — works for any completed run with a captured `output_path` |

**Key point:** this feature runs **no SQL**. It parses bytes off a file. It is the
read-only, on-screen twin of the existing **Download** action, sharing that path's
permission gate and Volume-read plumbing.

---

## 2. Current-state building blocks (what we reuse)

The download path already has everything except the parse + render:

| Building block | Where | Reuse |
|---|---|---|
| Permission gate for a `request_no` | `main.py` `_require_request_permission()` (line 1371) | Call it verbatim — parameters are as sensitive as the file. |
| Volume read as the App SP | `databricks_client.py` `download_volume_file()` (line 287) — `w.files.download` returns a streamable file-like | Read a **bounded** slice instead of the whole file. |
| Row lookup (`output_path`, `alv_id`) | `main.py` `fetch_request()` used by the download endpoint (line 1649) | Same lookup. |
| Volume-path guard (`/Volumes/...` only), filename derivation | `main.py` download endpoint (lines 1671–1678) | Same guards → same 409 / 422 / 502 error shape. |
| Downloads-row actions cell | `DownloadsPage.tsx` `RequestTableRow` (line 222) — `[Parameters] [Download]` | Insert the new button between them. |

The download endpoint reads the **whole** file (`contents.read(1 MB)` in a loop, line
1690). Preview must read only a bounded prefix so a 1,000,000-row export never buffers
in the App tier.

---

## 3. Design options

### 3a. Where the file is parsed

**Option A — parse on the backend (recommended).** A new endpoint reads a bounded byte
prefix off the Volume, parses CSV, and returns `{columns, rows, row_count, truncated}` —
the **same response shape as the existing preview** (`PreviewOut`), so the frontend can
reuse the results-table component almost unchanged.
- ✓ Consistent with the existing preview UI; one table renderer for both.
- ✓ The raw file bytes never reach the browser (only parsed, capped rows) — tighter
  than even the download path.
- ✓ Malformed rows handled server-side; the client always gets clean JSON.
- ✗ Backend owns CSV parsing (delimiter, quoting, header).

**Option B — stream raw bytes, parse in the browser.** Reuse the download endpoint with
a `?preview=true`/range and parse client-side.
- ✓ No new backend parse code.
- ✗ Ships raw file bytes to the browser; duplicates parsing logic; harder to bound.

**Verdict:** Option A. It matches the existing preview contract and keeps the raw file
server-side.

### 3b. How much of the file to read

The output can be up to the download job's 1,000,000-row ceiling. Preview must be
bounded two ways:

1. **Byte cap on the Volume read** — read at most `PREVIEW_MAX_BYTES` (e.g. 2 MB) from
   the file, never the whole thing. Drop a trailing partial line unless we hit EOF.
2. **Row cap after parse** — return at most `PREVIEW_MAX_ROWS` (e.g. 500, matching the
   existing preview cap) and set `truncated=true` when more exist.

Both caps apply; whichever bites first wins. `truncated` drives an honest "showing the
first N rows of this file — download for the full result" note.

### 3c. New screen vs modal

The user asked for a **new screen**. The app already uses HashRouter with deep-linkable
routes and a `Breadcrumb`. A route (`/requests/:requestNo/preview` or
`/downloads/:requestNo/preview`) is consistent, shareable, and gives Back/Forward for
free — preferred over a modal.

### 3d. File format

The pilot's jobs (dummy + `alv_sample_report_run`) both write **CSV**. Recommend: parse
CSV (header row → columns; comma delimiter), with a **raw-text fallback** — if the file
does not parse as CSV, show the first N lines as monospace text rather than erroring.
Non-CSV binary formats (parquet, xlsx) are out of scope for the pilot preview.

---

## 4. Recommended approach

**Backend — new endpoint `GET /api/requests/{request_no}/output-preview`:**

1. `fetch_request()` → row; `_require_request_permission()` gate (404 on deny).
2. Guards mirror the download endpoint: `409` no `output_path`; `422` non-`/Volumes/`
   path; `502` read failure.
3. Read a bounded prefix (`PREVIEW_MAX_BYTES`) via a Volume read (a bounded variant of
   `download_volume_file`, or the same call with an early `.read(n)` and close).
4. Parse CSV → `columns` + `rows`, cap at `PREVIEW_MAX_ROWS`, compute `truncated`.
5. Return `PreviewOut`-shaped JSON (`{columns, rows, row_count, truncated}`) plus
   `filename` and `format` (`"csv"` | `"text"`).

**Frontend:**

- New button in `RequestTableRow`'s actions cell, **between Parameters and Download**,
  enabled only when the row is COMPLETED with an `output_path` (same `ready` gate the
  Download button uses). Disabled otherwise with a "no output yet" hint.
- New route + screen (`OutputPreviewPage.tsx`) with `Breadcrumb`
  (`Home › Downloads › Preview`), reusing the existing paginated results-table styling
  from the form preview, plus a "download for the full result" link when `truncated`.
- New `useOutputPreview(requestNo)` hook.

**Button name.** The user proposed "View Sample Data". That collides with the form's
"Preview Sample Data" and this shows the *real* result, not a sample. Compact
alternatives — see `[DECIDE] 1`. Recommendation: **"Preview"** (or "View Output").

---

## 5. Security

Same posture as the download path — this is the download path minus the bytes leaving
the server:

- **Authorization:** identical `_require_request_permission()` gate; **404, not 403** on
  deny; checked before any byte is read.
- **App-SP read only:** the file is read via the Files API as the App SP; the raw
  storage path is never exposed (only a derived filename), and now not even the raw
  bytes — only parsed, capped rows.
- **Path guard:** only `/Volumes/...` paths are read (422 otherwise), unchanged.
- **Bounded read:** the byte + row caps prevent a huge file from exhausting App memory —
  a stricter guarantee than the streaming download.

No new grants (the App SP already holds `READ VOLUME` on `alv_outputs`). Document the
caps in `SECURITY_AND_PERMISSIONS.md`.

---

## 6. Interaction with multi-file runs

`docs/MULTI_FILE_DOWNLOAD_APPROACH.md` (also PLANNING) proposes runs that write a
directory of files. If that lands, `output_path` may be a directory. Preview would then
need to pick a file (the first, or a chosen one) to show. For the pilot's single-file
runs this does not arise. See `[DECIDE] 4`.

---

## 7. Open decisions for the product owner

### [DECIDE] 1: Button label

The current "Preview Sample Data" (form) shows a SQL sample; this shows the real result
file. Reusing "View Sample Data" would be misleading.
- **Option A (recommended):** **"Preview"** — compact, unambiguous next to Download.
- **Option B:** **"View Output"** / **"View Result"**.
- **Option C:** keep **"View Sample Data"** as the user first suggested.
A - option A works

### [DECIDE] 2: Row and byte caps

- Row cap: **500** (matches the form preview) — or higher (1000)?
- Byte cap on the Volume read: **2 MB** — enough for a few hundred wide CSV rows?
A: 1000 rows should be default cap

### [DECIDE] 3: Non-CSV / unparseable files

- **Option A (recommended):** parse CSV; fall back to a raw first-N-lines text view if
  it does not parse.
- **Option B:** CSV only; show a "preview not available for this file type" message
  otherwise.
option A looks good
### [DECIDE] 4: Multi-file runs (only if `MULTI_FILE_DOWNLOAD_APPROACH` lands first)

- Preview the **first** file automatically, or show a file picker before the table?
  (No impact on the single-file pilot; decide when multi-file is built.)
A - dont worry about the multi file, its backlog item, once i start developing for it, i will handle it. put a note in the 'git repo/alv-bricks/docs/MULTI_FILE_DOWNLOAD_APPROACH.md' about this 

### [DECIDE] 5: New screen route vs modal

- **Option A (recommended):** a routed screen (`/requests/:requestNo/preview`),
  deep-linkable, with Back/Forward.
- **Option B:** an in-page modal over the Downloads table.
option a

### [DECIDE] 6: Endpoint response shape

- **Option A (recommended):** reuse the existing `PreviewOut` shape
  (`{columns, rows, row_count, truncated}`) + `filename`/`format`, so the frontend
  reuses the preview table.
- **Option B:** a bespoke shape.
whatever is more efficient and apt according to you. 

---

## 8. Proposed implementation tasks (after sign-off)

1. **Backend read helper** — a bounded Volume read (byte cap) reusing
   `download_volume_file` plumbing; a CSV parser with header + raw-text fallback
   (Spark-free, unit-testable).
2. **Endpoint** — `GET /api/requests/{request_no}/output-preview`: gate → guards
   (409/422/502) → bounded read → parse → `PreviewOut`-shaped response.
3. **Models** — `OutputPreviewOut` (or reuse `PreviewOut` + `filename`/`format`).
4. **Config** — `PREVIEW_MAX_BYTES` / output-preview row cap in `config.py` + `app.yaml`.
5. **Frontend** — `useOutputPreview` hook; the new button in `RequestTableRow`
   (between Parameters and Download, gated on `ready`); `OutputPreviewPage.tsx` + route +
   breadcrumb; reuse the preview results table; "download for full result" on `truncated`.
6. **Tests** — backend: gate (404), 409/422/502 guards, byte + row cap / truncation,
   CSV parse + raw-text fallback, partial-last-line drop. Vitest: button gated on
   COMPLETED+output, screen renders parsed rows.
7. **Docs** — `SECURITY_AND_PERMISSIONS.md` (caps + posture), `METADATA_TABLE.md` if any
   contract note, `CHANGELOG.md`, README.

---

## 9. Related documents

| Document | Relevance |
|---|---|
| `src/alv-frontend/backend/alv_app/main.py` | Download endpoint (1623), params endpoint (1265), `_require_request_permission` (1371) |
| `src/alv-frontend/backend/alv_app/databricks_client.py` | `download_volume_file()` (287) — the Volume read to bound |
| `src/alv-frontend/backend/alv_app/preview.py` | The existing SQL-based preview — the response shape to mirror, the mechanism to contrast |
| `src/alv-frontend/frontend/src/components/DownloadsPage.tsx` | The actions cell (222) where the button goes |
| `docs/MULTI_FILE_DOWNLOAD_APPROACH.md` | Multi-file interaction (`[DECIDE] 4`) |
| `docs/SECURITY_AND_PERMISSIONS.md` | Gate + Volume-read posture; will document the caps |
