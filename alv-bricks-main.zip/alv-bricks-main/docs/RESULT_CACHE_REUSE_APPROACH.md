# Result cache + reuse — approach

> **Status: IMPLEMENTED** (branch `feat/result-cache-reuse`, task 7.3). Built to the
> **defaults** of every open decision below (Option A pre-submit endpoint, Option A "point
> to the existing run", show submitter + timestamp, cross-user reuse on, param_hash computed
> server-side, no separate audit event). The added edge case (latest wins) is enforced by
> the lookup's `ORDER BY generated_at DESC ... LIMIT 1`. See the implementation notes at the
> foot of this file.
>
> _Historical: this began as an approach document; the [DECIDE] markers below are retained
> for the record and resolved to their stated defaults._

## Goal

When a user submits a report with parameters that were already run (by them or anyone
else with whom they share the report permission) within the last 7 days, the App should
NOT blindly rerun the job. Instead, detect the prior run and present a popup offering
the user two choices: **rerun the job** (normal path) or **reuse the existing output
file**. This avoids redundant computation and delivers results immediately.

The feature is optional: a user who does not interact with the popup defaults to a
normal rerun (backward-compatible).

## How the app works today (baseline the design must fit)

- **Report submission.** A user fills a report's form, clicks Submit, and
  `src/alv-frontend/backend/alv_app/submit.py` builds a canonical payload
  (`build_param_payload`), normalizes it to JSON with stable key order
  (`canonical_param_json`), computes a SHA-256 digest (`param_hash`), and writes an
  initial `request_log` row with `status=QUEUED`. The Job is then triggered. See
  `submit.py` lines 1–34 for the deferred cache lookup note.

- **Request log tracking.** Every submission writes one `request_log` row with
  persisted columns: `request_no` (PK), `alv_id`, `param_hash`, `status`, `submitted_by`,
  `output_path`, `generated_at`, `expires_at`, etc. The `param_hash` is a stable cache
  key with `alv_id` (`docs/METADATA_TABLE.md`, line "Cache key = (alv_id, param_hash)").

- **Output retention.** Once a run reaches SUCCESS, `src/alv-frontend/backend/alv_app/request_log.py`'s
  `update_status` function writes `generated_at` and `output_path`, and **derives**
  `expires_at = generated_at + RESULT_TTL_DAYS` (default 7 days; `request_log.py`
  line noting "Groundwork for the later result-cache feature"). The `expires_at` is
  **already populated** in deployed tables.

- **Downloads + visibility.** The downloads page reads `request_log` rows through
  `src/alv-frontend/backend/alv_app/downloads.py`. The read path applies the same
  `report_permissions` gate used everywhere else: a user sees a report's runs only if
  they hold the report permission (either via a group grant or a direct user grant).
  Rows are filtered in SQL before pagination (`downloads.py` "Filtering happens in SQL,
  before the limit"), and `submitted_by` is visible, not masked.

- **Cross-user visibility.** Per `docs/SECURITY_AND_PERMISSIONS.md` section 8
  ("Output ownership — RESOLVED AS INTENDED"), cross-user output access is **intended
  behavior**. If users A and B both hold the same report permission (e.g., they are in
  the same group), they **both see each other's runs** for that report. The rule:
  "`report_permissions` group gate is the **only** authorization control" — being
  permitted on a report grants access to that report's runs, regardless of who submitted
  them. Consequently, **there is no owner-only restriction on the download path**.

- **Modal pattern.** The frontend already uses modals (e.g. `SaveTemplateModal.tsx`);
  the UX pattern for confirmation dialogs is established.

## Definition: cache hit

A cache hit is a prior `request_log` row that meets ALL of the following:

| Criterion | Note |
|---|---|
| **Same `alv_id`** | The submitted report matches exactly. |
| **Same `param_hash`** | The parameters, normalized and canonical, are identical. See "Canonicalization" below. |
| **Status = `COMPLETED`** | The prior run finished successfully. `QUEUED`, `RUNNING`, `FAILED`, `EXPIRED` do not match. |
| **Non-null `output_path`** | The output file pointer is recorded (not all SUCCESS runs may have this). |
| **`now < expires_at`** | The output is still within its retention window (default 7 days from generation). |
| **Permitted to caller** | The reuse candidate passes the same `report_permissions` gate as any other run access (section "Security" below). A caller without permission to see the report gets no hit. |
| **Most recent** | If multiple hits exist (e.g., the same report run twice in one week), pick the row with the newest `generated_at`. |

### Canonicalization

The `param_hash` is computed by `submit.py` exactly once per submission:

```python
canonical_json = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
param_hash = hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()
```

The payload itself comes from `build_param_payload`, which:
- Applies the field's `normalize` ops (trim, uppercase, lowercase) in order.
- Drops blank `omit_if_blank` fields entirely.
- Substitutes a `default` for blank non-omit fields.
- Preserves non-blank values post-normalization.

So two submissions are cache-equal iff:
1. They carry the same set of fields at the report (`alv_id`).
2. For each field, the RAW form values normalize to the same normalized value.

**Note:** Because normalization happens before the payload is built, a user who submits
with different whitespace, case, or blank-vs-missing variations in a field will
nonetheless get a cache hit if the normalized result is the same. This is correct and
intended — it prevents redundant runs even when form input varies trivially.

## Flow design

### 7.3.1 Where the check happens — **[DECIDE]**

Two architectural options:

**Option A: Pre-submit lookup endpoint**
- New endpoint `GET /api/reports/{alv_id}/cache-check` (or `POST` if easier to receive the
  full normalized parameters).
- Called by the frontend AFTER the user submits but BEFORE triggering the backend submit
  (a new pre-submit step in the flow).
- Returns `{ candidate?: RequestLogRow, ... }` or a `"no_hit"` response.
- If a hit is found, the frontend shows the popup; the user chooses rerun or reuse.
- **Pro:** clean separation; cache check is isolated; easy to test and reason about.
- **Con:** adds a round-trip; two separate API calls (cache-check then submit or download).

**Option B: Inside submit, return "needs confirmation" response**
- Extend the submit endpoint to check the cache internally.
- If a hit is found, return `202 Accepted` (or `409 Conflict`?) with the candidate info
  embedded, signaling "decision needed".
- The frontend shows the popup; the user chooses rerun or reuse.
- If reuse is chosen, the frontend issues a second request to finalize the reuse (see
  decision 7.3.2).
- **Pro:** single POST; no extra round-trip on the normal path.
- **Con:** submit endpoint behavior is now conditional; harder to reason about (the
  endpoint sometimes returns a "decision needed" instead of queuing the job).

**Recommendation:** **Option A** (pre-submit lookup endpoint). It keeps concerns
separated, makes the API contract explicit, and avoids the conditional response shape.
The frontend will need to call it after the user clicks Submit and before showing the
normal submit dialog, similar to how a form validation preview works today.

### 7.3.2 What "reuse" does — **[DECIDE]**

Two semantic options:

**Option A: Point to the existing run**
- No new `request_log` row is created.
- The frontend simply redirects the user to the existing run's download page.
- User sees the prior `request_no`, `submitted_by`, `generated_at`, etc.
- **Pro:** simplest; no new metadata row; history is accurate (no fake duplicate).
- **Con:** the user's "submission action" is not recorded (if auditing that matters).

**Option B: Create a lightweight new request_log row referencing the same output**
- A new `request_log` row is inserted, linked to the same `output_path` and `output` metadata.
- The new row carries the current user's email in `submitted_by` (or `NULL` if
  reuse-without-owning is allowed).
- New row gets its own `request_no`, `submitted_at = now`, but `generated_at` and
  `expires_at` point to the original (reused) run.
- **Pro:** each user's action is logged; the Downloads list shows their submission even if
  they reused; full audit trail.
- **Con:** more complex; the table has "fake" rows that re-point to the same output (could
  confuse an analyst reading raw data).
 
**Recommendation:** **Option A** (point to existing run) for the MVP. It is simpler, and
if auditing the reuse action becomes important, a separate audit table or event log can
be added without changing the core logic. The existing `request_log` row already records
who first ran the report (`submitted_by` on that row), and the Downloads page shows it —
full transparency.

### 7.3.3 The popup UI

If a cache hit is detected, the frontend shows a modal (pattern: `SaveTemplateModal.tsx`):

**Title:** "Identical report run found"

**Body:**
```
A report with these exact parameters was already run on [generated_at date/time]
by [submitted_by / "Someone in your group" if different user].
The output file is still available.

What would you like to do?
```

**Buttons:**
- **"Rerun the job"** — dismiss the popup, proceed to normal submit (trigger a new job).
- **"Reuse output"** — navigate to the existing run's download (or if Option B: POST to a
  "finalize reuse" endpoint, then navigate).
- **"Cancel"** — close the popup, stay on the form (no action taken).

**Design decision [DECIDE]:** Should the popup show WHO ran the original run and WHEN?
- **Pro:** transparency, audit trail in the UI.
- **Con:** if the caller does not hold permission to see that user (unlikely given they
  share the report permission, but not impossible), we should not expose the name.

**Recommendation:** Show `submitted_by` (the display name or email) and `generated_at`
(timestamp). This is consistent with the Downloads page, which already shows `submitted_by`
openly for all permitted runs.

## Security

The reuse candidate MUST pass the same `report_permissions` gate as any other run access.

**The gate:** Before a cache hit is returned to the caller, the backend MUST verify:
1. Resolve the caller's identity (email, OBO groups, user_id).
2. Call `is_report_permitted(settings, ident, alv_id)` (the existing entitlements function
   used by every other endpoint).
3. Return 404 ("report not found") if denied. Never disclose that a report the caller may
   not see exists.

**Cross-user reuse is intended:** Per `SECURITY_AND_PERMISSIONS.md` section 8, a reuse
candidate submitted by a different user is **not a security violation**; it is the intended
behavior. If users A and B both hold the report permission, A can reuse B's run, and B can
reuse A's run. `submitted_by` is displayed, not masked. The report permission is the whole
authorization model — there is no per-row owner restriction.

**Implementation:** The cache-check endpoint (whether Option A or B) performs the permission
check before querying `request_log`. The check result is cached (the same TTL as the global
permission map, 300s by default), so repeated cache checks for the same caller do not
hammer the gate.

## Edge cases

### E1: Output file missing or expired

The cache lookup query checks `expires_at > now()`. If the file has been deleted from the
Volume in the meantime but the `request_log` row still exists with `expires_at` in the future:

- **Current behavior (no cache feature):** A user who clicks Download on a stale run gets a
  404 or error from the Volume read.
- **Cache behavior:** The cache hit is returned (it is still within TTL). The user chooses
  reuse and is directed to that run. They then encounter the same 404 on download.

**Action:** Accept this as-is. The cache lookup need not verify the output file exists (that
is the download path's responsibility, and it already handles missing files). If the file
is gone, the user's experience is the same whether they cached-hit or reran (404 on
download). A future enhancement could add a column `output_verified_at` and periodically scan
for missing files, but that is out of scope here.

### E2: Multiple cache hits (same alv_id + param_hash, multiple COMPLETED rows)

This should rarely happen (users do not usually rerun identical params on the same day), but
the query must be deterministic:

**Rule:** Select the row with the **newest `generated_at`** (i.e., most recent successful run).
This ensures the user gets the freshest cached output.

**Query:**
```sql
SELECT * FROM request_log
WHERE alv_id = ? AND param_hash = ? AND status = 'COMPLETED' AND expires_at > now()
ORDER BY generated_at DESC LIMIT 1;
```

### E3: A still-RUNNING identical submission

A user submits a report. Before it finishes, they submit the same report again
(by accident, or before realizing it was queued). The new submit's cache check finds:
- The first submission's row with `status = 'RUNNING'`.

**Rule:** Do not cache-hit on a `RUNNING` row. Wait for the user to retry after it completes.
The cache lookup query filters `status = 'COMPLETED'` only, so this is already correct.

**Concurrent submits:** If two users simultaneously submit identical params:
- Both submit paths will insert their own `request_log` row with `status = 'QUEUED'`.
- Both will trigger jobs.
- Later, when one finishes, it will have `generated_at` and `expires_at` set.
- A third user submitting the same params might cache-hit the completed one. This is correct.

### E4: Exact expiry boundary (expires_at == now)

The query uses `expires_at > now()`, so a row that expires exactly at the current timestamp
is NOT a hit. This is correct (fail-safe; do not use a result that is just expired).

### E5: Parameter normalization edge cases

**Blank vs. omit:** A field with `omit_if_blank: true` that is blank in one submit and blank
again in a later submit will have the same `param_hash` (both have the field omitted). Cache
hit: correct.

**Case normalization:** A field with `normalize: ["uppercase"]` submitted as `"abc"` then
`"ABC"` produces the same `param_hash`. Cache hit: correct.

**Whitespace normalization:** A field with `normalize: ["trim"]` submitted as `" x "` then
`"x"` produces the same `param_hash`. Cache hit: correct.

### E6: Hash collisions

SHA-256 collisions are cryptographically negligible. If they occur (collision attack), the
attacker would need to engineer parameters that hash-collide and carry the same `alv_id`, and
then submit them. Documented as a known limitation; the risk is not real for this use case.

## Implementation tasks (deferred to later)

This section breaks down the work for future sprints. Each task is small enough to be
assigned independently.

1. **Backend cache-check endpoint** (Option A recommended above)
   - New function in a module (e.g., `cache_source.py`): parameterized SQL query matching
     the definition above (same `alv_id` + `param_hash` + `COMPLETED` + `expires_at > now()`).
   - New endpoint `GET /api/reports/{alv_id}/cache-check?param_hash=...` (or `POST` with
     the full payload, if binding the param_hash feels awkward).
   - Permission check via `is_report_permitted` before returning the hit.
   - Return JSON: `{ hit?: { request_no, generated_at, submitted_by }, expires_at? }` or
     `{ hit: null }` if no match.
   - 404 if `alv_id` is not permitted.

2. **Frontend integration**
   - After the form is filled and Submit is clicked, POST the form values to the backend's
     existing Submit endpoint to get the normalized `param_hash` (or compute it locally
     using the same normalization rules, if avoiding an extra round-trip is preferred).
   - Call the cache-check endpoint.
   - If a hit is returned, show the modal (title, body, buttons as designed above).
   - On "Rerun": proceed with normal submit flow.
   - On "Reuse": navigate to `/requests/{hit.request_no}` or the downloads page for that run.

3. **Unit tests**
   - Query builder test (cache hit SQL, bind params correct).
   - Permission gate test (denied caller returns 404).
   - Edge case tests (expiry boundary, multiple hits, missing fields).

4. **Integration tests**
   - Submit a report, let it complete, verify `expires_at` is set.
   - Submit identical params; verify cache-check finds the first run.
   - Submit with different params; verify no hit.
   - Submit as different user (same permission); verify hit is still returned + permission
     gate allows it.

5. **Documentation**
   - Update `METADATA_TABLE.md` section on `request_log` to note that `expires_at` and the
     cache key are now in active use (not just groundwork).
   - Add a brief "Cache reuse" section to the user guide or README explaining the feature.

## Open decisions — **[DECIDE]**

1. **Option A or B for "what reuse does"?** (Section 7.3.2)
   - A: Point to the existing run (simpler, recommended).
   - B: Create a new request_log row (full audit trail).
   - **Default:** A. Change if auditing the reuse action is a hard requirement.

2. **Pre-submit lookup endpoint (A) or inside submit + conditional response (B)?** (Section 7.3.1)
   - A: Separate `GET /api/reports/{alv_id}/cache-check` endpoint (recommended).
   - B: Extend submit to return "needs confirmation" on hit.
   - **Default:** A. Cleaner API contract.

3. **Show submitter name + timestamp in the popup?** (Section 7.3.3)
   - Yes: display `submitted_by` and `generated_at` (recommended for transparency).
   - No: generic message.
   - **Default:** Yes, consistent with Downloads page.

4. **Reuse across users enabled by default?** (Section 7.3.3)
   - Yes: if caller and original submitter share the report permission, reuse is offered.
   - No: only offer reuse if `submitted_by == caller`.
   - **Context:** Per §8 of SECURITY_AND_PERMISSIONS.md, cross-user visibility is intended.
     But reuse is a new UX, so there may be user-facing reasons to restrict it.
   - **Default:** Yes, consistent with the visibility model.

5. **Should the reuse action log a new audit row or event?** (Section 7.3.2)
   - If Option B (new request_log row): handled in the data model.
   - If Option A (point to existing run): should we emit a separate audit event (e.g.,
     "USER X reused run Y")? Or is reading the Download page history sufficient?
   - **Default:** Separate audit event is "nice-to-have"; MVP can ship without it.

6. **Frontend: compute param_hash locally or fetch from backend?**
   - Local: replicate the Python canonicalization in JavaScript, avoid extra round-trip.
   - Fetch: POST the form values to a `/api/reports/{alv_id}/param-hash` endpoint, get the
     hash back, use it in the cache-check call.
   - **Default:** Fetch (simplicity, single source of truth for the hash algorithm).

Additional edge case to handle - 
Incase a user submits a job for which the data already exists, and then there are two entries for the 
same parameters, the third user should be recommended to use the latest file instead of the oldest one.

> **Implemented (E2 / "latest wins").** `build_cache_lookup_sql` orders qualifying rows
> `ORDER BY generated_at DESC, submitted_at DESC, request_no DESC` and takes `LIMIT 1`, so a
> user reusing parameters that already have several cached outputs is always offered the
> **newest** file. The reuse popup labels it "This is the most recent matching run."

## Implementation notes (as built)

- **Backend seam** `alv_app/cache_source.py` — `build_cache_lookup_sql` (pure, bound
  params, testable) + `find_cached_run` over the same warehouse statement-exec seam / App
  SP as `downloads.py`. A hit is `status='COMPLETED'` AND `output_path IS NOT NULL` AND
  `expires_at > current_timestamp()`; latest wins. The result is not cached (reuse must
  reflect the live table).
- **Endpoint** `POST /api/reports/{alv_id}/cache-check` (`main.py`) — applies the SAME
  `report_permissions` gate as submit (404 on deny, before any warehouse read), computes
  `param_hash` server-side via the submit builders (single source of truth), and returns
  `{alv_id, param_hash, hit|null}`. A warehouse failure degrades to `hit=null` (200) so a
  cache-read problem never blocks a submission. The raw `output_path` is never returned —
  only `has_output`; the download stays App-proxied by `request_no`.
- **Models** `CacheHitOut` / `CacheCheckOut` (`models.py`).
- **Frontend** — `useCacheCheck` runs on Submit BEFORE the run; a hit opens `ReuseRunModal`
  (Reuse output → downloads the existing run via the Downloads download endpoint; Run the
  job again → normal submit; Cancel). No hit or a failed check → normal submit.
- **No schema / grant change** — `request_log` already carries every column read, and the
  App SP already `SELECT`s the table.
- **Tests** — `tests/test_cache_check.py` (SQL builder, mapping, latest-wins, hit / no-hit /
  degrade-on-failure / 404 / permission-gate) + `ReuseRun.test.tsx` (reuse vs rerun vs
  no-hit vs check-failure).

## Related documents

| Document | Content |
|---|---|
| `docs/METADATA_TABLE.md` | `request_log` schema, cache key definition, TTL. |
| `docs/SECURITY_AND_PERMISSIONS.md` | Authorization model, cross-user access decision (§8). |
| `src/alv-frontend/backend/alv_app/submit.py` | Payload build, canonicalization, param_hash computation. |
| `src/alv-frontend/backend/alv_app/request_log.py` | request_log writes; expires_at derivation. |
| `src/alv-frontend/backend/alv_app/downloads.py` | Output read, pagination, permission gate. |
| `src/alv-frontend/backend/alv_app/entitlements.py` | `is_report_permitted` gate used throughout. |
| `src/alv-frontend/frontend/src/components/SaveTemplateModal.tsx` | Modal UI pattern reference. |
