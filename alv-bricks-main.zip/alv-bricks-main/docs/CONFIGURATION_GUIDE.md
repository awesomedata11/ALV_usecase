# Configuration Guide — ALV metadata layer

How report metadata is authored, validated, and loaded. This is the doc report
authors live in.

## Table of contents
1. [Configuration structure](#1-configuration-structure)
2. [How config is loaded & validated](#2-how-config-is-loaded--validated)
3. [`input_fields_json` reference](#3-input_fields_json-reference)
4. [Validation vocabulary](#4-validation-vocabulary)
5. [Seeding the catalog](#5-seeding-the-catalog)
6. [Environment parameters](#6-environment-parameters)

---

## 1. Configuration structure

A report is authored as a **catalog-rows manifest** — one entry per runnable
report (per `job_id`):

```
src/report_specs/<report>.input_fields.json     # authoring source (seed input)
```

Each entry has identity columns (`report_key`, `selection_id`,
`report_type_code`, …), a `job_id`, and its **own complete flat**
`input_fields_json`. The pilot ships `src/report_specs/retail_ledger.input_fields.json`
(14 rows). See `docs/metadata_tables_example.md`.

## 2. How config is loaded & validated

`dbx_alv_reports.spec_parser.InputFieldsParser`:

1. Loads the JSON Schema `json_specifications/input_fields.schema.json` (Draft-07),
   shipped as package data.
2. Runs a schema pass (`jsonschema`) **and** an always-on semantic pass — so it
   still validates if `jsonschema` isn't installed (`JSONSCHEMA_AVAILABLE`).
3. **Collects all errors** (never fails on the first) and **fails the load** on an
   unknown validation rule (D-IFJ-10).

```python
from dbx_alv_reports import InputFieldsParser, validate_input_fields

ok, errors, warnings = validate_input_fields(blob, source="my_report")
spec = InputFieldsParser(blob).get_spec()   # raises ValueError if invalid
```

## 3. `input_fields_json` reference

Top level: `{ "schema_version": 1, "fields": [ … ] }`. Each field is **scalar** or
**composite**.

**Scalar** (`control`: `text` | `date`):

| Attribute | Type | Notes |
|---|---|---|
| `param_name` | string | Backend key passed to the Job (D6). Unique within the row. |
| `display_label` | string | UI label. |
| `display_order` | int | Render order. |
| `control` | enum | `text` / `date`. |
| `data_type` | enum | `string` (text) / `date` (date). |
| `selection_type` | enum | `single` / `multi`. |
| `mandatory` | bool | Required to submit. |
| `default` | any | Value when blank. |
| `omit_if_blank` | bool | Drop the key from the payload when blank (else send `default`). |
| `normalize` | string[] | `trim` / `uppercase` / `lowercase`. |
| `validations` | object[] | See §4. |

**Composite** (`control`: `date_range` | `time_range`): carries `parts.from` and
`parts.to` (each `{param_name, display_label, default?}`) — the backend receives
two scalar params while validation ownership stays on the composite. `data_type`
is `date` (date_range) or `time` (time_range).

> `selection`/`report_type` are **catalog columns, not fields** (D-IFJ-8).

## 4. Validation vocabulary

Each rule: `{ "rule": <name>, …params, "message_key": <KEY> }`. No inline text —
`message_key` resolves against the message catalogue (T2.2 / D-IFJ-9).

| `rule` | Params | Applies to |
|---|---|---|
| `from_lte_to` | — | date_range / time_range |
| `max_span` | `unit`, `value` | date_range |
| `max_offset_from_today` | `unit`, `value`, `applies_to`? | date / date_range |
| `to_required_if_from` | — | time_range |
| `no_filter_when_equal` | — | time_range |
| `regex` | `pattern` | text |
| `max_length` | `value` | text |

`unit` ∈ `days` / `months` / `years`. Rules are **control-specific** — the validator
rejects a rule attached to a control it doesn't apply to (e.g. `max_span` on `text`).
Adding a rule = extend the validator dispatch (incl. its allowed controls) **and** the
schema enum — not the table.

## 5. Seeding the catalog

```python
from dbx_alv_reports import ReportSeeder
ReportSeeder(spark, catalog="alv_bricks", schema="metadata") \
    .seed("src/report_specs/retail_ledger.input_fields.json")
```

`build_rows()` derives `alv_id` (slug of the natural key), the display name, and
serializes `input_fields_json`. `seed()` upserts via `MERGE INTO` keyed on `alv_id`
(idempotent). Non-numeric `job_id` placeholders are seeded `NULL` (unbound) with a
warning, pending the RIL contract.

## 6. Environment parameters

Env-specific values (catalog/schema) live in `src/env_parameters/<env>_parameters.yaml`,
**not** in report specs. The DAB targets (`dev`/`prod`) and job parameters carry
them to the drivers.
