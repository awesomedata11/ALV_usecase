# Parameter templates (variants) — approach

> **Status: IMPLEMENTED + DEPLOYED (2026-08-08), on branch `feat/report-templates`.**
> The decisions below are answered inline; the build followed them with two refinements
> from the follow-up Q&A: (a) the Templates list is scoped to the current report type
> (`alv_id`) and reached from a **contextual left-nav item** once a report is open, and
> (b) **edit/rename** is supported. Dynamic (relative date/time) templates remain future
> — a `value_kinds_json` column is reserved so they need no migration. See `CHANGELOG.md`
> and `docs/METADATA_TABLE.md` for the shipped contract.

## Goal

Let a user **save the parameter values of a report as a named template**, and
**reload that template later** to fill the form. This removes the need to type the
same inputs again for each run.

Rules:

- A template holds the form values for **one runnable report**.
- A user sees **only his own templates**. He can never see or use another user's
  templates.
- Save, list, load, and delete templates from the report screen.

This is the tracker backlog item **"templates (variants)"**.

## How the app works today (baseline the design must fit)

- **Reports.** One `alv_catalog` row = one runnable report, keyed by `alv_id`
  (e.g. `retail_ledger__detail__agent_item`). Each row carries its own flat
  `input_fields_json`. The form is rendered per `alv_id`.
- **Form values.** The frontend holds a flat map `Record<string, string>` keyed by
  `param_name` (a composite date range carries its own `from`/`to` keys). This same
  map is the body of both **submit** (`SubmitIn.values`) and **preview**
  (`PreviewIn.values`). So the values a template must store are exactly this map.
- **Metadata tables** are Delta over the SQL warehouse (NOT Lakebase). The App writes
  them as the **App service principal** through a bound-SQL seam (`request_log.py`,
  `admin.py`). Every user value is a bound parameter.
- **DDL is single-source** in `src/alv-backend/dbx_alv_reports/metadata/metadata_tables.py`. A
  table in `PILOT_TABLES` is created by the `provision` job's `ensure_all()`.
- **Report visibility.** Every report-scoped endpoint gates on `report_permissions`
  through `_require_report_permission` (404, not 403, on deny). Templates ride on top
  of this — a template feature must never let a user reach a report he may not see.
- **Owner identity.** The `report_permissions` user grants already store the user
  **email, lower-cased**, and match the caller's `X-Forwarded-Email` case-folded. The
  template owner uses the same identity approach.

## Data model — new table `report_templates`

A new metadata table, following the single-source DDL pattern. It does not touch
`alv_catalog`, `request_log`, or `report_permissions`.

| Column | Type | Null | Notes |
|---|---|---|---|
| `template_id` | STRING | no | **PK.** App-generated id (e.g. `TPL-<uuid>`). |
| `alv_id` | STRING | no | FK → `alv_catalog.alv_id`. The runnable report the template belongs to. |
| `owner` | STRING | no | The owning user's email, stored **lower-cased**, matched case-folded. |
| `template_name` | STRING | no | The name the user gives the template (display + pick). |
| `param_values_json` | STRING | no | The saved form values — the flat `{param_name: value}` map, exactly as the form holds and submit/preview post it. |
| `is_active` | BOOLEAN | yes | Soft-delete (delete without removing the row). NULL counts as active. |
| `created_at` | TIMESTAMP | yes | Audit. |
| `updated_at` | TIMESTAMP | yes | Audit (set on each save). |

- **Grain:** one row per template. A natural key of
  `(owner, alv_id, template_name)` keeps names unique per user per report (see
  decision 3).
- Add the table to `PILOT_TABLES` so `ensure_all()` (the `provision` job) creates it.
- **No migration is needed** — this is a brand-new table, and `ensure_all()` CREATEs
  it. This is unlike the `report_permissions` change, which had to ALTER a live table.

### Why store the raw form map (not the effective job payload)

The submit path builds an **effective payload** (normalize / omit-if-blank / default).
That is lossy for reload — an omitted blank field or a normalized value would not
refill the form the way the user left it. The template stores the **raw form values**
(the same map the form holds), so loading a template is a direct "set the form
values". Submit still re-derives the effective payload from the field defs at run
time, exactly as it does now. **[DECIDE — see decision 4.]**

## Owner identity

- The owner is the caller's **email, lower-cased**, from `X-Forwarded-Email` (via
  `resolve_identity`) — the same identity the `report_permissions` user grants use.
- At list/load/delete time, the query filters `owner = :caller_email_lower`, so a user
  can only ever read or change his own rows. This is the whole of the "own templates
  only" control.
- **Edge case:** a request with no resolvable email. On a deployed app the proxy always
  injects the email, so this is a local-dev / misconfiguration case. The safe behavior
  is to **deny** — no email ⇒ no owner ⇒ empty template list and a refused save.
  **[DECIDE — see decision 5.]**

## Endpoints (all report-scoped, all owner-scoped)

New endpoints under the existing report path, each gated by
`_require_report_permission` first (so an unpermitted report 404s before anything
else), then scoped to `owner = caller`:

- `GET  /api/reports/{alv_id}/templates` — list the caller's templates for this report
  (`template_id`, `template_name`, `updated_at`; values fetched on load, not in the
  list — keeps the list light, mirrors the `params` info-view pattern).
- `POST /api/reports/{alv_id}/templates` — save a template `{template_name, values}`.
  Upsert on `(owner, alv_id, template_name)` so re-saving a name overwrites it
  (decision 3).
- `GET  /api/reports/{alv_id}/templates/{template_id}` — one template's values, to load
  into the form. Owner-checked.
- `DELETE /api/reports/{alv_id}/templates/{template_id}` — delete (soft-delete).
  Owner-checked.

Writes use the bound-SQL App-SP seam (a new `templates.py`, mirroring `admin.py`).
Every user value is a bound parameter; `param_values_json` is free text and never
interpolated.

### Security notes (must hold)

- A user must never see, load, or delete a template that is not his — enforced by the
  `owner = caller` predicate on **every** read and write (not just the list).
- The report-permission gate runs **before** the owner check on every endpoint, so a
  user cannot probe templates for a report he may not see.
- No cross-user disclosure: the list is filtered in SQL by owner; we never return a
  count or name of another user's templates.
- `docs/METADATA_TABLE.md` gains the new table. `docs/SECURITY_AND_PERMISSIONS.md`
  gains a short note that templates are owner-private and ride behind the report gate.

## Frontend

- In `ReportForm.tsx`, add a **Templates** control near the form actions:
  - A **dropdown** listing the caller's templates for the current `alv_id`. Picking one
    loads its values into the form (via `setValues` + draft store).
  - A **Save as template** action — a small name input + button that posts the current
    `values`. On success the dropdown refreshes.
  - A **delete** action per template (in the dropdown or a small manage view).
- New hooks in `api/hooks.ts`: `useTemplates(alvId)`, `useSaveTemplate(alvId)`,
  `useLoadTemplate`, `useDeleteTemplate(alvId)`. New types in `api/types.ts`.
- Reuse existing design tokens and control styles — no new CSS system.
- Templates are scoped to the resolved `alv_id`, so switching report type shows that
  report type's templates (consistent with how the form itself is per `alv_id`).

## Open decisions — please answer inline

1. **Template scope — per `alv_id` or per `report_key`?**
   Params are defined per `alv_id` (each selection × report type has its own fields),
   and the form is rendered per `alv_id`. So a template only makes sense for one
   `alv_id`. My recommendation: **scope templates to `alv_id`**. When the user picks a
   selection + report type, he sees the templates for that exact runnable report.
   Confirm, or do you want templates grouped/visible at the whole-report (`report_key`)
   level?
   A: report key would be the way to go, once the user opens a report, then he should be able to see templates for    that report by clicking on 'Templates' in the left navbar

2. **Single new table vs reuse.** I propose a **new `report_templates` table** (it is a
   different concern from permissions/run-tracking, and mixing it in would be messy).
   Agree?
   A: ofcourse new table. 

3. **Name uniqueness + overwrite.** I propose **unique name per (owner, `alv_id`)** and
   **overwrite on re-save of the same name** (upsert). Alternative: allow duplicate
   names, always insert a new row. Which do you want?
   A: yes, using the same name again would overwrite the template, but only if its for the same report_key. 

4. **Store raw form values (recommended) or the effective job payload?** Raw form
   values reload the form faithfully; the effective payload is lossy for reload. I
   recommend **raw form values**. Agree?
   A: agree

5. **No-email edge case.** If the caller has no resolvable email (local dev /
   misconfig), I **deny** (empty list, refuse save). Agree, or use `user_id` as a
   fallback owner key?
   A: user would always have email id. 

6. **Limit on templates per user per report?** Do you want a cap (e.g. 50) to keep the
   list sane, or unlimited?
   A: unlimited.

7. **Edit beyond overwrite?** Is rename / edit-in-place needed, or is save-new +
   delete + re-save enough for the pilot?
   A: user should be able to edit his templates later as well.

8. **Should submitting or previewing from a loaded template behave any differently?**
   My assumption: **no** — loading a template just fills the form; submit/preview then
   run exactly as today. Confirm.
   A: for starting implementations that's okay, but in long term i would have two types of inputs in my templates - static and dynamic (for dates and timestamps - allowing for D-1, D-n, T-1hour etc) values in the templates, so that for ex if he opens a dynamic template to fetch data for last month, the template should be able to resolve the value of those date/time fields based on current date. so we'll have to plan how to create templates - should it be another pop up screen that gives more option to users for static/dynamic inputs?

Additional thoughts - remove the validate button from reports - not needed.

## Proposed implementation slices (after sign-off)

Each slice is deployed and validated by you before the next starts.

1. **Table + read/write backend** — new DDL in `metadata_tables.py`, add to
   `PILOT_TABLES`, run `provision`; new `templates.py` (bound-SQL App-SP seam); the four
   endpoints; owner + report-permission gating; backend tests.
2. **Frontend** — Templates dropdown + save + delete in `ReportForm.tsx`; hooks + types;
   frontend tests.
3. **Docs** — `METADATA_TABLE.md`, `SECURITY_AND_PERMISSIONS.md`, `CHANGELOG.md`,
   README progression, `CLAUDE.md` (onboard-a-template playbook note if useful).

## File touch-list (reference)

- `src/alv-backend/dbx_alv_reports/metadata/metadata_tables.py` — new `REPORT_TEMPLATES_TABLE`, add
  to `PILOT_TABLES`.
- `src/alv-frontend/backend/alv_app/templates.py` (new) — bound-SQL owner-scoped read/write seam.
- `src/alv-frontend/backend/alv_app/main.py` — the four `templates` endpoints.
- `src/alv-frontend/backend/alv_app/models.py` — `TemplateOut` / `TemplatesListOut` / `TemplateIn` /
  `TemplateValuesOut`.
- `src/alv-frontend/frontend/src/api/hooks.ts` + `api/types.ts` — template hooks + types.
- `src/alv-frontend/frontend/src/components/ReportForm.tsx` — the Templates control.
- `docs/METADATA_TABLE.md`, `docs/SECURITY_AND_PERMISSIONS.md` — updates.
- Tests: new `src/alv-frontend/backend/tests/test_templates.py`; a `ReportForm` template test.

---

# Dynamic templates (relative date/time values) — approach (REVISED to Idris' answers)

> **Status: IMPLEMENTED + DEPLOYED (2026-08-08), on branch `feat/report-templates`
> (uncommitted — commit + push once validated, decision 7).** Built to the decisions
> below; reuses the reserved `value_kinds_json` column (no migration). See `CHANGELOG.md`
> and `docs/METADATA_TABLE.md` for the shipped contract.
>
> **Decisions locked in:**
> - **No work-day logic at all** (decisions 9 & 11): the two work-day presets are dropped,
>   so there is no holiday-calendar concern — **8 presets** remain.
> - **Dynamic applies to date fields only** (decision 4: `date` + each side of
>   `date_range`); `time_range` stays static in v1 (no time presets given).
> - **Validate at SAVE, both static and dynamic** (decision 10): a template that fails the
>   report's validations cannot be saved — the modal pops the exact error. This changes the
>   base feature's current un-gated save; since we're on the same uncommitted branch, that
>   path is updated too.
> - **Resolve at load** in **Asia/Kolkata** (decisions 2 & 3). Build on
>   `feat/report-templates`, **no commits until the whole feature is done** (decision 7).

## Goal

Today a template stores **static** values (the literal text of each field). A dynamic
template instead stores, for a chosen date field, a **named relative rule** that resolves
against the current date **when the template is loaded** — so e.g. a "first day of previous
month" field always fills the right date without editing.

On **load**, the App resolves each dynamic field's rule against "now" (Asia/Kolkata,
decision 3) and fills the form with concrete dates; static fields fill with their saved
literals. What the user sees on the form is the resolved value, and Submit / Preview run on
it exactly as today (resolve-at-load, decision 2).

## The preset list (the whole grammar — a closed set)

Instead of a free syntax, a **closed set of named presets** (fail-closed: anything not in
the set is rejected at save). Each preset resolves to **one date**. Three take an integer
parameter `n`.

| Preset id | Label | Resolves to (relative to today T) | Param |
|---|---|---|---|
| `TODAY` | Current date | T | — |
| `CUR_DATE_PLUS_N_DAYS` | Current date ± n days | T + n calendar days (n may be negative) | `n` (int) |
| `FIRST_DAY_CUR_MONTH` | First day of current month | 1st of T's month | — |
| `LAST_DAY_CUR_MONTH` | Last day of current month | last day of T's month | — |
| `FIRST_DAY_NEXT_MONTH` | First day of next month | 1st of next month | — |
| `LAST_DAY_NEXT_MONTH` | Last day of next month | last day of next month | — |
| `FIRST_DAY_PREV_MONTH` | First day of previous month | 1st of previous month | — |
| `LAST_DAY_PREV_MONTH` | Last day of previous month | last day of previous month | — |

**"From month start to today"** is a **range shortcut**, not a single-date preset: it sets
a `date_range`'s `from` = `FIRST_DAY_CUR_MONTH` and `to` = `TODAY`. In storage it is just
those two single-date presets on the two range params — the UI offers it as one click.

> **Dropped from the original list (per decisions 9 & 11):** "Current date ± n **work
> days**" and "**Working day number n** of current month". Both need a working-day / holiday
> calendar, which is out of scope for v1 — so there is **no work-day logic at all**, and no
> holiday-calendar concern. They can be added later without disturbing the presets above.

Edge cases the resolver must get right (all unit-tested): `CUR_DATE_PLUS_N_DAYS` with a
negative `n`; month-length math for Feb / 30- vs 31-day months (real calendar arithmetic
via `calendar.monthrange`, never day-count approximations); year rollover for
next/previous-month presets in Jan/Dec.

## Storage — `value_kinds_json` (no new column)

Only dynamic params appear; every other field stays static (its literal in
`param_values_json`). A dynamic param's slot in `param_values_json` is ignored on load —
its value comes from resolving the preset.

```json
{
  "txn_date_from": { "kind": "dynamic", "preset": "FIRST_DAY_CUR_MONTH" },
  "txn_date_to":   { "kind": "dynamic", "preset": "TODAY" },
  "as_on_date":    { "kind": "dynamic", "preset": "CUR_DATE_PLUS_N_DAYS", "n": -1 }
}
```

`kind` is always `"dynamic"` here (static fields are simply absent). `preset` is one of the
ids above; `n` is present only for `CUR_DATE_PLUS_N_DAYS`. A NULL / absent
`value_kinds_json` ⇒ the template is fully static (today's behaviour, untouched).

## Resolution — where and when

- **Server-side, at load.** `GET /api/reports/{alv_id}/templates/{template_id}` resolves
  each dynamic preset against "now" and returns concrete `values` (dynamic + static
  merged), **plus** the `value_kinds` map so the UI can badge which fields were dynamic and
  re-open the editor with the right presets selected. One resolver, on the server; the
  frontend just fills the form.
- **Resolve at load only** (decision 2): the form then holds concrete dates and Submit /
  Preview run on them unchanged. Accepted trade-off: a value resolved at 23:59 and
  submitted after midnight keeps the pre-midnight date.
- A pure, unit-tested helper `dynamic_values.py` (mirrors the `sample_query` helper) owns
  the preset set + resolve, so it is testable with no I/O and no clock dependency (the
  "now" is injected).

## Validation — at SAVE, for BOTH static and dynamic templates (decision 10)

This is a change of stance from the base feature (where "Save as template" was **not**
validation-gated). Per your decision, a template is now validated **when it is saved**, and
a template that would fail the report's field validations **cannot be saved** — the UI pops
the exact validation error and the save is refused. This applies to **both** kinds:

- **Static** template: validate the literal values the user entered.
- **Dynamic** template: **resolve** the dynamic presets against "now" first, merge with the
  static values, then run the **same validation vocabulary** the form uses (`mandatory`,
  `from_lte_to`, `max_span`, `max_offset_from_today`, `regex`, `max_length`, …). If the
  resolved set fails, refuse the save and return the specific message(s).

- **Where the check runs.** The frontend already owns the full validation vocabulary
  (`validation.ts`), so the modal validates before POSTing and shows the error inline —
  no save call is made. The **backend also re-validates on save** (never trust the client):
  a save whose values fail validation returns **422** with the field errors, so the guard
  holds even if the client is bypassed. For the dynamic case the backend resolves-then-
  validates with its own resolver + a server-side port of the rule checks.
- **Known limitation (stated plainly):** a dynamic template is validated against **today's**
  resolved dates. It can still resolve to a validation failure in a *later* month (e.g. a
  month-spanning range that exceeds `max_span` only in a 31-day month). Save-time
  validation of relative values cannot prevent that; the user still sees the failure at
  submit time through the existing form validation. Re-validating at load is a later option.

## "Now" and the timezone

- Resolved against **Asia/Kolkata** (decision 3), via a `report_timezone` setting
  (default `Asia/Kolkata`) so it is configurable without a code change. The resolver takes
  an explicit `now` argument; only the endpoint reads the clock, keeping the resolver pure.

## Backend changes (delta on the shipped feature)

- **`src/alv-frontend/backend/alv_app/dynamic_values.py`** (new) — the preset enum (8 presets),
  `parse_value_kinds` (validate a `value_kinds` map: known presets only, `n` a required int
  for `CUR_DATE_PLUS_N_DAYS` and absent otherwise, preset only on a `date` field), and
  `resolve(preset, n, now) -> date`. Pure — no work-day/holiday logic (dropped), real
  calendar arithmetic, injected `now`.
- **Server-side validation on save.** `save_template` (a) resolves any dynamic presets
  against "now", (b) merges over the static values, and (c) runs the report's field
  validations. A failure returns **422** with the field errors — the backend guard behind
  the client-side check (decision 10). This needs a small **server-side port of the rule
  checks** the frontend `validation.ts` already does; kept as a pure helper
  (`template_validation.py` or folded into `dynamic_values.py`) and unit-tested. Bad
  preset/param also ⇒ 422 (like a bad name).
- **`templates.py`** — `save_template` validates + writes `value_kinds_json`;
  `get_template` resolves dynamic presets → concrete values (merged over the static map)
  and also returns the raw `value_kinds` map.
- **`models.py`** — `SaveTemplateIn` gains `value_kinds`; `TemplateDetailOut` gains
  `value_kinds`. A validation-failure 422 returns the per-field messages so the modal can
  show the exact error.
- **`config.py`** — `report_timezone` (default `Asia/Kolkata`).
- Endpoints keep their shape (the five under `/templates`); only payloads grow. **Existing
  static templates are unaffected at load** (absent `value_kinds` ⇒ all static). Note that
  **saving** any template now runs validation — a change from the base feature, applied to
  both kinds.

## Frontend changes

- **Save-as-template becomes a modal** (decision 6): a name field, then a row per **date
  field** in the report (scalar `date` and each side of a `date_range`) with a
  **Static | Dynamic** toggle. Dynamic reveals a **preset dropdown** (the labels above);
  `CUR_DATE_PLUS_N_DAYS` reveals a small **number input** for `n` (± days). A `date_range`
  additionally offers the one-click **"From month start to today"** shortcut that sets both
  sides. Non-date fields are shown read-only as static (saved as-is). A live **preview**
  line shows what each dynamic field resolves to *today*.
- **Validate-before-save (decision 10):** the modal runs the existing `validation.ts`
  vocabulary over the would-be values (resolving dynamic presets to today's dates first).
  If it fails, it **pops the exact error and refuses to save** — no POST is made. The
  backend re-validates and can still return 422, which the modal also surfaces.
- **Load** is unchanged from the user's view — it fills the form with the server-resolved
  concrete dates; a small **"dynamic"** badge marks fields that came from a preset, and the
  Templates screen shows which templates are dynamic.
- **Types + hooks** grow to carry `value_kinds`.

## Open decisions — please answer inline

1. **Grammar scope.** Approve the minimal anchor+offset grammar above (and its unit-
   awareness)? Any anchors/units to add or drop for the pilot?
   A: here's the grammar i want - 
      Current Date
      From month start to today
      Current date +/- ??? days
      Current Date +/- ??? Work Days
      Working day number n of current month
      First day of current month
      First day of next month
      First day of previous month
      Last day of previous month
      Last day of current month
      Last day of next month

2. **Resolve at load only (recommended), or also re-resolve at submit?** Load-only is
   simpler and "what you see is what you submit"; submit-time re-resolution avoids the
   midnight-edge staleness but means the submitted value can differ from what was shown.
   A: okay

3. **Timezone for "now".** Which clock resolves `TODAY`/`NOW`? Options: a configured
   reporting timezone (I'd default it to **Asia/Kolkata** for RIL), UTC, or the user's
   browser timezone. A configured tz is the most predictable for a report.
   A: yes the timezone should be asia kolkata

4. **Which fields may be dynamic?** I propose **only date / date_range / time_range**
   controls; text fields stay static. Agree?
   A: yes

5. **UI: presets only, or presets + a raw-expression box?** Presets-only is safest for the
   pilot (no syntax to learn); a raw box is power-user flexibility. Which for v1?
   A: based on the grammar i gave, see how best to present it to the user. 

6. **Save editor — modal (recommended) or inline panel** on the form? You suggested a
   popup; confirming.
   A: i feel popup would be ideal, but i leave the final decision up to you. 

7. **Branch base.** The base templates feature is on `feat/report-templates`, not yet
   merged. Build dynamic templates **on top of that branch**, or wait until it merges to
   `main` and branch fresh? (I lean: merge base first, then a new branch off `main`.)
   A: use the feat/report-templates branch, dont commit yet, once we do full impletmentation then we'll commit and push

8. **Presets list.** Which named presets do you want in the dropdown for v1? My starting
   set: Today, Yesterday, Last N days, This month to date, Last month, This year to date,
   Last hour, Last N hours. Add/remove?
   A: i shared my list - Current Date
From month start to today
Current date +/- ??? days
Current Date +/- ??? Work Days
Working day number n of current month
First day of current month
First day of next month
First day of previous month
Last day of previous month
Last day of current month
Last day of next month

--- NEW decisions raised after your answers (please answer these two) ---

9. **`Working day number n of current month` when `n` exceeds the month's working-day
   count** (e.g. n=25 in a month with 22 working days). Options: (a) **clamp** to the last
   working day of the month; (b) **reject at save** with a validation error. I lean (a)
   clamp — a saved template should still resolve to a sensible date every month even though
   month lengths vary.
   A: you can skip the Working day number n of current month option altogether.

10. **A dynamic value that resolves to something a field validation rejects** (e.g. a
    resolved date range wider than the report's `max_span`). Options: (a) **block the
    load** with an error; (b) **load it and show the normal form error** so the user can
    adjust before submitting. I lean (b).
    A: let the user select it, but while saving run a validate first, if the validate for that report fails - give a pop saying the exact error from the validation and dont let the user save. this validate should run on both kinds of templates - static or dynamic.

11. **Work days = Monday–Friday only, no holiday calendar, in v1** (holidays need RIL's
    calendar data we don't have; the resolver is built so a calendar can drop in later).
    Confirm this is acceptable for the pilot.
    A: work day logic is no longer needed. i mentioned it in first answer.

## Proposed implementation slices (after sign-off)

> **Branch (decision 7): build on `feat/report-templates` itself — do NOT commit until the
> full dynamic-templates implementation is done, then commit + push together.** So unlike
> the base feature, the slices below are built and locally tested but NOT committed
> slice-by-slice; deploy + validate happens once at the end.

1. **Preset resolver + validation helper** — `dynamic_values.py` (the 8-preset enum,
   `parse_value_kinds`, `resolve(preset, n, now)`) and a pure server-side port of the
   field-validation rules, with full unit tests: every preset, ± n days (incl. negative),
   month-length edges (Feb, 30/31-day), Jan/Dec year rollover, rejection of unknown
   presets / missing or extra `n` / a preset on a non-date field, and the validation rules
   (`from_lte_to`, `max_span`, `max_offset_from_today`, `mandatory`, `regex`, `max_length`).
   No wiring yet.
2. **Backend wiring** — `save_template` resolves-then-validates (both kinds) and writes
   `value_kinds_json` (422 with field messages on failure); `get_template` resolves dynamic
   presets; models + `report_timezone`; backend tests (save+load a dynamic template
   resolves to the right dates for a fixed injected "now"; a template that fails validation
   is refused 422; static templates load unchanged).
3. **Frontend** — the Save modal (static/dynamic toggle + preset dropdown + `n` input +
   the "from month start to today" shortcut + live "resolves to today" preview +
   validate-before-save that pops the exact error); dynamic badges on load; types/hooks;
   vitest.
4. **Deploy + validate** — App deploy (no new table, no migration, no new grants — only
   `value_kinds_json`, already present); you validate on the live app.
5. **Docs** — CHANGELOG / README / METADATA_TABLE (`value_kinds_json` contract) / this doc.

## File touch-list (reference)

- `src/alv-frontend/backend/alv_app/dynamic_values.py` (new) — the 8-preset enum + resolver + the pure
  server-side field-validation port (or a sibling `template_validation.py`).
- `src/alv-frontend/backend/alv_app/templates.py` — resolve-then-validate on save (422 on failure);
  write/resolve `value_kinds_json`.
- `src/alv-frontend/backend/alv_app/models.py` — `value_kinds` on save + detail models; validation-error
  422 shape carrying per-field messages.
- `src/alv-frontend/backend/alv_app/config.py` — `report_timezone` (default `Asia/Kolkata`).
- `src/alv-frontend/frontend/src/components/ReportForm.tsx` + a new save-modal component — the modal +
  validate-before-save (replaces the current inline "Save as template" name box).
- `src/alv-frontend/frontend/src/components/TemplatesPage.tsx` — dynamic badges (optional).
- `src/alv-frontend/frontend/src/api/hooks.ts` + `api/types.ts` — carry `value_kinds`.
- Tests: `src/alv-frontend/backend/tests/test_dynamic_values.py` (new) + additions to `test_templates.py`
  (save-validation for both kinds); frontend modal + validate-before-save test.
- Docs: `CHANGELOG.md`, `README.md`, `docs/METADATA_TABLE.md`.
</content>
</invoke>
