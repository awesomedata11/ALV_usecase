# Metadata Tables — Worked Example & Handover

> **Status:** v1 — handover snapshot
> **Owner:** ALV-Bricks team
> **Scope:** Concrete picture of the metadata tables under the **14-job** understanding
> of Retail Ledger: which tables exist, their grain, sample records, row counts, and
> relations. Companion to `input_fields_json_design.md` (the `input_fields_json` deep
> dive) and §3 of `ALV_App_Task_Breakdown.md` (the broader framework).
>
> **In scope for the pilot:** `alv_catalog`, `request_log`.
> **Out of scope (removed here):** `auth_map` / row-level auth (deferred, D19). The
> auth dimension is intentionally left out of this doc; pick it up when auth is added.

---

## 0. Reconciliation note (read first)

`ALV_App_Task_Breakdown.md` §3.1 currently says *"`alv_catalog` — one row per ALV
report"* (so **1** row for `retail_ledger`, with the four selections nested inside one
`input_fields_json`). The **14-job discovery supersedes that**:

- Each *(selection × report_type)* combination has its **own backend Job** → its **own
  `alv_catalog` row**. Retail Ledger = **14 rows**.
- `input_fields_json` is **flat per row** (no nested `selections[]`).
- `alv_catalog` gains navigation/identity columns: `selection_*`, `report_type_*`.

This doc reflects the new model. (§3.1 of the task-breakdown still says the old thing —
noted in §5 as a **to-think-about** item, not yet actioned.)

---

## 1. `alv_catalog` — catalogue + report→Job binding

**Grain:** one row per **runnable report** (= per `job_id`).
**Rows for Retail Ledger: 14.**

### Columns

| Column | Type | Notes |
|---|---|---|
| `alv_id` | STRING (PK) | Slug of the natural key, e.g. `retail_ledger__detail__agent_item` |
| `report_key` | STRING | `retail_ledger` (denormalized onto every row — flat by design) |
| `report_label` | STRING | "Retail Ledger" |
| `selection_id` | STRING | Navigation level 1, e.g. `detail` |
| `selection_label` | STRING | "Detail" |
| `selection_order` | INT | Display order of the selection |
| `report_type_code` | STRING (nullable) | Navigation level 2, e.g. `agent_item`. **NULL for Closing Balance** |
| `report_type_label` | STRING (nullable) | "Agent Item". NULL for Closing Balance |
| `report_type_order` | INT (nullable) | Display order of the report radio. NULL for Closing Balance |
| `alv_name` | STRING | Display name, e.g. "Retail Ledger — Detail — Agent Item" |
| `description` | STRING | Catalogue subtitle |
| `job_id` | BIGINT | **The bound Job — unique per row** |
| `job_run_mode` | STRING | `run_now` |
| `input_fields_json` | STRING (JSON) | **This row's own complete flat form** (`{schema_version, fields[]}`) |
| `is_active` | BOOLEAN | Hide from catalogue without deletion |

> Natural key: `(report_key, selection_id, report_type_code)`. `alv_id` is the slugged
> form of that key and is what `request_log` references.

### Field sets (3 distinct shapes across the 14 rows)

| Selection | Fields in `input_fields_json` | Count |
|---|---|---|
| Detail | `date_range`, `agent`, `jc`, `order_ref_no`, `transaction_type`, `time_range` | 6 |
| Sequence Wise / Time Wise | `date_range`, `agent` | 2 |
| Agent Closing Balance | `transaction_date` (single date) | 1 |

Each row stores its **own copy** of these fields (repetition accepted — no shared form /
no `form_id`; see `input_fields_json_design.md` §3.3).

### Full 14-row seed

| alv_id | sel_id | sel_ord | report_type_code | rt_ord | job_id | fields |
|---|---|---|---|---|---|---|
| `retail_ledger__detail__agent_item` | detail | 1 | `agent_item` | 1 | 101 | 6 |
| `retail_ledger__detail__agent_detail_payment_gateway` | detail | 1 | `agent_detail_payment_gateway` | 2 | 102 | 6 |
| `retail_ledger__detail__agent_detail_customer_state` | detail | 1 | `agent_detail_customer_state` | 3 | 103 | 6 |
| `retail_ledger__sequence_wise__agent_summary` | sequence_wise | 2 | `agent_summary` | 1 | 104 | 2 |
| `retail_ledger__sequence_wise__summary_jc_agent` | sequence_wise | 2 | `summary_jc_agent` | 2 | 105 | 2 |
| `retail_ledger__sequence_wise__statewise_summary` | sequence_wise | 2 | `statewise_summary` | 3 | 106 | 2 |
| `retail_ledger__sequence_wise__summary_price_group` | sequence_wise | 2 | `summary_price_group` | 4 | 107 | 2 |
| `retail_ledger__sequence_wise__national_partner_role` | sequence_wise | 2 | `national_partner_role` | 5 | 108 | 2 |
| `retail_ledger__time_wise__agent_summary` | time_wise | 3 | `agent_summary` | 1 | 109 | 2 |
| `retail_ledger__time_wise__summary_jc_agent` | time_wise | 3 | `summary_jc_agent` | 2 | 110 | 2 |
| `retail_ledger__time_wise__statewise_summary` | time_wise | 3 | `statewise_summary` | 3 | 111 | 2 |
| `retail_ledger__time_wise__summary_price_group` | time_wise | 3 | `summary_price_group` | 4 | 112 | 2 |
| `retail_ledger__time_wise__national_partner_role` | time_wise | 3 | `national_partner_role` | 5 | 113 | 2 |
| `retail_ledger__agent_closing_balance` | agent_closing_balance | 4 | _NULL_ | _NULL_ | 114 | 1 |

`job_id` values `101–114` are **placeholders** pending the RIL Job-key contract
(`input_fields_json_design.md` Open items #1, #4).

### One full `input_fields_json` (row `alv_id = retail_ledger__detail__agent_item`)

The complete blob for all 14 rows lives at
[`examples/retail_ledger.input_fields.json`](./examples/retail_ledger.input_fields.json)
(`catalog_rows[].input_fields_json`). Detail row, abridged to two fields:

```json
{
  "schema_version": 1,
  "fields": [
    {
      "control": "date_range",
      "display_label": "Transaction Date",
      "display_order": 1,
      "data_type": "date",
      "mandatory": true,
      "parts": {
        "from": { "param_name": "transaction_date_from", "display_label": "From" },
        "to":   { "param_name": "transaction_date_to",   "display_label": "To" }
      },
      "validations": [
        { "rule": "from_lte_to", "message_key": "ALV_DATE_FROM_GT_TO" },
        { "rule": "max_offset_from_today", "applies_to": "from", "unit": "months", "value": 12, "message_key": "ALV_DATE_TOO_OLD" },
        { "rule": "max_span", "unit": "days", "value": 31, "message_key": "ALV_DATE_SPAN_EXCEEDED" }
      ]
    },
    { "param_name": "agent", "display_label": "Agent", "display_order": 2, "control": "text", "data_type": "string", "selection_type": "single", "mandatory": false, "default": null, "omit_if_blank": true, "normalize": ["trim", "uppercase"], "validations": [] }
    /* + jc, order_ref_no, transaction_type, time_range */
  ]
}
```

---

## 2. `request_log` — run tracking + result cache

**Grain:** one row per **submission**, written entirely by the App (the customer's Job
never touches it). Doubles as the status-view source and the result cache (D8, D12).
**Rows: 0 at launch → unbounded** (grows with usage; cache hits add none).

### Columns

| Column | Type | Purpose |
|---|---|---|
| `request_no` | STRING (PK) | App-generated id shown to the user |
| `alv_id` | STRING (FK → `alv_catalog.alv_id`) | Which runnable report |
| `run_id` | BIGINT | Databricks Job run id (status polling) |
| `submitted_by` | STRING | User AAD object ID |
| `param_payload_json` | STRING | Canonical JSON of the parameter inputs used |
| `param_hash` | STRING | SHA-256 of the canonical payload |
| `status` | STRING | QUEUED / RUNNING / COMPLETED / FAILED / EXPIRED |
| `submitted_at` | TIMESTAMP | When the App triggered the run |
| `generated_at` | TIMESTAMP | When the output file was produced (on success) |
| `output_path` | STRING | NAS/ADLS path returned by the Job |
| `row_count` | LONG | Optional, if the Job returns it |
| `expires_at` | TIMESTAMP | When the cached file is purged (drives cache validity) |
| `error_message` | STRING | Populated on failure |

### Sample rows

| request_no | alv_id | run_id | submitted_by | param_payload_json | param_hash | status | submitted_at | generated_at | output_path | expires_at | error_message |
|---|---|---|---|---|---|---|---|---|---|---|---|
| REQ-20260625-0001 | `retail_ledger__detail__agent_item` | 88231 | u-aad-1001 | `{"transaction_date_from":"2026-05-01","transaction_date_to":"2026-05-15","agent":"Z217"}` | `a1f3…e9` | COMPLETED | 06-25 09:14 | 06-25 09:16 | `/mnt/alv/retail_ledger/agent_item/REQ-…0001.xlsx` | 06-26 09:16 | — |
| REQ-20260625-0002 | `retail_ledger__detail__agent_detail_payment_gateway` | 88240 | u-aad-1002 | `{"transaction_date_from":"2026-05-01","transaction_date_to":"2026-05-15","agent":"Z217"}` | `a1f3…e9` | RUNNING | 06-25 09:20 | — | — | — | — |
| REQ-20260624-0050 | `retail_ledger__detail__agent_item` | 87012 | u-aad-1001 | `{"transaction_date_from":"2026-04-01","transaction_date_to":"2026-04-10"}` | `7c20…1b` | EXPIRED | 06-24 11:00 | 06-24 11:02 | `/mnt/alv/retail_ledger/agent_item/REQ-…0050.xlsx` | 06-25 11:02 | — |
| REQ-20260624-0099 | `retail_ledger__agent_closing_balance` | 87990 | u-aad-1003 | `{"transaction_date":"2026-06-22"}` | `bb71…4c` | FAILED | 06-24 18:02 | — | — | — | Job run 87990 failed: source lock timeout |

### Cache key — and why it can't collide

Cache key = **`(alv_id, param_hash)`**.

Rows **0001** and **0002** carry the **identical** `param_payload_json` → **identical
`param_hash` `a1f3…e9`** — but they are *different report types*, so different `alv_id`.
The key includes `alv_id`, so they **do not collide**. Because `alv_id` already encodes
report + selection + report_type, keying on `(alv_id, param_hash)` is exactly the
"include report + selection + report_type in the hash" requirement
(`input_fields_json_design.md` D-IFJ-11) — no extra key columns needed.

**Cache hit (creates no row):** a later submission of `retail_ledger__detail__agent_item`
whose payload hashes to `a1f3…e9`, while row 0001 is `COMPLETED` and `expires_at > now()`,
makes the App offer "reuse the file from 09:16" and trigger **no** new run.

Lookup on submit:
```sql
SELECT * FROM request_log
WHERE alv_id = ? AND param_hash = ? AND status = 'COMPLETED' AND expires_at > now();
```

---

## 3. Relations

```
            ┌───────────────────────────────────────┐
            │               alv_catalog             │  grain: 1 row / runnable report
            │  PK alv_id                            │  Retail Ledger = 14 rows
            │     report_key, report_label,         │
            │     selection_id/label/order,         │
            │     report_type_code/label/order,     │
            │     job_id (unique per row),          │
            │     input_fields_json (flat),         │
            │     is_active                         │
            └───────────────────┬───────────────────┘
                                │ 1
                                │
                                │ N    FK: request_log.alv_id → alv_catalog.alv_id
            ┌───────────────────┴───────────────────┐
            │               request_log             │  grain: 1 row / submission
            │  PK request_no                        │  rows: 0 → unbounded
            │     alv_id (FK), run_id, submitted_by,│
            │     param_payload_json, param_hash,   │  cache key = (alv_id, param_hash)
            │     status, output_path, expires_at,  │
            │     ...                               │
            └───────────────────────────────────────┘
```

**Cardinality:** `alv_catalog` **1 — N** `request_log` (one runnable report → many runs).

---

## 4. Row-count summary

| Table | Rows in pilot | Grows by |
|---|---|---|
| `alv_catalog` | **14** (Retail Ledger) | +1 per runnable report onboarded (each new ALV report adds its own N rows) |
| `request_log` | **0 → unbounded** | +1 per submission (cache hits add none) |

---

### Deliberate design choices (settled)

- **No separate "report" parent table.** `report_key` / `report_label` are denormalized
  onto every `alv_catalog` row — flat, repetition accepted (per your preference).
- **No `auth_map` / row-level auth** — out of scope for the pilot (D19). Removed from
  this doc; revisit when auth is added (it brings back `auth_map` and an
  `auth_dimension_columns` column on `alv_catalog`).

### To think about later (open — decide what's correct, then action)

- **`message_key` vs inline `message`.** This doc and `input_fields_json_design.md`
  (D-IFJ-9) use `message_key` resolved against a message catalogue;
  `ALV_App_Task_Breakdown.md` §3.2 still shows inline `"message"` text. Which is right is
  still **to think about** — not yet decided.
- **§3.1 of `ALV_App_Task_Breakdown.md` ("one row per ALV report").** It predates the
  14-row / flat-`input_fields_json` model shown here. Whether/how to update it is **to
  think about** later.

---

## 6. Related artifacts

- `input_fields_json_design.md` — the `input_fields_json` contract (storage, fields,
  validation vocabulary, decisions D-IFJ-1…12).
- `examples/retail_ledger.input_fields.json` — the 14 self-contained rows with full
  `input_fields_json`.
- `ALV_App_Task_Breakdown.md` §3 — the broader framework (has the drifts noted above).
