# `input_fields_json` — Design & Decisions

> **Status:** v1 (initial) — living document
> **Owner:** ALV-Bricks team
> **Scope:** How report input parameters are stored in the metadata table and how
> the App (Phase 2) reads them, derives constraints, and enforces them in the UI.
> This is the deep-dive companion to Task **2.4**. The first concrete report it
> models is **Retail Ledger** (source of truth:
> `Retail ledger report/input_parameters.txt`).

---

## 1. Purpose

The metadata table stores **one JSON blob per runnable report** (per catalog row)
that fully describes its selection screen: which input fields exist, how they
render, what constraints apply, and what parameter names get passed to the backend
Job. The App is **generic** — it renders forms and validates input purely from this
JSON, with **no per-report code**. Onboarding a new report = inserting/extending
metadata, never changing the App.

---

## 2. Storage decision

| Decision | Choice | Reason |
|---|---|---|
| Column type | **`STRING` holding JSON** | No DDL coupling — new rules/attributes need no `ALTER TABLE`. Canonical artifact lives as a `.json` file in the bundle (version control, diffs, PR review). Loaded once into App memory and parsed in Python. |
| Why not `VARIANT` | Rejected for now | VARIANT pays off when you filter/extract *inside* the JSON in SQL at scale. Here it's one tiny row per report, read once at startup — VARIANT's benefits are wasted and we lose the "edit as a plain `.json` file" ergonomic. |
| Why not typed `ARRAY<STRUCT>` | Rejected | Every new rule/attribute becomes a schema-evolution event. Fights the "extend without touching the table" goal. |
| Schema versioning | **Single schema, `schema_version: 1`** | We are NOT maintaining multiple versions. The constant is *insurance only*: if an incompatible blob ever appears, the loader fails fast instead of misreading it. Costs one integer. |
| History / audit | **Delta time travel** | `DESCRIBE HISTORY` / `VERSION AS OF` on the metadata table gives full change history (who/when, diff, rollback) with no version field in the JSON. |

**Net:** keep `input_fields_json STRING`; enforce the contract in a **versioned
application-layer validator** (JSON Schema or Pydantic), not the Delta type.

---

## 3. Catalog layering — one row per runnable report (14 for Retail Ledger)

**Discovery (locked):** each *(selection × report type)* combination in Retail
Ledger is backed by its **own backend Job**, so each gets its **own catalog row**.

| Selection | Report types | Jobs / rows |
|---|---|---|
| Detail | Agent Item · Agent Detail Payment Gateway · Agent Detail Customer State | 3 |
| Sequence Wise | Agent Summary · Summary JC & Agent · StateWise Summary · Summary Price Group · National Partner Role | 5 |
| Time Wise | (same 5) | 5 |
| Agent Closing Balance | — (no report type) | 1 |
| **Total** | | **14** |

### 3.1 `input_fields_json` is FLAT per row

Because the row already identifies exactly one Job, its `input_fields_json` is a
single flat `fields[]` list — **no nested `selections[]`, no conditional grammar**.
(This retires the earlier "one Job vs four" fork and the nested-selections model.)

### 3.2 `selection` and `report_type` are catalog dimensions, NOT input fields

Choosing "Detail → Agent Item" simply **picks which row/Job to run** — it is routing,
not a value the Job consumes. Therefore:

- `report_type` (the SAP radio) and `selection_mode` are **removed from
  `input_fields_json`** and stored as **identity columns on the catalog row**.
- The form shrinks to only the genuine user inputs (dates, agent, jc, …).
- The Job is dispatched purely from the row's `job_id`; neither `selection` nor
  `report_type` is sent as a runtime parameter (the Job *is* that combination).

### 3.3 Each row is fully self-contained — no shared forms, no `form_id`

Every one of the 14 rows carries its **own complete flat `input_fields_json`**. There
is **no form library, no `form_id` reference, no inheritance** — repetition across rows
is **accepted on purpose** to keep the model flat and non-hierarchical.

Why repetition is the right call here:

- Report types within a Selection *usually* share inputs but **may diverge** (a report
  type can need different fields), so any "shared form" abstraction would need an override
  mechanism the moment reality diverges — exactly the merge-consistency complexity we want
  to avoid.
- 14 small rows are trivial to store, read, and diff. The App's read path is a simple
  per-row parse with **zero resolution/join step**.
- If two rows are identical today and one changes tomorrow, they just diverge naturally
  — there is no abstraction to unwind.

Trade-off accepted: a cross-cutting change (e.g. tweak the `agent` rule everywhere)
touches each affected row. At 14 rows that is fine — the authoring source is JSON under
version control, so a find/replace or a small seed script handles it. Revisit only if
row count grows large enough that the duplication genuinely hurts.

### 3.4 Navigation tree (built from catalog metadata)

The UI builds the picker from the catalog rows, not from inside any one blob:

```
Retail Ledger
├─ Detail            → Agent Item / Agent Detail Pmt Gateway / Agent Detail Customer State
├─ Sequence Wise     → Agent Summary / Summary JC & Agent / StateWise / Summary Price Group / National Partner Role
├─ Time Wise         → (same 5)
└─ Agent Closing Bal → (no report type — selecting it loads the form directly)
```

Flow: pick **Selection** → pick **Report** (radio; absent for Closing Balance) →
resolves to exactly one row → render that row's flat form → dispatch its `job_id`.
Closing Balance has no report type, so its tree leaf *is* the selection.

Because each row carries its own form (§3.3), the field set is known only **after** the
row is fully resolved (Selection + Report). Render the input fields after the Report
radio, and **re-render if the user changes the Report** within a Selection — the fields
may differ between sibling report types.

### 3.5 Suggested catalog row identity columns

`report_key` · `selection_id` · `selection_label` · `selection_order` ·
`report_type_code` (nullable) · `report_type_label` (nullable) · `report_type_order` ·
`job_id` · `input_fields_json` (flat). `(report_key, selection_id, report_type_code)`
is the natural key; `job_id` is the dispatch contract.

---

## 4. Field object reference

Each entry in a row's flat `fields[]` array:

| Attribute | Type | Meaning |
|---|---|---|
| `param_name` | string | **Backend contract** — key passed to the Job. Immutable once agreed with RIL. Unique within the row. (Composite controls declare param names under `parts`.) |
| `display_label` | string | UI label. Free to reword; never the contract. |
| `display_order` | int | Render order within the form. |
| `control` | enum | `text` · `date` · `date_range` · `time_range`. Drives the widget. |
| `data_type` | enum | `string` · `date` · `time`. All free-text fields are **`string`** (never auto-cast to number — preserves SAP leading zeros / codes). |
| `selection_type` | enum | `single` · `multi`. Pilot uses `single` for free-text fields (uploads/IN-lists out of scope). |
| `mandatory` | bool | Required to submit the form. |
| `default` | any/null | Value used when the user leaves it blank (see `omit_if_blank`). |
| `omit_if_blank` | bool | **`true`** → drop the key from the payload entirely when blank (no `null` sent). **`false`** → send `default` (or `null`). Decision **D-IFJ-3**. |
| `normalize` | string[] | Canonicalization hints applied before validate/hash: e.g. `["trim"]`, `["trim","uppercase"]`. |
| `validations` | object[] | Rule list (see §5). Single-field rules sit on the field; pairwise/range rules sit on the composite control that owns both endpoints. |

> **Note:** `radio` / `options` are no longer needed in `input_fields_json` — the
> former `report_type` radio is now the catalog's `report_type` dimension (§3.2).

Composite controls (`date_range`, `time_range`) carry a `parts` object that maps
`from`/`to` to their individual `param_name`s, so the backend still receives two
scalar params while validation ownership stays in one place.

---

## 5. Validation vocabulary (rule names)

Rules are dispatched by `rule` name; the **same implementation** runs client-side
(UX) and server-side (pre-dispatch), so they cannot drift. Every rule references a
`message_key` resolved against the **message catalogue** (T2.2) — no inline message
text in the JSON (single home for user-facing strings, D-IFJ-9).

| `rule` | Params | Applies to | Meaning |
|---|---|---|---|
| `from_lte_to` | — | `date_range` / `time_range` | `from ≤ to`. |
| `max_span` | `unit`, `value` | `date_range` | `to − from ≤ value` (e.g. 31 days). Inclusivity defined once (see §7). |
| `max_offset_from_today` | `unit`, `value`, `applies_to` | `date` / `date_range` | The endpoint must not be more than `value` `unit` in the past from today (e.g. 12 months on `from`). |
| `to_required_if_from` | — | `time_range` | If `from` given, `to` is required. |
| `no_filter_when_equal` | — | `time_range` | Equal/zero endpoints (`00:00:00–00:00:00`) ⇒ treat as "no filter" (omit). |
| `regex` | `pattern` | `text` | Optional format check (none required for pilot). |
| `max_length` | `value` | `text` | Optional length cap. |

**Meta-validation:** the loader validates the *rules themselves* at startup (required
params present; unknown `rule` ⇒ **fail the load**, never silently skip — D-IFJ-10).

---

## 6. Read & enforcement path (how the App uses this)

1. **Load + parse once** at startup / admin reload; validate each blob through the
   versioned validator. Malformed config fails **at load**, never at user-request time.
2. **Build navigation** from catalog metadata (report → selection → report_type) and
   **render generically:** once a row is chosen, show its fields in `display_order`;
   `control` → widget, `mandatory` → required marker.
3. **Validate twice, one source of truth:** run `validations[]` client-side for UX and
   re-run server-side before dispatch.
4. **Canonicalize → build payload → hash:** trim, uppercase where flagged, ISO-normalize
   dates/times, apply `omit_if_blank`. Build `{param_name: value, ...}`. The result-cache
   key is **`SHA-256(report_key + selection_id + report_type_code + canonical payload)`** —
   the report/selection/report-type identity MUST be in the key, because sibling report
   types take identical inputs and would otherwise collide on the same hash (D-IFJ-11).
   This is equivalent to including `job_id` (the triple is 1:1 with `job_id`).
5. **Dispatch by `job_id`** from the resolved row. `selection`/`report_type` are not sent
   as params (they are encoded by the row/Job, §3.2).

---

## 7. Date / time semantics (pinned once)

- **Range inclusivity:** `[from, to]` inclusive both ends (matches SAP `BETWEEN`).
- **Span counting:** `max_span` counts inclusive day delta; **1 May–31 May = 31 days = allowed**, 1 May–1 Jun = 32 = rejected.
- **"Today":** the 12-month offset is relative to the **App server clock in a fixed timezone** (document the TZ in deployment config), so day-boundary behavior is deterministic.
- **Both date rules apply together** on the date range: `max_offset_from_today` (≤12 months on `from`) **and** `max_span` (≤31 days). They are independent rules, not a contradiction.
- **Time range (Detail only):** `00:00:00–00:00:00` (equal endpoints) ⇒ no time filter (omit). Decide separately whether a time range may cross midnight (assumed **no** for pilot).

---

## 8. Decisions log

| ID | Decision |
|---|---|
| D-IFJ-1 | Store as `STRING` JSON; enforce via app-layer validator, not Delta type. |
| D-IFJ-2 | Single schema with `schema_version: 1` constant; no multi-version maintenance. Audit via Delta time travel. |
| D-IFJ-3 | Per-field `default` + `omit_if_blank` boolean. When blank and `omit_if_blank=true`, the key is **omitted** (no `null`); otherwise `default` is sent. |
| D-IFJ-4 | All free-text fields are `data_type: string`; never auto-cast to numeric (preserve SAP codes / leading zeros). |
| D-IFJ-5 | Uploads / Excel IN-lists are **out of scope** for the pilot; UI inputs only. Free-text fields are `single`. |
| D-IFJ-6 | Canonicalize (trim, uppercase-where-flagged, ISO dates/times, omit-blank) before building payload and before hashing the cache key. |
| D-IFJ-7 | **One catalog row per runnable report (per `job_id`); `input_fields_json` is FLAT.** No nested `selections[]`, no conditional-visibility language. Retail Ledger = 14 rows. |
| D-IFJ-8 | **`selection` and `report_type` are catalog identity columns, not input fields/params.** Removed from `input_fields_json`; the Job is dispatched by `job_id` alone. |
| D-IFJ-9 | No inline message text; rules carry `message_key` resolved against the message catalogue. |
| D-IFJ-10 | Loader meta-validates rules at startup; unknown rule ⇒ fail load (never silently skip). |
| D-IFJ-11 | Result-cache key = `SHA-256(report_key + selection_id + report_type_code + canonical payload)` — the report/selection/report-type identity MUST be in the key so sibling report types with identical inputs don't collide. Equivalent to keying on `job_id` (the triple is 1:1 with it); the explicit triple is preferred for debuggability. |
| D-IFJ-12 | **Each of the 14 rows is fully self-contained** — its own complete flat `input_fields_json`, **no shared form / no `form_id` / no inheritance**. Repetition across rows is accepted deliberately to keep the model flat; a divergent report type simply carries its own fields. Revisit only if row count makes duplication painful. |

---

## 9. Open items (need RIL / your input)

1. **`param_name` ↔ Job-key contract per Job** — now co-signed **per row (14 Jobs)** with RIL (highest-risk item). Values in the strawman are *placeholders*. Param naming is expected to be consistent across the shared forms.
2. **Blank-filter semantics on the backend** — confirm an omitted key means "no filter" (match all) in each Job's SQL.
3. **Time-range crossing midnight** — assumed not allowed for pilot; confirm.
4. **`job_id` values** — the 14 Jobs must exist / be named so each row can bind one.

---

## 10. Strawman: 4 forms + 14-row routing manifest

The authoring source lives at
[`examples/retail_ledger.input_fields.json`](./examples/retail_ledger.input_fields.json):
the full **14 self-contained catalog rows** — each with its identity columns
*(selection × report_type)*, a placeholder `job_id`, and its **own complete flat
`input_fields_json`** (repetition accepted, §3.3). At seed time each row's stored
`input_fields_json` is the referenced form (expanded). `param_name` / `job_id`
strings are **placeholders pending the RIL contract** (Open items #1, #4).
