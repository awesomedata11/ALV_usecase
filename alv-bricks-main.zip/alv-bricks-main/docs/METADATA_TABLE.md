# Metadata Table Contract

> **Status:** v1 (pilot metadata layer).
> **Owner:** ALV-Bricks team.
> **Audience:** the App (Phase 2) depends on these table shapes — treat a column
> rename/removal as a **breaking change** with a `CHANGELOG` entry.

Single source of truth for the DDL: `src/alv-backend/dbx_alv_reports/metadata/metadata_tables.py`.
This doc describes the tables that module produces. Shapes follow the newer 14-row /
flat `input_fields_json` model (`metadata_tables_example.md`), which supersedes
`ALV_App_Task_Breakdown.md` §3.1.

Tables live in a configurable `{catalog}.{schema}` (default `alv_bricks.metadata`).

---

## `alv_catalog` — catalogue + report→Job binding (task 2.2)

**Grain:** one row per **runnable report** (= per `job_id`). Retail Ledger = **14 rows**.
Each row carries its **own** complete flat `input_fields_json` (no shared forms /
no inheritance — repetition accepted, `input_fields_json_design.md` §3.3).

| Column | Type | Null | Notes |
|---|---|---|---|
| `alv_id` | STRING | no | **PK.** Slug of the natural key, e.g. `retail_ledger__detail__agent_item`. |
| `report_key` | STRING | no | e.g. `retail_ledger`. Denormalized onto every row. |
| `report_label` | STRING | yes | e.g. "Retail Ledger". |
| `selection_id` | STRING | no | Navigation level 1, e.g. `detail`. |
| `selection_label` | STRING | yes | e.g. "Detail". |
| `selection_order` | INT | yes | Display order of the selection. |
| `report_type_code` | STRING | yes | Navigation level 2, e.g. `agent_item`. **NULL for Closing Balance.** |
| `report_type_label` | STRING | yes | e.g. "Agent Item". NULL for Closing Balance. |
| `report_type_order` | INT | yes | Display order of the report radio. NULL for Closing Balance. |
| `alv_name` | STRING | yes | Display name, e.g. "Retail Ledger — Detail — Agent Item". |
| `description` | STRING | yes | Catalogue subtitle. |
| `job_id` | BIGINT | yes | **The bound customer Job (unique per row).** NULL while unbound (placeholder). |
| `job_run_mode` | STRING | yes | `run_now`. |
| `input_fields_json` | STRING | no | This row's own complete flat form: `{schema_version, fields[]}`. |
| `is_active` | BOOLEAN | yes | Hide from catalogue without deletion. |
| `created_at` / `updated_at` | TIMESTAMP | yes | Audit (set by the seeder's MERGE). |

- **Natural key:** `(report_key, selection_id, report_type_code)`; `alv_id` is its slug.
- **`input_fields_json` contract:** `docs/input_fields_json_design.md` +
  `src/alv-backend/dbx_alv_reports/json_specifications/input_fields.schema.json`.
- `selection`/`report_type` are **identity columns, not form fields** (D-IFJ-8); the
  Job is dispatched by `job_id` alone.

---

## `request_log` — run tracking + result cache (task 2.4)

**Grain:** one row per **submission**, written entirely by the App. Cache key =
`(alv_id, param_hash)` (D12, D-IFJ-11).

| Column | Type | Null | Notes |
|---|---|---|---|
| `request_no` | STRING | no | **PK.** App-generated id shown to the user. |
| `alv_id` | STRING | no | **FK → `alv_catalog.alv_id`.** |
| `run_id` | BIGINT | yes | Databricks Job run id (status polling). |
| `submitted_by` | STRING | yes | Submitting user — email, else `preferred_username`, else the SSO user id (that precedence; see `src/alv-frontend/backend/alv_app/main.py::_submitted_by`). Historical rows may mix forms, so the Downloads `scope=mine` filter matches on all three. |
| `param_payload_json` | STRING | yes | Canonical JSON of the parameter inputs. |
| `param_hash` | STRING | yes | SHA-256 of the canonical payload (cache key with `alv_id`). |
| `status` | STRING | yes | QUEUED / RUNNING / COMPLETED / FAILED / EXPIRED. |
| `submitted_at` | TIMESTAMP | yes | When the App triggered the run. |
| `generated_at` | TIMESTAMP | yes | When the output file was produced. |
| `output_path` | STRING | yes | Full path to the output **file** returned by the Job (stored verbatim; the App never parses it). New runs use the per-run layout `/Volumes/<cat>/<schema>/<vol>/<YYYYMMDD>/<alv_id>/<request_no>/<file>` (docs/OUTPUT_PATH_LAYOUT_APPROACH.md); rows from before that change kept their older flat path and still resolve. |
| `row_count` | BIGINT | yes | Optional, if the Job returns it. |
| `expires_at` | TIMESTAMP | yes | When the cached file stops being offered. **Written by the App** on the same output-capture path as `generated_at`: `generated_at + RESULT_TTL_DAYS` (default 7). Not backfilled on rows captured before that change. |
| `error_message` | STRING | yes | Populated on failure. |

Cache lookup on submit — **live as of the result-cache-reuse feature (task 7.3).** The
App reads this on a pre-submit `cache-check` and, on a hit, offers the user the existing
output instead of a fresh run. The lookup additionally requires `output_path IS NOT NULL`
and, when several rows qualify, takes the **newest** (`ORDER BY generated_at DESC ...
LIMIT 1`) — so `param_hash` and `expires_at` are no longer groundwork-only. See
`alv_app/cache_source.py` and `docs/RESULT_CACHE_REUSE_APPROACH.md`.
```sql
SELECT ... FROM request_log
WHERE alv_id = ? AND param_hash = ? AND status = 'COMPLETED'
  AND output_path IS NOT NULL AND expires_at > current_timestamp()
ORDER BY generated_at DESC, submitted_at DESC, request_no DESC
LIMIT 1;
```

---

## `report_permissions` — report visibility by principal (group or user)

**Grain:** one row per (`report_key`, `principal_type`, `principal_name`). Created by
`ensure_all()` (it is in `PILOT_TABLES`), bootstrapped once by the
`seed_alv_report_permissions` job from `src/report_specs/report_permissions.json`; after
setup the **admin console** (`/api/admin/permissions`) owns grants and the seed job is
not re-run.

| Column | Type | Null | Notes |
|---|---|---|---|
| `report_key` | STRING | no | **PK part 1.** FK → `alv_catalog.report_key` (report level, e.g. `retail_ledger`). |
| `principal_type` | STRING | no | **PK part 2.** `'group'` (match against the user's `/Me` groups) or `'user'` (match the caller's email). |
| `principal_name` | STRING | no | **PK part 3.** For `group`: a Databricks group **display name** (case-sensitive), e.g. `alv-report_ledger_group`. For `user`: the user's **email, stored lower-cased** and matched case-folded. |
| `is_active` | BOOLEAN | yes | Revoke a grant without deleting the row. NULL counts as active. |
| `granted_at` | TIMESTAMP | yes | Audit (set on insert by the MERGE). |
| `granted_by` | STRING | yes | Audit — who granted it (the seed name, or the admin's identity). |

> **Schema change (2026-08-08):** this table previously had grain
> (`report_key`, `group_name`). It was generalized to carry ad-hoc **user** grants
> alongside **group** grants. `group_name` was renamed to `principal_name` and
> `principal_type` was added. A one-time migration on the deployed table performs the
> rename + add-column + backfill (`principal_type='group'`); `ensure_all()` only
> CREATEs, it does not ALTER an existing table. The seeder still accepts a legacy
> `group_name` manifest entry (treated as a group grant).

**Semantics the App enforces** (`src/alv-frontend/backend/alv_app/entitlements.py`):

- A user sees a report when **any** active grant permits them: a **group** grant for a
  group they belong to, **OR** a **user** grant naming their email. Several grants per
  report mean **OR**; a report granted by both a group and a user appears once.
- A `report_key` with **no active row is hidden from everyone** — the default is
  **CLOSED**. A grant is what makes a report visible at all.
- Gating is at **report level**: the home-page card and every selection / report type
  under that `report_key` move together. It is *not* per report type.
- Enforced on the **read and write paths alike** — catalogue, form, submit, preview,
  status, and download. A report the caller may not see returns **404**, identical to
  a non-existent one, so the gate discloses nothing.
- The App reads this table as the **App service principal**. **Group** grants are
  matched against the user's groups from `GET /api/2.0/preview/scim/v2/Me` (the user's
  injected OBO token; needs no admin rights). **User** grants are matched against the
  proxy-injected `X-Forwarded-Email` header, so they work **even when OBO is off**.
- **Flat groups only** (group grants). `/Me` returns **direct** memberships, so a user
  only in a group *nested inside* a mapped group will **not** see the report.

A `report_key` here need not exist in `alv_catalog` (a grant may precede the report) —
it simply grants nothing until the report is seeded.

---

## `report_templates` — per-user saved parameter templates (variants)

**Grain:** one row per (`owner`, `alv_id`, `template_name`). Created by `ensure_all()`
(it is in `PILOT_TABLES`); written entirely by the App at runtime (there is no seed job).
A **template** is a named snapshot of the raw form values for one runnable report, owned
by one user — a user sees only his own templates.

| Column | Type | Null | Notes |
|---|---|---|---|
| `template_id` | STRING | no | **PK.** App-generated id, e.g. `TPL-<uuid>`. |
| `alv_id` | STRING | no | **FK → `alv_catalog.alv_id`.** The runnable report the template fills. |
| `owner` | STRING | no | The owning user's **email, stored lower-cased** and matched case-folded. A user sees only rows where `owner` = his email. |
| `template_name` | STRING | no | User-given name (display + pick). **Unique per (`owner`, `alv_id`)** — re-saving a name overwrites that template. |
| `param_values_json` | STRING | no | The saved **RAW** form values: the flat `{param_name: value}` map as submit/preview receive it (composite ranges carry their own `from`/`to` keys). **NOT** the normalized job payload — storing the raw map lets a load refill the form faithfully. |
| `value_kinds_json` | STRING | yes | **Dynamic templates.** An optional `{param_name: {"kind":"dynamic","preset":<PRESET>,"n"?:<int>}}` map for the date fields that resolve **relative to "now" at load**. Only dynamic fields appear; everything else is static (its literal in `param_values_json`). NULL/absent ⇒ fully static. Presets (closed set, `alv_app/dynamic_values.py`): `TODAY`, `CUR_DATE_PLUS_N_DAYS` (needs `n`), `FIRST_DAY_CUR_MONTH`, `LAST_DAY_CUR_MONTH`, `FIRST_DAY_NEXT_MONTH`, `LAST_DAY_NEXT_MONTH`, `FIRST_DAY_PREV_MONTH`, `LAST_DAY_PREV_MONTH`. Only `date`-typed params may be dynamic. |
| `is_active` | BOOLEAN | yes | Soft-delete without removing the row. NULL counts as active. |
| `created_at` | TIMESTAMP | yes | Audit — first save. |
| `updated_at` | TIMESTAMP | yes | Audit — set on each save / rename / delete. |

**Semantics the App enforces** (`src/alv-frontend/backend/alv_app/templates.py` + the
`/api/reports/{alv_id}/templates` endpoints):

- **Owner-private.** Every read and write carries `owner = :owner` (the caller's
  lower-cased email), so a user can only ever see or change his own rows. A foreign or
  guessed `template_id` simply does not match — it reads as **404**, disclosing nothing.
- **Report-gated first.** Each endpoint applies the `report_permissions` gate (via
  `is_report_permitted`) **before** the owner logic, so a user cannot touch templates for
  a report he may not see. **404, not 403**, exactly like every other report-scoped path.
- An **unidentifiable caller (no email)** is refused (404) — templates are owned by email.
- **Save is an upsert** on (`owner`, `alv_id`, `template_name`): re-using a name overwrites
  that template (and reactivates a soft-deleted one). **Rename** rejects a name already used
  by another of the user's templates for the same report.
- Written by the App as the **App service principal** (bound SQL, same seam as
  `request_log` / the admin console). No new grants — the App SP's schema-level
  `MODIFY`/`SELECT` covers it.
- **Validated at save** (both static and dynamic): the App resolves any dynamic presets
  against "now", merges over the static values, and runs the report's field validations; a
  template that would fail is refused **422** with the failing-field messages. A dynamic
  template is validated against *today's* resolved dates — it may still resolve to a
  validation failure in a later month, which surfaces at submit via the form validation.
- **Dynamic values resolve at load**, in the report timezone (`REPORT_TIMEZONE`, default
  `Asia/Kolkata`). `GET …/templates/{id}` returns concrete dates (dynamic merged over
  static) plus the raw `value_kinds` map so the UI can badge + re-edit them.

---

## `auth_map` — DEFERRED (task 2.3 / D19), superseded for report visibility

Row-level authorisation is **out of scope for the pilot**. The DDL exists in
`metadata_tables.py` (`AUTH_MAP_TABLE`) but is **not created** by `ensure_all()`
unless `include_auth_map=True`.

> **D19 is superseded for report visibility** by `report_permissions` above. `auth_map`'s
> grain was *data-row* filtering by business dimension (plant/region), which is a
> different concern from deciding which reports a user may open. The DDL and its tests
> are retained unchanged in case data-row filtering is revived; nothing reads it.

---

## Constraints & history

- PK/FK are declared as **informational** UC constraints (not enforced at write
  time) — they document the contract and enable optimizer/BI tooling.
- **History/audit** via Delta time travel (`DESCRIBE HISTORY`, `VERSION AS OF`) — no
  version field in the JSON (D-IFJ-2).
