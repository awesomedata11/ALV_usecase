# App Prerequisites — grants the App service principal needs (end-to-end)

> **Audience:** the operator deploying / wiring the ALV-Bricks Databricks App.
> **Scope:** the definitive list of everything the **App service principal (SP)** and
> the workspace must be granted for the App to work end-to-end — the read path
> (catalogue + form) **and** the new submit path (persist `request_log` + trigger the
> Job). Each item has the exact CLI/SQL to grant it.

The App runs as its own **service principal** (Databricks Apps auto-injects its OAuth
creds). All data access, the `request_log` writes, and the Jobs `run-now` happen as
this SP. Fill in the placeholders once:

| Placeholder | What it is | Where to find it |
|---|---|---|
| `<APP_SP>` | The App's service-principal **application id** (client id) | Databricks Apps UI → the app → its service principal; or `databricks apps get alv-bricks` |
| `<DUMMY_JOB_ID>` | The deployed `alv_dummy_report_run` job id — **now `1044615550343710`** | `databricks bundle run -t dev` output, or the Jobs UI, after `databricks bundle deploy -t dev` |

Deployed context (pilot): workspace **fevm-classic-stable-lakebase**, catalog
**`classic_stable_lakebase_catalog`**, schema **`alv_metadata`**, SQL warehouse
**`f399753196bda967`**.

---

## 0. Status at a glance — all applied on `fevm-classic-stable-lakebase`

**Everything below is now applied** on the pilot workspace and the submit path is
live-tested end-to-end. The 🆕/✅ markers record when each grant landed (read-path
deploy vs. the submit pass); re-run the SQL/CLI as-is for a fresh workspace.

| Grant | Status | Section |
|---|---|---|
| `USE CATALOG` on the catalog | ✅ applied (read-path deploy) | [1](#1-unity-catalog) |
| `USE SCHEMA` + `SELECT` on `alv_metadata` | ✅ applied (read-path deploy) | [1](#1-unity-catalog) |
| **`MODIFY` on `alv_metadata`** | ✅ applied (submit pass) — for the `request_log` INSERT/UPDATE | [1](#1-unity-catalog) |
| **`READ VOLUME` / `WRITE VOLUME` on `alv_outputs`** | ✅ applied (submit pass) — the Job writes, the App later reads outputs | [2](#2-uc-volume-for-job-outputs) |
| SQL warehouse `CAN_USE` (id `f399753196bda967`) | ✅ applied (read-path deploy) | [3](#3-sql-warehouse) |
| `DATABRICKS_WAREHOUSE_ID` env var | ✅ set (`app.yaml`) | [3](#3-sql-warehouse) |
| **Job trigger permission (`CAN_MANAGE_RUN`)** on the dummy job | ✅ applied (submit pass) — so `run-now` works as the SP | [4](#4-jobs) |
| **All 14 `alv_catalog.job_id` bound** to dummy job `1044615550343710` | ✅ applied (submit pass) | [5](#5-bind-the-14-job_ids-the-job-binding-step) |
| **`report_permissions` created + seeded** | 🆕 **required this pass** — reports are HIDDEN until seeded | [6](#6-report-visibility-report_permissions) |
| **App `user_api_scopes`** (`iam.current-user:read`) | ✅ already effective on the deployed app — **do not PATCH** | [6](#6-report-visibility-report_permissions) |

---

## 1. Unity Catalog

The metadata tables (`alv_catalog`, `request_log`) are **Delta over the SQL
warehouse**. The App reads `alv_catalog`, **reads** `request_log` (the Downloads page,
`GET /api/requests`), and **writes** `request_log` (the submit path), so the SP needs
`MODIFY` on the schema in addition to the read grants. The Downloads read is covered by
the existing `SELECT` grant — it needs **no new grant**.

```sql
-- ✅ already applied on the read-path deploy (shown for completeness / re-runnable):
GRANT USE CATALOG ON CATALOG classic_stable_lakebase_catalog TO `<APP_SP>`;
GRANT USE SCHEMA  ON SCHEMA  classic_stable_lakebase_catalog.alv_metadata TO `<APP_SP>`;
GRANT SELECT      ON SCHEMA  classic_stable_lakebase_catalog.alv_metadata TO `<APP_SP>`;

-- 🆕 NEW this pass — required for the request_log INSERT/UPDATE (task 7.4):
GRANT MODIFY ON SCHEMA classic_stable_lakebase_catalog.alv_metadata TO `<APP_SP>`;
```

> `MODIFY` at the schema level covers INSERT/UPDATE on `request_log` (and any future
> metadata writes). Scope it to the single table instead if you prefer least-privilege:
> `GRANT MODIFY ON TABLE classic_stable_lakebase_catalog.alv_metadata.request_log TO \`<APP_SP>\`;`

Verify:
```sql
SHOW GRANTS `<APP_SP>` ON SCHEMA classic_stable_lakebase_catalog.alv_metadata;
```

## 2. UC Volume (for Job outputs)

The dummy job writes its dummy CSV to a **UC Volume** (per CONTRACT.md §4.2:
App-proxied download from a UC Volume). The volume is **parameterized** on the job
(`volume` param) — create it and grant the SP read+write. The default volume name on
the job resource is `alv_outputs`.

```sql
-- Create the output Volume (managed) if it doesn't exist:
CREATE VOLUME IF NOT EXISTS classic_stable_lakebase_catalog.alv_metadata.alv_outputs;

-- 🆕 NEW this pass — the Job writes outputs; the App later reads them to proxy downloads:
GRANT READ VOLUME  ON VOLUME classic_stable_lakebase_catalog.alv_metadata.alv_outputs TO `<APP_SP>`;
GRANT WRITE VOLUME ON VOLUME classic_stable_lakebase_catalog.alv_metadata.alv_outputs TO `<APP_SP>`;
```

> The **Job** (running as its own principal) also needs `WRITE VOLUME` to produce the
> file; the **App** SP needs `READ VOLUME` to proxy the download later (task 9.x). If
> the Job runs as the App SP (single-principal pilot), the two grants above cover both.

### 2a. Output-path layout the Job MUST follow (RIL Job I/O contract)

A report Job **does not choose its own layout**. It writes its output file(s) into a
per-run subfolder on the volume, so runs stay browsable by day / report and are cheap
to retention-clean (docs/OUTPUT_PATH_LAYOUT_APPROACH.md):

```
/Volumes/<catalog>/<schema>/<volume>/<YYYYMMDD>/<alv_id>/<request_no>/<file(s)>
```

- **`<YYYYMMDD>`** — the Job stamps the run date itself, in the `report_timezone` job
  param (default `Asia/Kolkata`), **not** the cluster locale.
- **`<alv_id>`** and **`<request_no>`** — passed to the Job as run parameters (already
  sent by the App on `run-now`); used **verbatim** as single path segments (`alv_id` is
  never split into its `report_key__…` parts).
- The filename inside the `<request_no>` folder is free (our stand-in jobs let Spark
  name the `part-*.csv`); the Job returns the **concrete file path** in its
  `dbutils.notebook.exit` pointer (`output_path`), exactly as before.
- The stand-in jobs build this via the shared `dbx_alv_reports.build_output_dir` helper;
  a real RIL Job reproduces the same composition.

### 2b. Retention cleanup job — run-as needs `WRITE VOLUME`

The daily `alv_output_cleanup` job (`resources/alv_output_cleanup.job.yml`) deletes
`<YYYYMMDD>` folders older than `output_retention_days` (default **30**, set in
`databricks.yml`). Its **run-as identity needs `WRITE VOLUME`** on `alv_outputs` to
delete. In dev it runs as the deploying user; in prod it runs as the SPN — grant that
SPN `WRITE VOLUME` (the `GRANT WRITE VOLUME … TO <APP_SP>` above already covers the App
SP if the cleanup runs as it). The schedule (01:00 `Asia/Kolkata`) is auto-paused in the
dev target and unpaused in prod.

## 3. SQL warehouse

```bash
# ✅ already applied (read-path deploy) — SP can use the serverless warehouse:
databricks grants update warehouse f399753196bda967 \
  --json '{"changes":[{"principal":"<APP_SP>","add":["CAN_USE"]}]}'
```

- Env var **`DATABRICKS_WAREHOUSE_ID=f399753196bda967`** — ✅ already set in
  `src/alv-frontend/backend/app.yaml`. It drives both the `alv_catalog` read and the `request_log`
  writes (statement-execution).

## 4. Jobs

The App calls `jobs run-now` on the row's bound `job_id` as the SP, so the SP needs
run permission on the dummy job.

```bash
# 🆕 NEW this pass — grant the App SP permission to TRIGGER the dummy job:
databricks jobs update-permissions <DUMMY_JOB_ID> \
  --json '{"access_control_list":[{"service_principal_name":"<APP_SP>","permission_level":"CAN_MANAGE_RUN"}]}'
```

- `CAN_MANAGE_RUN` is the minimum for `run-now`; `CAN_MANAGE` also works.
- The dummy job is defined in `resources/alv_dummy_report_run.job.yml` and deploys via
  `databricks bundle deploy -t dev`. **Deployed** on the pilot workspace as job
  `1044615550343710` and run SUCCESS end-to-end.

## 5. Bind the 14 `job_id`s (the job-binding step)

All 14 `alv_catalog` rows currently have **`job_id = NULL`** (placeholders). Until a
row is bound, the submit endpoint returns a clean **409 "not bound to a job yet"**.
After deploying the dummy job, bind **all 14 rows** to it (ONE job for all rows, for
now):

```sql
-- 🆕 NEW this pass — bind every Retail Ledger row to the deployed dummy job:
UPDATE classic_stable_lakebase_catalog.alv_metadata.alv_catalog
SET job_id = <DUMMY_JOB_ID>,
    job_run_mode = 'run_now',
    updated_at = current_timestamp()
WHERE report_key = 'retail_ledger';
```

Verify (expect 14 rows, all non-NULL):
```sql
SELECT count(*) AS bound
FROM classic_stable_lakebase_catalog.alv_metadata.alv_catalog
WHERE report_key = 'retail_ledger' AND job_id IS NOT NULL;
```

> After binding, **restart the App** (or wait for a cache reload) so its in-memory
> metadata cache picks up the new `job_id`s — the cache is warmed once at startup.

## 6. Report visibility (`report_permissions`)

Reports are gated by workspace-group membership and the default is **CLOSED**: a
`report_key` with no active row in `report_permissions` is **invisible to everyone**,
on the read *and* write paths. So after this feature lands the App looks empty until
the table is seeded.

**a. Create the table** — it is part of `PILOT_TABLES`, so it comes from the existing
provisioning job (no new grant, no new SQL):

```bash
databricks bundle run provision_alv_metadata -t dev
```

**b. Seed the mappings** — the new job, from `src/report_specs/report_permissions.json`
(ships `retail_ledger` and `cc_recharge` → `alv-report_ledger_group`):

```bash
databricks bundle run seed_alv_report_permissions -t dev
```

Verify (expect 2 rows):
```sql
SELECT report_key, group_name, is_active, granted_at
FROM classic_stable_lakebase_catalog.alv_metadata.report_permissions
ORDER BY report_key;
```

**c. Grants — nothing new.** The App only ever **SELECT**s this table, and the existing
schema-level `SELECT` (§1) already covers it. The seed job runs as *your* identity via
the bundle, not the App SP.

**d. User authorization (OBO) — already in place; do NOT change it.** The App reads the
*end user's* groups from `GET /api/2.0/preview/scim/v2/Me` using the
`X-Forwarded-Access-Token` the platform injects. The deployed app already has effective
`user_api_scopes` `['iam.access-control:read', 'iam.current-user:read']` and its
`/api/me` reports `has_user_token: true`, so this works as-is.

> ⚠️ **Do not add or PATCH `user_api_scopes`.** A PATCH can silently purge the existing
> scopes, which would break the gate (every user would then see nothing). The `sql`
> scope is **not** needed — the mapping table is read as the App SP.

**e. Restart the App** after seeding? Not required for the mappings — the App caches
`report_permissions` for only `PERMISSIONS_MAP_TTL_SECONDS` (default 300s), so a re-seed
takes effect within ~5 minutes. A restart makes it immediate.

**Only direct group memberships count.** `/Me` does not resolve nesting, so map the
group users are actually in, not a parent group.

---

## Order of operations

_Completed on `fevm-classic-stable-lakebase` (dummy job `1044615550343710`); reuse
these steps to stand the App up on a fresh workspace._

1. Deploy the bundle (`databricks bundle deploy -t dev`) → note `<DUMMY_JOB_ID>`.
2. Apply the 🆕 grants: schema `MODIFY` (§1), Volume read/write (§2), job
   `CAN_MANAGE_RUN` (§4). Create the output Volume (§2) if absent.
3. Bind the 14 `job_id`s (§5).
4. Create + seed `report_permissions` (§6) — **otherwise the App shows no reports.**
5. Deploy/restart the App so the cache reloads with the bound `job_id`s.
6. Submit a report from the UI → a `request_log` row is written (`QUEUED` + `run_id`)
   and the dummy job runs, writing a CSV to the Volume and returning its pointer.
