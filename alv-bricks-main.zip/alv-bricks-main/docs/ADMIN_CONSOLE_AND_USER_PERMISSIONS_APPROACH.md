# Admin console + ad-hoc user permissions — approach (WORKING DRAFT)

> **Status: DRAFT for review.** This is a working file to agree the approach before
> we build. Nothing here is implemented. Open decisions are marked **[DECIDE]** — I
> need your call on these before implementation starts.

## Goal

Two connected changes:

1. **Ad-hoc user permissions.** Today a user sees a report only if they are in a
   mapped workspace **group** (`report_permissions`, grain `report_key` × `group_name`).
   Add a second grant path: grant a report to a **named user** directly. The two paths
   are **OR** — a user sees a report if a group grant OR a user grant permits it.
2. **Admin console (UI).** An admin user grants/revokes report access to users (and
   groups) from a screen in the App, written straight to the metadata tables.

## How permissioning works today (baseline)

The gate lives in `src/alv-frontend/backend/alv_app/entitlements.py`. One funnel decides everything:

```
request → resolve_identity() → permitted_report_keys(settings, ident) → frozenset[report_key]
```

- **User groups** come from the END USER's OBO token via `current_user.me()` (`/Me`) —
  the only route that works for a non-admin SP. TTL-cached per user (300s).
- **The report→group map** is read from `report_permissions` as the **App SP** (bound
  SQL, `permissions_source.py`). TTL-cached globally (300s).
- **Decision:** `permitted = { report_key : allowed_groups ∩ user.groups ≠ ∅ }`.
- **Deny by default**, **fail closed** on every error, denial returns **404 not 403**.
- Every endpoint funnels through this: catalogue reads via
  `MetadataCache.visible_reports()`, write/single-report paths via
  `is_report_permitted()`, Downloads via `listable_alv_ids()`.

The key property: **all enforcement already routes through `permitted_report_keys()`**.
If we widen that one function to also union in user grants, every endpoint inherits the
change with no per-endpoint edits.

## Part 1 — Ad-hoc user permissions

### 1.1 Data model — new table `user_report_permissions`

New table, not a change to `report_permissions` (keeps group vs user grants separate;
does not disturb the existing seeded manifest). Follows the single-source DDL pattern
in `metadata/metadata_tables.py`.

| Column | Type | Notes |
|---|---|---|
| `user_identifier` | STRING (PK) | The user key. **[DECIDE] which identifier — see 1.2.** |
| `report_key` | STRING (PK) | FK → `alv_catalog.report_key`. |
| `is_active` | BOOLEAN | Revoke without delete (mirror `report_permissions`). |
| `granted_at` | TIMESTAMP | Audit. |
| `granted_by` | STRING | Audit — the admin who granted it. |

- Grain: one row per (`user_identifier`, `report_key`). PK = both columns.
- Add to `PILOT_TABLES` so `MetadataTables.ensure_all()` creates it (the `provision`
  job creates it on next run).

### 1.2 The user identifier — **[DECIDE]**

The grant must match the same identity the gate sees at request time. Options:

- **Email** (recommended) — human-friendly for the admin to type, and `resolve_identity`
  exposes `X-Forwarded-Email`. Risk: email match must be **case-folded**.
- **`user_id`** (AAD/SCIM object id) — most stable, never changes, but the admin does not
  know it; the UI would need a user picker that resolves name → id.
- **`preferred_username`** — avoid as the primary key; it can change.

**Recommendation:** store **email, lower-cased**, and at match time compare the caller's
email lower-cased. Keep a fallback match on `user_id` for robustness (same precedence
idea as `_submitted_by`). Final call is yours.

### 1.3 Runtime gate change (the only logic change)

Extend `permitted_report_keys()` in `entitlements.py` to union a second source:

- New `user_report_permission_map(settings) → {report_key: frozenset[user_identifier]}`,
  read via a new `fetch_user_report_permissions()` in `permissions_source.py` (same bound-SQL
  App-SP seam), TTL-cached in its own `_TtlCache` entry.
- New `_user_identity_matches(ident, allowed)` — case-folded email, then `user_id`.
- `permitted = group_permitted ∪ user_permitted`. OR semantics, deny-by-default and
  fail-closed preserved (a user-map read failure denies, does not degrade open).

**Note:** today a user with **no groups** is denied early. With user grants, a groupless
user may still hold a direct grant — so the early "no groups" return must **continue** to
the user-grant check instead of returning empty. This is a real behavior change to flag.

### 1.4 No endpoint changes

Because `visible_reports()`, `is_report_permitted()`, and `listable_alv_ids()` all call
`permitted_report_keys()`, catalogue / submit / preview / status / download / downloads-list
all inherit user grants automatically. 404-on-deny is unchanged.

## Part 2 — Admin console (UI + write path)

This is the larger design question, because the App today **never writes permission
tables at runtime** — they are seeded by a DAB job. The admin console needs runtime
writes as the App SP.

### 2.1 Who is an admin? — **[DECIDE]**

We need an admin gate before exposing any grant endpoint. Options:

- **A dedicated admin group** (e.g. `alv-admins`) checked via the same `/Me` groups we
  already read — cheap, consistent with the existing model. **(Recommended.)**
- **Workspace admin flag** — heavier; `/Me` may not expose it cleanly for a non-admin SP.
- **A config allow-list of admin emails** — simplest, least flexible.

**Recommendation:** admin = member of a configured admin group name
(`ADMIN_GROUP` setting), resolved from the caller's `/Me` groups. Fail closed.

### 2.2 New write endpoints (App SP, admin-gated)

New module `admin.py` + endpoints under an admin prefix, each gated by the admin check:

- `GET  /api/admin/permissions?report_key=` — list group + user grants for a report.
- `POST /api/admin/permissions/user` — grant a report to a user (MERGE/INSERT).
- `DELETE /api/admin/permissions/user` — revoke (set `is_active=false`, or delete).
- `POST/DELETE /api/admin/permissions/group` — same for group grants (manage
  `report_permissions` from the UI too, so the console is the single control surface).

All writes are **bound SQL** as the App SP, mirroring `request_log.py`. Every write emits
an audit log line and stamps `granted_by` = admin identity.

**[DECIDE] Cache freshness:** grants are TTL-cached (300s). After an admin writes, the
change is not visible for up to 300s. Options: (a) accept the TTL lag; (b) add a
cache-invalidate hook the write path calls (`_TtlCache.clear()` already exists). I
recommend **(b)** — invalidate the permission-map caches on write so the console feels
immediate.

### 2.3 Reconciling with the seed-job model — **[DECIDE]**

Today `report_permissions` is authored in `src/report_specs/report_permissions.json` and
seeded by a DAB job (MERGE, non-destructive). If the admin console also writes the table
at runtime, the two can drift:

- **Re-running the seed job will not delete** UI-added rows (MERGE only adds/updates), so
  they coexist — but a UI-added row is **not** in the manifest, so it is undocumented.

Options: (a) **UI is the source of truth** for user grants; keep the seed job only for
initial/group bootstrap. (b) Keep both and accept the manifest is a bootstrap, not a
mirror. I recommend **(a)** — user grants are inherently ad-hoc and do not belong in a
checked-in manifest; document that clearly.

### 2.4 Frontend

- New **Admin** nav item, visible only when `/api/me` (or a small `/api/admin/whoami`)
  reports the caller is an admin — so non-admins never see it. The endpoint gate is the
  real control; hiding the nav is cosmetic.
- Screen: pick a report → see current group + user grants → add a user (email input) →
  revoke. Reuse existing table/form styling and design tokens; no new CSS system.

## Security notes (must hold)

- The admin endpoints are a **new write surface** — they must be gated **before** any
  write, fail closed, and never disclose existence to non-admins (404, consistent with
  the rest of the app).
- Ad-hoc grants do **not** change the two-identity model: user identity for authorization,
  App SP for data. Reading/writing the new table is App-SP work.
- `docs/SECURITY_AND_PERMISSIONS.md` must gain a section on the user-grant path, the admin
  gate, and the runtime write surface. `docs/METADATA_TABLE.md` gains the new table.

## Open decisions — I need your call

1. **User identifier** (1.2): email (lower-cased) as PK, with `user_id` fallback match? Or user_id primary with a name-picker UI?
  A: email id would be pk. admin can add it in both upper case or lowercase, but the app should compare after doing lowercase to decide 
     if the user can see the report or not. also there would be some edge cases here, what if the logged in user is both in a permission group
     and also assigned ad-hoc. check this. also..does having two tables to maintain permissions - one for groups and one for individual groups 
     really make sense? i dont think it would be efficient. let's extend the existing table to have a flag saying what kind of permission this is
     - user or group, would that be efficient?
2. **Admin definition** (2.1): membership of a configured admin group?
  A: Can be  A dedicated admin group or an individual user or list of users. during initial build the app should pick it up from the env yml file
     similar to how databricks jobs ymls have options to pass user ids for can manage etc. 
3. **Cache invalidation on write** (2.2): invalidate immediately, or accept ≤300s lag?
  A: Invalidate immediately, duh!
4. **Source of truth** (2.3): UI owns user grants; seed job stays group-bootstrap only?
  A: seed job would be one time run, after that ui would keep adding, no one will run the seed job again after setup. 
5. **Scope of the console**: manage user grants only, or group grants too from the same screen?
  A: Can do both - pass a user group name or user email and it should work - this will tie to my recommendation in decision 1 where having a single
    table could be efficient?
6. **Deploy**: the new table needs the `provision` job re-run to create it — confirm that fits the deploy flow.
  A: I dont fully understand. pls elaborate.

Additional Thoughts - The admin panel should not show on a report wise basis. we should have the button surface in the left navbar when a user 
has admin priviledges. then the new screen will show the dropdown for report name, and a text box for entering user email or groups.
the user can also add a comma seperated list of emails and groups, the app should be able to handle it. lmk what other decisions need to be
made on the ui side for this. 
## FINALIZED DECISIONS (2026-08-08) — supersedes the draft above

1. **Single generalized table, not two.** Extend `report_permissions` with a
   `principal_type` (`'user'`|`'group'`) column and rename `group_name` →
   `principal_name`. New PK `(report_key, principal_type, principal_name)`. One read,
   one cache, one gate. `principal_type='user'` rows store the email **lower-cased**;
   the gate compares the caller's email lower-cased. Group rows match as today.
2. **User-in-group-AND-ad-hoc is a non-issue** — the gate accumulates a *set* of
   `report_key`s, so a doubly-granted report appears once. Explicit test added.
3. **Admin identity from config, not a table.** New env var `ALV_ADMINS` =
   comma-separated **emails and/or group names**, wired via `src/env_parameters/*.yaml` →
   `app.yaml`. Caller is admin if their lower-cased email OR any `/Me` group is in the
   list. Fail closed. This is the bootstrap admin surface, distinct from the grant table.
4. **Immediate cache invalidation** — every admin write clears the permission-map cache
   before returning.
5. **Seed job = one-time bootstrap.** After setup the UI owns all grants; the seed job
   is not re-run. Manifest is a bootstrap, not a mirror.
6. **One admin screen for both principal kinds.** Comma-separated input; a token
   containing `@` is classified `user`, otherwise `group` (safe: Databricks group names
   never contain `@`). Response reports each token as added / already-existed / invalid.
7. **Admin nav is global, not per-report.** An **Admin** item appears in the left navbar
   only for admins; the screen has a report dropdown + a principal text box (comma list).
8. **No existence validation** of emails/groups (consistent with today — we cannot check
   group existence without SCIM admin). A grant that matches nobody is harmless.
9. **Migration (one-time, at slice-1 deploy):** `ensure_all()` only CREATEs, never
   ALTERs, so the already-deployed `report_permissions` needs an explicit one-time
   migration: `RENAME COLUMN group_name TO principal_name`, `ADD COLUMN principal_type`,
   `UPDATE ... SET principal_type='group'`. 2 existing rows; group grants preserved.

## Proposed implementation slices (after sign-off)

Feature-by-feature, each deployed + validated before the next:

1. **Table + read/gate** — new DDL, `provision` run, `fetch_user_report_permissions`,
   widen `permitted_report_keys`, tests. No UI yet; verify via a seeded test row.
2. **Admin write endpoints** — `admin.py`, admin gate, bound-SQL writes, cache invalidate,
   tests.
3. **Admin UI** — nav gating + grant/revoke screen.

## File touch-list (reference)

- `src/alv-backend/dbx_alv_reports/metadata/metadata_tables.py` — new `USER_REPORT_PERMISSIONS_TABLE`, add to `PILOT_TABLES`.
- `src/alv-frontend/backend/alv_app/permissions_source.py` — `fetch_user_report_permissions()`.
- `src/alv-frontend/backend/alv_app/entitlements.py` — user map + cache + widen `permitted_report_keys` + admin check.
- `src/alv-frontend/backend/alv_app/admin.py` (new) — write seam + admin gate.
- `src/alv-frontend/backend/alv_app/main.py` — admin endpoints + `whoami`/admin flag on `/api/me`.
- `src/alv-frontend/backend/alv_app/config.py` — `admin_group` setting.
- `src/alv-frontend/frontend/src/` — Admin nav + screen.
- `docs/SECURITY_AND_PERMISSIONS.md`, `docs/METADATA_TABLE.md` — updates.
- Tests: `src/alv-frontend/backend/tests/test_permissions.py`, new `test_admin.py`.
