# Multi-file download handling — approach

> **Status: PLANNING (design phase).**
> On branch `feat/add-report-from-ui`. This document captures design decisions for
> handling report jobs that produce multiple output files (e.g., Spark part files,
> chunked CSVs) instead of today's single-file assumption.

> **Downstream note — output-file preview.** The **output-file preview** feature
> (`docs/OUTPUT_FILE_PREVIEW_APPROACH.md`, built 2026-08-18) reads
> `request_log.output_path` as a **single file**, exactly like the download path it is
> modelled on. When multi-file lands and `output_path` can be a directory, the preview
> endpoint (`GET /api/requests/{request_no}/output-preview`) must be extended the same
> way the download endpoint is — pick the first file automatically, or add a file
> picker before the preview table. It has no multi-file handling today (single-file
> pilot only); fold it into whichever multi-file delivery choice is chosen here.

## Goal

Today the App assumes a report job returns exactly **one output file**, pointed to by
`request_log.output_path`. A real report job (Retail Ledger) may produce a **directory
full of files** (Spark writes part files; manual chunking emits a CSV per batch). The
App must:

- **Detect** when a run produces multiple files.
- **Present** them to the user (list or bundled).
- **Deliver** them (per-file streams or a packaged archive).
- **Track** the result in the metadata layer without breaking today's single-file
  runs.

This doc proposes architecture, identifies tradeoffs, and leaves product choices for
sign-off.

---

## 1. Problem statement

### The single-file assumption today

The App's download path was designed around a single output file:

| Component | Where the assumption lives | Citation |
|---|---|---|
| **Contract** | Job returns a single `output_path` string | `src/alv-backend/alv_dummy_report_run.ipynb` cell 4: `return_payload = {"status": "COMPLETED", "output_path": output_path, ...}` |
| **Metadata** | `request_log.output_path` is a STRING (one path) | `docs/METADATA_TABLE.md` §2: `output_path` column; cached as a scalar |
| **Models** | `RequestOut.output_path` and `RequestStatusOut.output_path` are `str \| None` | `src/alv-frontend/backend/alv_app/models.py` lines 188, 253 |
| **Download endpoint** | Reads one path, streams one file | `src/alv-frontend/backend/alv_app/main.py` lines 1529–1554: derives filename, streams, sets single `Content-Disposition` |
| **Files API** | Calls `client.files.download(output_path)` once | `src/alv-frontend/backend/alv_app/databricks_client.py` line 308 |
| **Frontend** | One Download button, one filename | (SPA, not in this repo) |

### Consequence

If a job writes `/Volumes/.../run_123/part-00000.csv`, `/Volumes/.../run_123/part-00001.csv`,
`/Volumes/.../run_123/part-00002.csv`, today the App cannot express or handle it. The
`output_path` field can only store one of the three. The user gets a 409 (no output
yet) or incomplete results.

---

## 2. Current-state walkthrough

### How a job produces output and the App captures it

1. **Job execution** (e.g., `alv_dummy_report_run.ipynb`):
   - Writes result(s) to a parameterized UC Volume subdirectory.
   - Returns via `dbutils.notebook.exit(json.dumps({...}))` a **pointer JSON**
     (cell 5: `return_payload`), containing `output_path` (single string), `row_count`,
     `generated_at`, and `status`.

2. **App captures the pointer** (status-poll path):
   - Calls `jobs.get_run_output(task_run_id)` and parses `notebook_output.result`.
   - Invokes `get_run_output()` (line 213) which returns a `RunOutput` dataclass
     (line 195–200): `output_path: str | None`, plus metadata.
   - Calls `update_status(...)` (line 1209 in main.py) passing `output_path=…`.

3. **App stores in request_log** (`src/alv-frontend/backend/alv_app/request_log.py`):
   - `update_status()` line 143 accepts `output_path: str | None`.
   - Issues SQL UPDATE line 162: `output_path = :output_path` (a single bound
     parameter).

4. **Downloads list and download endpoint** (main.py):
   - `fetch_request()` line 381 reads `output_path` as a single column.
   - Downloads endpoint line 1529 checks `if not output_path.startswith("/Volumes/")`,
     line 1530 derives `filename = posixpath.basename(output_path)`, line 1533 calls
     `download_volume_file(output_path)`, line 1552 returns one `StreamingResponse`.

**Every layer assumes a scalar string, never a collection.**

---

## 3. Design options

### Option A: Job-side concatenation (complexity to the job)

**The job always writes a single file.** For multi-part results, the job concatenates
or archives them before exit.

**Tradeoffs:**
- ✓ Zero changes to App / metadata layer.
- ✓ Works today with no migration.
- ✗ Burden falls on every job. RIL must implement concatenation / archiving logic.
- ✗ Large results may not fit in memory (RAM during concat; re-streaming inefficient).
- ✗ Defeats Spark's partitioning (coalesce = less parallelism, larger intermediate
  files).

**Verdict:** Viable for small, non-Spark workloads; not suitable for scaled reporting.

---

### Option B: Contract change — return directory + manifest

**Job returns `output_path` as a directory**, plus a **file list** or **manifest**.

Variant B1: Flat list in the return payload:
```json
{
  "status": "COMPLETED",
  "output_path": "/Volumes/catalog/schema/volume/run_123",
  "files": [
    {"name": "part-00000.csv", "size_bytes": 1024, "row_count": 100},
    {"name": "part-00001.csv", "size_bytes": 2048, "row_count": 200}
  ],
  "row_count": 300,
  "generated_at": "2026-08-12T..."
}
```

Variant B2: Manifest file alongside data:
```
/Volumes/.../run_123/part-00000.csv
/Volumes/.../run_123/part-00001.csv
/Volumes/.../run_123/_manifest.json      <-- contains file list + metadata
```

**Tradeoffs:**
- ✓ Scalable: job lists what it wrote; App adapts per-run.
- ✓ Preserves Spark output structure (no coalesce needed).
- ✗ Contract is now versioned and more complex (a list vs. a string).
- ✗ Variant B1: payload size grows with file count (e.g., 1000 part files = large
  JSON). Hits the ~5 MB truncation limit?
- ✗ Variant B2: manifest file adds a dependency; job must guarantee its atomicity.

**Verdict:** B1 works for moderate file counts (<100); B2 adds reliability for scale.
B1 + B2 together is best but more complex.

---

### Option C: App-side directory listing

**Job returns `output_path` as a directory.** The App, when reading output, **lists the
Volume path** to discover files.

Contract change (minimal):
```json
{
  "status": "COMPLETED",
  "output_path": "/Volumes/catalog/schema/volume/run_123",
  "is_multi_file": true,
  "row_count": 300,
  "generated_at": "2026-08-12T..."
}
```

Or detect automatically: if `output_path` ends with `/` or the App detects it's a
directory (API call), treat it as multi-file.

**Tradeoffs:**
- ✓ Job side is simplest (no manifest logic).
- ✓ App discovers reality (no trust in the manifest).
- ✗ Extra API call to list the directory on every download (volume file listing can
  be slow for large dirs).
- ✗ Race: files could be added/deleted between status poll and download (unlikely but
  possible).
- ✗ Requires the App SP to have LIST permission on the Volume prefix (already true,
  but must document).

**Verdict:** Simple and safe; acceptable latency for typical reports.

---

### Option D: Hybrid — lazy detection + caching

**Combine B and C:** the job optionally includes a file list in the payload. The App
trusts it if present; otherwise lists the directory.

```json
{
  "status": "COMPLETED",
  "output_path": "/Volumes/catalog/schema/volume/run_123",
  "files": [
    {"name": "part-00000.csv", "size_bytes": 1024},
    {"name": "part-00001.csv", "size_bytes": 2048}
  ],
  "row_count": 300
}
```

Store `files_json: string | null` in `request_log`.

**Tradeoffs:**
- ✓ Scalable and opt-in: simple jobs skip it; large reports include it for speed.
- ✓ App still works if the list is missing (falls back to listing).
- ✗ Adds a `files_json` column to the metadata (migration on existing tables).
- ✗ Validation: App must sanity-check the list (files actually exist, no escaping
  attacks).

**Verdict:** Flexible; requires careful validation.

---

## 4. Delivery choices

### How the App presents and serves multiple files

Assuming the App detects a multi-file result (via any option above), it must choose
how to serve them:

**Choice 1: Per-file download UI**
- Frontend lists the files.
- User picks one and downloads.
- App streams that one file.
- ✓ Familiar; no new serialization.
- ✗ User must pick; not suitable for "give me everything."

**Choice 2: Server-side ZIP stream**
- App reads all files in the directory.
- Concatenates them into a ZIP archive (or TAR.GZ).
- Streams the archive to the browser.
- ✓ One-click "get all files."
- ✗ ZIP overhead (headers, compression). Large results may grow or need buffering.
- ✗ App compute: streaming a ZIP is CPU-bound (compression on large files).

**Choice 3: Manifest endpoint + streaming options**
- `GET /api/requests/{request_no}/manifest` returns the file list.
- User (or frontend automation) then calls `GET /api/requests/{request_no}/download?file=<name>`
  per file.
- ✓ Flexible; user controls bandwidth / concurrency.
- ✗ Requires frontend loop logic.
- ✗ Multiple round-trips.

**Choice 4: Concatenated stream**
- App concatenates all files (no compression).
- Returns as a single byte stream (e.g., `multipart/form-data` or custom boundary).
- ✓ No ZIP overhead; fast on App.
- ✗ Frontend must parse boundaries; not standard for file downloads.

### Recommended: **Choice 1 + Choice 2 hybrid**

- **Default:** list the files in the frontend; user clicks individual "Download"
  buttons.
- **Convenience:** offer a "Download all as ZIP" option.
- Both use the same App endpoint (`/api/requests/{request_no}/download` with optional
  `?file=<name>` param).

---

## 5. How the App detects multi-file runs

### Approach: directory-aware output_path

Change the contract minimally: **`output_path` can now be a directory path** (still a
single string). The App detects multi-file based on:

1. **Heuristic 1: Explicit marker in the return payload**
   ```json
   {"status": "COMPLETED", "output_path": "...", "is_multi_file": true}
   ```
   Simplest; job must cooperate.

2. **Heuristic 2: App-side check — is it a directory?**
   - App SP calls `client.files.get_directory_metadata(output_path)` or similar.
   - If the path is a directory (not a file), treat as multi-file.
   - Requires logic to distinguish; the Files API may not have a cheap directory check.

3. **Heuristic 3: File list in payload (optional)**
   ```json
   {"status": "COMPLETED", "output_path": "...", "files": [...]}
   ```
   Job provides the list; App uses it if present, falls back to listing if missing.

**Recommended:** Heuristic 1 (explicit marker) + fallback to Heuristic 2 (directory
check) if the marker is absent. This keeps backward compat (old jobs return false or
omit the marker) and lets new jobs opt in.

---

## 6. Recommended approach

### Summary

**Option C (App-side directory listing) + Delivery Choice 1+2 (per-file + ZIP)**.

Rationale:
- Job-side change is **minimal:** return `output_path` as a directory; optionally add
  `is_multi_file: true` flag.
- App detects multi-file automatically (App SP can list directories).
- Backward compatible: old jobs return a file path; App treats it as single-file
  (basename works, `is_directory()` check returns false).
- Simple security posture: App only ever reads paths under `/Volumes/…`, no new
  privileges.

### Contract changes (Job → App)

**RunOutput shape (in `databricks_client.py`):**

```python
@dataclass(frozen=True)
class RunOutput:
    ok: bool
    status: str | None
    output_path: str | None          # now can be file OR directory
    is_multi_file: bool = False      # new; True ⟹ path is a directory
    files: list[dict] | None = None  # optional; [{"name": "...", "size": ...}, ...]
    row_count: int | None = None
    generated_at: str | None = None
    detail: str | None = None
```

Job returns:
```json
{
  "status": "COMPLETED",
  "output_path": "/Volumes/catalog/schema/volume/run_123/",
  "is_multi_file": true,
  "files": [
    {"name": "part-00000.csv", "size_bytes": 1024},
    {"name": "part-00001.csv", "size_bytes": 2048}
  ],
  "row_count": 300,
  "generated_at": "2026-08-12T..."
}
```

**Metadata table changes (`request_log`):**

Add two **optional** columns:
- `is_multi_file: BOOLEAN` — marks the run as multi-file.
- `files_json: STRING` — optional JSON array of file metadata (cached from the job
  return).

Both nullable; today's rows stay NULL.

**Models changes** (`src/alv-frontend/backend/alv_app/models.py`):

- `RequestOut` adds `is_multi_file: bool = False` and `file_count: int | None = None`.
- `RequestStatusOut` adds same.

**Download endpoint changes** (`src/alv-frontend/backend/alv_app/main.py`):

- `download_request_output(request_no, file: str | None = None)`:
  - If `file` param is set and the run is multi-file: stream that single file.
  - If no `file` param and run is multi-file: return a **manifest** (list of files +
    metadata) with a 206 Partial Content status, or a list-response model.
  - If no `file` param and run is single-file: stream the file as today.

Actually, better: split into two endpoints:
- `GET /api/requests/{request_no}/download?file=<name>` — stream a single file (works for both
  single and multi).
- `GET /api/requests/{request_no}/files` — list files in a multi-file run (returns
  JSON, not bytes).

### Status-poll changes (how the App learns multi-file status)

The status-poll endpoint already calls `get_run_output()`, which parses the job return.
It now receives `is_multi_file` + `files`. The endpoint:

1. Calls `update_status(...)` passing `is_multi_file=…` and `files_json=…`.
2. `update_status()` (request_log.py) writes them to the row.
3. Subsequent downloads read the cached values.

### Frontend changes (not in scope here, but for context)

- Downloads list shows `is_multi_file` badge.
- Download button shows "Download all" (ZIP) or opens a file picker.
- File picker calls `GET /api/requests/{request_no}/files`, then streams individual
  `?file=<name>` requests or a ZIP.

---

## 7. Backward compatibility

### Single-file runs (today's behavior)

1. Job returns `output_path: "/Volumes/.../single_file.csv"` (no `is_multi_file`,
   or `is_multi_file: false`).
2. App stores `is_multi_file = false` in the row.
3. Download endpoint sees `is_multi_file = false`, streams the file as today.
4. No changes to the UI for single-file runs.

### Migration (none needed)

- Existing `request_log` rows predate the new columns (`is_multi_file`, `files_json`).
- Both columns are nullable; old rows stay NULL.
- The App's backward-compat logic (check the flag; default to single-file if absent)
  lets old rows work.

### Coexistence

Single-file and multi-file runs can coexist in the same `request_log` table. Each
run reports its own shape.

---

## 8. Security

### Threat model (from `docs/SECURITY_AND_PERMISSIONS.md`):

The App is the **AuthZ chokepoint**: it validates the caller's report permission
before reading any bytes, then proxies the read through the App SP (Unity Catalog
enforces the App SP's grants, not the user's).

### Multi-file security posture

**Same as single-file:**

- **Authorization:** `_require_request_permission()` (main.py line 1509) gates all
  download paths. No caller sees a run's files without `report_permissions` on the
  run's report.
- **Data access:** all file reads are via the App SP and the Files API. Paths never
  reach the browser or a direct storage URL.
- **Path validation:** all returned paths must be under `/Volumes/...` (main.py line
  1523). An escape attempt (e.g., `"output_path": "../../sensitive"`) is rejected.

### New concerns (multi-file specific)

1. **Directory traversal in file names:**
   - When listing `/Volumes/.../run_123/`, the App receives a list of files.
   - A malicious job could return `{"name": "../../../etc/passwd"}`.
   - **Mitigation:** validate each filename: must not contain `/`, `..`, or absolute
     paths. Only leaf names (e.g., `part-00001.csv`).

2. **Size attack (unbounded listing):**
   - If a run writes millions of files, listing the directory could be expensive.
   - **Mitigation:** cap the file count returned (e.g., 10k max files). Return an
     error if exceeded.

3. **TOCTOU (time-of-check, time-of-use):**
   - Files could be deleted or modified between the list and the stream.
   - **Mitigation:** not a security issue (just a 404 on the download). Accept the
     race.

### Safeguard checklist (cross-reference to `SECURITY_AND_PERMISSIONS.md` §5)

- Safeguard 4 (**write paths enforce independently**): the download path already
  calls `_require_request_permission()` before any file access. ✓
- Safeguard 6 (**unresolvable identifiers denied**): a `request_no` that resolves to
  an unpermitted report 404s. ✓
- Safeguard 7 (**404, never 403**): unchanged. ✓
- Safeguard 16 (**empty permitted set runs no query**): unchanged; applies to the
  list endpoint, not downloads. ✓

**New safeguard:**
- **Safeguard 18 (new): Filename validation in multi-file lists.** Every file name
  returned from a multi-file run is validated to be a safe leaf name (no path
  separators, no escapes). Invalid names are rejected with a 422 (malformed
  response).

---

## 9. Open decisions for the product owner

### [DECIDE] 1: Multi-file delivery — per-file picker vs ZIP vs both?

**Question:** When a user downloads a multi-file run, what should they see?

- **Option A:** A file picker (list + individual download buttons). User picks one or
  several.
- **Option B:** A "Download all as ZIP" button (one click, all files bundled).
- **Option C:** Both (default to picker; offer ZIP as well).

Tradeoff: Option C is most flexible but adds UI complexity. Option A is familiar;
Option B is convenient but has ZIP overhead.

**Recommendation:** Option C — per-file list by default (simple, no extra App work),
plus a "Download as ZIP" button (convenient one-click). Let the user choose.

### [DECIDE] 2: Is `is_multi_file` marker required in the job return?

**Question:** Must the job explicitly set `"is_multi_file": true`, or should the App
detect it automatically?

- **Option A:** Explicit. Job always says `is_multi_file: true | false`. Simpler to
  debug.
- **Option B:** Implicit. App checks if `output_path` is a directory. Simpler for
  jobs (no change needed).
- **Option C:** Hybrid. Job can set it; if absent, App detects automatically.

**Tradeoff:** Option A is clearer; Option B is less coupling. Option C is most
flexible but adds validation logic.

**Recommendation:** Option C — accept the marker if present; fall back to directory
detection if absent. Allows old jobs (without the marker) to upgrade transparently.

### [DECIDE] 3: File list in the return — always include, or optional?

**Question:** Should the job always return the file list in the `files[]` array, or
is it optional (App lists the directory if missing)?

- **Option A:** Always included. Job is responsible for accuracy.
- **Option B:** Optional. App lists the directory if missing.
- **Option C:** Recommended but optional (same as Hybrid, above).

**Tradeoff:** Option A is fastest for the App (no extra API calls); Option B is
resilient (falls back if the list is missing or wrong). Option C requires validation.

**Recommendation:** Option C (same as Hybrid) — if the job provides the list, use it
(fast path); otherwise list the directory (safe path). Reduces latency for large
reports while maintaining correctness.

### [DECIDE] 4: ZIP compression or plain concatenation?

**Question:** If the user chooses "Download all as ZIP", should files be compressed,
or just concatenated?

- **Option A:** ZIP with compression (smaller download, but CPU-bound on the App).
- **Option B:** Plain concatenation or TAR (no compression; fast, but larger).
- **Option C:** Configurable per run or per report.

**Tradeoff:** Option A reduces bandwidth but increases App CPU. Option B is fast but
larger. Option C is flexible but adds complexity.

**Recommendation:** Option A (ZIP with compression). Compression is standard practice
and savings outweigh CPU cost on modern hardware. Most files are CSV or text
(highly compressible). Start here; optimize if App CPU becomes a bottleneck.

### [DECIDE] 5: Max file count per run?

**Question:** If a run produces thousands of files, should there be a cap?

- **Option A:** No cap. App lists however many there are.
- **Option B:** Hard cap (e.g., 10k files). Reject runs that exceed it.
- **Option C:** Soft cap (list up to 10k; truncate the response).

**Tradeoff:** Option A is most flexible but can be slow for huge directories. Option
B prevents abuse but rejects valid runs. Option C is a middle ground.

**Recommendation:** Option C (soft cap of 10k) — list up to 10k files; if more
exist, return `has_more: true` and a note. Prevent runaway I/O while preserving
usability.

### [DECIDE] 6: Who decides the output path — App or Job?

**Question:** Should the App SP have the authority to pick `output_path` if the job
returns an unpredictable one?

This is out of scope for the initial design (job returns what it wants), but worth
documenting for later.

---

## 10. Proposed implementation tasks

1. **Contract extension**: update `RunOutput` dataclass to include `is_multi_file`,
   `files`. Update `alv_dummy_report_run.ipynb` to return the new shape.

2. **Metadata table migration**: add `is_multi_file` and `files_json` columns to
   `request_log` (nullable, migration script for deployed tables).

3. **Models update**: add fields to `RequestOut`, `RequestStatusOut`.

4. **Status-poll endpoint**: capture and store `is_multi_file` and `files_json` from
   the job return.

5. **Download endpoint refactor**: split into:
   - `GET /api/requests/{request_no}/files` (list files, 200 with JSON).
   - `GET /api/requests/{request_no}/download[?file=<name>]` (stream, with optional
     per-file param).
   - Handle single-file runs transparently (return 1-item list or stream the file).

6. **Filename validation**: add safeguard to reject file names with path separators
   or escapes.

7. **ZIP streaming**: implement server-side ZIP generation (e.g., Python `zipfile`
   module, streaming via generator).

8. **Frontend**: add file list UI, file picker, "Download all as ZIP" button.

9. **Tests**: unit tests for filename validation, directory listing, ZIP generation;
   integration tests for the full flow (multi-file run → list → download).

10. **Documentation**: update `docs/METADATA_TABLE.md` (new columns), docs/SECURITY_AND_PERMISSIONS.md`
    (new safeguard), `docs/APP_PREREQUISITES.md` if Volume LIST permission needs
    clarification, `CHANGELOG.md`, README.

---

## 11. Related documents

| Document | Content |
|---|---|
| `docs/METADATA_TABLE.md` | The `request_log` table contract; will document new columns |
| `docs/SECURITY_AND_PERMISSIONS.md` | Security posture; will add filename-validation safeguard |
| `src/alv-frontend/backend/alv_app/main.py` | Download endpoint (lines 1475–1554) |
| `src/alv-frontend/backend/alv_app/databricks_client.py` | `RunOutput` and `get_run_output()` |
| `src/alv-frontend/backend/alv_app/request_log.py` | `update_status()` function |
| `src/alv-backend/alv_dummy_report_run.ipynb` | Job contract (return shape) |
| `docs/APP_DEPLOY_RUNBOOK.md` | Volume setup and permissions |

