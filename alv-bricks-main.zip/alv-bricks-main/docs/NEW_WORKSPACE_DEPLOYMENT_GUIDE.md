# New-Workspace Deployment Guide (UI-only, no CLI / MCP)

> **Audience:** the operator standing ALV-Bricks up on a **fresh Databricks workspace
> that has no Databricks CLI and no MCP access** — everything is done through the
> workspace UI + SQL editor — and the **job developer** who owns the report/download Job.
> **Repo layout assumed:** the reorganized layout (`src/alv-backend/`, `src/alv-frontend/`).
> **Reference (already-working pilot):** `docs/APP_PREREQUISITES.md`,
> `docs/APP_DEPLOY_RUNBOOK.md` (both assume CLI; this guide is the CLI-free equivalent).

The App runs as its **own service principal (SP)**, auto-created by Databricks Apps.
Every data read, every `request_log` / `report_templates` write, and every job
`run-now` happens as that SP. All the grants below target it.

### Where you set configuration (two files + a few discovered IDs)

There are exactly **two files to edit**, plus a few IDs you read off the UI as you go.
Set `catalog` / `schema` in **both** files to the **same** values.

**A. `databricks.yml` — drives the metadata + seed JOBS (deployed as a bundle).** Edit the
target you will deploy (the shipped `prod` target has `REPLACE_ME` placeholders; or add
your own target):

| Field in `databricks.yml` | Set to |
|---|---|
| `targets.<env>.workspace.host` | your new workspace URL (prod ships as `https://REPLACE_ME…`) |
| `targets.<env>.workspace.root_path` | where the bundle deploys (default is fine) |
| `targets.<env>.variables.catalog` | the metadata **catalog** |
| `targets.<env>.variables.schema` | the metadata **schema** |
| `targets.<env>.permissions.service_principal_name` | (prod) an SPN that may `CAN_MANAGE` the jobs (ships as `REPLACE_ME_SPN`); delete the block for a personal deploy |

The jobs pass `catalog`/`schema` to the notebooks **as job parameters automatically** —
**you never type catalog/schema into a notebook widget.** `bundle_source_path` /
`framework_source_path` derive from `${workspace.file_path}` — leave them alone.

> `src/env_parameters/*.yaml` is **documentation only — not read by the code**; the bundle
> `variables` above are the real source. Updating it changes nothing (keep it in step for
> tidiness if you like).

**B. `src/alv-frontend/backend/app.yaml` — drives the APP** (full table in [Part 2](#part-2--app-environment-variables-srcalv-frontendbackendappyaml)).
Set `CATALOG` / `SCHEMA_NAME` to the **same** catalog/schema as (A), plus
`DATABRICKS_WAREHOUSE_ID`, `ALV_ADMINS`, and `DEV_MODE=false`.

**C. IDs you discover during setup** (used in the grant / bind steps below). Throughout the
SQL in this guide, `<CATALOG>` / `<SCHEMA>` are the values from (A)+(B):

| Value | What it is | Where (UI) |
|---|---|---|
| `<APP_SP>` | the App's service-principal **application (client) id** | Apps UI → your app → its service principal |
| `<WAREHOUSE_ID>` | a serverless SQL warehouse id | SQL Warehouses → the warehouse → *ID* in its details/URL |
| `<REPORT_JOB_ID>` | the report/download Job id (from the job developer) | Workflows → the Job → id in the URL |
| `<GROUP>` | a workspace group whose members may see the reports | Admin/Groups UI |

---

## Part 1 — What the JOB DEVELOPER must add (the output contract)

The App does **not** parse files. It reads a small **JSON pointer** the Job returns
from its last line, then records the output location and serves the file. The Job must
therefore do two things: **(a)** accept the parameters the App sends, and **(b)** end by
returning the pointer.

### 1a. The exit-pointer snippet — MUST be the LAST statement of the Job's notebook

Add this at the very end of the report/download notebook (after it has written the
result file). `dbutils.notebook.exit(...)` stops execution, so nothing may follow it.

```python
# ===== ALV-Bricks output contract — MUST be the LAST statement in the notebook =====
# The ALV app reads this exit value (jobs.get_run_output -> notebook_output.result),
# parses it as JSON, and records output_path / row_count / generated_at on the request.
import json, datetime

# PRECONDITION: your report logic has already written the result file to a UC VOLUME
# and you know its full path + the number of data rows written.
#   output_path : the FULL /Volumes/... path of the file you wrote  (see the hard rule below)
#   row_count   : number of data rows written (int)

dbutils.notebook.exit(json.dumps({
    "status": "COMPLETED",                                              # literal, on success
    "output_path": output_path,                                        # MUST start with /Volumes/
    "row_count": int(row_count),                                       # int
    "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "request_no": dbutils.widgets.get("request_no"),                   # echo back (recommended)
}))
```

**Hard rules (each one is enforced by the App):**

1. **`output_path` MUST be a UC Volume path** — it has to start with `/Volumes/…`. The
   App proxies the download from a UC Volume only; any other path (DBFS, ADLS abfss://,
   local) makes the download endpoint return **HTTP 422** and the file is unreachable.
2. **Return a POINTER, not the data.** The exit string is capped at ~5 MB; if it is
   truncated the App marks the run **FAILED**. Never `exit()` the file contents.
3. **`status` must be `"COMPLETED"` on success.** On failure, either raise (so the run
   fails) or return `"status": "FAILED"`.
4. `row_count` is an int; `generated_at` is an ISO-8601 timestamp string.
5. It must be the **last** statement — code after `dbutils.notebook.exit` never runs.

### 1b. Parameters the Job must accept

On `run-now` the **App passes**: every report **form field** value, plus `request_no`
and `alv_id`. The **Job itself** supplies its own output-location parameters
(`catalog` / `schema` / `volume` / `output_dir`) as **job-level parameter defaults**.

Declare all of these so a triggered run always resolves them (job parameters map to
notebook widgets of the same name automatically). For the **Retail Ledger** pilot the
form-field set (the union across all its report types) is fixed:

```python
# ---- plumbing (set as JOB-LEVEL parameter DEFAULTS on the Job; the App does NOT send them) ----
dbutils.widgets.text("catalog", "<CATALOG>")
dbutils.widgets.text("schema", "<SCHEMA>")
dbutils.widgets.text("volume", "alv_outputs")     # UC Volume the App SP can READ
dbutils.widgets.text("output_dir", "")            # optional subdir under the volume
dbutils.widgets.text("env", "prod")

# ---- correlation (SENT BY THE APP on every run) ----
dbutils.widgets.text("request_no", "")            # the App's request id — echo it back
dbutils.widgets.text("alv_id", "")                # which runnable report was submitted

# ---- report FORM fields (SENT BY THE APP; declare the full union for the rows this Job serves) ----
dbutils.widgets.text("transaction_date_from", "")
dbutils.widgets.text("transaction_date_to", "")
dbutils.widgets.text("transaction_date", "")
dbutils.widgets.text("transaction_time_from", "")
dbutils.widgets.text("transaction_time_to", "")
dbutils.widgets.text("agent", "")
dbutils.widgets.text("jc", "")
dbutils.widgets.text("order_ref_no", "")
dbutils.widgets.text("transaction_type", "")
```

> The App sends only **non-blank** form values (blank optional fields are omitted), so
> every widget needs a `""` default. If **one Job serves several report types**, it must
> accept the **union** of their fields and branch on `alv_id`. If field names change in a
> report spec, keep this widget list in step.
> A complete, working reference implementation of this whole pattern is the stand-in
> `src/alv-backend/alv_dummy_report_run.ipynb`.

### 1c. Grants the JOB's run-as principal needs (not the App SP)

- **`WRITE VOLUME`** on the output Volume (`<CATALOG>.<SCHEMA>.alv_outputs`) — to write the file.
- **`SELECT`** on whatever source tables the report reads.

(If the Job is configured to run **as the App SP**, then the App SP's `WRITE VOLUME`
grant in Part 4 covers this and no separate principal is needed.)

---

## Part 2 — App environment variables (`src/alv-frontend/backend/app.yaml`)

These are read by the backend (`alv_app/config.py`). Edit `app.yaml` in the repo **before**
you point the App at it. `DATABRICKS_HOST` / `DATABRICKS_CLIENT_ID` /
`DATABRICKS_CLIENT_SECRET` are **auto-injected by the platform — never set them**.

| Env var | Set to | Required? | Notes |
|---|---|---|---|
| `DEV_MODE` | `false` | **Yes** | Must be `false` when deployed: uses real SSO identity and hard-disables the permission bypass. |
| `CATALOG` | `<CATALOG>` | **Yes** | Catalog holding the metadata tables. |
| `SCHEMA_NAME` | `<SCHEMA>` | **Yes** | Schema holding the metadata tables. |
| `DATABRICKS_WAREHOUSE_ID` | `<WAREHOUSE_ID>` | **Yes** | Serverless SQL warehouse the App queries `alv_catalog` / `request_log` through. |
| `ALV_ADMINS` | admin email(s) and/or group name(s), comma-separated | **Yes (for admin console)** | Empty ⇒ no admins ⇒ every `/api/admin/*` route 404s. e.g. `you@co.com`. |
| `REPORT_TIMEZONE` | `Asia/Kolkata` | Recommended | Timezone that resolves dynamic-template relative dates at load. Default is `Asia/Kolkata`; set explicitly. |
| `RESULT_TTL_DAYS` | `7` | Optional | `expires_at = generated_at + this`. Default 7. |
| `DOWNLOADS_PAGE_SIZE` | `50` | Optional | Downloads page size (default 50). |
| `DOWNLOADS_MAX_PAGE_SIZE` | `200` | Optional | Hard cap on a client `?limit=` (default 200). |
| `PERMISSIONS_USER_TTL_SECONDS` / `PERMISSIONS_MAP_TTL_SECONDS` | `300` | Optional | Group / mapping cache TTLs (default 300s). |
| `DEV_BYPASS_PERMISSIONS` | — | **Never set** | Dangerous dev-only escape; refused when `DEV_MODE=false` anyway. Do not add it to a deployed `app.yaml`. |

**Not needed:** the `PGHOST` / `PGPORT` / `PGDATABASE` / `PGUSER` / `PGPASSWORD` block —
the Lakebase/psycopg factory (`db.py`) is declared but unused; **no Lakebase resource is
required**.

Minimal deployed `app.yaml` `env:` block:

```yaml
env:
  - { name: DEV_MODE,                value: "false" }
  - { name: CATALOG,                 value: "<CATALOG>" }
  - { name: SCHEMA_NAME,             value: "<SCHEMA>" }
  - { name: DATABRICKS_WAREHOUSE_ID, value: "<WAREHOUSE_ID>" }
  - { name: ALV_ADMINS,              value: "you@co.com" }
  - { name: REPORT_TIMEZONE,         value: "Asia/Kolkata" }
```

---

## Part 3 — App service-principal permissions (grant checklist)

Run the SQL in a **SQL editor** (Unity Catalog grants) and use the **UI permissions
dialogs** for the warehouse and the Job. Substitute `<APP_SP>` with the App SP's
application id (Apps UI → your app → its service principal).

### 3.1 Unity Catalog (metadata reads + writes)

```sql
GRANT USE CATALOG ON CATALOG <CATALOG>                     TO `<APP_SP>`;
GRANT USE SCHEMA  ON SCHEMA  <CATALOG>.<SCHEMA>            TO `<APP_SP>`;
GRANT SELECT      ON SCHEMA  <CATALOG>.<SCHEMA>            TO `<APP_SP>`;
-- MODIFY: request_log INSERT/UPDATE (submit + status) AND report_templates writes (save/rename/delete)
GRANT MODIFY      ON SCHEMA  <CATALOG>.<SCHEMA>            TO `<APP_SP>`;
```

### 3.2 UC Volume for outputs

```sql
CREATE VOLUME IF NOT EXISTS <CATALOG>.<SCHEMA>.alv_outputs;
GRANT READ VOLUME  ON VOLUME <CATALOG>.<SCHEMA>.alv_outputs TO `<APP_SP>`;  -- App proxies downloads
GRANT WRITE VOLUME ON VOLUME <CATALOG>.<SCHEMA>.alv_outputs TO `<APP_SP>`;  -- only if the Job runs AS the App SP
```

### 3.3 SQL warehouse — UI

SQL Warehouses → `<WAREHOUSE_ID>` → **Permissions** → add `<APP_SP>` with **Can use**.

### 3.4 The report Job — UI

Workflows → the Job → **Permissions** → add `<APP_SP>` with **Can Manage Run** (minimum
for `run-now`; *Can Manage* also works). Repeat for every Job an `alv_catalog` row binds to.

### 3.5 User authorization (OBO) — required for report visibility, UI

Report visibility reads the **end user's** own groups from `/Me` using the user's
forwarded token. On the App's page in the UI, enable **user authorization** and grant
these OAuth scopes:

- `iam.current-user:read` *(required)*
- `iam.access-control:read` *(required)*

> ⚠️ Do **not** add the `sql` scope, and once set, **do not blindly re-PATCH** the scopes
> from other tooling — a partial update can silently drop them, which makes every user
> see **no reports**. `/api/me` must report `has_user_token: true` for the gate to work.

---

## Part 4 — Metadata tables: deploy the bundle via the UI, then run the jobs

The metadata-creation and seed **jobs** are defined in this repo as a Databricks Asset
Bundle (`databricks.yml` + `resources/*.job.yml`). Deploy the bundle **from the workspace
UI** (no CLI), then **Run now** each job from Workflows. The jobs read `catalog`/`schema`
from the target you configured in **(A)** and pass them to the notebooks as parameters —
**you set no notebook widgets by hand.**

1. **Import the repo** — Workspace → **Git folder** → add the GitHub repo (the branch with
   the reorg layout).
2. **Deploy the bundle (UI)** — open the Git folder, and use the workspace's **Databricks
   Asset Bundles → Deploy** action, selecting the target you edited in **(A)**. This
   creates the jobs below and syncs `src/alv-backend/` + `src/report_specs/` as workspace
   files. (`bundle_source_path` / `framework_source_path` are set for you.)
3. **Run the jobs from Workflows UI, in order** — each is already parameterized from the
   bundle, so just **Run now**:

| Order | Job (Workflows UI name / resource key) | Creates / does |
|---|---|---|
| 1 | `[<env>] ALV — provision metadata` (`provision_alv_metadata`) | Creates the schema + all four tables: `alv_catalog`, `request_log`, `report_permissions`, `report_templates`. |
| 2 | `[<env>] ALV — seed report catalog` (`seed_alv_reports`) | Seeds the 14 Retail Ledger `alv_catalog` rows (`job_id` NULL). |
| 3 | `[<env>] ALV — seed report permissions` (`seed_alv_report_permissions`) | Seeds `report_permissions` — **edit the group first** (Part 5). |
| (opt) | `[<env>] ALV — seed CC Recharge catalog` (`seed_alv_cc_recharge`) | Seeds the second demo report. |
| (opt) | `[<env>] ALV — seed sample data` (`seed_alv_sample_data`) | Seeds `retail_ledger_sample` for the Preview / sample-download demo. |

> The provision/seed job env specs already declare `pyyaml` + `jsonschema`
> (`resources/*.job.yml`), so a clean bundle deploy needs no manual `%pip`. Re-running any
> job is safe: provision is idempotent (CREATE IF NOT EXISTS) and the seeders MERGE.
>
> The bundle also deploys two **stand-in report jobs** (`alv_dummy_report_run`,
> `alv_sample_report_run`). They are optional — useful to smoke-test the whole submit →
> download pipeline **before** the real report Job exists (bind `job_id` to the dummy job
> in Part 6, then swap to `<REPORT_JOB_ID>` later).

Verify in a SQL editor:

```sql
SELECT count(*) FROM <CATALOG>.<SCHEMA>.alv_catalog;   -- expect 14 (Retail Ledger)
SHOW TABLES IN <CATALOG>.<SCHEMA>;                     -- alv_catalog, request_log, report_permissions, report_templates
```

---

## Part 5 — Report visibility (deny-by-default — the App looks EMPTY until this is done)

`report_permissions` gates every report; a `report_key` with **no active row is hidden
from everyone**. Before seeding (Part 4 step 3):

1. Edit `src/report_specs/report_permissions.json` so each `report_key` maps to a group
   that **exists in this workspace** and whose **direct members** are the intended users.
   (The shipped file maps to `alv-report_ledger_group`; create that group with members,
   or change the name to a real one.) Only **direct** membership counts — nesting is not
   resolved.
2. Run `seed_report_permissions.ipynb` (Part 4 step 3).

Verify + timing:

```sql
SELECT report_key, principal_type, principal_name, is_active
FROM <CATALOG>.<SCHEMA>.report_permissions ORDER BY report_key;
```

The App refreshes this mapping within `PERMISSIONS_MAP_TTL_SECONDS` (default 300s); a
restart makes it immediate. Ad-hoc grants can also be made later in the in-app **Admin**
console (visible to `ALV_ADMINS`).

---

## Part 6 — Bind each report to its Job (`alv_catalog.job_id`)

Every row starts with `job_id = NULL`; submitting an unbound report returns a clean
**409**. After the Job exists (`<REPORT_JOB_ID>`), bind the rows in a SQL editor:

```sql
-- Bind all Retail Ledger rows to one Job (adjust WHERE / repeat per Job if you have several):
UPDATE <CATALOG>.<SCHEMA>.alv_catalog
SET job_id = <REPORT_JOB_ID>, job_run_mode = 'run_now', updated_at = current_timestamp()
WHERE report_key = 'retail_ledger';

-- Verify (expect 14, all non-NULL):
SELECT count(*) FROM <CATALOG>.<SCHEMA>.alv_catalog
WHERE report_key = 'retail_ledger' AND job_id IS NOT NULL;
```

**Restart the App after binding** (the metadata cache is warmed once at startup).

---

## Part 7 — Create + deploy the App (UI)

The App is a FastAPI backend that also serves the **pre-built** React SPA. The built
`static/` is committed, so **no `npm` build is needed** unless you change the frontend
(public npm is firewalled; if you must build, use `--registry=https://npm-proxy.cloud.databricks.com/`).

1. **Enable Databricks Apps** in the workspace (workspace admin, if not already on).
2. Compute UI → **Apps → Create app** → name it (e.g. `alv-bricks`). This creates the
   App SP — note its application id for the Part 3 grants.
3. Ensure the deploy source root is the backend folder **`src/alv-frontend/backend/`**
   (it holds `app.yaml`, `alv_app/`, `static/`, `requirements.txt`). Either point the App
   at that path inside the imported Git folder, or copy that folder to a workspace path
   and select it as the source. **Do not** pick a parent that contains a `package.json`
   or `.venv`.
4. Confirm `app.yaml` has the Part 2 values, then **Deploy**.
5. Apply the Part 3 grants to the App SP; enable OBO scopes (Part 3.5).
6. **Restart** the App so it reloads the cache with the bound `job_id`s (Part 6).

---

## Part 8 — Order of operations (checklist)

1. [ ] Import the repo (Git folder). Edit `databricks.yml` target **(A)** and `app.yaml` **(B)** — same catalog/schema in both. Edit the group in `report_specs/report_permissions.json` (Part 5).
2. [ ] Create catalog/schema (if new) and the `alv_outputs` Volume (Part 3.2).
3. [ ] **Deploy the bundle via the UI**, then Run-now `provision_alv_metadata` → `seed_alv_reports` → `seed_alv_report_permissions` (Part 4).
4. [ ] Job developer delivers the Job (Part 1) → note `<REPORT_JOB_ID>`.
5. [ ] Create the App (Part 7) → note `<APP_SP>`.
6. [ ] Apply all SP grants (Part 3.1–3.4) + enable OBO scopes (Part 3.5).
7. [ ] Bind `alv_catalog.job_id` (Part 6).
8. [ ] Confirm `app.yaml` env (Part 2) → **Deploy / Restart** the App.
9. [ ] Smoke-test (Part 9).

---

## Part 9 — Smoke test

1. Open the App URL (workspace SSO). The home page shows the report card(s) — **if it is
   empty, `report_permissions` is unseeded or your group is wrong (Part 5)**.
2. Open Retail Ledger, fill the form, **Submit** → you get a `request_no` (`QUEUED`).
   - A `409` means the row's `job_id` is unbound (Part 6) — bind + restart.
3. On the **Downloads** page the row advances `QUEUED → RUNNING → COMPLETED` as the Job
   runs; **Download** streams the file.
   - Stuck at `QUEUED`/`RUNNING`: check the Job's run and that the App SP has *Can Manage
     Run* (Part 3.4).
   - `COMPLETED` but download fails/422: the Job's `output_path` is not a `/Volumes/…`
     path (Part 1, rule 1), or the App SP lacks `READ VOLUME` (Part 3.2).

---

## Common gotchas (each maps to a step above)

| Symptom | Cause → fix |
|---|---|
| Home page empty, no reports | `report_permissions` not seeded / wrong group / user not a **direct** member → Part 5. |
| Every `/api/admin/*` 404s | `ALV_ADMINS` empty → set it in `app.yaml` (Part 2). |
| Reports empty for everyone despite seeding | OBO scopes missing or purged → re-enable `iam.current-user:read` + `iam.access-control:read`; `/api/me` must show `has_user_token: true` (Part 3.5). |
| Submit returns 409 | `alv_catalog.job_id` is NULL → bind + restart (Part 6). |
| Submit/downloads 502 | App SP missing schema `MODIFY` or warehouse `Can use` → Part 3.1 / 3.3. |
| Run COMPLETED but download 422 | `output_path` is not `/Volumes/…` → Part 1, rule 1. |
| Run marked FAILED right after finishing | Job `exit()`ed the data (truncated >~5 MB) instead of a small pointer → Part 1, rule 2. |
| New `job_id` / re-seed not reflected | Cache warmed at startup → **restart the App**. |
