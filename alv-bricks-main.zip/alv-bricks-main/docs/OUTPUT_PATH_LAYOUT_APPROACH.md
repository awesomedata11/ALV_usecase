# Structured output paths (dated / per-report / per-request subfolders) — approach

> **Note (2026-08-19): the folder uses `alv_id`, not `report_key`.** The submit path
> already passes `alv_id` to the Job, so this needs **no new job parameter and no App-side
> change** — the whole change is inside the Job notebooks. `alv_id` is used **opaquely as a
> folder name** (never parsed for its `report_key__selection__type` parts), so it does not
> depend on the seeding convention. The grain is therefore per **runnable report type**
> (finer than `report_key`), which also cleanly separates two report types of the same
> report on disk.

> **Status: IMPLEMENTED + DEPLOYED (2026-08-19), on branch `feat/structured-output-paths`
> (uncommitted — commit + push once validated on the live app).** The decisions below are
> answered inline; the build followed them. Locked in: **date-first `<YYYYMMDD>/<alv_id>/
> <request_no>/`** layout (decisions 1–3, `YYYYMMDD`, stamped in `report_timezone` =
> `Asia/Kolkata`), the **Job owns the layout** using the params it already receives
> (decision 5 — no App change, no new job param), the **in-folder filename is the default
> Spark `part-*.csv`** written via `coalesce(1)` (decision 4), **no sanitisation** (decision
> 6), the layout is **documented in the RIL Job I/O contract** (decision 7,
> `docs/APP_PREREQUISITES.md` §2a), multi-file stays out of scope (decision 8), and a
> **daily retention cleanup job** was added (decision 9). See `CHANGELOG.md` and
> `docs/APP_PREREQUISITES.md` for the shipped contract.

## Goal

Today every run writes its output file to **one flat directory**. As run volume grows
this is unmanageable — thousands of files in a single folder, no way to browse by date
or report. Instead, lay the files out in **subfolders**:

```
<basepath>/20260819/<alv_id>/REQ-1234/xyz.csv
             │          │        │       │
             │          │        │       └─ the output file
             │          │        └───────── the request (one submission)
             │          └────────────────── the runnable report type (alv_id, used as-is)
             └───────────────────────────── the run date (YYYYMMDD)
```

This is purely a **storage-layout** change: what path a run's file is written to. It does
**not** change what the user sees, how downloads/previews work, or the metadata contract
— the App already stores and serves whatever `output_path` the Job returns.

## How the app writes output today (the baseline the design must fit)

The path is built in **two places that must agree**:

1. **The App (submit path, `src/alv-frontend/backend/alv_app/main.py`).** On submit it
   builds `job_parameters` = the form payload (`{param_name: value}`) **plus** two
   plumbing keys: `request_no` (app-generated, e.g. `REQ-1A2B3C4D5E6F`) and `alv_id`. It
   passes these to `jobs run-now` (`databricks_client.trigger_job_run`). It does **not**
   currently pass the volume/dir — those come from the Job's own parameter defaults.
2. **The Job notebook** (`src/alv-backend/alv_dummy_report_run.ipynb` and
   `alv_sample_report_run.ipynb`). Each declares `catalog` / `schema` / `volume` /
   `output_dir` params (defaults in `resources/*.job.yml`; `output_dir` defaults `""`) and
   builds:

   ```python
   base = f"/Volumes/{catalog}/{schema}/{volume}"
   if output_dir:
       base = f"{base}/{output_dir}"
   output_path = f"{base}/{request_no}_{run_id}.csv"      # <- flat: everything in one dir
   dbutils.fs.put(output_path, ...)
   ```

3. **The App captures the path back.** When the status poll resolves a run to `SUCCESS`,
   the App reads the Job's `dbutils.notebook.exit` pointer (`output_path`, `row_count`,
   `generated_at`) and persists `output_path` verbatim into `request_log`. **Download**
   (`GET …/download`) and **output preview** (`GET …/output-preview`) then read that exact
   path off the Volume as the App SP — they never parse or reconstruct it.

**Consequences for this design:**

- The App and the Job share a **path contract**. Whoever owns the layout, both sides must
  produce/consume the same shape. Because the App stores the returned path opaquely,
  **the Job is the last word on the actual path** — the App only influences it via the
  params it passes.
- The **real RIL Job** (customer-built, not in this repo) must honour the same contract.
  So the contract has to be simple and explicit — a subfolder the App hands the Job, not a
  layout the Job is trusted to invent (D6: the `param_name` ↔ Job-key contract is agreed
  with the customer).
- **`alv_id`'s `report_key__selection__type` form is a seeding convention, not a
  contract** (this bit us in the report-routing bug). We use `alv_id` **as a whole, opaque
  folder name** and never split it into parts, so the layout does not depend on that
  convention.

## Approach — the Job owns the layout, using params it already receives

**Decided (2026-08-19):** the **Job** builds the path from the two ids it **already gets**
(`alv_id` + `request_no`) and stamps the **current date itself**:

```
output_path = f"/Volumes/{catalog}/{schema}/{volume}/{today}/{alv_id}/{request_no}/{filename}"
                                                        │        │        │
                                    Job computes ───────┘        │        │
                        App already passes alv_id ───────────────┘        │
                        App already passes request_no ───────────────────-┘
```

- **No App-side change and no new job parameter.** Submit already sends `request_no` +
  `alv_id` (`main.py:751`). The Job now simply *uses* them to compose the path instead of
  writing flat. `main.py` and the frontend are untouched.
- **The Job computes the date and builds the full path.** In the notebook:

  ```python
  from datetime import datetime
  from zoneinfo import ZoneInfo
  today = datetime.now(ZoneInfo(report_timezone)).strftime("%Y%m%d")   # e.g. 20260819
  base = f"/Volumes/{catalog}/{schema}/{volume}"
  out_dir = f"{base}/{today}/{alv_id}/{request_no}"
  output_path = f"{out_dir}/{filename}"
  dbutils.fs.put(output_path, ...)      # auto-creates the intermediate dirs
  ```

  The `output_dir` param goes away — the Job derives the whole subtree from `alv_id` +
  `request_no` + its own clock.

Why this shape:

- The path-building logic lives with the process that writes the file. Each Job — dummy,
  sample, and the future RIL Jobs — stamps its own run date and composes the same layout
  from the two ids it is handed.
- The date is the **Job's run date**, not submission time. Accepted trade-off: a run that
  queues across midnight can land under a different day than the `request_no` was created
  on. (See decision 3 — pick the timezone the Job stamps in.)
- `alv_id` is used **as an opaque folder name**, never split into its
  `report_key__selection__type` parts, so the layout does not lean on the seeding
  convention.

### What changes, precisely

| Layer | Change |
|---|---|
| App submit (`main.py`) | **None.** `alv_id` + `request_no` are already in `job_parameters`. |
| Job notebooks (dummy + sample) | Compute `today` from the clock (in `report_timezone`); build `output_path = f"{base}/{today}/{alv_id}/{request_no}/{filename}"` from the params already received. `dbutils.fs.put` auto-creates the dirs. |
| Job YAMLs (dummy + sample) | **Remove** the now-unused `output_dir` param; add a `report_timezone` param (default `Asia/Kolkata`) so the Job's date clock is configurable, not hardcoded. (`alv_id` + `request_no` params already exist.) |
| Filename | Decide the in-folder filename (decision 4). |

### What does NOT change (important)

- **No metadata schema / migration.** `request_log.output_path` still stores the full
  path the Job returns — just a longer one. No column change, no backfill.
- **Download + output-preview are untouched** — they read `output_path` verbatim.
- **Existing rows keep working** — their stored flat paths still resolve; only new runs
  get nested paths. No back-compat break.
- **No new grants.** The App SP's `WRITE VOLUME` / `READ VOLUME` on `alv_outputs` covers
  every subdirectory of the volume; UC Volumes create parent dirs on write.
- **`param_hash` is unaffected** — it is computed over the form payload only, never the
  plumbing keys (`request_no` / `alv_id`), so caching/reuse still keys on
  identical inputs.

## Open decisions — please answer inline

1. **Layout order — confirm `<date>/<alv_id>/<request_no>/`.**
   Your example is `<basepath>/20260819/<alv_id>/REQ-1234/file.csv`. Date-first makes
   retention/cleanup by day trivial (drop a whole `20260819/` tree). Alternative would be
   `<alv_id>/<date>/<request_no>/` (browse by report type first). I recommend
   **date-first**, per your example. Confirm.
   A:

2. **Date format — `YYYYMMDD` (e.g. `20260819`)?**
   Your example uses `20260819`. Alternative `2026-08-19` (hyphenated, more readable in a
   file browser). I recommend matching your example (`YYYYMMDD`). Confirm, or prefer
   hyphens?
   A:

3. **Which timezone does the Job stamp the date in?** (The date is the **Job's run
   date** — decided, per your direction the Job figures out "today" itself.) The Job needs
   a timezone to turn "now" into a `YYYYMMDD` folder. Options: (a) **Asia/Kolkata** (the
   RIL report clock, same as templates) passed as a `report_timezone` job param; (b) the
   cluster/UTC default. I recommend **(a) Asia/Kolkata via a job param**, so it is
   configurable and matches the report timezone rather than depending on the cluster's
   locale. Confirm.
   A:

4. **In-folder filename.** The `REQ-1234/` folder already isolates one request, so the
   filename inside it is free. Options:
   - (a) keep today's `<request_no>_<run_id>.csv` (fully unique, traceable);
   - (b) a cleaner `<alv_id>.csv` or `output.csv` (folder already carries the ids);
   - (c) `<alv_id>_<YYYYMMDD_HHMMSS>.csv`.
   I lean **(a)** — zero collision risk and the filename is self-describing even if moved
   out of its folder. Which do you want?
   A: let this be a default spark output filename - doesnt matter now that we have the request id in the subfolder name itself.

5. **Who owns the layout — App or the Job?** **DECIDED: the Job**, using the `alv_id` +
   `request_no` it already receives (no new job param, no App change). The Job stamps the
   date and builds the whole path (see "Approach"). Every RIL Job must implement the same
   composition. Noted here for the record — no answer needed.

6. **`alv_id` / `request_no` sanitisation.** `alv_id`s today are clean slugs
   (`retail_ledger__detail__agent_item`) and `request_no` is `REQ-<hex>`, but to be safe the
   **Job** should reject/replace any character that isn't `[A-Za-z0-9_-]` so a stray value
   can never escape the base dir (path-traversal / `..`). Since the Job owns the path, this
   guard lives in the notebook helper. I propose collapsing anything outside `[A-Za-z0-9_-]`
   to `_`. Agree?
   A: not needed. 

7. **The real RIL Job contract.** This change defines the layout the RIL Jobs must build
   from the params they already receive: "write your output file(s) under
   `/Volumes/<cat>/<schema>/<volume>/<YYYYMMDD>/<alv_id>/<request_no>/`, stamping the date
   in `report_timezone`". Do you want me to add this to the **Job I/O contract**
   (`docs/APP_PREREQUISITES.md` / the CONTRACT note) so it's handed to RIL, or keep it in
   this doc only for now?
   A: yes document it alongside the other changes necessary to make the jobs work with the app.

8. **Multi-file groundwork.** A per-request `REQ-1234/` folder is exactly what the backlog
   **multi-file download** (`docs/MULTI_FILE_DOWNLOAD_APPROACH.md`) needs — all files for
   one request in one folder. Should this change explicitly return the **folder** (not just
   a single file path) so multi-file can build on it later, or stay single-file
   (`output_path`) for now and let the multi-file feature extend it? I lean **stay
   single-file now**, note the folder as the natural extension point.
   A: we will work on the multifile download later, for now the scope of this task is well defined. 

9. **Retention / expiry interplay.** `expires_at` already drives result-cache validity;
   actual **file cleanup** isn't implemented yet. Date-first folders make a future
   "delete everything older than N days" job trivial. Out of scope for this change — just
   confirm you're happy to leave file deletion as a later item (this change only makes it
   easier).
   A: create a job that runs once a day, clearing out the volume based on current date - N (n is configurable in the databricks yaml)

## Proposed implementation slices (after sign-off)

Each slice is deployed and validated by you before the next starts.

1. **Library path helper + Job notebooks.** Add a small **Spark-free, pure**
   `build_output_path(base, alv_id, request_no, filename, now)` helper to the
   `dbx_alv_reports` library (the notebooks already `sys.path`-bootstrap it), so the
   composition + `alv_id`/`request_no` sanitisation is **unit-tested with no cluster**
   (layout order, `YYYYMMDD` stamping via injected `now`, traversal rejection). Update both
   Job notebooks to compute `today` (in `report_timezone`), call the helper, and write the
   nested path; update the two YAMLs (add `report_timezone`, drop `output_dir`). **No
   App/frontend change.** Library unit tests. Deploy the bundle; you submit a run and
   confirm the file lands at `…/20260819/<alv_id>/<request_no>/…` and that download +
   preview still serve it.
2. **Docs.** `CHANGELOG.md` + README progression, `docs/METADATA_TABLE.md` (note the path
   shape stored in `output_path`), the Job I/O contract note for RIL (decision 7),
   `CLAUDE.md` if a playbook note helps, and mark this doc IMPLEMENTED with the decisions
   locked in.

## File touch-list (reference)

- `src/alv-backend/dbx_alv_reports/…` — new pure
  `build_output_path(base, alv_id, request_no, filename, now)` helper (+ re-export from
  the package `__init__`), so the Job imports it and it is unit-testable off-cluster.
- `src/alv-backend/alv_dummy_report_run.ipynb`,
  `src/alv-backend/alv_sample_report_run.ipynb` — compute `today` (in `report_timezone`);
  build the nested path via the helper from the `alv_id` + `request_no` already received.
- `resources/alv_dummy_report_run.job.yml`,
  `resources/alv_sample_report_run.job.yml` — add `report_timezone` (default
  `Asia/Kolkata`); remove the unused `output_dir` param. (`alv_id` + `request_no` params
  already exist.)
- **No App-side files** — `main.py` / the frontend are untouched (`alv_id` + `request_no`
  are already passed).
- Tests: library unit tests for `build_output_path`.
- Docs: `CHANGELOG.md`, `README.md`, `docs/METADATA_TABLE.md`, `docs/APP_PREREQUISITES.md`
  (contract), this doc.
