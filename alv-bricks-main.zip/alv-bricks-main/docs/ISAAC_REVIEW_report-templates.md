# Isaac Review — `feat/report-templates`

> **Date:** 2026-08-08. **Branch reviewed:** `feat/report-templates` (diff vs `main`).
> **Method:** the `isaac review --base main` CLI hit a prompt-length limit on the 690 KB /
> 28-file diff, so the reviewer ran a manual security-focused pass plus the `code-review
> --effort high --base main` skill.
>
> This doc records the raw findings **and** my (Claude's) triage against the actual code
> and Delta / Unity Catalog semantics. **No code was changed** — findings only. Review
> after the templates task, then decide what (if anything) to act on.

## TL;DR

- **Security assessment PASSED** — the important invariants all hold (gate order, 404-on-deny,
  bound parameters, owner-scoping, case-folded email; 16 tests cover them).
- Of the 8 findings, **most do not hold up** on this platform / codebase. The only one
  worth a small honest fix is **#5/#6** (write endpoints return null `created_at`/`updated_at`).
- **Nothing here blocks merge.**

## Verdict table

| # | Finding | Reviewer severity | My verdict | Worth fixing? |
|---|---|---|---|---|
| 1 | No UNIQUE constraint on (owner, alv_id, template_name) | High | **Invalid** — UC constraints are informational only; Delta has no enforced UNIQUE. MERGE enforces it. | No |
| 2 | `save_template` returns fallback id without verifying write | High | **Invalid** — `_execute` raises on any warehouse failure; the empty-SELECT path can't occur, and the FE ignores the returned id. | No |
| 3 | `apiPost` doesn't guard `resp.json()` on a 200 | Medium | **True but pre-existing** (also `apiGet`), not from this branch; FastAPI won't emit malformed JSON. | Optional, whole-codebase |
| 4 | TOCTOU race in `rename_template` | Medium | **Technically true, negligible** — one user renaming his own two templates at the same instant; Delta can't enforce uniqueness anyway. | No (pilot) |
| 5 | `save_report_template` returns null timestamps | Low | **Valid (cosmetic)** — response omits DB-set `created_at`/`updated_at`. | **Yes (small)** |
| 6 | `rename_report_template` returns null timestamps | Low | **Valid (cosmetic)** — same as #5. | **Yes (small)** |
| 7 | Redundant SELECT after MERGE in `save_template` | Low | **Invalid** — the SELECT resolves the *existing* row's id on overwrite; the statement API doesn't return the merged id. | No |
| 8 | Repeated bound-param dicts across template fns | Very low | **By design** — matches `admin.py` / `request_log.py` house style. | No |

## Detail + my reasoning

### 1. Missing UNIQUE constraint — INVALID
`src/alv-backend/dbx_alv_reports/metadata/metadata_tables.py`. UC PK/FK/UNIQUE are **informational,
not enforced at write time** (documented in `CLAUDE.md` and `docs/METADATA_TABLE.md`), and
Delta has no enforced UNIQUE constraint at all. No other metadata table declares one.
Uniqueness of (owner, alv_id, template_name) is enforced by the `MERGE ... ON` in
`save_template`. Adding the constraint would change nothing at runtime.

### 2. `save_template` fallback id — INVALID
`src/alv-frontend/backend/alv_app/templates.py`. The reviewer's scenario ("SELECT fails → returns
`new_id`") can't happen: `_execute` **raises `TemplateError`** on any warehouse
failure/timeout, so a failed post-MERGE SELECT surfaces as a 502, never an empty result.
The `existing or new_id` fallback is only reachable when a MERGE succeeds and the row then
disappears — effectively impossible. The frontend also doesn't consume the returned id (it
invalidates and refetches the list).

### 3. `apiPost` unguarded `resp.json()` — TRUE, PRE-EXISTING
`src/alv-frontend/frontend/src/api/client.ts`. Real, but it predates this branch and applies equally to
`apiGet`. A 200 with malformed JSON doesn't occur from FastAPI. If we ever harden it, do it
across the client, not as part of this feature.

### 4. TOCTOU in `rename_template` — TRUE, NEGLIGIBLE
`src/alv-frontend/backend/alv_app/templates.py`. The window is one user renaming two of *his own*
templates for the *same report* at the same instant. Delta can't enforce uniqueness at the
DB level regardless, so a hard guarantee isn't available here anyway. Not worth a lock for
the pilot.

### 5 / 6. Write endpoints return null timestamps — VALID (cosmetic), WORTH A SMALL FIX
`src/alv-frontend/backend/alv_app/main.py` — `save_report_template` and `rename_report_template` return
`TemplateSummaryOut` with `created_at`/`updated_at` = null even though the DB sets them.
Impact is near-zero (the FE refetches the list; the write response isn't rendered as a
row), but the response is dishonest. Cheapest fix: drop the two timestamp fields from the
response shape for the write endpoints, or have the write functions return the real values.

### 7. Redundant SELECT after MERGE — INVALID
`src/alv-frontend/backend/alv_app/templates.py`. On an **overwrite**, the correct id is the *existing*
row's, not the freshly generated `new_id`; the statement-execution API doesn't return the
merged row's id, so the SELECT is how we learn it. Not redundant.

### 8. Repeated param dicts — BY DESIGN
`src/alv-frontend/backend/alv_app/templates.py`. The explicit `{"name","value","type"}` dicts mirror the
established pattern in `admin.py` and `request_log.py`. Consistency across the seam modules
is intended; a shared helper would make this module diverge from its siblings.

## Recommendation

Nothing blocks merge. The only change I'd consider is **#5/#6**, purely for response
honesty. If you want it, I'll apply it to the working tree (uncommitted) for your review.
