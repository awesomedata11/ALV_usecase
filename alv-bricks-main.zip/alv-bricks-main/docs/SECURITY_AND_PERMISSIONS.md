# Security and permissions — ALV-Bricks

Reference document for security reviews and architecture discussions.

| Item | Value |
|---|---|
| Scope | The ALV-Bricks App (FastAPI backend + React frontend) on Databricks Apps, and the metadata it reads |
| Workspace (pilot) | `fevm-classic-stable-lakebase` |
| Catalog / schema | `classic_stable_lakebase_catalog.alv_metadata` |
| CLI profile | `fevm-lakebase` |
| Status | Report visibility by group: **built, deployed, and validated** (2026-08-04). Output ownership check: **open** (see §8) |
| Last updated | 2026-08-04 |

---

## 1. Summary for a reviewer

The App answers two different questions with two different identities.

| Question | Identity used | Why |
|---|---|---|
| **Who is asking, and which groups is this person in?** | the **end user**, through their OBO token | Only the user can prove their own identity and read their own group list without admin rights |
| **What data do we then read or write?** | the **App service principal (SP)** | The data is shared, non-personal report metadata and sample data. The SP owns it |

We call this **selective OBO**. We use the user's identity for **authorization**, and the App SP for **data access**. We do not use OBO to read business data.

Three controls carry the design:

1. **Deny by default.** A report with no permission row is invisible to everybody.
2. **Enforcement on write paths, not only on display.** Hiding a card is not a security control.
3. **Deny returns `404`, not `403`.** The App never confirms that a report the user may not see exists.

---

## 2. Identity: how we know who is asking

Databricks Apps puts the signed-in user's identity in front of the App:

- The proxy injects the user's OAuth token in the header **`X-Forwarded-Access-Token`**. This is the **On-Behalf-Of (OBO)** token, also called *user authorization*.
- The App validates that token **server-side** by calling `GET /api/2.0/preview/scim/v2/Me` (`WorkspaceClient.current_user.me()`) with it. Databricks returns the caller's own record.

### 2.1 The platform token flow (generic OBO)

This is how Databricks Apps delivers the user token. It applies to any App that uses user authorization:

```
[ User Browser ]
       │
       ▼ (SSO login)
[ Databricks Proxy ] ──► (generates a short-lived user token)
       │
       ▼ (injects header: X-Forwarded-Access-Token)
[ Your App Backend ] (FastAPI / Flask / Streamlit)
       │
       ▼ (queries data via the Databricks SDK / SQL)
[ Unity Catalog / SQL Warehouse ] ──► (enforces the user's exact permissions)
```

### 2.2 How ALV-Bricks differs from that flow

> **Read this before you use the diagram above in a review.** The last step of the generic
> flow is **not** what ALV-Bricks does. In full OBO, the App queries data *as the user*, so
> Unity Catalog enforces that user's own grants. We deliberately **stop short of that**: the
> token is used to establish **identity**, and the App SP still performs the data access.

```
[ User Browser ]
       │
       ▼ (SSO login)
[ Databricks Proxy ] ──► (generates a short-lived user token)
       │
       ▼ (injects header: X-Forwarded-Access-Token)
[ ALV-Bricks backend (FastAPI) ]
       │
       ├── AUTHORIZATION ─── as the USER ───► /Me  (SCIM)
       │        │                              └─► returns THIS user's own `groups`
       │        ▼
       │   intersect with `report_permissions`  ──► the permitted set of report_key
       │        │                                   (deny by default; 404 on deny)
       │        ▼
       │   ── if not permitted: stop here. No data call is ever made. ──
       │
       └── DATA ACCESS ─── as the APP SP ───► SQL Warehouse / Jobs / Volume
                │                              (catalogue, report_permissions,
                │                               preview query, job trigger,
                ▼                               request_log, output files)
         [ Unity Catalog ] ──► enforces the APP SP's grants, not the user's
```

**Consequences of this choice, stated plainly for a reviewer:**

- **Unity Catalog does not enforce per-user data access here.** The App does the enforcement, at the report-visibility level, before any data call. UC sees only the App SP.
- **End users need no grants of their own** on the catalog, schema, sample table, jobs, or volume. This keeps onboarding simple and matches the pilot's data model, where report metadata and sample data are shared and non-personal.
- **The authorization check runs before the data call**, so a rejected caller causes no query, no job trigger, and no write.
- **The trade-off:** if a report ever exposes genuinely per-user or personal data, report-level gating is not sufficient, and that path should move to full OBO so UC enforces the user's own grants. See §8 for the one place this already matters today.

**Why we validate the token instead of trusting a header.** Databricks also forwards `X-Forwarded-Email`, `X-Forwarded-User`, and `X-Forwarded-Preferred-Username`. The public documentation does **not** state whether the proxy strips a client-supplied copy of those headers. A control that trusts a plain header alone can be bypassed if a client can set that header. The token is verified by Databricks itself, so it cannot be forged. The plain headers are used only as a **cache key and for log lines**, never as the basis of an access decision.

Related note: in live testing `X-Forwarded-Preferred-Username` returned a **display name** (`Idris Chakera`), not an email. Use **`X-Forwarded-Email`** where an email is required.

### Scopes

The App already holds the effective user scopes `iam.current-user:read` and `iam.access-control:read`. These are platform defaults and are sufficient.

> **Do not PATCH `user_api_scopes` on this App.** If the workspace-level *User authorization (preview)* toggle is off, a PATCH returns HTTP **200 while silently discarding the field**, and the OBO token then stops arriving. The failure looks like success. We deliberately changed nothing here, so we never depend on that behaviour.

We do **not** need the `sql` scope, because the group check uses `/Me` and not a SQL query.

---

## 3. Authorization: report visibility by principal (group or user)

### The rule

A user sees a report when **any** active grant permits them — a **group** grant for a group they belong to, **OR** a **user** grant naming their email. Several grants on one report behave as **OR**; a report granted by both a group and a user appears once.

Gating is at **report level** (`report_key`): the home-page card and every selection and report type under it move together.

### The mapping table

`classic_stable_lakebase_catalog.alv_metadata.report_permissions`

| Property | Value |
|---|---|
| Grain | one row per (`report_key`, `principal_type`, `principal_name`), composite primary key |
| `principal_type` | `'group'` (matched against the user's `/Me` groups) or `'user'` (matched against the caller's email) |
| `principal_name` | a group display name (case-sensitive), or a user email **stored lower-cased** and matched case-folded |
| Audit columns | `is_active`, `granted_at`, `granted_by` |
| Created by | the `provision_alv_metadata` job (single-source DDL, `CREATE TABLE IF NOT EXISTS`) |
| Bootstrapped by | the `seed_alv_report_permissions` job (one-time), from `src/report_specs/report_permissions.json` |
| Written at runtime by | the **admin console** (`/api/admin/permissions`) — grant/revoke, as the App SP |
| Read by | the **App SP** — it owns the table, the same as the catalogue read |

> **Schema change (2026-08-08):** grain was generalized from (`report_key`, `group_name`) to add ad-hoc **user** grants. `group_name` → `principal_name`; `principal_type` added. A one-time migration renames + adds the column + backfills `principal_type='group'` on the deployed table (`ensure_all()` only CREATEs, never ALTERs).

Current pilot mapping:

| `report_key` | `principal_type` | `principal_name` | `is_active` |
|---|---|---|---|
| `retail_ledger` | group | `alv-report_ledger_group` | true |
| `cc_recharge` | group | `alv-report_ledger_group` | true |

### The decision path, per request

1. Resolve identity: `X-Forwarded-Email` (the caller's email) and `X-Forwarded-Access-Token` (the OBO token; no token means **no groups** — see §5).
2. **Group grants:** call `/Me` with the token, take the `groups` list (the user's own memberships), and intersect with each report's mapped groups.
3. **User grants:** match the caller's lower-cased email against each report's mapped user emails. This uses only the trustworthy email header, so it holds **even when OBO is off** and `/Me` could not be read.
4. Read the active rows of `report_permissions` as the App SP; the two grant kinds are indexed separately.
5. **Union** the group-permitted and user-permitted `report_key`s. That set is what this user may see.
6. Filter the report list at one point in `cache.py`, so every render path inherits the filter.

### Who may administer grants

The admin console write endpoints are gated by an **admin check** separate from the grant table: a caller is an admin if their email OR one of their `/Me` groups appears in the `ALV_ADMINS` config list (comma-separated emails and/or group names, wired via `src/env_parameters/*.yaml` → `app.yaml`). The check fails closed, and non-admin callers get **404** on every `/api/admin/*` route (existence is not disclosed). This is the bootstrap admin surface — it is deliberately config-driven, not stored in the grant table, so admin rights cannot be granted through the very console they gate.

---

## 4. Why we rejected the other options

This is the part reviewers usually ask about, so the reasoning is recorded here in full. Each point was verified live on the pilot workspace, not assumed.

### `is_account_group_member()` / `is_member()` — not usable

Both SQL functions take **one argument** (a group name) and always evaluate the **session user**, that is, the identity that runs the query. Our SQL runs as the App SP, so they would report the **SP's** groups for every user.

Live evidence of a second trap: for a workspace administrator, `is_account_group_member('admins')` returned **false** while `is_member('admins')` returned **true**, because that `admins` group is workspace-local rather than an account group. The two functions read **different group types** and are not interchangeable.

### SCIM Groups / Users lookups — rejected on privilege grounds

Reading **another** user's group membership through the SCIM `Groups` or `Users` APIs requires **workspace admin**. Tested with a non-admin service principal, the `members` and `groups` fields are **silently stripped** — no error is raised, the fields are simply empty. A naive implementation would therefore deny every user quietly, which is a difficult fault to diagnose.

The App SP is **not** a workspace admin, and we chose not to make a web-facing application a workspace admin to answer one narrow question.

A narrower variant exists — grant the SP `Manage` on only the gating groups — but `Manage` is **read and write**, so the App could then modify or delete the very groups it gates on. We rejected it.

### `/Me` — chosen

A user may always read their own identity, so `/Me` needs **no elevated privilege at all**. It also avoids a provisioning trap: under **automatic identity management (AIM)**, SCIM group member lists can be incomplete, which would silently deny legitimate users. `/Me` is unaffected, because the user reports their own memberships.

### No system table

`system.information_schema.groups` and `.group_members` appear in community posts but are **not** in the official system-table list. We do not design against them.

---

## 5. Safeguards in place

| # | Safeguard | How it works |
|---|---|---|
| 1 | **Deny by default (fail-closed)** | A `report_key` with no active mapping is never in the permitted set. An unmapped report is invisible however correct everything else is |
| 2 | **Errors reduce access, never widen it** | Any failure in the gate results in *fewer* reports. A failed read of the mapping table returns `PermissionMap(ok=False)`, which denies everything |
| 3 | **A read failure is not cached** | So the App recovers by itself once the underlying problem clears, instead of holding a denial for the whole TTL |
| 4 | **Write paths enforce independently** | `submit` and `preview` check the report; `status`, `params` and `download` resolve the request's `alv_id` to its `report_key` and check that (all three share `_require_request_permission`). `/api/requests` filters rows too. Hiding a card is not relied upon |
| 5 | **Order of checks** | On `submit`, the permission check runs **before** the `request_log` write, **before** the job trigger, and before the `409` unbound-job check. A rejected caller causes no side effect |
| 6 | **Unresolvable identifiers are denied** | An `alv_id` that cannot be resolved to a `report_key` is treated as not permitted, rather than allowed by omission |
| 7 | **`404`, never `403`** | Every denial raises `404` with the **same** message as a genuine missing report (`report not found: …` / `request not found: …`). Existence is not disclosed |
| 8 | **The user token is never exposed** | It is held in a field marked `repr=False`, so it cannot leak through a log line or a stack trace. It is never persisted, and never returned in a response body. The API exposes only the boolean `has_user_token` |
| 9 | **The dev bypass cannot be turned on remotely** | `dev_bypass_permissions` defaults to **False**, is read only from settings (environment or `.env`), and can **never** come from a request header or query parameter |
| 10 | **The dev bypass needs two flags** | It requires `dev_bypass_permissions` **and** `dev_mode`. The deployed `app.yaml` sets `DEV_MODE=false`, so a bypass is **refused and logged as an error** even if the variable is set by mistake |
| 11 | **Per-user cache, never keyless** | The group set is cached under `user:<email or user id>`. A missing key does not collapse to a shared entry, so one user can never inherit another user's groups |
| 12 | **A cap we must respect** | Workspace SCIM is limited to **255 GET/min and cannot be raised**, so caching is a correctness requirement, not an optimisation. TTL default is 300 s (`PERMISSIONS_USER_TTL_SECONDS`, `PERMISSIONS_MAP_TTL_SECONDS`) |
| 13 | **The startup cache stays user-independent** | The metadata cache is still loaded once by the App SP. All per-user filtering happens at request time, so no user's entitlements are ever baked into shared state |
| 14 | **The Downloads list filters in SQL, before its limit** | The permitted-`alv_id` allowlist, the scope and the search are all `WHERE`-clause predicates, so the page limit runs last. The earlier shape (`LIMIT 100` then filter in Python) meant the visible set depended on where the cap fell |
| 15 | **The list query binds every user value** | `scope` / `q` / `sort` / `limit` / `offset` never reach the statement as text: `sort` is looked up in a fixed allowlist, `limit` is clamped to `DOWNLOADS_MAX_PAGE_SIZE`, and the search reaches SQL only as resolved `alv_id` s — one bound JSON array, so a many-report user also stays under the statement API's 256-parameter cap |
| 16 | **An empty permitted set runs no query at all** | "This user may see nothing" is answered locally. A broad table scan is never issued on behalf of an unpermitted caller |
| 17 | **The params view is gated like the file** | `GET /api/requests/{n}/params` shares `_require_request_permission` with status and download — parameters describe the data, so they are treated as being as sensitive as it. A malformed stored payload degrades to `parse_ok=false`, never a 500 that could leak a stack trace |

### Diagnosing "the user sees no reports"

An empty result is intentionally ambiguous to the **user**, but never to the operator. Each denial logs a `reason` at WARNING:

| Reason | Meaning |
|---|---|
| `no_user_token` | **OBO is off**, or the header was stripped. User authorization is not enabled on the App. The user's groups were never read |
| `me_failed` | The token arrived, but `/Me` failed — expired token, missing `iam.current-user:read` scope, or the workspace was unreachable |
| `no_groups` | `/Me` answered normally and the user genuinely belongs to no group |
| `no_mapping` | The user has groups, but none is mapped to any report |

This distinction matters: without it, a **misconfiguration** and a **correct denial** look identical.

---

## 6. Data access: what the App SP does

See the diagram in **§2.2** for how this sits beside the authorization path, and note the
consequence recorded there: **Unity Catalog enforces the App SP's grants, not the user's.**

The App SP remains the identity for all data work:

- Reads the report catalogue and the `report_permissions` map.
- Runs the **sample-data preview** query on the SQL warehouse.
- Triggers the reporting Jobs and writes `request_log`.
- Reads output files from the `alv_outputs` Volume.

**Why the preview does not use OBO.** The preview reads a shared, non-sensitive sample table. Querying it as the SP is the correct choice and keeps the design simple: end users do not need their own grants on the table. This was recorded as a decision, with OBO reserved for per-user data access on audit-critical paths.

### Preview query safety

The preview accepts user input, so it is treated as a data-exposure surface:

- **Bound parameters.** User values are passed as query parameters (`:p0`, `:p1`, …). They are never concatenated into the SQL string, which is the robust defence against SQL injection.
- **Identifier allowlist.** Column and table identifiers are validated against the report's own configuration, never taken from the request.
- **Explicit column list.** No `SELECT *`, so a schema change cannot widen what is returned.
- **Bounded results.** The preview is capped (500 rows maximum), and the `IN` list is capped at 200 values.
- **Audit line per preview**, which records the request without recording raw user values.

---

## 7. Known limitations

Recorded deliberately, because each one is a question a reviewer should ask.

- **Flat groups only.** `/Me` returns **direct** memberships. A user who belongs only to a group *nested inside* a mapped group will **not** see the report. Map the group the users are actually in.
- **Group display name is the join key.** The mapping stores the group's display name, so renaming a group in Databricks silently breaks the mapping. The seeder rejects whitespace-padded names, because those would never match.
- **Report-level, not row-level.** This controls **which reports** a user sees, not which **rows** they see inside a report. Row-level filtering by business dimension was the grain of the deferred `auth_map` (decision D19), which is **superseded for report visibility** and left unused.
- **Propagation is not instant.** A permission change takes effect within the cache TTL (300 s by default). Restart the App for immediate effect.
- **Revocation needs an explicit action.** The seeder uses `MERGE`, so removing an entry from the manifest does **not** delete the row. To revoke, set `is_active: false` and re-seed, or delete the row.
- **OBO is in Public Preview** at the time of writing, and requires the workspace *User authorization* setting. Users cannot revoke their consent once granted.
- **The forwarded headers are undocumented** on the public Apps authentication page. They work, and we treat them as observed behaviour — which is precisely why the access decision rests on the validated token instead.

---

## 8. Output ownership — RESOLVED AS INTENDED (2026-08-04)

**Closed by an explicit product decision. Do not "fix" this.**

An earlier revision of this document listed cross-user output access as an open
security item, proposing a `submitted_by == caller` restriction on the download and
list paths. **That is now settled the other way:** cross-user *visibility* **and**
cross-user *download* are **intended behaviour**, provided both users hold the report
permission.

- **The rule:** the `report_permissions` group gate is the **only** authorization
  control on the request-list, status, params and download paths — and it is correct as
  written. Being permitted on a report grants access to that report's runs, whoever
  submitted them. Sharing a report group is the act that grants the sharing.
- **`submitted_by` is displayed, not masked** — the Downloads table shows who submitted
  each run, deliberately, so shared access is legible rather than silent.
- **Consequently there is no owner-only restriction anywhere on these paths**, and none
  should be added. A future reviewer reading "cross-user download works" is looking at
  a decision, not a defect.
- **Where ownership *is* modelled:** the Downloads list offers a `scope=mine` filter
  (`GET /api/requests?scope=mine`), which narrows to the caller's own rows. That is a
  **convenience filter, not a control** — it is not, and must not be relied on as, an
  authorization boundary. `scope=accessible` (the default) intentionally shows
  everyone's runs for your permitted reports.
- **Matching the caller:** `submitted_by` is written as
  `email or preferred_username or user_id` by precedence, and that precedence has varied
  over the table's life, so the `scope=mine` predicate matches all three forms
  (case-insensitively). Rows are not migrated.

If the requirement ever changes, the change belongs in `report_permissions` grain (e.g.
finer-grained mappings), not in a per-row owner check bolted onto the download path.

---

## 9. How to verify the controls

### Verify the allow path
Sign in as a member of a mapped group. The mapped report cards appear, and preview and download work.

### Verify the deny path
Two independent methods, both confirmed working on 2026-08-04:

1. **Deactivate the mapping**
   ```sql
   UPDATE classic_stable_lakebase_catalog.alv_metadata.report_permissions
   SET is_active = false WHERE report_key = 'cc_recharge';
   ```
2. **Remove the user from the group** in the Databricks admin console.

In both cases, after the TTL passes (or after an App restart), the report card disappears, the catalogue no longer lists it, its rows vanish from Downloads, and a direct request for its `alv_id` returns **404**.

The second method is the stronger test: it proves the gate reads the **end user's** groups through OBO. If the App used the SP's identity, removing that user from the group would change nothing.

### Verify fail-closed
Add a report and do **not** map it. It must be invisible to everyone, including an administrator.

---

## 10. Operating procedures

### When a new report is added
`report_permissions` must be populated, or the report stays invisible. The full checklist is in `CLAUDE.md` under *Onboard a new report*; the permission step is:

1. Add the new `report_key` to `src/report_specs/report_permissions.json` with its group or groups.
2. Run the `seed_alv_report_permissions` job.
3. The App reflects the change within `PERMISSIONS_MAP_TTL_SECONDS` (300 s default), or immediately after a restart.

### To grant or revoke access for a group
See *Grant / revoke a report for a group* in `CLAUDE.md`. In summary: edit the manifest, re-seed, and remember that `MERGE` never deletes — revoke with `is_active: false` or by deleting the row.

### After any metadata re-seed
Re-seeding `alv_catalog` resets the `job_id` bindings to `NULL`, because the manifest carries placeholder nulls. Re-bind the jobs and restart the App. This does not affect `report_permissions`, which is seeded by its own job.

---

## 11. Related documents

| Document | Content |
|---|---|
| `docs/METADATA_TABLE.md` | The `report_permissions` table contract |
| `docs/APP_PREREQUISITES.md` | Workspace grants and App configuration, including the `user_api_scopes` warning |
| `docs/APP_DEPLOY_RUNBOOK.md` | Deployment order, including the two jobs to run |
| `CLAUDE.md` | Onboarding playbooks and the decision log |
| `src/alv-frontend/backend/alv_app/entitlements.py` | The gate itself; the module docstring holds the design rationale |
