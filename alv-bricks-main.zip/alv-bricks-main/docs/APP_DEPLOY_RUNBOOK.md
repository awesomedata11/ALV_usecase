# App Deployment Runbook

> **Audience:** developers updating or re-deploying the ALV-Bricks Databricks App.
> **Scope:** end-to-end steps for first-time setup **and** iterative feature deploys,
> with annotated pitfalls and recovery steps.

---

## Workspace and CLI configuration

| Item | Value |
|---|---|
| Workspace | `https://fevm-classic-stable-lakebase.cloud.databricks.com` |
| CLI profile | `fevm-lakebase` (in `~/.databrickscfg`) |
| App name | `alv-bricks` |
| App URL | `https://alv-bricks-7474646826130163.aws.databricksapps.com` |
| Workspace source path | `/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src` |
| Deploy source root (local) | `src/alv-frontend/backend/` |

Verify auth before any deploy step:

```bash
databricks bundle validate -t dev -p fevm-lakebase
# Expected: "Validation OK!" and user: idris.chakera@databricks.com
```

---

## Overview: two separate deploys

This repo has **two independent deployment targets** that are often both needed:

| Target | Tool | What it does |
|---|---|---|
| **DAB bundle** (`databricks bundle deploy -t dev`) | Databricks Asset Bundles CLI | Deploys job YAMLs, syncs notebooks (`src/alv-backend/`) and specs (`src/report_specs/`, `src/env_parameters/`) to the workspace. Does NOT touch the App. |
| **Databricks App** (`databricks apps deploy alv-bricks`) | Apps CLI | Deploys the FastAPI backend + built React SPA to the App compute. Does NOT touch jobs or notebooks. |

Always run the bundle deploy first when seeder notebooks or job YAMLs have changed.

> **Automated path (preferred):** the App deploy is now a DAB job. After
> `databricks bundle deploy -t dev` (which syncs the App backend as workspace files too),
> run `databricks bundle run alv_deploy_app -t dev` — it creates/reuses the App, starts it,
> deploys the synced source, floors the warehouse auto-stop, and prints the App-SP grants.
> The manual `databricks sync` + `databricks apps deploy` steps in Parts 2–3 below remain
> valid for one-off/hotfix uploads or when deploying from the legacy `alv-frontend-src` path.

---

## Part 1 — DAB bundle deploy

Run this when you change anything in `src/alv-backend/`, `src/report_specs/`, `src/env_parameters/`,
or `resources/*.yml`:

```bash
cd /path/to/repo

# Validate
databricks bundle validate -t dev -p fevm-lakebase

# Deploy (syncs workspace files + updates job/pipeline resources)
databricks bundle deploy -t dev -p fevm-lakebase
```

To run a job after deploying (e.g. seeder):

```bash
databricks bundle run seed_alv_sample_data -t dev -p fevm-lakebase
# Wait for TERMINATED SUCCESS before proceeding
```

### Report visibility — required once (and after any change to the group map)

Report visibility is **deny by default**: until `report_permissions` exists and is
seeded, the App shows **no reports at all**. Run both jobs, in this order:

```bash
# 1. create the table (report_permissions is in PILOT_TABLES — idempotent, safe to re-run)
databricks bundle run provision_alv_metadata -t dev -p fevm-lakebase

# 2. seed the report → group map from src/report_specs/report_permissions.json
databricks bundle run seed_alv_report_permissions -t dev -p fevm-lakebase
```

No new grants are needed: the App only SELECTs the table and the existing schema-level
`SELECT` covers it. The App picks up a re-seed within `PERMISSIONS_MAP_TTL_SECONDS`
(default 300s) — no restart required. Full detail: `docs/APP_PREREQUISITES.md` §6.

> ⚠️ Do **not** add or PATCH the app's `user_api_scopes` — the deployed app's existing
> scopes already make `/Me` work, and a PATCH can silently purge them.

---

## Part 2 — App deploy (iterative)

### Step 1 — build the frontend (only if frontend files changed)

```bash
cd src/alv-frontend/frontend
npm run build --registry=https://npm-proxy.cloud.databricks.com/
# Output: ../backend/static/index.html + ../backend/static/assets/index-<hash>.{js,css}
```

> **Note:** public npm is firewalled on this workspace. Always pass
> `--registry=https://npm-proxy.cloud.databricks.com/` for `npm install`.
> `npm run build` itself does not need the flag.

Commit the built `static/` before deploying — the Apps runtime runs
`uvicorn` only (no build step), so the SPA must be pre-built.

### Step 2 — upload changed files to the workspace

Upload **only the files that changed** using `workspace import --format RAW`. This is
fast, safe, and does not risk polluting the workspace with unwanted directories.

```bash
PROFILE="-p fevm-lakebase"
WS_ROOT="/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src"
REPO="src/alv-frontend/backend"

# --- Python source files ---
databricks workspace import \
  --file "$REPO/alv_app/main.py" --format RAW --overwrite \
  "$WS_ROOT/alv_app/main.py" $PROFILE

# Repeat for each changed file, e.g.:
# databricks workspace import --file "$REPO/alv_app/preview.py" --format RAW --overwrite "$WS_ROOT/alv_app/preview.py" $PROFILE

# --- NEW Python file (first time only — same command, no pre-existing path needed) ---
# The workspace creates the file on first import.
databricks workspace import \
  --file "$REPO/alv_app/new_module.py" --format RAW --overwrite \
  "$WS_ROOT/alv_app/new_module.py" $PROFILE

# --- Static assets (after npm run build) ---
# Always upload all three: index.html + the two hashed asset files.
# Delete OLD hashed assets from workspace before uploading new ones (different hash = different filename).
databricks workspace import \
  --file "$REPO/static/index.html" --format RAW --overwrite \
  "$WS_ROOT/static/index.html" $PROFILE

databricks workspace import \
  --file "$REPO/static/assets/index-<NEW_HASH>.js" --format RAW --overwrite \
  "$WS_ROOT/static/assets/index-<NEW_HASH>.js" $PROFILE

databricks workspace import \
  --file "$REPO/static/assets/index-<NEW_HASH>.css" --format RAW --overwrite \
  "$WS_ROOT/static/assets/index-<NEW_HASH>.css" $PROFILE

# Delete old hashed assets (replace <OLD_HASH> with previous filenames):
databricks workspace delete "$WS_ROOT/static/assets/index-<OLD_HASH>.js" $PROFILE
databricks workspace delete "$WS_ROOT/static/assets/index-<OLD_HASH>.css" $PROFILE
```

> **Tip:** the current hashed filenames are always visible in `src/alv-frontend/backend/static/assets/`.
> Run `ls src/alv-frontend/backend/static/assets/` before and after `npm run build` to see what changed.

### Step 3 — verify the app is running

```bash
databricks apps get alv-bricks -p fevm-lakebase | python3 -c \
  "import sys,json; d=json.load(sys.stdin); print('compute:', d['compute_status']['state'])"
```

- If `compute: ACTIVE` → proceed to Step 4.
- If `compute: STARTING` → wait ~60 s and check again.
- If `compute: STOPPED` → start it first:

```bash
databricks apps start alv-bricks -p fevm-lakebase --no-wait
# Poll until ACTIVE:
watch -n 10 'databricks apps get alv-bricks -p fevm-lakebase | python3 -c \
  "import sys,json; d=json.load(sys.stdin); print(d[\"compute_status\"][\"state\"])"'
```

### Step 4 — deploy

```bash
databricks apps deploy alv-bricks \
  --source-code-path "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
```

Expected output (success):

```json
{
  "status": {
    "message": "App started successfully",
    "state": "SUCCEEDED"
  }
}
```

### Step 5 — confirm the app is running

```bash
databricks apps get alv-bricks -p fevm-lakebase | python3 -c \
  "import sys,json; d=json.load(sys.stdin)
print('compute:', d['compute_status']['state'])
print('app:', d['app_status']['state'], '—', d['app_status']['message'])"
# Expected: compute: ACTIVE | app: RUNNING — App has status: App is running
```

Open the app URL in a browser to do a final smoke-test.

---

## Part 3 — First-time setup (new workspace or fresh clone)

Only needed once per workspace. Skip if the app already exists.

### 3.1 Create the workspace directory

```bash
databricks workspace mkdirs \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
```

### 3.2 Upload all source files

Upload the entire `src/alv-frontend/backend/` tree **excluding** `.venv/`, `__pycache__/`,
`.pytest_cache/`, and `tests/` (the runtime does not need tests).

```bash
PROFILE="-p fevm-lakebase"
WS_ROOT="/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src"

# Root-level files
for f in app.yaml requirements.txt pyproject.toml uv.lock README.md .python-version .env.example; do
  databricks workspace import --file "src/alv-frontend/backend/$f" --format RAW --overwrite "$WS_ROOT/$f" $PROFILE
done

# alv_app/ Python package
databricks workspace mkdirs "$WS_ROOT/alv_app" $PROFILE
for f in src/alv-frontend/backend/alv_app/*.py; do
  databricks workspace import --file "$f" --format RAW --overwrite \
    "$WS_ROOT/alv_app/$(basename $f)" $PROFILE
done

# static/ assets
databricks workspace mkdirs "$WS_ROOT/static/assets" $PROFILE
databricks workspace import --file "src/alv-frontend/backend/static/index.html" \
  --format RAW --overwrite "$WS_ROOT/static/index.html" $PROFILE
for f in src/alv-frontend/backend/static/assets/*; do
  databricks workspace import --file "$f" --format RAW --overwrite \
    "$WS_ROOT/static/assets/$(basename $f)" $PROFILE
done
```

### 3.3 Create the app

```bash
databricks apps create alv-bricks -p fevm-lakebase
```

### 3.4 Deploy

Follow Part 2 Steps 3–5 above.

### 3.5 Apply grants

Follow `docs/APP_PREREQUISITES.md` to grant the App SP access to the SQL warehouse,
catalog tables, and the job it needs to trigger.

---

## ⚠ Common pitfalls and fixes

### Pitfall 1 — `workspace import-dir` uploads `.venv`

**Symptom:** the next `apps deploy` fails immediately with:

```
Error downloading source code. Error: error updating files:
failed to create file python/source_code/.venv/bin/python:
open python/source_code/.venv/bin/python: permission denied
```

**Root cause:** `databricks workspace import-dir` does not respect `.gitignore`. It
uploads the entire local directory tree, including `.venv/` (hundreds of MB, platform
binary `.so` files). The Apps snapshot runtime cannot write those binary files.

**Fix:**

```bash
# 1. Delete .venv from the workspace
databricks workspace delete \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/.venv" \
  --recursive -p fevm-lakebase

# 2. Verify it is gone
databricks workspace list \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
# .venv must NOT appear in the output

# 3. Redeploy
databricks apps deploy alv-bricks \
  --source-code-path "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
```

**Prevention:** **Never use `workspace import-dir` on `src/alv-frontend/backend/`.**
Use `workspace import --format RAW --overwrite` per file (Part 2, Step 2),
or use `databricks sync` which honours `.gitignore`:

```bash
# databricks sync respects .gitignore — safe to run on src/alv-frontend/backend/
databricks sync src/alv-frontend/backend \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase --full
```

> Confirm `.venv` is listed in `src/alv-frontend/backend/.gitignore` (it should be, as it is
> standard uv/venv practice). If it is not, add it now.

---

### Pitfall 2 — App in STOPPED state

**Symptom:**

```
Error: Cannot deploy app alv-bricks as it is not in RUNNING state.
Please start the app first.
```

**Fix:**

```bash
databricks apps start alv-bricks -p fevm-lakebase --no-wait
# Poll until compute_status.state == ACTIVE (usually ~60-90 s)
databricks apps get alv-bricks -p fevm-lakebase | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print(d['compute_status']['state'])"
```

---

### Pitfall 3 — Pending deployment lock

**Symptom:**

```
Error: Cannot deploy app alv-bricks as there is a pending deployment in progress
for less than 20 minutes. Please wait before trying again.
```

**Fix:** wait for the in-progress deployment to finish (check
`databricks apps list-deployments alv-bricks -p fevm-lakebase`), then retry.
If the lock is stale (>20 min), use `--force-lock`:

```bash
databricks apps deploy alv-bricks \
  --source-code-path "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  --force-lock -p fevm-lakebase
```

---

### Pitfall 4 — Stale hashed static assets in browser

**Symptom:** after `npm run build`, the deployed app still shows old UI.

**Root cause:** Vite names bundles with a content hash (e.g.
`index-CxZSiLyV.js`). When the bundle changes, the hash changes. If the old file
remains in the workspace and the new file is not uploaded, `index.html` references
a file that does not exist → blank page or console 404.

**Fix:** after every `npm run build` that produces new asset filenames:

1. Upload `static/index.html` (updated references).
2. Upload the new `static/assets/index-<NEW>.js` and `static/assets/index-<NEW>.css`.
3. Delete the old `static/assets/index-<OLD>.js` and `static/assets/index-<OLD>.css`
   from the workspace.

```bash
# Find old filenames in the workspace
databricks workspace list \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/static/assets" \
  -p fevm-lakebase

# Delete old files
databricks workspace delete \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/static/assets/index-<OLD>.js" \
  -p fevm-lakebase
databricks workspace delete \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/static/assets/index-<OLD>.css" \
  -p fevm-lakebase
```

---

### Pitfall 5 — App returns 401 from the CLI / curl

**Symptom:** `curl https://alv-bricks-7474646826130163.aws.databricksapps.com/api/health`
returns `401`.

**Root cause:** the app uses Databricks SSO. The platform proxy validates the session
cookie. A raw Bearer token from `databricks auth token` is a Databricks platform API
token, not an Apps SSO session token — it is rejected.

**This is not a deployment error.** The app works correctly in a browser where the
SSO session exists. Use the browser URL to smoke-test after deploy. CLI health-checks
against the deployed app are not supported without an OBO token.

---

### Pitfall 6 — `requirements.txt` out of sync with `pyproject.toml`

**Symptom:** App fails to start with `ModuleNotFoundError` for a newly-added dep.

**Root cause:** Apps installs Python deps from `requirements.txt` (at the source root),
not from `pyproject.toml` or `uv.lock`. Adding a dep to `pyproject.toml` alone is
not enough.

**Fix:** after changing deps in `pyproject.toml` / `uv.lock`:

```bash
cd src/alv-frontend/backend
uv pip compile pyproject.toml -o requirements.txt
# Then upload the updated requirements.txt to the workspace
databricks workspace import \
  --file "requirements.txt" --format RAW --overwrite \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/requirements.txt" \
  -p fevm-lakebase
```

---

## Deployment checklist

Use this checklist for every feature-branch deploy before merging:

```
[ ] uv run pytest -v                          # 82+ tests pass locally
[ ] cd src/alv-frontend/frontend && npm run build          # tsc -b + vite build both clean
[ ] git add src/alv-frontend/backend/static && git commit  # built static assets committed
[ ] databricks bundle validate -t dev         # bundle config valid
[ ] databricks bundle deploy -t dev           # (if notebooks/jobs changed)
[ ] databricks bundle run <seeder> -t dev     # (if sample data changed)
[ ] Upload changed backend files (import --format RAW per file)
[ ] databricks apps get alv-bricks → compute: ACTIVE
[ ] databricks apps deploy alv-bricks --source-code-path ...
[ ] databricks apps get alv-bricks → app: RUNNING
[ ] Browser smoke-test at live URL
[ ] git push origin feat/<branch>
```

---

## Reference: useful CLI commands

```bash
# Check current app state
databricks apps get alv-bricks -p fevm-lakebase

# List recent deployments (latest first)
databricks apps list-deployments alv-bricks -p fevm-lakebase

# Get details of a specific deployment (useful for diagnosing failures)
databricks apps get-deployment alv-bricks <deployment_id> -p fevm-lakebase

# Tail app logs (live)
databricks apps logs alv-bricks -p fevm-lakebase

# List workspace source directory
databricks workspace list \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase

# Check if a specific file is present in workspace
databricks workspace get-status \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/alv_app/preview.py" \
  -p fevm-lakebase
```
