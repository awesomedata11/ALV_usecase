# Databricks notebook source
# MAGIC %md
# MAGIC # deploy_app — deploy / update the ALV-Bricks Databricks App
# MAGIC
# MAGIC Publishes the App: create it (or reuse it), turn its compute on, upload the code
# MAGIC from the synced workspace source, floor the SQL warehouse auto-stop, and print the
# MAGIC grants the App's service principal (SP) needs.
# MAGIC
# MAGIC **DAB-only driver, six-ish steps, zero business logic** — the same pattern as the
# MAGIC other `src/alv-backend/*` notebooks. The bundle syncs `src/alv-frontend/backend/**`
# MAGIC as workspace files; this notebook points `w.apps.deploy` at that synced path, so
# MAGIC `databricks bundle deploy -t dev && databricks bundle run alv_deploy_app -t dev`
# MAGIC deploys or updates the App with no manual CLI steps.
# MAGIC
# MAGIC The App is a self-contained FastAPI backend + a pre-built React SPA (Vite emits into
# MAGIC `backend/static`) — the Apps runtime runs `uvicorn` only, **no build step**. Build
# MAGIC the frontend and commit `static/` before deploying (see `docs/APP_DEPLOY_RUNBOOK.md`).
# MAGIC
# MAGIC The App authenticates as its own SP via env vars the Apps runtime injects — no
# MAGIC credentials live in the files. This notebook's own run identity (the deploying user
# MAGIC in dev, the SPN in prod) needs `CAN_MANAGE` on the App to deploy it.

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 1 — Widgets + read params
# MAGIC Standard ALV driver widgets (`env`/`catalog`/`schema`/`bundle_source_path`) plus the
# MAGIC App-specific ones the job passes.

# COMMAND ----------

dbutils.widgets.text("env", "dev")
dbutils.widgets.text("catalog", "")
dbutils.widgets.text("schema", "")
dbutils.widgets.text("bundle_source_path", "")
dbutils.widgets.text("app_name", "alv-bricks")
dbutils.widgets.text("app_source_path", "")
dbutils.widgets.text("warehouse_id", "")
dbutils.widgets.text("volume", "alv_outputs")
dbutils.widgets.text("warehouse_min_autostop_mins", "60")

env = dbutils.widgets.get("env")
catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")
bundle_source_path = dbutils.widgets.get("bundle_source_path")
app_name = dbutils.widgets.get("app_name")
volume = dbutils.widgets.get("volume")
warehouse_id = dbutils.widgets.get("warehouse_id").strip()
min_autostop = int(dbutils.widgets.get("warehouse_min_autostop_mins") or "60")

# The bundle syncs the App backend to <bundle_source_path>/src/alv-frontend/backend.
app_source_path = dbutils.widgets.get("app_source_path").strip()
if not app_source_path:
    app_source_path = f"{bundle_source_path}/src/alv-frontend/backend"

assert catalog and schema, "catalog and schema are required"
print(f"env={env}  app={app_name}  catalog={catalog}  schema={schema}")
print(f"app_source_path={app_source_path}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 2 — Connect to Databricks

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.apps import App, AppDeployment

w = WorkspaceClient()
print(f"Ready to work with app: {app_name}")


def _compute_state(app):
    """compute_status.state — tolerate str vs enum across SDK versions."""
    if not app.compute_status:
        return None
    state = app.compute_status.state
    return getattr(state, "value", state)

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 3 — Create the app (or reuse it)
# MAGIC Safe to re-run — reuses the app if it already exists.

# COMMAND ----------

existing = {a.name: a for a in w.apps.list()}
if app_name in existing:
    app = existing[app_name]
    print(f"App '{app_name}' already exists — reusing it. (compute is: {_compute_state(app)})")
else:
    print(f"Creating app '{app_name}' ... this can take a minute.")
    app = w.apps.create_and_wait(app=App(
        name=app_name,
        description="ALV-Bricks — metadata-driven SAP ALV reporting on Databricks (pilot: Retail Ledger)"))
    print(f"Done. Created app '{app_name}'.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 4 — Turn the app on, then upload its code
# MAGIC **Order matters:** the app's compute must be **ACTIVE before** we upload code.
# MAGIC Deploying to a switched-off app fails.

# COMMAND ----------

if _compute_state(app) != "ACTIVE":
    print(f"Turning the app on (it was: {_compute_state(app)}) ... this can take a minute.")
    w.apps.start_and_wait(name=app_name)
    print("App compute is now ACTIVE.")
else:
    print("App compute is already ACTIVE.")

print(f"\nUploading the app code from: {app_source_path}")
# databricks-sdk changed this API: newer versions take an AppDeployment object,
# older ones take a flat source_code_path kwarg. Try the new form, fall back.
try:
    dep = w.apps.deploy_and_wait(
        app_name=app_name,
        app_deployment=AppDeployment(source_code_path=app_source_path))
except TypeError:
    dep = w.apps.deploy_and_wait(app_name=app_name, source_code_path=app_source_path)
print(f"Deploy finished. Status: {dep.status.state if dep.status else 'unknown'}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 5 — Keep the warehouse awake
# MAGIC An asleep warehouse makes the App's first query fail slowly. Floor the auto-stop at
# MAGIC `warehouse_min_autostop_mins` (default 60). `auto_stop_mins = 0` means "never stop" —
# MAGIC left as-is. Best-effort: a failure here does not fail the deploy.

# COMMAND ----------

if warehouse_id:
    try:
        wh = w.warehouses.get(id=warehouse_id)
        cur = wh.auto_stop_mins or 0
        if cur != 0 and cur < min_autostop:
            w.warehouses.edit(
                id=warehouse_id,
                name=wh.name,
                cluster_size=wh.cluster_size,
                min_num_clusters=wh.min_num_clusters,
                max_num_clusters=wh.max_num_clusters,
                auto_stop_mins=min_autostop,
                warehouse_type=wh.warehouse_type,
                enable_serverless_compute=wh.enable_serverless_compute,
                spot_instance_policy=wh.spot_instance_policy)
            print(f"Warehouse {warehouse_id}: auto_stop_mins {cur} -> {min_autostop}.")
        else:
            print(f"Warehouse {warehouse_id}: auto_stop_mins={cur} — no change needed.")
    except Exception as e:  # noqa: BLE001 — best-effort, never fail the deploy
        print(f"Could not adjust warehouse {warehouse_id} auto-stop ({e}). Skipping.")
else:
    print("No warehouse_id supplied — skipping the auto-stop floor.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 6 — Grants the App SP needs (send to a UC admin)
# MAGIC Prints the real commands with the App's SP + this target's catalog/schema/volume
# MAGIC filled in. **No `system.*` — a Unity Catalog admin / catalog owner can run these; an
# MAGIC account admin is NOT required** (unlike the reference notebook this was adapted from).
# MAGIC Until they are applied the App opens but every query fails and no report can run.
# MAGIC Full reference: `docs/APP_PREREQUISITES.md`.

# COMMAND ----------

app = w.apps.get(name=app_name)
sp = app.service_principal_client_id or app.service_principal_id or "<app-sp-not-found>"

# --- SQL grants (run by a UC admin / catalog owner) ---
sql_lines = [
    "-- Run as a Unity Catalog admin / owner of the catalog + volume (NOT an account admin).",
    f"GRANT USE CATALOG ON CATALOG {catalog} TO `{sp}`;",
    f"GRANT USE SCHEMA  ON SCHEMA  {catalog}.{schema} TO `{sp}`;",
    f"GRANT SELECT      ON SCHEMA  {catalog}.{schema} TO `{sp}`;   -- read alv_catalog / report_permissions / report_templates / request_log",
    f"GRANT MODIFY      ON SCHEMA  {catalog}.{schema} TO `{sp}`;   -- request_log INSERT/UPDATE (submit + status)",
    "",
    "-- Output volume: the report Job writes results, the App proxies downloads/preview.",
    f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume};",
    f"GRANT READ VOLUME, WRITE VOLUME ON VOLUME {catalog}.{schema}.{volume} TO `{sp}`;",
]

# --- Permission-API grants (warehouse + jobs are NOT SQL GRANTs) ---
cli_lines = ["# Run with the Databricks CLI as a workspace admin (permissions API, not SQL):"]
if warehouse_id:
    cli_lines.append(
        f"databricks grants update warehouse {warehouse_id} "
        f"--json '{{\"changes\":[{{\"principal\":\"{sp}\",\"add\":[\"CAN_USE\"]}}]}}'")
else:
    cli_lines.append(
        "databricks grants update warehouse <WAREHOUSE_ID> "
        f"--json '{{\"changes\":[{{\"principal\":\"{sp}\",\"add\":[\"CAN_USE\"]}}]}}'")

# The App triggers each report row's bound job via run-now, so it needs CAN_MANAGE_RUN
# on every bound job. Read the live bindings from alv_catalog (best-effort).
job_ids = []
try:
    rows = spark.sql(
        f"SELECT DISTINCT job_id FROM {catalog}.{schema}.alv_catalog WHERE job_id IS NOT NULL"
    ).collect()
    job_ids = [str(r["job_id"]) for r in rows]
except Exception as e:  # noqa: BLE001
    print(f"(Could not read alv_catalog.job_id bindings: {e})")

cli_lines.append("")
cli_lines.append("# CAN_MANAGE_RUN on every bound report job (so the App SP can run-now):")
if job_ids:
    for jid in job_ids:
        cli_lines.append(
            f"databricks jobs update-permissions {jid} "
            f"--json '{{\"access_control_list\":[{{\"service_principal_name\":\"{sp}\","
            f"\"permission_level\":\"CAN_MANAGE_RUN\"}}]}}'")
else:
    cli_lines.append(
        "# (no bound job_ids found in alv_catalog yet — bind them, then grant CAN_MANAGE_RUN)")
    cli_lines.append(
        f"databricks jobs update-permissions <JOB_ID> "
        f"--json '{{\"access_control_list\":[{{\"service_principal_name\":\"{sp}\","
        f"\"permission_level\":\"CAN_MANAGE_RUN\"}}]}}'")

print(f"The App's service principal is: {sp}\n")
print("----- SQL: copy to a Unity Catalog admin -----\n")
print("\n".join(sql_lines))
print("\n----- CLI: run as a workspace admin -----\n")
print("\n".join(cli_lines))

# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP 7 — Done
# MAGIC Checklist:
# MAGIC - [ ] A UC admin ran the SQL grants (step 6).
# MAGIC - [ ] A workspace admin ran the warehouse + job CLI grants (step 6).
# MAGIC - [ ] `report_permissions` is seeded (`seed_alv_report_permissions`) — else the App
# MAGIC       shows no reports (deny-by-default). See `docs/APP_PREREQUISITES.md` §6.
# MAGIC - [ ] The people who should see the App have `CAN USE` on it.

# COMMAND ----------

print(f"Open the app here: {app.url}")
