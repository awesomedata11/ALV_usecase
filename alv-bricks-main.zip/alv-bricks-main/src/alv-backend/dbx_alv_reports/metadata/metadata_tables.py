"""Single source of truth for the ALV metadata-table contract (DDL).

Covers the pilot metadata layer (tasks 2.1-2.4) plus report visibility:

* :func:`ddl_create_schema`  -- 2.1 provision the schema
* ``alv_catalog``            -- 2.2 catalogue + report->Job binding (14 rows for Retail Ledger)
* ``request_log``            -- 2.4 App-owned run tracking + result cache (D8, D12)
* ``report_permissions``     -- report visibility by principal (group/user; deny by default)
* ``report_templates``       -- per-user saved parameter templates (variants)
* ``auth_map``               -- 2.3 DEFERRED (D19); DDL is provided but NOT created by default

The table shapes follow ``docs/metadata_tables_example.md`` (the newer 14-row /
flat ``input_fields_json`` model), which supersedes ``ALV_App_Task_Breakdown.md``
3.1. Column names/types live here and nowhere else -- treat a rename as a
breaking change (see ``docs/METADATA_TABLE.md``).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, List, Optional

from ..common.utilities.logging import get_log
from ..common.utilities.uc_utils import UnityCatalogUtils

ALV_CATALOG = "alv_catalog"
REQUEST_LOG = "request_log"
REPORT_PERMISSIONS = "report_permissions"
REPORT_TEMPLATES = "report_templates"
AUTH_MAP = "auth_map"


@dataclass(frozen=True)
class Column:
    """One column in a metadata table."""

    name: str
    type: str
    nullable: bool = True
    comment: str = ""

    def to_ddl(self) -> str:
        null = "" if self.nullable else " NOT NULL"
        comment = f" COMMENT '{self.comment.replace(chr(39), chr(39) * 2)}'" if self.comment else ""
        return f"{self.name} {self.type}{null}{comment}"


@dataclass(frozen=True)
class TableDef:
    """A metadata table definition: columns + table constraints + comment."""

    name: str
    comment: str
    columns: List[Column]
    table_constraints: List[str] = field(default_factory=list)

    @property
    def column_names(self) -> List[str]:
        return [c.name for c in self.columns]


# --------------------------------------------------------------------------- #
# Table definitions
# --------------------------------------------------------------------------- #

ALV_CATALOG_TABLE = TableDef(
    name=ALV_CATALOG,
    comment=(
        "Catalogue + report->Job binding. Grain: one row per runnable report "
        "(= per job_id). Retail Ledger = 14 rows. Each row carries its own "
        "complete flat input_fields_json (no shared forms / no inheritance)."
    ),
    columns=[
        Column("alv_id", "STRING", nullable=False,
               comment="PK. Slug of the natural key, e.g. retail_ledger__detail__agent_item."),
        Column("report_key", "STRING", nullable=False,
               comment="e.g. retail_ledger. Denormalized onto every row (flat by design)."),
        Column("report_label", "STRING", comment="e.g. 'Retail Ledger'."),
        Column("selection_id", "STRING", nullable=False, comment="Navigation level 1, e.g. detail."),
        Column("selection_label", "STRING", comment="e.g. 'Detail'."),
        Column("selection_order", "INT", comment="Display order of the selection."),
        Column("report_type_code", "STRING", comment="Navigation level 2, e.g. agent_item. NULL for Closing Balance."),
        Column("report_type_label", "STRING", comment="e.g. 'Agent Item'. NULL for Closing Balance."),
        Column("report_type_order", "INT", comment="Display order of the report radio. NULL for Closing Balance."),
        Column("alv_name", "STRING", comment="Display name, e.g. 'Retail Ledger - Detail - Agent Item'."),
        Column("description", "STRING", comment="Catalogue subtitle."),
        Column("job_id", "BIGINT", comment="The bound customer Job (unique per row). NULL while unbound (placeholder)."),
        Column("job_run_mode", "STRING", comment="run_now (default)."),
        Column("input_fields_json", "STRING", nullable=False,
               comment="This row's own complete flat form: {schema_version, fields[]}."),
        Column("is_active", "BOOLEAN", comment="Hide from catalogue without deletion."),
        Column("created_at", "TIMESTAMP", comment="Audit."),
        Column("updated_at", "TIMESTAMP", comment="Audit."),
    ],
    table_constraints=["CONSTRAINT alv_catalog_pk PRIMARY KEY (alv_id)"],
)

REQUEST_LOG_TABLE = TableDef(
    name=REQUEST_LOG,
    comment=(
        "App-owned run tracking + result cache. Grain: one row per submission. "
        "Written entirely by the App; the customer's Job never touches it. "
        "Cache key = (alv_id, param_hash) (D12, D-IFJ-11)."
    ),
    columns=[
        Column("request_no", "STRING", nullable=False, comment="PK. App-generated id shown to the user."),
        Column("alv_id", "STRING", nullable=False, comment="FK -> alv_catalog.alv_id. Which runnable report."),
        Column("run_id", "BIGINT", comment="Databricks Job run id (status polling)."),
        Column("submitted_by", "STRING",
               comment=("Submitting user, most-human-readable first: email, else "
                        "preferred_username, else the SSO user id. Historical rows "
                        "may mix these forms -- match on all of them.")),
        Column("param_payload_json", "STRING", comment="Canonical JSON of the parameter inputs used."),
        Column("param_hash", "STRING", comment="SHA-256 of the canonical payload (cache key with alv_id)."),
        Column("status", "STRING", comment="QUEUED / RUNNING / COMPLETED / FAILED / EXPIRED."),
        Column("submitted_at", "TIMESTAMP", comment="When the App triggered the run."),
        Column("generated_at", "TIMESTAMP", comment="When the output file was produced (on success)."),
        Column("output_path", "STRING", comment="NAS/ADLS path returned by the Job."),
        Column("row_count", "BIGINT", comment="Optional, if the Job returns it."),
        Column("expires_at", "TIMESTAMP", comment="When the cached file stops being offered (generated_at + TTL)."),
        Column("error_message", "STRING", comment="Populated on failure."),
    ],
    table_constraints=[
        "CONSTRAINT request_log_pk PRIMARY KEY (request_no)",
        "CONSTRAINT request_log_alv_fk FOREIGN KEY (alv_id) REFERENCES {alv_catalog_fqn} (alv_id)",
    ],
)

REPORT_PERMISSIONS_TABLE = TableDef(
    name=REPORT_PERMISSIONS,
    comment=(
        "Report visibility by PRINCIPAL (a workspace group OR an individual user). "
        "Grain: one row per (report_key, principal_type, principal_name). A user sees "
        "a report if ANY grant permits them -- a group grant for a group they are in, "
        "OR a user grant naming their email (OR semantics across all grants). A report "
        "with NO active row here is HIDDEN (deny by default). Gates the whole report -- "
        "its card and every selection / report_type under it -- not individual report "
        "types. Supersedes the deferred row-level auth map (D19) for report visibility."
    ),
    columns=[
        Column("report_key", "STRING", nullable=False,
               comment="FK -> alv_catalog.report_key (report-level, e.g. retail_ledger)."),
        Column("principal_type", "STRING", nullable=False,
               comment="'group' (match against the user's /Me groups) or 'user' (match the caller's email, lower-cased)."),
        Column("principal_name", "STRING", nullable=False,
               comment=("The granted principal. For principal_type='group', a Databricks "
                        "group display name (case-sensitive), e.g. alv-report_ledger_group. "
                        "For principal_type='user', the user's email, stored LOWER-CASED "
                        "and matched case-folded.")),
        Column("is_active", "BOOLEAN", comment="Revoke a grant without deleting the row."),
        Column("granted_at", "TIMESTAMP", comment="Audit."),
        Column("granted_by", "STRING", comment="Audit -- who granted the mapping."),
    ],
    table_constraints=[
        "CONSTRAINT report_permissions_pk PRIMARY KEY (report_key, principal_type, principal_name)",
    ],
)

REPORT_TEMPLATES_TABLE = TableDef(
    name=REPORT_TEMPLATES,
    comment=(
        "Per-user saved parameter templates (variants). Grain: one row per "
        "(owner, alv_id, template_name). A template is a named snapshot of the RAW "
        "form values for ONE runnable report (alv_id), owned by ONE user -- a user "
        "sees only his own templates. param_values_json holds the flat "
        "{param_name: value} form map exactly as submit/preview receive it (NOT the "
        "normalized job payload), so loading a template refills the form faithfully. "
        "value_kinds_json is groundwork for later dynamic (relative date/time) "
        "templates; NULL/absent means all values are static (the pilot behaviour)."
    ),
    columns=[
        Column("template_id", "STRING", nullable=False,
               comment="PK. App-generated id, e.g. TPL-<uuid>."),
        Column("alv_id", "STRING", nullable=False,
               comment="FK -> alv_catalog.alv_id. The runnable report this template fills."),
        Column("owner", "STRING", nullable=False,
               comment=("The owning user's email, stored LOWER-CASED and matched "
                        "case-folded. A user sees only rows where owner = his email.")),
        Column("template_name", "STRING", nullable=False,
               comment="User-given name (display + pick). Unique per (owner, alv_id)."),
        Column("param_values_json", "STRING", nullable=False,
               comment=("The saved RAW form values: the flat {param_name: value} map as "
                        "submit/preview post it (composite ranges carry their own from/to "
                        "keys). NOT the normalized job payload.")),
        Column("value_kinds_json", "STRING",
               comment=("Reserved for later dynamic templates: an optional "
                        "{param_name: 'static'|'dynamic'} map + resolution rule. "
                        "NULL/absent => every value is static (pilot behaviour).")),
        Column("is_active", "BOOLEAN", comment="Soft-delete without removing the row. NULL counts as active."),
        Column("created_at", "TIMESTAMP", comment="Audit -- first save."),
        Column("updated_at", "TIMESTAMP", comment="Audit -- set on each save/edit."),
    ],
    table_constraints=[
        "CONSTRAINT report_templates_pk PRIMARY KEY (template_id)",
        "CONSTRAINT report_templates_alv_fk FOREIGN KEY (alv_id) REFERENCES {alv_catalog_fqn} (alv_id)",
    ],
)

# DEFERRED for the pilot (D19). Retained as the target schema for a later phase;
# NOT created by ensure_all() unless include_auth_map=True. SUPERSEDED for report
# visibility by report_permissions -- its grain was data-row filtering by business
# dimension, which is not what the App gates on.
AUTH_MAP_TABLE = TableDef(
    name=AUTH_MAP,
    comment="DEFERRED (D19). Row-level auth map; unused in the pilot.",
    columns=[
        Column("user_id", "STRING", nullable=False, comment="AAD object ID."),
        Column("plant_code", "STRING", comment="Auth dimension."),
        Column("region_code", "STRING", comment="Auth dimension."),
        Column("additional_dimensions_json", "STRING", comment="Reserved."),
        Column("granted_at", "TIMESTAMP", comment="Audit."),
        Column("granted_by", "STRING", comment="Audit."),
    ],
)

# Tables created by default in the pilot (auth_map is deferred, D19).
PILOT_TABLES: List[TableDef] = [
    ALV_CATALOG_TABLE,
    REQUEST_LOG_TABLE,
    REPORT_PERMISSIONS_TABLE,
    REPORT_TEMPLATES_TABLE,
]


# --------------------------------------------------------------------------- #
# DDL builders (pure functions -- unit-testable with no Spark)
# --------------------------------------------------------------------------- #

def _fqn(catalog: str, schema: str, table: Optional[str] = None) -> str:
    parts = [catalog, schema] + ([table] if table else [])
    return ".".join(f"`{p}`" for p in parts)


def ddl_create_schema(catalog: str, schema: str, comment: str = "ALV metadata layer") -> str:
    """Return CREATE SCHEMA DDL (task 2.1)."""
    return (
        f"CREATE SCHEMA IF NOT EXISTS {_fqn(catalog, schema)} "
        f"COMMENT '{comment.replace(chr(39), chr(39) * 2)}'"
    )


def ddl_create_table(table: TableDef, catalog: str, schema: str) -> str:
    """Return CREATE TABLE DDL for one :class:`TableDef`."""
    lines = [c.to_ddl() for c in table.columns]
    constraints = [
        c.format(alv_catalog_fqn=_fqn(catalog, schema, ALV_CATALOG))
        for c in table.table_constraints
    ]
    body = ",\n  ".join(lines + constraints)
    comment = table.comment.replace("'", "''")
    return (
        f"CREATE TABLE IF NOT EXISTS {_fqn(catalog, schema, table.name)} (\n  "
        f"{body}\n) USING DELTA\nCOMMENT '{comment}'"
    )


def ddl_all(catalog: str, schema: str, include_auth_map: bool = False) -> List[str]:
    """Return the full ordered DDL for the pilot metadata layer (2.1-2.4).

    Args:
        catalog: Target UC catalog.
        schema: Target UC schema.
        include_auth_map: Also emit the deferred ``auth_map`` DDL (D19).

    Returns:
        Ordered list of DDL statements: schema first, then tables. ``alv_catalog``
        precedes ``request_log`` so the FK reference resolves.
    """
    tables = list(PILOT_TABLES)
    if include_auth_map:
        tables.append(AUTH_MAP_TABLE)
    return [ddl_create_schema(catalog, schema)] + [
        ddl_create_table(t, catalog, schema) for t in tables
    ]


# --------------------------------------------------------------------------- #
# Spark-bound orchestrator (used by the provision driver notebook)
# --------------------------------------------------------------------------- #

class MetadataTables:
    """Create/ensure the metadata schema and tables on a live workspace.

    Explicit dependency injection (CLAUDE.md “Class design patterns”): pass ``spark`` and
    an optional ``log``. Pure DDL generation lives in the module-level ``ddl_*``
    functions so it stays unit-testable without Spark.

    >>> mt = MetadataTables(spark, catalog="alv_bricks", schema="metadata")
    >>> mt.ensure_all()          # 2.1 + 2.2 + 2.4
    """

    def __init__(
        self,
        spark: Any,
        catalog: str,
        schema: str,
        log: Optional[logging.Logger] = None,
    ) -> None:
        self.spark = spark
        self.catalog = catalog
        self.schema = schema
        self.log = log or get_log("metadata")
        self.uc = UnityCatalogUtils(spark=spark, log=self.log)

    def ensure_schema(self) -> None:
        """Task 2.1 -- create the metadata schema if absent."""
        self.log.info("ensuring schema %s.%s", self.catalog, self.schema)
        self.uc.run(ddl_create_schema(self.catalog, self.schema))

    def ensure_all(self, include_auth_map: bool = False) -> None:
        """Tasks 2.1-2.4 -- create the schema, then all pilot tables in order."""
        for stmt in ddl_all(self.catalog, self.schema, include_auth_map=include_auth_map):
            self.uc.run(stmt)
        self.log.info(
            "ensured metadata tables in %s.%s (auth_map=%s)",
            self.catalog, self.schema, include_auth_map,
        )
