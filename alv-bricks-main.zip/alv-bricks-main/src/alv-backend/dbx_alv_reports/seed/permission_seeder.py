"""Seed ``report_permissions`` from a permissions manifest (report visibility).

Mirrors :mod:`dbx_alv_reports.seed.report_seeder`: the authoring source is a JSON
manifest (``report_specs/report_permissions.json``) listing one entry per
(``report_key``, ``principal_type``, ``principal_name``); the seeder validates it and
upserts via ``MERGE INTO`` so re-seeding is idempotent.

A grant names a **principal** -- a workspace ``group`` OR an individual ``user`` (by
email). Grain is one row per (report_key, principal_type, principal_name); several
grants per report are allowed and mean OR (a user sees the report if ANY grant permits
them). A report with no row is HIDDEN by the App (deny by default), so this manifest is
the bootstrap that makes a report visible -- after setup, the admin console owns grants.

This seeder is the ONE-TIME bootstrap. It accepts the legacy ``group_name`` key on an
entry (treated as ``principal_type='group'``, ``principal_name=<group_name>``) so an
older manifest still seeds; new manifests use the explicit ``principal_type`` /
``principal_name`` pair. ``user`` emails are stored LOWER-CASED (matched case-folded).

Pure row-derivation (:meth:`PermissionSeeder.build_rows`) is unit-testable with no
Spark; the ``MERGE`` runs on a live workspace via :meth:`PermissionSeeder.seed`.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..common.utilities.logging import get_log
from ..metadata.metadata_tables import REPORT_PERMISSIONS

# Column order used for the MERGE source view (granted_at is set in SQL).
_SEED_COLUMNS = ["report_key", "principal_type", "principal_name", "is_active", "granted_by"]

# The two principal kinds a grant may name.
_PRINCIPAL_TYPES = ("group", "user")

# report_key mirrors alv_catalog's slug shape; principal_name is a Databricks group
# display name or a user email (both permissive -- validated only for non-blankness).
_REPORT_KEY_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]*$")


def _normalize_entry(row: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *row* with the legacy ``group_name`` folded into the pair.

    ``{"group_name": "g"}`` becomes ``{"principal_type": "group", "principal_name": "g"}``.
    An entry that already carries ``principal_type`` / ``principal_name`` is returned as
    is. This keeps an older manifest seedable without a rewrite.
    """
    if "group_name" in row and "principal_name" not in row:
        out = {k: v for k, v in row.items() if k != "group_name"}
        out.setdefault("principal_type", "group")
        out["principal_name"] = row["group_name"]
        return out
    return dict(row)


class PermissionSeeder:
    """Validate a permissions manifest and upsert its rows into ``report_permissions``."""

    def __init__(
        self,
        spark: Any,
        catalog: str,
        schema: str,
        log: Optional[logging.Logger] = None,
    ) -> None:
        self.spark = spark
        self.catalog = catalog
        self.schema = schema
        self.log = log or get_log("seed")

    # -- pure helpers (no Spark) -------------------------------------------
    @staticmethod
    def load_manifest(path: str) -> Dict[str, Any]:
        with Path(path).open(encoding="utf-8") as fh:
            return json.load(fh)

    @staticmethod
    def validate_manifest(manifest: Dict[str, Any]) -> Tuple[List[str], List[str]]:
        """Validate the manifest shape and every permission entry.

        Returns ``(errors, warnings)`` accumulated across all entries (collect-all,
        never fail on the first -- CLAUDE.md "Configuration: JSON → validated object").
        """
        errors: List[str] = []
        warnings: List[str] = []
        rows = manifest.get("report_permissions")
        if not isinstance(rows, list) or not rows:
            return (["manifest: 'report_permissions' must be a non-empty array."], warnings)

        seen: Dict[Tuple[str, str, str], int] = {}
        for i, raw in enumerate(rows):
            src = f"report_permissions[{i}]"
            if not isinstance(raw, dict):
                errors.append(f"{src}: must be an object.")
                continue
            row = _normalize_entry(raw)
            report_key = row.get("report_key")
            principal_type = row.get("principal_type")
            principal_name = row.get("principal_name")
            if not report_key or not isinstance(report_key, str):
                errors.append(f"{src}: requires a non-empty string 'report_key'.")
            elif not _REPORT_KEY_RE.match(report_key):
                errors.append(
                    f"{src}: report_key {report_key!r} is not a valid slug "
                    f"(allowed: ^[A-Za-z0-9_][A-Za-z0-9_.-]*$)."
                )
            if principal_type not in _PRINCIPAL_TYPES:
                errors.append(
                    f"{src}: requires 'principal_type' in {_PRINCIPAL_TYPES!r} "
                    f"(or the legacy 'group_name'); got {principal_type!r}."
                )
            if not principal_name or not isinstance(principal_name, str):
                errors.append(f"{src}: requires a non-empty string 'principal_name' (or 'group_name').")
            elif principal_name != principal_name.strip():
                errors.append(f"{src}: principal_name {principal_name!r} has leading/trailing whitespace.")
            elif principal_type == "user" and "@" not in principal_name:
                warnings.append(
                    f"{src}: principal_type='user' but principal_name {principal_name!r} "
                    f"has no '@' -- a user grant is matched against the caller's email."
                )
            if (
                isinstance(report_key, str)
                and principal_type in _PRINCIPAL_TYPES
                and isinstance(principal_name, str)
            ):
                # User emails are matched case-folded, so dedupe them case-folded too.
                norm_name = principal_name.lower() if principal_type == "user" else principal_name
                key = (report_key, principal_type, norm_name)
                if key in seen:
                    errors.append(
                        f"{src}: duplicate (report_key, principal_type, principal_name) "
                        f"{key!r} (also report_permissions[{seen[key]}])."
                    )
                else:
                    seen[key] = i
            if row.get("is_active") is False:
                warnings.append(
                    f"{src}: is_active=false -- {report_key!r} will NOT be visible to "
                    f"{principal_name!r} through this grant."
                )
        return errors, warnings

    @classmethod
    def build_rows(cls, manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate a manifest and derive seed rows.

        Raises:
            ValueError: if the manifest fails validation (fail-loud -- config error).
        """
        errors, _ = cls.validate_manifest(manifest)
        if errors:
            raise ValueError("manifest is invalid:\n- " + "\n- ".join(errors))
        return cls.derive_rows(manifest)

    @classmethod
    def derive_rows(cls, manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Derive seed rows from an **already-validated** manifest (no re-validation).

        ``granted_by`` falls back to the manifest-level ``granted_by`` (so a manifest
        can declare it once) and then to ``None``.
        """
        default_granted_by = manifest.get("granted_by")
        rows: List[Dict[str, Any]] = []
        for raw in manifest["report_permissions"]:
            row = _normalize_entry(raw)
            principal_type = row["principal_type"]
            principal_name = row["principal_name"]
            # Store user emails lower-cased so the gate can match case-folded.
            if principal_type == "user":
                principal_name = principal_name.lower()
            rows.append(
                {
                    "report_key": row["report_key"],
                    "principal_type": principal_type,
                    "principal_name": principal_name,
                    "is_active": bool(row.get("is_active", True)),
                    "granted_by": row.get("granted_by", default_granted_by),
                }
            )
        return rows

    # -- Spark path ---------------------------------------------------------
    def seed(self, manifest_path: str) -> Optional[Dict[str, Any]]:
        """Validate + upsert rows into ``report_permissions``. Returns None on success.

        Uses ``MERGE INTO`` keyed on (``report_key``, ``principal_type``,
        ``principal_name``) so re-seeding is idempotent: existing grants are updated,
        new grants inserted, ``granted_at`` set only on insert.

        Note this seeder only ever ADDS or UPDATES the grants the manifest names -- it
        never deletes a grant that has dropped out of the manifest. To revoke, either
        set ``is_active: false`` on the entry (and re-seed) or DELETE the row.
        """
        from pyspark.sql.types import (  # local import: keep the module Spark-free
            BooleanType,
            StringType,
            StructField,
            StructType,
        )

        manifest = self.load_manifest(manifest_path)
        errors, warnings = self.validate_manifest(manifest)
        for w in warnings:
            self.log.warning(w)
        if errors:
            from ..common.utilities.err_utils import get_exception

            for e in errors:
                self.log.error(e)
            return get_exception(
                "PERMISSION_SEED_VALIDATION_FAILED",
                f"{len(errors)} validation error(s) in {manifest_path}",
                error_at="PermissionSeeder.seed",
            )

        rows = self.derive_rows(manifest)  # already validated above

        schema = StructType(
            [
                StructField("report_key", StringType(), False),
                StructField("principal_type", StringType(), False),
                StructField("principal_name", StringType(), False),
                StructField("is_active", BooleanType(), True),
                StructField("granted_by", StringType(), True),
            ]
        )
        df = self.spark.createDataFrame(
            [tuple(r[c] for c in _SEED_COLUMNS) for r in rows], schema
        )
        src_view = "_report_permissions_seed_src"
        df.createOrReplaceTempView(src_view)

        target = f"`{self.catalog}`.`{self.schema}`.`{REPORT_PERMISSIONS}`"
        key_cols = ("report_key", "principal_type", "principal_name")
        on_clause = " AND ".join(f"t.{c} = s.{c}" for c in key_cols)
        set_cols = ",\n    ".join(f"t.{c} = s.{c}" for c in _SEED_COLUMNS if c not in key_cols)
        insert_cols = ", ".join(_SEED_COLUMNS) + ", granted_at"
        insert_vals = ", ".join(f"s.{c}" for c in _SEED_COLUMNS) + ", current_timestamp()"
        merge = (
            f"MERGE INTO {target} t\n"
            f"USING {src_view} s ON {on_clause}\n"
            f"WHEN MATCHED THEN UPDATE SET\n    {set_cols}\n"
            f"WHEN NOT MATCHED THEN INSERT ({insert_cols})\n    VALUES ({insert_vals})"
        )
        self.log.info("seeding %d permission row(s) into %s", len(rows), target)
        self.spark.sql(merge)
        self.log.info("permission seed complete (%d row(s) upserted).", len(rows))
        return None
