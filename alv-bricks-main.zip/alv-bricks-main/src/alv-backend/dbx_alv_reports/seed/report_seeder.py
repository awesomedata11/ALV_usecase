"""Seed ``alv_catalog`` from a catalog-rows manifest (task 2.6).

Reads the authoring source (``report_specs/<report>.input_fields.json`` -- the
14 self-contained Retail Ledger rows), validates each row's ``input_fields_json``
against the contract, derives the identity columns (``alv_id`` slug, display
name), and upserts one row per runnable report via ``MERGE INTO``.

Pure row-derivation (:meth:`ReportSeeder.derive_rows` / :meth:`ReportSeeder.build_rows`)
is unit-testable with no Spark; the ``MERGE`` runs on a live workspace via
:meth:`ReportSeeder.seed`.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..common.utilities.logging import get_log
from ..metadata.metadata_tables import ALV_CATALOG
from ..spec_parser.input_fields_parser import InputFieldsParser

# Column order used for the MERGE source view (excludes audit cols, set in SQL).
_SEED_COLUMNS = [
    "alv_id",
    "report_key",
    "report_label",
    "selection_id",
    "selection_label",
    "selection_order",
    "report_type_code",
    "report_type_label",
    "report_type_order",
    "alv_name",
    "description",
    "job_id",
    "job_run_mode",
    "input_fields_json",
    "is_active",
]


def slug_alv_id(report_key: str, selection_id: str, report_type_code: Optional[str]) -> str:
    """Natural-key slug: ``report_key__selection_id[__report_type_code]``."""
    parts = [report_key, selection_id]
    if report_type_code:
        parts.append(report_type_code)
    return "__".join(parts)


def _coerce_job_id(raw: Any, source: str, warnings: List[str]) -> Optional[int]:
    """Return an int job_id, or ``None`` for placeholders/unbound (with a warning)."""
    if raw is None:
        return None
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str) and raw.isdigit():
        return int(raw)
    warnings.append(
        f"{source}: job_id {raw!r} is not numeric (placeholder); seeding NULL (unbound). "
        f"RIL must supply the real job_id (Open items #1, #4)."
    )
    return None


class ReportSeeder:
    """Validate a manifest and upsert its rows into ``alv_catalog``."""

    def __init__(
        self,
        spark: Any,
        catalog: str,
        schema: str,
        log: Optional[logging.Logger] = None,
    ) -> None:
        self.spark = spark
        self.catalog = catalog
        self.schema = schema
        self.log = log or get_log("seed")

    # -- pure helpers (no Spark) -------------------------------------------
    @staticmethod
    def load_manifest(path: str) -> Dict[str, Any]:
        with Path(path).open(encoding="utf-8") as fh:
            return json.load(fh)

    @staticmethod
    def validate_manifest(
        manifest: Dict[str, Any],
    ) -> Tuple[List[str], List[str]]:
        """Validate manifest shape + every embedded ``input_fields_json``.

        Returns ``(errors, warnings)`` accumulated across all rows (collect-all,
        never fail on the first -- CLAUDE.md “Configuration: JSON → validated object”).
        """
        errors: List[str] = []
        warnings: List[str] = []
        rows = manifest.get("catalog_rows")
        if not isinstance(rows, list) or not rows:
            return (["manifest: 'catalog_rows' must be a non-empty array."], warnings)

        seen_alv_ids: Dict[str, int] = {}
        for i, row in enumerate(rows):
            src = f"catalog_rows[{i}]"
            if not isinstance(row, dict):
                errors.append(f"{src}: must be an object.")
                continue
            for req in (
                "report_key",
                "report_label",
                "selection_id",
                "selection_label",
                "selection_order",
                "input_fields_json",
            ):
                if req not in row:
                    errors.append(f"{src}: missing required key {req!r}.")
            rk, sid = row.get("report_key"), row.get("selection_id")
            if rk and sid:
                alv_id = row.get("alv_id") or slug_alv_id(rk, sid, row.get("report_type_code"))
                if alv_id in seen_alv_ids:
                    errors.append(f"{src}: duplicate alv_id {alv_id!r} (also catalog_rows[{seen_alv_ids[alv_id]}]).")
                else:
                    seen_alv_ids[alv_id] = i
            ifj = row.get("input_fields_json")
            if isinstance(ifj, dict):
                parser = InputFieldsParser(ifj, source=f"{src}.input_fields_json")
                parser.validate()
                errors.extend(parser.get_errors())
                warnings.extend(w for w in parser.get_warnings() if "jsonschema not installed" not in w)
            elif ifj is not None:
                errors.append(f"{src}: input_fields_json must be an object.")
        return errors, warnings

    @classmethod
    def build_rows(cls, manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate a manifest and derive seed rows.

        Raises:
            ValueError: if the manifest fails validation (fail-loud -- config error).
        """
        errors, _ = cls.validate_manifest(manifest)
        if errors:
            raise ValueError("manifest is invalid:\n- " + "\n- ".join(errors))
        rows, _ = cls.derive_rows(manifest)
        return rows

    @classmethod
    def derive_rows(cls, manifest: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[str]]:
        """Derive seed rows from an **already-validated** manifest (no re-validation).

        Returns ``(rows, warnings)`` -- warnings cover unbound placeholder job_ids.
        """
        rows: List[Dict[str, Any]] = []
        warnings: List[str] = []
        for row in manifest["catalog_rows"]:
            rk = row["report_key"]
            sid = row["selection_id"]
            rtc = row.get("report_type_code")
            alv_id = row.get("alv_id") or slug_alv_id(rk, sid, rtc)
            name = row.get("alv_name") or " — ".join(
                p for p in (row.get("report_label"), row.get("selection_label"), row.get("report_type_label")) if p
            )
            rows.append(
                {
                    "alv_id": alv_id,
                    "report_key": rk,
                    "report_label": row.get("report_label"),
                    "selection_id": sid,
                    "selection_label": row.get("selection_label"),
                    "selection_order": row.get("selection_order"),
                    "report_type_code": rtc,
                    "report_type_label": row.get("report_type_label"),
                    "report_type_order": row.get("report_type_order"),
                    "alv_name": name,
                    "description": row.get("description"),
                    "job_id": _coerce_job_id(row.get("job_id"), alv_id, warnings),
                    "job_run_mode": row.get("job_run_mode", "run_now"),
                    "input_fields_json": json.dumps(
                        row["input_fields_json"], separators=(",", ":"), ensure_ascii=False
                    ),
                    "is_active": bool(row.get("is_active", True)),
                }
            )
        return rows, warnings

    # -- Spark path ---------------------------------------------------------
    def seed(self, manifest_path: str) -> Optional[Dict[str, Any]]:
        """Validate + upsert rows into ``alv_catalog``. Returns None on success.

        Uses ``MERGE INTO`` keyed on ``alv_id`` so re-seeding is idempotent:
        existing rows are updated, new rows inserted, ``created_at`` set only on
        insert, ``updated_at`` always refreshed.
        """
        from pyspark.sql.types import (  # local import: keep the module Spark-free
            BooleanType,
            IntegerType,
            LongType,
            StringType,
            StructField,
            StructType,
        )

        manifest = self.load_manifest(manifest_path)
        errors, warnings = self.validate_manifest(manifest)
        for w in warnings:
            self.log.warning(w)
        if errors:
            from ..common.utilities.err_utils import get_exception

            for e in errors:
                self.log.error(e)
            return get_exception(
                "SEED_VALIDATION_FAILED",
                f"{len(errors)} validation error(s) in {manifest_path}",
                error_at="ReportSeeder.seed",
            )

        rows, build_warnings = self.derive_rows(manifest)  # already validated above
        for w in build_warnings:
            self.log.warning(w)

        schema = StructType(
            [
                StructField("alv_id", StringType(), False),
                StructField("report_key", StringType(), True),
                StructField("report_label", StringType(), True),
                StructField("selection_id", StringType(), True),
                StructField("selection_label", StringType(), True),
                StructField("selection_order", IntegerType(), True),
                StructField("report_type_code", StringType(), True),
                StructField("report_type_label", StringType(), True),
                StructField("report_type_order", IntegerType(), True),
                StructField("alv_name", StringType(), True),
                StructField("description", StringType(), True),
                StructField("job_id", LongType(), True),
                StructField("job_run_mode", StringType(), True),
                StructField("input_fields_json", StringType(), False),
                StructField("is_active", BooleanType(), True),
            ]
        )
        df = self.spark.createDataFrame([tuple(r[c] for c in _SEED_COLUMNS) for r in rows], schema)
        src_view = "_alv_catalog_seed_src"
        df.createOrReplaceTempView(src_view)

        target = f"`{self.catalog}`.`{self.schema}`.`{ALV_CATALOG}`"
        set_cols = ",\n    ".join(f"t.{c} = s.{c}" for c in _SEED_COLUMNS if c != "alv_id")
        insert_cols = ", ".join(_SEED_COLUMNS) + ", created_at, updated_at"
        insert_vals = ", ".join(f"s.{c}" for c in _SEED_COLUMNS) + ", current_timestamp(), current_timestamp()"
        merge = (
            f"MERGE INTO {target} t\n"
            f"USING {src_view} s ON t.alv_id = s.alv_id\n"
            f"WHEN MATCHED THEN UPDATE SET\n    {set_cols},\n    t.updated_at = current_timestamp()\n"
            f"WHEN NOT MATCHED THEN INSERT ({insert_cols})\n    VALUES ({insert_vals})"
        )
        self.log.info("seeding %d rows into %s", len(rows), target)
        self.spark.sql(merge)
        self.log.info("seed complete (%d rows upserted).", len(rows))
        return None
