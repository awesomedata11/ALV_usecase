"""Loader + validator for ``input_fields_json`` (task 2.5).

Flow (CLAUDE.md “Configuration: JSON → validated object”): JSON blob -> JSON-Schema validation -> normalized
:class:`~dbx_alv_reports.data_objects.input_fields.InputFieldsSpec`.

The parser:

* resolves the schema relative to the package
  (``json_specifications/input_fields.schema.json``);
* **degrades gracefully** if ``jsonschema`` is not importable
  (``JSONSCHEMA_AVAILABLE`` flag) -- an always-on, self-contained semantic pass
  still enforces the contract;
* **collects** errors/warnings rather than throwing on the first one, so an
  author sees every problem in one pass; and
* fails the load on an **unknown validation rule** (never silently skips --
  D-IFJ-10).
"""

from __future__ import annotations

import json
import logging
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..common.utilities.logging import get_log
from ..data_objects.input_fields import (
    COMPOSITE_CONTROLS,
    SCALAR_CONTROLS,
    InputFieldsSpec,
)

try:  # graceful degradation (CLAUDE.md “Configuration: JSON → validated object”)
    import jsonschema  # type: ignore
    from jsonschema import Draft7Validator  # type: ignore

    JSONSCHEMA_AVAILABLE = True
except Exception:  # pragma: no cover
    JSONSCHEMA_AVAILABLE = False

_SCHEMA_PATH = Path(__file__).resolve().parent.parent / "json_specifications" / "input_fields.schema.json"

SUPPORTED_SCHEMA_VERSION = 1
KNOWN_RULES = {
    "from_lte_to",
    "max_span",
    "max_offset_from_today",
    "to_required_if_from",
    "no_filter_when_equal",
    "regex",
    "max_length",
}
_RULE_REQUIRED_PARAMS = {
    "max_span": ["unit", "value"],
    "max_offset_from_today": ["unit", "value"],
    "regex": ["pattern"],
    "max_length": ["value"],
}
_UNITS = {"days", "months", "years"}
_SELECTION_TYPES = {"single", "multi"}

# Which controls each rule may attach to (input_fields_json_design.md 5).
_RULE_ALLOWED_CONTROLS = {
    "from_lte_to": {"date_range", "time_range"},
    "max_span": {"date_range"},
    "max_offset_from_today": {"date", "date_range"},
    "to_required_if_from": {"time_range"},
    "no_filter_when_equal": {"time_range"},
    "regex": {"text"},
    "max_length": {"text"},
}


@lru_cache(maxsize=1)
def load_schema() -> Dict[str, Any]:
    """Load the input_fields JSON Schema shipped as package data (cached)."""
    with _SCHEMA_PATH.open(encoding="utf-8") as fh:
        return json.load(fh)


if JSONSCHEMA_AVAILABLE:

    @lru_cache(maxsize=1)
    def _get_validator() -> "Draft7Validator":
        """Compile the Draft7 validator once and reuse it."""
        return Draft7Validator(load_schema())


class InputFieldsParser:
    """Validate one ``input_fields_json`` blob and parse it into a typed spec.

    >>> parser = InputFieldsParser(blob, source="retail_ledger__detail__agent_item")
    >>> if parser.validate():
    ...     spec = parser.get_spec()
    """

    def __init__(
        self,
        blob: Dict[str, Any],
        source: str = "<inline>",
        log: Optional[logging.Logger] = None,
    ) -> None:
        self.blob = blob
        self.source = source
        self.log = log or get_log("input_fields_parser")
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self._validated = False

    @classmethod
    def from_file(cls, path: str, log: Optional[logging.Logger] = None) -> "InputFieldsParser":
        p = Path(path)
        with p.open(encoding="utf-8") as fh:
            return cls(json.load(fh), source=p.name, log=log)

    # -- public API ---------------------------------------------------------
    def validate(self) -> bool:
        """Run schema + semantic validation. Returns ``True`` iff no errors."""
        self.errors = []
        self.warnings = []
        self._schema_validate()
        self._semantic_validate()
        self._validated = True
        if not JSONSCHEMA_AVAILABLE:
            self.warnings.append(
                "jsonschema not installed; relied on the built-in semantic validator only."
            )
        return not self.errors

    def get_spec(self) -> InputFieldsSpec:
        """Return the parsed :class:`InputFieldsSpec`. Raises if invalid."""
        if not self._validated:
            self.validate()
        if self.errors:
            raise ValueError(
                f"{self.source}: input_fields_json is invalid:\n- " + "\n- ".join(self.errors)
            )
        return InputFieldsSpec.from_dict(self.blob)

    def get_errors(self) -> List[str]:
        return list(self.errors)

    def get_warnings(self) -> List[str]:
        return list(self.warnings)

    def summary(self) -> str:
        return (
            f"{self.source}: {len(self.errors)} error(s), {len(self.warnings)} warning(s) "
            f"[jsonschema={'on' if JSONSCHEMA_AVAILABLE else 'off'}]"
        )

    # -- schema pass --------------------------------------------------------
    def _schema_validate(self) -> None:
        if not JSONSCHEMA_AVAILABLE:
            return
        try:
            validator = _get_validator()
            for err in sorted(validator.iter_errors(self.blob), key=lambda e: list(e.path)):
                loc = "/".join(str(p) for p in err.path) or "<root>"
                self.errors.append(f"schema[{loc}]: {err.message}")
        except Exception as exc:  # pragma: no cover
            self.errors.append(f"schema validation failed to run: {exc!r}")

    # -- semantic pass (always on) -----------------------------------------
    def _semantic_validate(self) -> None:
        blob = self.blob
        if not isinstance(blob, dict):
            self.errors.append("root: input_fields_json must be a JSON object.")
            return
        if blob.get("schema_version") != SUPPORTED_SCHEMA_VERSION:
            self.errors.append(
                f"root: unsupported schema_version {blob.get('schema_version')!r} "
                f"(expected {SUPPORTED_SCHEMA_VERSION}) -- failing fast (D-IFJ-2)."
            )
        fields = blob.get("fields")
        if not isinstance(fields, list) or not fields:
            self.errors.append("root: 'fields' must be a non-empty array.")
            return

        seen_params: Dict[str, int] = {}
        seen_orders: Dict[int, int] = {}
        for idx, f in enumerate(fields):
            self._validate_field(idx, f, seen_params, seen_orders)

    def _validate_field(
        self,
        idx: int,
        f: Any,
        seen_params: Dict[str, int],
        seen_orders: Dict[int, int],
    ) -> None:
        where = f"fields[{idx}]"
        if not isinstance(f, dict):
            self.errors.append(f"{where}: must be an object.")
            return
        control = f.get("control")
        if control in COMPOSITE_CONTROLS:
            self._validate_composite(where, f, seen_params)
        elif control in SCALAR_CONTROLS:
            self._validate_scalar(where, f, seen_params)
        else:
            self.errors.append(
                f"{where}: unknown control {control!r} "
                f"(expected one of {sorted(SCALAR_CONTROLS | COMPOSITE_CONTROLS)})."
            )

        order = f.get("display_order")
        if isinstance(order, int):
            if order in seen_orders:
                self.warnings.append(
                    f"{where}: duplicate display_order {order} (also fields[{seen_orders[order]}])."
                )
            else:
                seen_orders[order] = idx

        for vi, rule in enumerate(f.get("validations", []) or []):
            self._validate_rule(f"{where}.validations[{vi}]", rule, control)

    def _validate_scalar(self, where: str, f: Dict[str, Any], seen_params: Dict[str, int]) -> None:
        pname = f.get("param_name")
        if not isinstance(pname, str) or not pname:
            self.errors.append(f"{where}: scalar field requires a non-empty param_name.")
        else:
            self._register_param(where, pname, seen_params)
        st = f.get("selection_type")
        if st not in _SELECTION_TYPES:
            self.errors.append(f"{where}: selection_type must be one of {sorted(_SELECTION_TYPES)}, got {st!r}.")
        if f.get("control") == "text" and f.get("data_type") != "string":
            self.errors.append(f"{where}: text control must have data_type 'string'.")
        if f.get("control") == "date" and f.get("data_type") != "date":
            self.errors.append(f"{where}: date control must have data_type 'date'.")

    def _validate_composite(self, where: str, f: Dict[str, Any], seen_params: Dict[str, int]) -> None:
        parts = f.get("parts")
        if not isinstance(parts, dict) or "from" not in parts or "to" not in parts:
            self.errors.append(f"{where}: composite control requires parts with 'from' and 'to'.")
            return
        for side in ("from", "to"):
            part = parts.get(side)
            if not isinstance(part, dict) or not part.get("param_name"):
                self.errors.append(f"{where}.parts.{side}: requires a non-empty param_name.")
            else:
                self._register_param(f"{where}.parts.{side}", part["param_name"], seen_params)
        control, dtype = f.get("control"), f.get("data_type")
        if control == "date_range" and dtype != "date":
            self.errors.append(f"{where}: date_range must have data_type 'date'.")
        if control == "time_range" and dtype != "time":
            self.errors.append(f"{where}: time_range must have data_type 'time'.")

    def _register_param(self, where: str, pname: str, seen_params: Dict[str, int]) -> None:
        if pname in seen_params:
            self.errors.append(
                f"{where}: duplicate param_name {pname!r} within the row (must be unique -- D6)."
            )
        else:
            seen_params[pname] = 1

    def _validate_rule(self, where: str, rule: Any, control: Any = None) -> None:
        if not isinstance(rule, dict):
            self.errors.append(f"{where}: validation must be an object.")
            return
        name = rule.get("rule")
        if name not in KNOWN_RULES:
            # D-IFJ-10: unknown rule => fail the load, never silently skip.
            self.errors.append(
                f"{where}: unknown validation rule {name!r} (known: {sorted(KNOWN_RULES)})."
            )
            return
        allowed = _RULE_ALLOWED_CONTROLS.get(name, set())
        if control is not None and allowed and control not in allowed:
            self.errors.append(
                f"{where}: rule {name!r} does not apply to control {control!r} "
                f"(allowed: {sorted(allowed)})."
            )
        if not rule.get("message_key"):
            self.errors.append(f"{where}: rule {name!r} requires a message_key (D-IFJ-9).")
        for req in _RULE_REQUIRED_PARAMS.get(name, []):
            if req not in rule:
                self.errors.append(f"{where}: rule {name!r} requires param {req!r}.")
        if "unit" in rule and rule["unit"] not in _UNITS:
            self.errors.append(f"{where}: unit must be one of {sorted(_UNITS)}, got {rule['unit']!r}.")


def validate_input_fields(
    blob: Dict[str, Any], source: str = "<inline>"
) -> Tuple[bool, List[str], List[str]]:
    """Convenience one-shot: returns ``(ok, errors, warnings)``."""
    p = InputFieldsParser(blob, source=source)
    ok = p.validate()
    return ok, p.get_errors(), p.get_warnings()
