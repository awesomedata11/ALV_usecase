"""dbx_alv_reports -- ALV report metadata framework (metadata layer).

Public API for the pilot metadata layer (tasks 2.1-2.6). Everything else is
internal. See ``CLAUDE.md`` and ``docs/METADATA_TABLE.md``.
"""

from __future__ import annotations

from importlib import metadata as _metadata
from pathlib import Path

from .common.utilities.output_path import (
    DATE_FORMAT,
    build_output_dir,
    expired_date_dirs,
    parse_date_dir,
)
from .data_objects.input_fields import Field, InputFieldsSpec, ValidationRule
from .metadata.metadata_tables import (
    ALV_CATALOG_TABLE,
    AUTH_MAP_TABLE,
    REPORT_PERMISSIONS_TABLE,
    REPORT_TEMPLATES_TABLE,
    REQUEST_LOG_TABLE,
    MetadataTables,
    ddl_all,
    ddl_create_schema,
    ddl_create_table,
)
from .sample_query import (
    BoundArgs,
    SampleQuerySpec,
    SampleReportSqlError,
    build_exit_pointer,
    build_sample_report_sql,
    parse_sample_query,
)
from .seed.permission_seeder import PermissionSeeder
from .seed.report_seeder import ReportSeeder, slug_alv_id
from .spec_parser.input_fields_parser import (
    InputFieldsParser,
    load_schema,
    validate_input_fields,
)


def _read_version() -> str:
    try:
        return _metadata.version("dbx-alv-reports")
    except Exception:
        version_file = Path(__file__).resolve().parent / "VERSION"
        if version_file.exists():
            return version_file.read_text(encoding="utf-8").strip()
        return "0.0.0"


__version__ = _read_version()

__all__ = [
    "__version__",
    # metadata tables
    "MetadataTables",
    "ddl_all",
    "ddl_create_schema",
    "ddl_create_table",
    "ALV_CATALOG_TABLE",
    "REQUEST_LOG_TABLE",
    "REPORT_PERMISSIONS_TABLE",
    "REPORT_TEMPLATES_TABLE",
    "AUTH_MAP_TABLE",
    # input_fields parsing
    "InputFieldsParser",
    "InputFieldsSpec",
    "Field",
    "ValidationRule",
    "validate_input_fields",
    "load_schema",
    # seeding
    "ReportSeeder",
    "slug_alv_id",
    "PermissionSeeder",
    # sample-report download (sample_query → parameterized SELECT + exit pointer)
    "SampleQuerySpec",
    "BoundArgs",
    "SampleReportSqlError",
    "parse_sample_query",
    "build_sample_report_sql",
    "build_exit_pointer",
    # structured output paths (per-run subfolder layout) + retention cleanup
    "build_output_dir",
    "expired_date_dirs",
    "parse_date_dir",
    "DATE_FORMAT",
]
