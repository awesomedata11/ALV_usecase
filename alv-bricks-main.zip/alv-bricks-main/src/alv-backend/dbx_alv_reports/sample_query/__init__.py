"""Sample-query download helpers (Spark-free, pure SQL/pointer builders).

The ``alv_sample_report_run`` driver notebook uses these to turn a report row's
``sample_query`` block into a **parameterized** SELECT against
``retail_ledger_sample`` and to shape the ``dbutils.notebook.exit`` output pointer.

Kept deliberately Spark-free so the WHERE/SQL building and pointer-shaping can be
unit-tested with no cluster — only the notebook itself touches ``spark``. The SQL
semantics mirror the App's ``preview.build_preview_sql`` so a download filters the
same rows the user previewed (operators ``>=`` / ``<=`` / ``IN``, blank-skip, bound
parameters — user values are never interpolated into the SQL text).
"""

from __future__ import annotations

from .sample_report_query import (
    BoundArgs,
    ColumnDef,
    ParamMapping,
    SampleQuerySpec,
    SampleReportSqlError,
    build_exit_pointer,
    build_sample_report_sql,
    parse_sample_query,
)

__all__ = [
    "BoundArgs",
    "ColumnDef",
    "ParamMapping",
    "SampleQuerySpec",
    "SampleReportSqlError",
    "build_exit_pointer",
    "build_sample_report_sql",
    "parse_sample_query",
]
