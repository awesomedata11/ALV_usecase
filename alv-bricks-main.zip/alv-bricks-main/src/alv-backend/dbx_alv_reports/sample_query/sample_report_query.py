"""Pure builders for the sample-report download SELECT + exit pointer.

This module is **Spark-free**: it turns a report row's ``sample_query`` block plus
the user's form values into a parameterized SQL string, a bound-argument mapping,
and the ``dbutils.notebook.exit`` pointer JSON — all as pure functions so they can
be unit-tested with no cluster. The ``alv_sample_report_run`` notebook is the only
place that imports ``spark`` and calls ``spark.sql(sql, args=args)``.

The SQL semantics deliberately mirror the App's ``preview.build_preview_sql`` so a
**download filters the exact rows a user previewed** (D6 param contract):

* operators ``>=`` / ``<=`` / ``=`` bind a single value; ``IN`` comma-splits;
* blank / whitespace-only form values are skipped (no condition);
* column names are validated against a strict identifier allowlist and
  backtick-quoted — never taken raw from the request;
* user **values** are NEVER interpolated into the SQL text — they are emitted as
  ``:name`` bind markers and returned as an args mapping, so quotes / semicolons in
  a value can never change the query shape.

Unlike the preview (capped at 500 rows), a download returns the **full** filtered
result; a large, configurable safety ceiling (:data:`DEFAULT_MAX_ROWS`) guards
against a pathological unfiltered scan and can be raised/removed by the caller.
"""

from __future__ import annotations

import datetime
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# Operators supported in a sample_query param mapping (mirrors preview.VALID_OPERATORS).
VALID_OPERATORS = {"=", ">=", "<=", "IN"}

# Strict SQL identifier allowlist for every column_name (defence in depth: the spec
# is trusted config, but a download is data-exposing so we validate it anyway).
_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Cap the elements a single IN (...) filter may expand to, so a user cannot force an
# unbounded parameter list by pasting thousands of comma-values (mirrors preview).
_MAX_IN_ELEMENTS = 200

# Safety ceiling on returned rows for a download. Large (a download is meant to
# return the full filtered result) but bounded so an unfiltered request can't scan
# without limit; callers may raise it or pass ``None`` to remove it entirely.
DEFAULT_MAX_ROWS = 1_000_000

# The shared sample table the App's SP reads (same table the preview queries).
SAMPLE_TABLE = "retail_ledger_sample"


class SampleReportSqlError(ValueError):
    """Raised for a malformed ``sample_query`` block or an over-large IN filter."""


@dataclass
class ColumnDef:
    """A column to include in the download SELECT list.

    Attributes:
        display_name: Human-readable header reused for the CSV column header.
        column_name: Actual column name in ``retail_ledger_sample``.
    """

    display_name: str
    column_name: str


@dataclass
class ParamMapping:
    """Maps a form ``param_name`` to a WHERE-clause condition.

    Attributes:
        param_name: Key of the value in the submitted form-values dict.
        column_name: ``retail_ledger_sample`` column to filter on.
        operator: SQL comparison operator; one of ``=``, ``>=``, ``<=``, ``IN``.
    """

    param_name: str
    column_name: str
    operator: str


@dataclass
class SampleQuerySpec:
    """Parsed, validated representation of a ``sample_query`` block.

    Attributes:
        columns: Ordered columns to SELECT (drives the projection + CSV header).
        param_mappings: Ordered WHERE-clause bindings.
        default_limit: The preview's row cap; ignored by the download builder (a
            download returns the full result up to :data:`DEFAULT_MAX_ROWS`).
    """

    columns: List[ColumnDef]
    param_mappings: List[ParamMapping]
    default_limit: int = 100


@dataclass
class BoundArgs:
    """The result of building a download query.

    Attributes:
        sql: Parameterized SQL text with ``:name`` markers (no user values inline).
        args: ``{marker_name: value}`` mapping to pass as ``spark.sql(sql, args=...)``.
        column_names: The projected column names, in spec order.
        display_names: The projected display names, in spec order (CSV header).
    """

    sql: str
    args: Dict[str, str]
    column_names: List[str] = field(default_factory=list)
    display_names: List[str] = field(default_factory=list)


def _require_identifier(name: str, where: str) -> None:
    """Raise :class:`SampleReportSqlError` unless *name* is a strict SQL identifier.

    Args:
        name: The candidate column name to validate.
        where: Location label for the error message.

    Raises:
        SampleReportSqlError: If *name* does not match ``^[A-Za-z_][A-Za-z0-9_]*$``.
    """
    if not _IDENTIFIER_RE.match(name or ""):
        raise SampleReportSqlError(
            f"{where}: {name!r} is not a valid SQL identifier "
            "(allowed: ^[A-Za-z_][A-Za-z0-9_]*$)."
        )


def parse_sample_query(blob: object) -> Optional[SampleQuerySpec]:
    """Parse a raw ``sample_query`` dict into a :class:`SampleQuerySpec`.

    Mirrors the App's ``preview.parse_sample_query`` contract so the download reads
    the same block the preview does.

    Args:
        blob: The value of ``input_fields_json["sample_query"]``, or ``None`` when
            the block is absent (the report has no sample query).

    Returns:
        A fully-validated :class:`SampleQuerySpec`, or ``None`` when *blob* is
        ``None``.

    Raises:
        SampleReportSqlError: If *blob* is present but violates the contract:
            missing/empty ``columns`` or ``param_mappings``, an unsupported
            operator, or a ``column_name`` that is not a strict SQL identifier.
    """
    if blob is None:
        return None
    if not isinstance(blob, dict):
        raise SampleReportSqlError("sample_query must be a JSON object.")

    raw_cols = blob.get("columns")
    if not isinstance(raw_cols, list) or not raw_cols:
        raise SampleReportSqlError("sample_query.columns must be a non-empty array.")
    columns: List[ColumnDef] = []
    for i, c in enumerate(raw_cols):
        if not isinstance(c, dict):
            raise SampleReportSqlError(f"sample_query.columns[{i}]: must be an object.")
        display_name = c.get("display_name")
        column_name = c.get("column_name")
        if not display_name or not isinstance(display_name, str):
            raise SampleReportSqlError(
                f"sample_query.columns[{i}]: requires a non-empty display_name."
            )
        if not column_name or not isinstance(column_name, str):
            raise SampleReportSqlError(
                f"sample_query.columns[{i}]: requires a non-empty column_name."
            )
        _require_identifier(column_name, f"sample_query.columns[{i}].column_name")
        columns.append(ColumnDef(display_name=display_name, column_name=column_name))

    raw_mappings = blob.get("param_mappings")
    if not isinstance(raw_mappings, list) or not raw_mappings:
        raise SampleReportSqlError("sample_query.param_mappings must be a non-empty array.")
    param_mappings: List[ParamMapping] = []
    for i, m in enumerate(raw_mappings):
        if not isinstance(m, dict):
            raise SampleReportSqlError(
                f"sample_query.param_mappings[{i}]: must be an object."
            )
        param_name = m.get("param_name")
        column_name = m.get("column_name")
        operator = m.get("operator")
        if not param_name or not isinstance(param_name, str):
            raise SampleReportSqlError(
                f"sample_query.param_mappings[{i}]: requires a non-empty param_name."
            )
        if not column_name or not isinstance(column_name, str):
            raise SampleReportSqlError(
                f"sample_query.param_mappings[{i}]: requires a non-empty column_name."
            )
        _require_identifier(column_name, f"sample_query.param_mappings[{i}].column_name")
        if operator not in VALID_OPERATORS:
            raise SampleReportSqlError(
                f"sample_query.param_mappings[{i}]: unsupported operator {operator!r} "
                f"(valid: {sorted(VALID_OPERATORS)})."
            )
        param_mappings.append(
            ParamMapping(param_name=param_name, column_name=column_name, operator=operator)
        )

    default_limit = blob.get("default_limit", 100)
    try:
        default_limit = int(default_limit)
    except (TypeError, ValueError):
        default_limit = 100

    return SampleQuerySpec(
        columns=columns, param_mappings=param_mappings, default_limit=default_limit
    )


def build_sample_report_sql(
    spec: SampleQuerySpec,
    values: Dict[str, str],
    catalog: str,
    schema: str,
    *,
    max_rows: Optional[int] = DEFAULT_MAX_ROWS,
    table: str = SAMPLE_TABLE,
) -> BoundArgs:
    """Build a **parameterized** SELECT for the download (mirrors ``build_preview_sql``).

    User values are NEVER interpolated into the SQL text — they are emitted as
    ``:name`` bind markers and returned in :attr:`BoundArgs.args`, suitable for
    ``spark.sql(sql, args=args)``. Only trusted, identifier-validated column names
    and the hardcoded table are placed inline (backtick-quoted).

    Args:
        spec: The validated :class:`SampleQuerySpec` for the report row.
        values: Raw form values keyed by ``param_name``; blank / whitespace-only
            values are skipped (no condition) and unknown keys are ignored.
        catalog: Unity Catalog catalog (e.g. ``classic_stable_lakebase_catalog``).
        schema: Unity Catalog schema (e.g. ``alv_metadata``).
        max_rows: Safety ceiling appended as ``LIMIT``; ``None`` removes the limit
            entirely (the full filtered result). Defaults to :data:`DEFAULT_MAX_ROWS`
            — much larger than the preview's 500-row cap, which is NOT applied here.
        table: The sample table name (defaults to :data:`SAMPLE_TABLE`).

    Returns:
        A :class:`BoundArgs` with the SQL, the args mapping, and the projected
        column / display names (spec order).

    Raises:
        SampleReportSqlError: If an ``IN`` filter expands to more than
            ``_MAX_IN_ELEMENTS`` elements (an explosion guard mirroring preview).
    """
    col_names = [col.column_name for col in spec.columns]
    display_names = [col.display_name for col in spec.columns]
    select_clause = ", ".join(f"`{c}`" for c in col_names)
    fqtn = f"`{catalog}`.`{schema}`.`{table}`"

    conditions: List[str] = []
    args: Dict[str, str] = {}
    pidx = 0  # monotonic index → unique bind names across all conditions
    for pm in spec.param_mappings:
        val = values.get(pm.param_name, "")
        if not isinstance(val, str) or val.strip() == "":
            continue

        col = f"`{pm.column_name}`"
        if pm.operator in (">=", "<=", "="):
            marker = f"p{pidx}"
            pidx += 1
            conditions.append(f"{col} {pm.operator} :{marker}")
            args[marker] = val
        elif pm.operator == "IN":
            parts = [p.strip() for p in val.split(",")]
            parts = [p for p in parts if p]
            if not parts:
                continue
            if len(parts) > _MAX_IN_ELEMENTS:
                raise SampleReportSqlError(
                    f"sample_query IN filter for {pm.param_name!r} has {len(parts)} "
                    f"elements (max {_MAX_IN_ELEMENTS})."
                )
            markers: List[str] = []
            for elem in parts:
                marker = f"p{pidx}"
                pidx += 1
                markers.append(f":{marker}")
                args[marker] = elem
            conditions.append(f"{col} IN ({','.join(markers)})")

    sql = f"SELECT {select_clause} FROM {fqtn}"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    if max_rows is not None and max_rows > 0:
        sql += f" LIMIT {int(max_rows)}"

    return BoundArgs(
        sql=sql, args=args, column_names=col_names, display_names=display_names
    )


def build_exit_pointer(
    *,
    status: str,
    request_no: str,
    output_path: str,
    run_id: str,
    row_count: int,
    generated_at: Optional[str] = None,
) -> Dict[str, Any]:
    """Shape the ``dbutils.notebook.exit`` output pointer (CONTRACT mechanism (a)).

    Matches the frozen pointer the App parses in the 8.x/9.x status seam
    (``databricks_client.get_run_output``): ``output_path`` (a ``/Volumes/...``
    path), ``row_count``, ``generated_at``, plus ``status`` / ``request_no`` /
    ``run_id`` for correlation — identical to the dummy job's payload.

    Args:
        status: Terminal status the App reads (e.g. ``COMPLETED``).
        request_no: The App request id, echoed back for correlation.
        output_path: The ``/Volumes/<catalog>/<schema>/<volume>/...`` CSV path.
        run_id: The Databricks run id (or ``"interactive"`` when run standalone).
        row_count: Rows written to the CSV (excludes the header).
        generated_at: ISO-8601 UTC timestamp; defaults to ``now`` when omitted.

    Returns:
        The pointer dict (JSON-serialize it and pass to ``dbutils.notebook.exit``).
    """
    if generated_at is None:
        generated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    return {
        "status": status,
        "request_no": request_no,
        "output_path": output_path,
        "run_id": run_id,
        "row_count": row_count,
        "generated_at": generated_at,
    }
