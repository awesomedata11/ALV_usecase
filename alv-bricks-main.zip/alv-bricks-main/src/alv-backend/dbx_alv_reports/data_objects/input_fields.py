"""Typed view of a row's ``input_fields_json`` (CLAUDE.md “Class design patterns”).

These dataclasses mirror the JSON 1:1 so ``InputFieldsSpec.from_dict(blob)`` works
directly. Field names use ``snake_case`` to match the JSON keys (the newer flat
model in ``input_fields_json_design.md``). No validation happens here -- that is
the parser's job (:mod:`dbx_alv_reports.spec_parser`); these objects assume an
already-validated blob and give the App/tests an ergonomic, typed handle.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

SCALAR_CONTROLS = {"text", "date"}
COMPOSITE_CONTROLS = {"date_range", "time_range"}


@dataclass
class ValidationRule:
    rule: str
    message_key: str
    applies_to: Optional[str] = None
    unit: Optional[str] = None
    value: Optional[float] = None
    pattern: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ValidationRule":
        return cls(
            rule=d["rule"],
            message_key=d["message_key"],
            applies_to=d.get("applies_to"),
            unit=d.get("unit"),
            value=d.get("value"),
            pattern=d.get("pattern"),
        )


@dataclass
class FieldPart:
    """One endpoint (``from``/``to``) of a composite control."""

    param_name: str
    display_label: str
    default: Any = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "FieldPart":
        return cls(
            param_name=d["param_name"],
            display_label=d["display_label"],
            default=d.get("default"),
        )


@dataclass
class Field:
    """One form field -- scalar (text/date) or composite (date_range/time_range)."""

    control: str
    display_label: str
    display_order: int
    data_type: str
    mandatory: bool
    validations: List[ValidationRule] = field(default_factory=list)
    # scalar-only
    param_name: Optional[str] = None
    selection_type: Optional[str] = None
    default: Any = None
    omit_if_blank: Optional[bool] = None
    normalize: List[str] = field(default_factory=list)
    # composite-only
    parts: Optional[Dict[str, FieldPart]] = None

    @property
    def is_composite(self) -> bool:
        return self.control in COMPOSITE_CONTROLS

    @property
    def param_names(self) -> List[str]:
        """Backend parameter key(s) this field contributes to the payload."""
        if self.is_composite and self.parts:
            return [p.param_name for p in self.parts.values()]
        return [self.param_name] if self.param_name else []

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Field":
        parts = None
        if "parts" in d:
            parts = {k: FieldPart.from_dict(v) for k, v in d["parts"].items()}
        return cls(
            control=d["control"],
            display_label=d["display_label"],
            display_order=d["display_order"],
            data_type=d["data_type"],
            mandatory=d["mandatory"],
            validations=[ValidationRule.from_dict(v) for v in d.get("validations", [])],
            param_name=d.get("param_name"),
            selection_type=d.get("selection_type"),
            default=d.get("default"),
            omit_if_blank=d.get("omit_if_blank"),
            normalize=list(d.get("normalize", [])),
            parts=parts,
        )


@dataclass
class InputFieldsSpec:
    """The parsed ``input_fields_json`` for one runnable report."""

    schema_version: int
    fields: List[Field]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "InputFieldsSpec":
        return cls(
            schema_version=d["schema_version"],
            fields=[Field.from_dict(f) for f in d.get("fields", [])],
        )

    def ordered_fields(self) -> List[Field]:
        """Fields sorted by ``display_order`` (render order)."""
        return sorted(self.fields, key=lambda f: f.display_order)

    def all_param_names(self) -> List[str]:
        """Every backend parameter key across all fields (parts expanded)."""
        names: List[str] = []
        for f in self.fields:
            names.extend(f.param_names)
        return names
