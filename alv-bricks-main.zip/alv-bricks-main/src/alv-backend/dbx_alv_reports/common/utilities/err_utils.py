"""Error-dict helpers for the runtime execution path.

The frameworks use two coexisting error styles (CLAUDE.md “Utilities, logging & error handling”):

* **raise-early** for programmer/config errors (bad spec, unknown rule) --
  fail loud at construction/registration; and
* **error-dict return** for the runtime execution path, so an orchestrator's
  ``run()`` can report a clean failure that a driver notebook turns into a
  failed job run.

This module provides the error-dict shape.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional


def get_exception(
    error_code: str,
    error_message: str,
    log_level: str = "ERROR",
    error_at: Optional[str] = None,
    exc: Optional[BaseException] = None,
) -> Dict[str, Any]:
    """Build the standard error-dict returned by ``run()`` methods.

    Args:
        error_code: Short machine code, e.g. ``"SEED_VALIDATION_FAILED"``.
        error_message: Human-readable description.
        log_level: One of the ``logging`` level names.
        error_at: Optional location hint (module/function).
        exc: Optional originating exception (its ``repr`` is appended).

    Returns:
        A dict with ``error_code``, ``error_message``, ``log_level`` and
        ``error_at`` keys.
    """
    message = error_message if exc is None else f"{error_message} :: {exc!r}"
    return {
        "error_code": error_code,
        "error_message": message,
        "log_level": log_level,
        "error_at": error_at,
    }


def log_error(log: logging.Logger, err: Dict[str, Any]) -> None:
    """Emit an error-dict through ``log`` at its declared level."""
    level = getattr(logging, str(err.get("log_level", "ERROR")).upper(), logging.ERROR)
    where = f" [{err['error_at']}]" if err.get("error_at") else ""
    log.log(level, "%s%s: %s", err.get("error_code"), where, err.get("error_message"))
