"""Structured output-path builder (Spark-free, pure).

A report run's output file is laid out in per-run subfolders instead of a flat
directory (docs/OUTPUT_PATH_LAYOUT_APPROACH.md):

    <base>/<YYYYMMDD>/<alv_id>/<request_no>/

* ``<base>`` is the UC Volume root the job writes to (``/Volumes/<cat>/<sc>/<vol>``);
* ``<YYYYMMDD>`` is the run date, stamped by the **job** in the report timezone
  (the job passes an already-tz-aware ``now``; only the notebook reads the clock);
* ``<alv_id>`` is the runnable report type, used **as an opaque folder name** (never
  split into its ``report_key__selection__type`` parts — that form is a seeding
  convention, not a contract);
* ``<request_no>`` isolates one submission, so the filename inside the folder is
  free (the stand-in jobs let Spark name the ``part-*.csv``).

Kept deliberately Spark-free and clock-free (``now`` is injected) so it can be
unit-tested with no cluster; the job notebook is the only place that reads the
wall clock and touches ``spark`` / ``dbutils``.
"""

from __future__ import annotations

import datetime

# Folder date format: compact YYYYMMDD (e.g. 20260819), per the approved layout.
DATE_FORMAT = "%Y%m%d"


def build_output_dir(
    base: str,
    alv_id: str,
    request_no: str,
    now: datetime.datetime,
) -> str:
    """Build the per-run output DIRECTORY ``<base>/<YYYYMMDD>/<alv_id>/<request_no>``.

    The job writes its output file(s) *inside* the returned directory (e.g. a Spark
    ``coalesce(1).write.csv(dir)`` drops a ``part-*.csv`` there); the concrete file
    path is then resolved by the notebook and returned to the App.

    Args:
        base: the UC Volume root (``/Volumes/<catalog>/<schema>/<volume>``). Any
            trailing slash is trimmed.
        alv_id: the runnable report id — used verbatim as a single path segment.
        request_no: the App-generated submission id (e.g. ``REQ-1A2B3C4D5E6F``).
        now: the run instant, already localized to the report timezone by the
            caller. Only its date is used (``strftime('%Y%m%d')``).

    Returns:
        The output directory path, with no trailing slash.

    Raises:
        ValueError: if ``base``, ``alv_id`` or ``request_no`` is blank.
    """
    base_clean = base.rstrip("/")
    if not base_clean:
        raise ValueError("base must be a non-empty volume path")
    if not alv_id:
        raise ValueError("alv_id must be non-empty")
    if not request_no:
        raise ValueError("request_no must be non-empty")

    run_date = now.strftime(DATE_FORMAT)
    return f"{base_clean}/{run_date}/{alv_id}/{request_no}"


def parse_date_dir(name: str) -> datetime.date | None:
    """Parse a top-level output folder name (``YYYYMMDD``) into a date, or ``None``.

    Anything that is not exactly an 8-digit ``%Y%m%d`` folder (e.g. a stray file, a
    ``_tmp`` dir, or a differently-shaped name) returns ``None`` so the cleanup job
    leaves it untouched — it only ever deletes recognizably-dated run folders.
    """
    try:
        return datetime.datetime.strptime(name, DATE_FORMAT).date()
    except (ValueError, TypeError):
        return None


def expired_date_dirs(
    names: list[str],
    now: datetime.datetime,
    retention_days: int,
) -> list[str]:
    """Return the ``YYYYMMDD`` folder names that are past the retention window.

    A folder is expired when its date is **strictly older** than
    ``now.date() - retention_days`` — i.e. the most recent ``retention_days`` days
    (today included) are always kept. Names that are not ``YYYYMMDD`` folders are
    ignored (never returned), so the cleanup can never touch anything unexpected.

    Args:
        names: the top-level entry names directly under the volume base.
        now: the run instant, localized to the report timezone by the caller.
        retention_days: keep-window in days; must be a non-negative int.

    Returns:
        The subset of ``names`` (order preserved) that should be deleted.

    Raises:
        ValueError: if ``retention_days`` is negative.
    """
    if retention_days < 0:
        raise ValueError("retention_days must be >= 0")
    cutoff = now.date() - datetime.timedelta(days=retention_days)
    expired: list[str] = []
    for name in names:
        d = parse_date_dir(name)
        if d is not None and d < cutoff:
            expired.append(name)
    return expired
