"""Unity Catalog helpers (Spark-bound).

A thin stateful helper holding ``spark``/``log`` (constructor ``(spark, log=None)``)
matching the ``UnityCatalogUtils`` convention in CLAUDE.md “Utilities, logging & error handling”. Kept
deliberately small -- the metadata layer only needs schema/table existence
checks and SQL execution.
"""

from __future__ import annotations

import logging
from typing import Any, List, Optional

from .logging import get_log


class UnityCatalogUtils:
    """Small Spark-backed Unity Catalog utility surface."""

    def __init__(self, spark: Any, log: Optional[logging.Logger] = None) -> None:
        self.spark = spark
        self.log = log or get_log("uc_utils")

    # -- identifiers --------------------------------------------------------
    @staticmethod
    def fqn(catalog: str, schema: str, table: Optional[str] = None) -> str:
        """Backtick-quote a fully-qualified UC identifier."""
        parts = [catalog, schema] + ([table] if table else [])
        return ".".join(f"`{p}`" for p in parts)

    # -- existence checks ---------------------------------------------------
    def schema_exists(self, catalog: str, schema: str) -> bool:
        rows = self.spark.sql(
            f"SHOW SCHEMAS IN `{catalog}` LIKE '{schema}'"
        ).collect()
        return len(rows) > 0

    def table_exists(self, catalog: str, schema: str, table: str) -> bool:
        try:
            return self.spark.catalog.tableExists(f"{catalog}.{schema}.{table}")
        except Exception:  # pragma: no cover - fallback for older runtimes
            rows = self.spark.sql(
                f"SHOW TABLES IN {self.fqn(catalog, schema)} LIKE '{table}'"
            ).collect()
            return len(rows) > 0

    # -- execution ----------------------------------------------------------
    def run(self, sql: str) -> None:
        """Execute a statement, logging it at DEBUG."""
        self.log.debug("executing SQL: %s", sql)
        self.spark.sql(sql)

    def run_all(self, statements: List[str]) -> None:
        for stmt in statements:
            self.run(stmt)
