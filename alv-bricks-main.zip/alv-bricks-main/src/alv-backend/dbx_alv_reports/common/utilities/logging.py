"""Named application logger with idempotent handler setup.

Mirrors the ``common/utilities/logging.py`` convention used across the
``client_shared_utils`` frameworks (see CLAUDE.md “Utilities, logging & error handling”): every class
does ``self.log = log or get_log()`` so a logger is always injectable, never
required.
"""

from __future__ import annotations

import logging
import sys
from typing import Optional

APP_LOGGER_NAME = "alv_reports"
_LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


def _configure_app_logger(level: int = logging.INFO) -> logging.Logger:
    """Configure the root app logger once; safe to call repeatedly."""
    logger = logging.getLogger(APP_LOGGER_NAME)
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(_LOG_FORMAT))
        logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False
    return logger


def get_log(module_name: Optional[str] = None, level: int = logging.INFO) -> logging.Logger:
    """Return the app logger, or a named child of it.

    Args:
        module_name: Optional child-logger suffix (e.g. ``"metadata"``).
        level: Level applied to the root app logger on first configuration.

    Returns:
        A configured :class:`logging.Logger`.
    """
    root = _configure_app_logger(level)
    if module_name:
        return root.getChild(module_name)
    return root
