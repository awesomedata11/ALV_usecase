"""Unit tests for the shipped JSON Schema + the pilot manifest (task 2.5)."""

import json

import pytest

from dbx_alv_reports import ReportSeeder
from dbx_alv_reports.spec_parser.input_fields_parser import (
    JSONSCHEMA_AVAILABLE,
    load_schema,
)

pytestmark = pytest.mark.unit


def test_schema_file_is_valid_json_draft07():
    schema = load_schema()
    assert schema["$schema"].endswith("draft-07/schema#")
    assert "input_fields" in schema["$id"]
    assert "fields" in schema["properties"]


def test_load_schema_is_cached():
    # lru_cache: repeated calls return the same object (no re-read per blob).
    assert load_schema() is load_schema()


def test_every_pilot_blob_validates(manifest_path):
    manifest = ReportSeeder.load_manifest(manifest_path)
    errors, _ = ReportSeeder.validate_manifest(manifest)
    assert errors == [], errors


def test_every_cc_recharge_blob_validates(cc_recharge_manifest_path):
    manifest = ReportSeeder.load_manifest(cc_recharge_manifest_path)
    errors, _ = ReportSeeder.validate_manifest(manifest)
    assert errors == [], errors


@pytest.mark.skipif(not JSONSCHEMA_AVAILABLE, reason="jsonschema not installed")
def test_jsonschema_pass_matches_semantic_pass(manifest_path):
    from jsonschema import Draft7Validator

    validator = Draft7Validator(load_schema())
    manifest = ReportSeeder.load_manifest(manifest_path)
    for row in manifest["catalog_rows"]:
        assert list(validator.iter_errors(row["input_fields_json"])) == []
