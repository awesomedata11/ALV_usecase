"""Unit tests for the Spark-free sample-report download builders.

Covers the pure helper the ``alv_sample_report_run`` notebook imports: parsing a
``sample_query`` block, building the parameterized SELECT (date-range / IN / blank-
skip / bound-not-concatenated / injection-as-bound-value / IN explosion guard), and
the exit-pointer JSON shape the App parses (CONTRACT mechanism (a)).
"""

import pytest

from dbx_alv_reports import (
    SampleReportSqlError,
    build_exit_pointer,
    build_sample_report_sql,
    parse_sample_query,
)
from dbx_alv_reports.sample_query.sample_report_query import DEFAULT_MAX_ROWS

pytestmark = pytest.mark.unit


# The agent_item sample_query (report_specs/retail_ledger.input_fields.json).
AGENT_ITEM_SAMPLE_QUERY = {
    "columns": [
        {"display_name": "Transaction Date", "column_name": "transaction_date"},
        {"display_name": "Agent Code", "column_name": "agent_code"},
        {"display_name": "Agent Name", "column_name": "agent_name"},
        {"display_name": "Item Code", "column_name": "item_code"},
        {"display_name": "Item Name", "column_name": "item_name"},
        {"display_name": "Circle", "column_name": "circle"},
        {"display_name": "Transaction Type", "column_name": "transaction_type"},
        {"display_name": "Amount", "column_name": "amount"},
        {"display_name": "Quantity", "column_name": "quantity"},
    ],
    "param_mappings": [
        {"param_name": "transaction_date_from", "column_name": "transaction_date", "operator": ">="},
        {"param_name": "transaction_date_to", "column_name": "transaction_date", "operator": "<="},
        {"param_name": "agent", "column_name": "agent_code", "operator": "IN"},
        {"param_name": "transaction_type", "column_name": "transaction_type", "operator": "IN"},
    ],
    "default_limit": 100,
}

CATALOG = "classic_stable_lakebase_catalog"
SCHEMA = "alv_metadata"


@pytest.fixture
def spec():
    return parse_sample_query(AGENT_ITEM_SAMPLE_QUERY)


# --- parse ------------------------------------------------------------------


def test_parse_none_returns_none():
    assert parse_sample_query(None) is None


def test_parse_populates_columns_and_mappings(spec):
    assert [c.column_name for c in spec.columns][:2] == ["transaction_date", "agent_code"]
    assert spec.columns[0].display_name == "Transaction Date"
    assert [m.operator for m in spec.param_mappings] == [">=", "<=", "IN", "IN"]


def test_parse_rejects_bad_column_identifier():
    blob = {
        "columns": [{"display_name": "X", "column_name": "a; DROP TABLE t"}],
        "param_mappings": [{"param_name": "p", "column_name": "a", "operator": "="}],
    }
    with pytest.raises(SampleReportSqlError):
        parse_sample_query(blob)


def test_parse_rejects_unsupported_operator():
    blob = {
        "columns": [{"display_name": "X", "column_name": "a"}],
        "param_mappings": [{"param_name": "p", "column_name": "a", "operator": "LIKE"}],
    }
    with pytest.raises(SampleReportSqlError):
        parse_sample_query(blob)


# --- build SQL --------------------------------------------------------------


def test_agent_item_full_filter_matches_preview_semantics(spec):
    values = {
        "transaction_date_from": "2026-07-01",
        "transaction_date_to": "2026-07-31",
        "agent": "AG001,AG002",
        "transaction_type": "CREDIT",
    }
    built = build_sample_report_sql(spec, values, CATALOG, SCHEMA)

    assert built.sql == (
        "SELECT `transaction_date`, `agent_code`, `agent_name`, `item_code`, "
        "`item_name`, `circle`, `transaction_type`, `amount`, `quantity` "
        "FROM `classic_stable_lakebase_catalog`.`alv_metadata`.`retail_ledger_sample` "
        "WHERE `transaction_date` >= :p0 AND `transaction_date` <= :p1 "
        "AND `agent_code` IN (:p2,:p3) AND `transaction_type` IN (:p4) "
        f"LIMIT {DEFAULT_MAX_ROWS}"
    )
    assert built.args == {
        "p0": "2026-07-01",
        "p1": "2026-07-31",
        "p2": "AG001",
        "p3": "AG002",
        "p4": "CREDIT",
    }
    assert built.column_names[0] == "transaction_date"
    assert built.display_names[0] == "Transaction Date"


def test_blank_and_whitespace_params_are_skipped(spec):
    values = {
        "transaction_date_from": "2026-07-01",
        "transaction_date_to": "",          # blank -> skipped
        "agent": "   ",                       # whitespace -> skipped
        "transaction_type": "CREDIT",
    }
    built = build_sample_report_sql(spec, values, CATALOG, SCHEMA)
    where = built.sql.split(" WHERE ", 1)[1]
    assert "`transaction_date` >= :p0" in where
    assert "<=" not in where                     # date_to skipped
    assert "`agent_code` IN" not in where        # agent skipped (still in projection)
    assert built.args == {"p0": "2026-07-01", "p1": "CREDIT"}


def test_no_filters_yields_where_less_select(spec):
    built = build_sample_report_sql(spec, {}, CATALOG, SCHEMA)
    assert " WHERE " not in built.sql
    assert built.args == {}
    assert built.sql.endswith(f"LIMIT {DEFAULT_MAX_ROWS}")


def test_values_are_bound_not_string_concatenated(spec):
    # A quote/semicolon injection attempt must ride as a bound value, never inline.
    evil = "AG001'); DROP TABLE retail_ledger_sample;--"
    values = {"agent": evil}
    built = build_sample_report_sql(spec, values, CATALOG, SCHEMA)
    assert evil not in built.sql             # never interpolated into SQL text
    assert "DROP TABLE" not in built.sql
    assert built.args == {"p0": evil}        # carried as a single bound param
    assert built.sql.count("`agent_code` IN (:p0)") == 1


def test_in_comma_split_binds_each_element(spec):
    built = build_sample_report_sql(spec, {"agent": "AG001, AG002 , AG003"}, CATALOG, SCHEMA)
    assert "`agent_code` IN (:p0,:p1,:p2)" in built.sql
    assert built.args == {"p0": "AG001", "p1": "AG002", "p2": "AG003"}


def test_in_explosion_guard():
    blob = {
        "columns": [{"display_name": "A", "column_name": "agent_code"}],
        "param_mappings": [{"param_name": "agent", "column_name": "agent_code", "operator": "IN"}],
    }
    spec = parse_sample_query(blob)
    huge = ",".join(f"AG{i}" for i in range(201))
    with pytest.raises(SampleReportSqlError):
        build_sample_report_sql(spec, {"agent": huge}, CATALOG, SCHEMA)


def test_no_500_row_preview_cap_default_is_large(spec):
    built = build_sample_report_sql(spec, {}, CATALOG, SCHEMA)
    assert f"LIMIT {DEFAULT_MAX_ROWS}" in built.sql
    assert DEFAULT_MAX_ROWS >= 1_000_000    # far above the preview's 500 cap


def test_max_rows_none_removes_limit(spec):
    built = build_sample_report_sql(spec, {}, CATALOG, SCHEMA, max_rows=None)
    assert "LIMIT" not in built.sql


# --- exit pointer -----------------------------------------------------------


def test_exit_pointer_shape():
    p = build_exit_pointer(
        status="COMPLETED",
        request_no="REQ-1",
        output_path="/Volumes/c/s/alv_outputs/REQ-1_42.csv",
        run_id="42",
        row_count=17,
        generated_at="2026-08-03T00:00:00+00:00",
    )
    assert p == {
        "status": "COMPLETED",
        "request_no": "REQ-1",
        "output_path": "/Volumes/c/s/alv_outputs/REQ-1_42.csv",
        "run_id": "42",
        "row_count": 17,
        "generated_at": "2026-08-03T00:00:00+00:00",
    }


def test_exit_pointer_defaults_generated_at():
    p = build_exit_pointer(
        status="COMPLETED",
        request_no="REQ-1",
        output_path="/Volumes/c/s/v/f.csv",
        run_id="1",
        row_count=0,
    )
    # ISO-8601 UTC timestamp auto-filled; output_path is a /Volumes path.
    assert p["generated_at"].endswith("+00:00")
    assert p["output_path"].startswith("/Volumes/")
