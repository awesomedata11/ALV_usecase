"""Unit tests for the metadata-table DDL (tasks 2.1-2.4)."""

import pytest

from dbx_alv_reports import ddl_all, ddl_create_schema, ddl_create_table
from dbx_alv_reports.metadata import (
    ALV_CATALOG_TABLE,
    AUTH_MAP_TABLE,
    PILOT_TABLES,
    REPORT_PERMISSIONS_TABLE,
    REPORT_TEMPLATES_TABLE,
    REQUEST_LOG_TABLE,
)

pytestmark = pytest.mark.unit

CAT, SCH = "cat", "sch"


def test_create_schema_ddl():
    ddl = ddl_create_schema(CAT, SCH)
    assert "CREATE SCHEMA IF NOT EXISTS `cat`.`sch`" in ddl


def test_ddl_all_default_excludes_auth_map():
    stmts = ddl_all(CAT, SCH)
    # schema + alv_catalog + request_log + report_permissions + report_templates
    assert len(stmts) == 5
    assert "CREATE SCHEMA" in stmts[0]
    assert "`alv_catalog`" in stmts[1]
    assert "`request_log`" in stmts[2]
    assert "`report_permissions`" in stmts[3]
    assert "`report_templates`" in stmts[4]
    assert not any("auth_map" in s for s in stmts)


def test_ddl_all_includes_auth_map_when_requested():
    stmts = ddl_all(CAT, SCH, include_auth_map=True)
    assert len(stmts) == 6
    assert any("`auth_map`" in s for s in stmts)


def test_alv_catalog_before_request_log_for_fk():
    # request_log FK references alv_catalog; alv_catalog must be created first.
    stmts = ddl_all(CAT, SCH)
    assert stmts.index(next(s for s in stmts if "`alv_catalog`" in s)) < stmts.index(
        next(s for s in stmts if "`request_log`" in s)
    )


def test_alv_catalog_has_pk_and_required_columns():
    ddl = ddl_create_table(ALV_CATALOG_TABLE, CAT, SCH)
    assert "PRIMARY KEY (alv_id)" in ddl
    assert "input_fields_json STRING NOT NULL" in ddl
    assert "job_id BIGINT" in ddl
    names = ALV_CATALOG_TABLE.column_names
    for col in ("alv_id", "report_key", "selection_id", "report_type_code", "job_id", "input_fields_json", "is_active"):
        assert col in names


def test_request_log_has_pk_and_fk():
    ddl = ddl_create_table(REQUEST_LOG_TABLE, CAT, SCH)
    assert "PRIMARY KEY (request_no)" in ddl
    assert "FOREIGN KEY (alv_id) REFERENCES `cat`.`sch`.`alv_catalog` (alv_id)" in ddl
    assert "param_hash STRING" in ddl


def test_report_permissions_has_composite_pk_and_columns():
    ddl = ddl_create_table(REPORT_PERMISSIONS_TABLE, CAT, SCH)
    # Composite PK — grain is one row per (report_key, principal_type, principal_name).
    assert "PRIMARY KEY (report_key, principal_type, principal_name)" in ddl
    assert "report_key STRING NOT NULL" in ddl
    assert "principal_type STRING NOT NULL" in ddl
    assert "principal_name STRING NOT NULL" in ddl
    assert REPORT_PERMISSIONS_TABLE.column_names == [
        "report_key",
        "principal_type",
        "principal_name",
        "is_active",
        "granted_at",
        "granted_by",
    ]


def test_report_templates_has_pk_fk_and_columns():
    ddl = ddl_create_table(REPORT_TEMPLATES_TABLE, CAT, SCH)
    # PK on the app-generated id; FK to alv_catalog (created before it — see PILOT order).
    assert "PRIMARY KEY (template_id)" in ddl
    assert "FOREIGN KEY (alv_id) REFERENCES `cat`.`sch`.`alv_catalog` (alv_id)" in ddl
    assert "template_id STRING NOT NULL" in ddl
    assert "owner STRING NOT NULL" in ddl
    assert "template_name STRING NOT NULL" in ddl
    assert "param_values_json STRING NOT NULL" in ddl
    assert REPORT_TEMPLATES_TABLE.column_names == [
        "template_id",
        "alv_id",
        "owner",
        "template_name",
        "param_values_json",
        "value_kinds_json",
        "is_active",
        "created_at",
        "updated_at",
    ]


def test_pilot_tables_include_report_templates_but_not_auth_map():
    assert PILOT_TABLES == [
        ALV_CATALOG_TABLE,
        REQUEST_LOG_TABLE,
        REPORT_PERMISSIONS_TABLE,
        REPORT_TEMPLATES_TABLE,
    ]
    assert AUTH_MAP_TABLE not in PILOT_TABLES  # deferred (D19), superseded for visibility


def test_uses_delta():
    for t in PILOT_TABLES:
        assert "USING DELTA" in ddl_create_table(t, CAT, SCH)
