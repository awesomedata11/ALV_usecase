"""Unit tests for the input_fields loader/validator (task 2.5)."""

import json

import pytest

from dbx_alv_reports import InputFieldsParser, validate_input_fields
from dbx_alv_reports.data_objects.input_fields import InputFieldsSpec

pytestmark = pytest.mark.unit


def _scalar(param_name="agent", **over):
    base = {
        "param_name": param_name,
        "display_label": "Agent",
        "display_order": 1,
        "control": "text",
        "data_type": "string",
        "selection_type": "single",
        "mandatory": False,
    }
    base.update(over)
    return base


def test_valid_scalar_blob_passes_and_parses():
    blob = {"schema_version": 1, "fields": [_scalar()]}
    parser = InputFieldsParser(blob, source="t")
    assert parser.validate(), parser.get_errors()
    spec = parser.get_spec()
    assert isinstance(spec, InputFieldsSpec)
    assert spec.all_param_names() == ["agent"]


def test_valid_date_range_composite_parses_parts():
    blob = {
        "schema_version": 1,
        "fields": [
            {
                "control": "date_range",
                "display_label": "Transaction Date",
                "display_order": 1,
                "data_type": "date",
                "mandatory": True,
                "parts": {
                    "from": {"param_name": "d_from", "display_label": "From"},
                    "to": {"param_name": "d_to", "display_label": "To"},
                },
                "validations": [
                    {"rule": "from_lte_to", "message_key": "ALV_DATE_FROM_GT_TO"},
                    {"rule": "max_span", "unit": "days", "value": 31, "message_key": "ALV_SPAN"},
                ],
            }
        ],
    }
    ok, errors, _ = validate_input_fields(blob, "t")
    assert ok, errors
    spec = InputFieldsParser(blob).get_spec()
    assert spec.all_param_names() == ["d_from", "d_to"]
    assert spec.fields[0].is_composite


def test_unknown_rule_fails_load():
    # D-IFJ-10: unknown rule must fail, never silently skip.
    blob = {"schema_version": 1, "fields": [_scalar(validations=[{"rule": "nope", "message_key": "ALV_X"}])]}
    ok, errors, _ = validate_input_fields(blob, "t")
    assert not ok
    assert any("unknown validation rule" in e for e in errors)


def test_duplicate_param_name_fails():
    blob = {"schema_version": 1, "fields": [_scalar("a", display_order=1), _scalar("a", display_order=2)]}
    ok, errors, _ = validate_input_fields(blob, "t")
    assert not ok
    assert any("duplicate param_name" in e for e in errors)


def test_missing_selection_type_fails():
    field = _scalar()
    del field["selection_type"]
    ok, errors, _ = validate_input_fields({"schema_version": 1, "fields": [field]}, "t")
    assert not ok
    assert any("selection_type" in e for e in errors)


def test_bad_schema_version_fails_fast():
    ok, errors, _ = validate_input_fields({"schema_version": 2, "fields": [_scalar()]}, "t")
    assert not ok
    assert any("schema_version" in e for e in errors)


def test_max_span_requires_unit_and_value():
    # date_range so the rule is control-appropriate; isolates the param requirement.
    blob = {
        "schema_version": 1,
        "fields": [
            {
                "control": "date_range",
                "display_label": "D",
                "display_order": 1,
                "data_type": "date",
                "mandatory": True,
                "parts": {
                    "from": {"param_name": "f", "display_label": "From"},
                    "to": {"param_name": "t", "display_label": "To"},
                },
                "validations": [{"rule": "max_span", "message_key": "ALV_S"}],
            }
        ],
    }
    ok, errors, _ = validate_input_fields(blob, "t")
    assert not ok
    assert any("requires param 'unit'" in e or "requires param 'value'" in e for e in errors)


def test_rule_on_wrong_control_fails():
    # max_span applies to date_range, not text.
    blob = {
        "schema_version": 1,
        "fields": [_scalar(validations=[{"rule": "max_span", "unit": "days", "value": 31, "message_key": "ALV_S"}])],
    }
    ok, errors, _ = validate_input_fields(blob, "t")
    assert not ok
    assert any("does not apply to control 'text'" in e for e in errors)


def test_composite_missing_to_part_fails():
    blob = {
        "schema_version": 1,
        "fields": [
            {
                "control": "date_range",
                "display_label": "D",
                "display_order": 1,
                "data_type": "date",
                "mandatory": True,
                "parts": {"from": {"param_name": "f", "display_label": "From"}},
            }
        ],
    }
    ok, errors, _ = validate_input_fields(blob, "t")
    assert not ok


def test_unknown_control_fails():
    blob = {"schema_version": 1, "fields": [_scalar(control="slider")]}
    ok, errors, _ = validate_input_fields(blob, "t")
    assert not ok
    assert any("unknown control" in e for e in errors)


def test_get_spec_raises_on_invalid():
    parser = InputFieldsParser({"schema_version": 1, "fields": []}, source="t")
    with pytest.raises(ValueError):
        parser.get_spec()
