"""Unit tests for row derivation + manifest validation (task 2.6)."""

import json

import pytest

from dbx_alv_reports import ReportSeeder, slug_alv_id

pytestmark = pytest.mark.unit


@pytest.fixture
def manifest(manifest_path):
    return ReportSeeder.load_manifest(manifest_path)


@pytest.fixture
def cc_recharge_manifest(cc_recharge_manifest_path):
    return ReportSeeder.load_manifest(cc_recharge_manifest_path)


def test_slug_alv_id():
    assert slug_alv_id("retail_ledger", "detail", "agent_item") == "retail_ledger__detail__agent_item"
    assert slug_alv_id("retail_ledger", "agent_closing_balance", None) == "retail_ledger__agent_closing_balance"


def test_manifest_validates_clean(manifest):
    errors, _ = ReportSeeder.validate_manifest(manifest)
    assert errors == [], errors


def test_build_rows_produces_14_unique_rows(manifest):
    rows = ReportSeeder.build_rows(manifest)
    assert len(rows) == 14
    ids = [r["alv_id"] for r in rows]
    assert len(set(ids)) == 14
    assert "retail_ledger__detail__agent_item" in ids
    assert "retail_ledger__agent_closing_balance" in ids


def test_placeholder_job_id_becomes_null(manifest):
    rows = ReportSeeder.build_rows(manifest)
    assert all(r["job_id"] is None for r in rows)  # all placeholders in the pilot manifest


def test_derive_rows_returns_placeholder_warnings(manifest):
    rows, warnings = ReportSeeder.derive_rows(manifest)
    assert len(rows) == 14
    # every row has a placeholder (non-numeric) job_id -> one warning each
    assert len(warnings) == 14
    assert all("unbound" in w for w in warnings)


def test_missing_display_column_flagged():
    row = {
        "report_key": "r",
        # report_label missing
        "selection_id": "s",
        # selection_label missing
        # selection_order missing
        "report_type_code": None,
        "report_type_label": None,
        "report_type_order": None,
        "job_id": None,
        "input_fields_json": {
            "schema_version": 1,
            "fields": [
                {
                    "param_name": "a",
                    "display_label": "A",
                    "display_order": 1,
                    "control": "text",
                    "data_type": "string",
                    "selection_type": "single",
                    "mandatory": False,
                }
            ],
        },
    }
    errors, _ = ReportSeeder.validate_manifest({"catalog_rows": [row]})
    assert any("report_label" in e for e in errors)
    assert any("selection_label" in e for e in errors)
    assert any("selection_order" in e for e in errors)


def test_alv_name_and_input_fields_json_are_serialized(manifest):
    rows = ReportSeeder.build_rows(manifest)
    row0 = next(r for r in rows if r["alv_id"] == "retail_ledger__detail__agent_item")
    assert row0["alv_name"].startswith("Retail Ledger")
    assert json.loads(row0["input_fields_json"])["schema_version"] == 1
    assert row0["is_active"] is True
    assert row0["job_run_mode"] == "run_now"


def test_build_rows_raises_on_invalid_manifest():
    bad = {"catalog_rows": [{"report_key": "r", "selection_id": "s"}]}  # missing input_fields_json
    with pytest.raises(ValueError):
        ReportSeeder.build_rows(bad)


def test_manifest_flags_bad_embedded_input_fields():
    bad = {
        "catalog_rows": [
            {
                "report_key": "r",
                "report_label": "R",
                "selection_id": "s",
                "selection_label": "S",
                "selection_order": 1,
                "report_type_code": None,
                "report_type_label": None,
                "report_type_order": None,
                "job_id": None,
                "input_fields_json": {"schema_version": 1, "fields": []},  # empty -> invalid
            }
        ]
    }
    errors, _ = ReportSeeder.validate_manifest(bad)
    assert errors


def test_duplicate_alv_id_flagged():
    row = {
        "report_key": "r",
        "report_label": "R",
        "selection_id": "s",
        "selection_label": "S",
        "selection_order": 1,
        "report_type_code": "x",
        "report_type_label": "X",
        "report_type_order": 1,
        "job_id": 1,
        "input_fields_json": {
            "schema_version": 1,
            "fields": [
                {
                    "param_name": "a",
                    "display_label": "A",
                    "display_order": 1,
                    "control": "text",
                    "data_type": "string",
                    "selection_type": "single",
                    "mandatory": False,
                }
            ],
        },
    }
    errors, _ = ReportSeeder.validate_manifest({"catalog_rows": [row, dict(row)]})
    assert any("duplicate alv_id" in e for e in errors)


# -- CC Recharge Data: a full clone of the Retail Ledger manifest (report_key /
# report_label only). Mirrors the retail exercises so the second report is proven
# to validate cleanly and derive its own 14 cc_recharge alv_ids.
CC_RECHARGE_ALV_IDS = {
    "cc_recharge__detail__agent_item",
    "cc_recharge__detail__agent_detail_payment_gateway",
    "cc_recharge__detail__agent_detail_customer_state",
    "cc_recharge__sequence_wise__agent_summary",
    "cc_recharge__sequence_wise__summary_jc_agent",
    "cc_recharge__sequence_wise__statewise_summary",
    "cc_recharge__sequence_wise__summary_price_group",
    "cc_recharge__sequence_wise__national_partner_role",
    "cc_recharge__time_wise__agent_summary",
    "cc_recharge__time_wise__summary_jc_agent",
    "cc_recharge__time_wise__statewise_summary",
    "cc_recharge__time_wise__summary_price_group",
    "cc_recharge__time_wise__national_partner_role",
    "cc_recharge__agent_closing_balance",
}


def test_cc_recharge_manifest_validates_clean(cc_recharge_manifest):
    errors, _ = ReportSeeder.validate_manifest(cc_recharge_manifest)
    assert errors == [], errors


def test_cc_recharge_build_rows_produces_expected_14_alv_ids(cc_recharge_manifest):
    rows = ReportSeeder.build_rows(cc_recharge_manifest)
    assert len(rows) == 14
    ids = [r["alv_id"] for r in rows]
    assert len(set(ids)) == 14
    assert set(ids) == CC_RECHARGE_ALV_IDS
    assert all(r["report_key"] == "cc_recharge" for r in rows)
    assert all(r["report_label"] == "CC Recharge Data" for r in rows)


def test_cc_recharge_detail_agent_item_carries_sample_query(cc_recharge_manifest):
    rows = ReportSeeder.build_rows(cc_recharge_manifest)
    row0 = next(r for r in rows if r["alv_id"] == "cc_recharge__detail__agent_item")
    ifj = json.loads(row0["input_fields_json"])
    assert "sample_query" in ifj
    assert ifj["sample_query"]["default_limit"] == 100
    assert row0["alv_name"].startswith("CC Recharge Data")


def test_cc_recharge_placeholder_job_ids_become_null(cc_recharge_manifest):
    rows = ReportSeeder.build_rows(cc_recharge_manifest)
    assert all(r["job_id"] is None for r in rows)  # all placeholders, seed NULL (unbound)


def test_cc_recharge_is_structural_clone_of_retail(manifest, cc_recharge_manifest):
    """Only report_key + report_label differ; everything else is identical."""

    def normalize(m):
        m = json.loads(json.dumps(m))  # deep copy
        for r in m["catalog_rows"]:
            r["report_key"] = "_"
            r["report_label"] = "_"
        return m

    assert manifest["_note"] == cc_recharge_manifest["_note"]
    assert normalize(manifest) == normalize(cc_recharge_manifest)
