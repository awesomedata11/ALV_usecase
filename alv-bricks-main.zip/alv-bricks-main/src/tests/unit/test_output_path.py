"""Unit tests for the Spark-free structured output-path builder.

Covers the pure helper the report-run notebooks import to lay out a run's output
under ``<base>/<YYYYMMDD>/<alv_id>/<request_no>/`` (docs/OUTPUT_PATH_LAYOUT_APPROACH.md):
date stamping (via an injected ``now``), the segment order, base-slash hygiene,
``alv_id`` used verbatim as one opaque segment, and blank-input guards.
"""

import datetime
from zoneinfo import ZoneInfo

import pytest

from dbx_alv_reports import DATE_FORMAT, build_output_dir

pytestmark = pytest.mark.unit

BASE = "/Volumes/cat/sc/alv_outputs"
ALV_ID = "retail_ledger__detail__agent_item"
REQ = "REQ-1A2B3C4D5E6F"


def test_layout_order_and_date_stamp():
    now = datetime.datetime(2026, 8, 19, 10, 30, tzinfo=ZoneInfo("Asia/Kolkata"))
    out = build_output_dir(BASE, ALV_ID, REQ, now)
    assert out == f"{BASE}/20260819/{ALV_ID}/{REQ}"


def test_date_uses_the_localized_now_not_utc():
    # 2026-08-19 00:30 IST is still 2026-08-18 in UTC; the folder must reflect the
    # instant it is given (the notebook localizes to the report tz before calling us).
    ist = datetime.datetime(2026, 8, 19, 0, 30, tzinfo=ZoneInfo("Asia/Kolkata"))
    assert build_output_dir(BASE, ALV_ID, REQ, ist) == f"{BASE}/20260819/{ALV_ID}/{REQ}"


def test_alv_id_is_one_opaque_segment_never_split():
    now = datetime.datetime(2026, 1, 5, tzinfo=datetime.timezone.utc)
    out = build_output_dir(BASE, ALV_ID, REQ, now)
    # The double-underscore alv_id occupies exactly ONE path segment.
    segments = out[len(BASE) + 1 :].split("/")
    assert segments == ["20260105", ALV_ID, REQ]


def test_trailing_slash_on_base_is_trimmed():
    now = datetime.datetime(2026, 8, 19, tzinfo=datetime.timezone.utc)
    out = build_output_dir(BASE + "/", ALV_ID, REQ, now)
    assert "//" not in out.replace("/Volumes", "")  # no doubled separators
    assert out == f"{BASE}/20260819/{ALV_ID}/{REQ}"


def test_no_trailing_slash_on_result():
    now = datetime.datetime(2026, 8, 19, tzinfo=datetime.timezone.utc)
    assert not build_output_dir(BASE, ALV_ID, REQ, now).endswith("/")


def test_single_digit_month_and_day_zero_padded():
    now = datetime.datetime(2026, 3, 7, tzinfo=datetime.timezone.utc)
    assert build_output_dir(BASE, ALV_ID, REQ, now) == f"{BASE}/20260307/{ALV_ID}/{REQ}"


@pytest.mark.parametrize("bad_base", ["", "/", "///"])
def test_blank_base_rejected(bad_base):
    now = datetime.datetime(2026, 8, 19, tzinfo=datetime.timezone.utc)
    with pytest.raises(ValueError):
        build_output_dir(bad_base, ALV_ID, REQ, now)


def test_blank_alv_id_rejected():
    now = datetime.datetime(2026, 8, 19, tzinfo=datetime.timezone.utc)
    with pytest.raises(ValueError):
        build_output_dir(BASE, "", REQ, now)


def test_blank_request_no_rejected():
    now = datetime.datetime(2026, 8, 19, tzinfo=datetime.timezone.utc)
    with pytest.raises(ValueError):
        build_output_dir(BASE, ALV_ID, "", now)


def test_date_format_constant():
    assert DATE_FORMAT == "%Y%m%d"


# --- retention cleanup helpers ---------------------------------------------------

from dbx_alv_reports import expired_date_dirs, parse_date_dir  # noqa: E402

NOW = datetime.datetime(2026, 8, 19, 1, 0, tzinfo=ZoneInfo("Asia/Kolkata"))


def test_parse_date_dir_valid():
    assert parse_date_dir("20260819") == datetime.date(2026, 8, 19)


@pytest.mark.parametrize("bad", ["", "2026-08-19", "notadate", "202608", "20261301", "retail_ledger"])
def test_parse_date_dir_rejects_non_yyyymmdd(bad):
    assert parse_date_dir(bad) is None


def test_expired_keeps_recent_window_deletes_older():
    names = ["20260819", "20260818", "20260720", "20260101"]
    # retention 30 days -> cutoff = 2026-07-20; strictly older than cutoff is deleted.
    out = expired_date_dirs(names, NOW, 30)
    assert out == ["20260101"]  # 07-20 is the cutoff itself (kept), 08-18/19 recent


def test_expired_cutoff_is_strict_boundary_kept():
    # A folder exactly on the cutoff date is KEPT (strictly-older test).
    names = ["20260720"]  # cutoff for retention=30 on 2026-08-19
    assert expired_date_dirs(names, NOW, 30) == []


def test_expired_ignores_non_date_names():
    names = ["20260101", "_tmp", "retail_ledger__detail", "output.csv"]
    assert expired_date_dirs(names, NOW, 30) == ["20260101"]


def test_expired_retention_zero_keeps_only_today():
    names = ["20260819", "20260818"]
    assert expired_date_dirs(names, NOW, 0) == ["20260818"]


def test_expired_preserves_input_order():
    names = ["20260101", "20250101", "20240101"]
    assert expired_date_dirs(names, NOW, 30) == ["20260101", "20250101", "20240101"]


def test_expired_negative_retention_rejected():
    with pytest.raises(ValueError):
        expired_date_dirs(["20260101"], NOW, -1)


def test_expired_empty_list():
    assert expired_date_dirs([], NOW, 30) == []
