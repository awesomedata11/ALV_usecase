"""Unit tests for the report_permissions manifest validation + row derivation."""

import pytest

from dbx_alv_reports import PermissionSeeder

pytestmark = pytest.mark.unit


@pytest.fixture
def manifest(report_permissions_manifest_path):
    return PermissionSeeder.load_manifest(report_permissions_manifest_path)


def _entry(report_key="retail_ledger", group_name="alv-report_ledger_group", **extra):
    """A legacy group-shaped entry (group_name) — still accepted by the seeder."""
    return {"report_key": report_key, "group_name": group_name, **extra}


def _group(report_key="retail_ledger", principal_name="alv-report_ledger_group", **extra):
    return {"report_key": report_key, "principal_type": "group", "principal_name": principal_name, **extra}


def _user(report_key="retail_ledger", principal_name="user@example.com", **extra):
    return {"report_key": report_key, "principal_type": "user", "principal_name": principal_name, **extra}


# --- the real shipped manifest --------------------------------------------------
def test_shipped_manifest_validates_clean(manifest):
    errors, _ = PermissionSeeder.validate_manifest(manifest)
    assert errors == [], errors


def test_shipped_manifest_seeds_both_pilot_reports(manifest):
    rows = PermissionSeeder.build_rows(manifest)
    triples = {(r["report_key"], r["principal_type"], r["principal_name"]) for r in rows}
    assert triples == {
        ("retail_ledger", "group", "alv-report_ledger_group"),
        ("cc_recharge", "group", "alv-report_ledger_group"),
    }
    # Every shipped mapping is active, else the reports would ship invisible.
    assert all(r["is_active"] is True for r in rows)


def test_manifest_level_granted_by_is_inherited(manifest):
    rows = PermissionSeeder.build_rows(manifest)
    assert all(r["granted_by"] == manifest["granted_by"] for r in rows)


# --- derivation -----------------------------------------------------------------
def test_is_active_defaults_true():
    rows = PermissionSeeder.build_rows({"report_permissions": [_entry()]})
    assert rows[0]["is_active"] is True


def test_is_active_false_is_preserved():
    rows = PermissionSeeder.build_rows({"report_permissions": [_entry(is_active=False)]})
    assert rows[0]["is_active"] is False


def test_row_level_granted_by_overrides_manifest_level():
    rows = PermissionSeeder.build_rows(
        {"granted_by": "seed", "report_permissions": [_entry(granted_by="admin@example.com")]}
    )
    assert rows[0]["granted_by"] == "admin@example.com"


def test_granted_by_absent_is_none():
    rows = PermissionSeeder.build_rows({"report_permissions": [_entry()]})
    assert rows[0]["granted_by"] is None


def test_multiple_groups_per_report_allowed():
    """Multiple groups for one report is legal (OR semantics in the App)."""
    rows = PermissionSeeder.build_rows(
        {
            "report_permissions": [
                _entry(group_name="group-a"),
                _entry(group_name="group-b"),
            ]
        }
    )
    assert [r["principal_name"] for r in rows] == ["group-a", "group-b"]


# --- principal_type: group + user, and the legacy group_name shim ---------------
def test_legacy_group_name_entry_becomes_a_group_grant():
    """An older manifest using group_name still seeds, as a group grant."""
    rows = PermissionSeeder.build_rows({"report_permissions": [_entry()]})
    assert rows[0]["principal_type"] == "group"
    assert rows[0]["principal_name"] == "alv-report_ledger_group"


def test_explicit_group_grant_is_derived():
    rows = PermissionSeeder.build_rows({"report_permissions": [_group(principal_name="grp-x")]})
    assert (rows[0]["principal_type"], rows[0]["principal_name"]) == ("group", "grp-x")


def test_user_grant_email_is_lower_cased():
    """User emails are stored lower-cased so the gate can match case-folded."""
    rows = PermissionSeeder.build_rows(
        {"report_permissions": [_user(principal_name="Admin@Example.COM")]}
    )
    assert rows[0]["principal_type"] == "user"
    assert rows[0]["principal_name"] == "admin@example.com"


def test_user_and_group_grants_coexist():
    rows = PermissionSeeder.build_rows(
        {"report_permissions": [_group(), _user(report_key="cc_recharge")]}
    )
    kinds = {(r["report_key"], r["principal_type"]) for r in rows}
    assert kinds == {("retail_ledger", "group"), ("cc_recharge", "user")}


def test_bad_principal_type_is_error():
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [{"report_key": "retail_ledger",
                                 "principal_type": "bogus", "principal_name": "x"}]}
    )
    assert any("principal_type" in e for e in errors)


def test_user_grant_without_at_sign_warns():
    _, warnings = PermissionSeeder.validate_manifest(
        {"report_permissions": [_user(principal_name="not-an-email")]}
    )
    assert any("has no '@'" in w for w in warnings)


def test_same_email_different_case_is_duplicate():
    """User grants dedupe case-folded (they are matched case-folded)."""
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [_user(principal_name="a@x.com"), _user(principal_name="A@X.com")]}
    )
    assert any("duplicate" in e for e in errors)


# --- validation negatives (collect-all, fail-loud on build) ---------------------
def test_missing_array_is_error():
    errors, _ = PermissionSeeder.validate_manifest({})
    assert errors and "report_permissions" in errors[0]


def test_empty_array_is_error():
    errors, _ = PermissionSeeder.validate_manifest({"report_permissions": []})
    assert errors


def test_missing_report_key_is_error():
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [{"group_name": "g"}]}
    )
    assert any("report_key" in e for e in errors)


def test_missing_group_name_is_error():
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [{"report_key": "retail_ledger"}]}
    )
    assert any("group_name" in e for e in errors)


def test_non_slug_report_key_is_error():
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [_entry(report_key="retail ledger; DROP TABLE x")]}
    )
    assert any("not a valid slug" in e for e in errors)


def test_group_name_with_surrounding_whitespace_is_error():
    """A stray space would silently never match the /Me display name — fail loud."""
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [_entry(group_name=" alv-report_ledger_group ")]}
    )
    assert any("whitespace" in e for e in errors)


def test_duplicate_pair_is_error():
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [_entry(), _entry()]}
    )
    assert any("duplicate" in e for e in errors)


def test_collect_all_errors_not_just_the_first():
    errors, _ = PermissionSeeder.validate_manifest(
        {"report_permissions": [{}, {"report_key": "ok"}]}
    )
    # Entry 0 misses both keys, entry 1 misses group_name → at least 3 errors.
    assert len(errors) >= 3


def test_build_rows_raises_on_invalid_manifest():
    with pytest.raises(ValueError, match="manifest is invalid"):
        PermissionSeeder.build_rows({"report_permissions": [{"group_name": "g"}]})


def test_inactive_mapping_warns():
    _, warnings = PermissionSeeder.validate_manifest(
        {"report_permissions": [_entry(is_active=False)]}
    )
    assert any("is_active=false" in w for w in warnings)
