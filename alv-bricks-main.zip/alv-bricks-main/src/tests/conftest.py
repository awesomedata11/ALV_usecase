"""Minimal root conftest.

Kept intentionally small (CLAUDE.md “Testing & hygiene”): no Databricks/Spark imports
here so unit tests run in plain CI. Spark fixtures belong under
``tests/integration/conftest.py`` when integration tests are added.
"""

import os
from pathlib import Path

import pytest

# Deterministic timestamps in tests.
os.environ.setdefault("TZ", "UTC")

REPO_ROOT = Path(__file__).resolve().parents[1]
RETAIL_LEDGER_MANIFEST = REPO_ROOT / "report_specs" / "retail_ledger.input_fields.json"
CC_RECHARGE_MANIFEST = REPO_ROOT / "report_specs" / "cc_recharge.input_fields.json"
REPORT_PERMISSIONS_MANIFEST = REPO_ROOT / "report_specs" / "report_permissions.json"


@pytest.fixture
def manifest_path() -> str:
    return str(RETAIL_LEDGER_MANIFEST)


@pytest.fixture
def cc_recharge_manifest_path() -> str:
    return str(CC_RECHARGE_MANIFEST)


@pytest.fixture
def report_permissions_manifest_path() -> str:
    return str(REPORT_PERMISSIONS_MANIFEST)
