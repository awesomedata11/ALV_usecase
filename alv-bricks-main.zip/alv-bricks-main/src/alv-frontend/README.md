# ALV-Bricks — Databricks App (read path 3.x/4.x/5.x + submit 7.x)

The Databricks App for ALV-Bricks: a **FastAPI backend** + a **React/Vite frontend**.
The app opens on a **home page of ALV report cards** (screenshot 1); the active
Retail Ledger card drops into the **read path**: the app loads the deployed
`alv_catalog` metadata into an in-memory cache and renders a **metadata-driven
catalogue + selection-criteria form** with client-side validation. **Submit is now
wired** (tasks 7.1/7.2/7.4/7.5): it builds the Job parameter payload, persists a
`request_log` row, triggers the bound Job via `run-now`, and returns a `request_no`.
Status **polling** and output **download** are later tasks (8.x/9.x) and are NOT built
here (there is no status view yet).

This `src/alv-frontend/` tree is self-contained and separate from the metadata
library at `alv-backend/` (`dbx_alv_reports`, the DAB-only library). The app does **not**
import `dbx_alv_reports` — the Apps deploy source root is `src/alv-frontend/backend/` only, so
the library is never on the Apps runtime; instead `alv_app/fields.py` is a thin parser
honoring the same `input_fields.schema.json` contract (see its module docstring).

```
src/alv-frontend/
  backend/              FastAPI backend, managed with uv  ← DEPLOY SOURCE ROOT
    app.yaml            Databricks Apps manifest (lives at the deploy root)
    requirements.txt    Apps installs Python deps from THIS (not uv/pyproject)
    alv_app/
      main.py           FastAPI app + routes (/api/health, /api/me, /api/report-groups, /api/reports*, submit)
      config.py         env-driven settings (CATALOG / SCHEMA_NAME / warehouse id)
      identity.py       SSO-header identity + dev fallback
      databricks_client.py  app SP auth-check + jobs run-now trigger (submit path)
      catalog_source.py DATA SEAM: read alv_catalog via SDK statement-execution
      request_log.py    DATA SEAM: INSERT/UPDATE request_log (parameterized, submit path)
      submit.py         build Job param payload + canonical JSON + SHA-256 param_hash (7.1/7.2)
      fields.py         thin input_fields_json parser → render-ready FormField
      cache.py          in-memory metadata cache (parse once, keyed by alv_id; carries job_id)
      catalogue.py      shape cached rows → API response models (+ report groups)
      models.py         Pydantic response/request models
      db.py             Lakebase/psycopg factory (declared; unused)
    static/             built React SPA (Vite outDir) — served at / by FastAPI; committed
    pyproject.toml + uv.lock
    tests/              cache/endpoint/report-groups/submit tests (real 14-row single-report
                        AND 28-row two-report fixtures; mocked warehouse+run-now)
  frontend/             React + Vite + TypeScript + TanStack Query
    src/
      api/              fetch client (GET+POST) + typed TanStack hooks + response types
      components/       Header, HomePage (report cards), LeftNav, MainArea, ReportForm, FieldControl
      validation.ts     client-side validation from the metadata vocabulary (5.4)
      App.test.tsx      Vitest routing regression suite (card → correct report)
      setupTests.ts     Vitest setup: jest-dom matchers + auto-cleanup
      messages.ts       message_key → readable string map (5.4)
    (build outputs to ../backend/static — no dist/ here)
```

## Endpoints

**Read path (served from cache — no SQL on the render path):**

- `GET /api/report-groups` — the distinct seeded reports for the **home-page cards**:
  `(report_key, report_label, runnable_count)`. `runnable_count` counts active rows
  whose `job_id` is bound (0 until the job-binding step). Shape: `ReportGroupsOut`.
- `GET /api/reports` — the active catalogue, grouped for nav
  (`report_key` → selections → report types), ordered by `selection_order` /
  `report_type_order` / `report_key`. Shape: `CatalogueOut` in `alv_app/models.py`.

  | Param | Default | Notes |
  |---|---|---|
  | `report_key` | — | Optional. Scope the tree to **one** report, so `report_key` / `report_label` always identify it and the nav tree cannot mix two reports' selections. Trimmed and length-capped server-side; blank counts as absent. |

  Selections are keyed internally by **(`report_key`, `selection_id`)**: a
  `selection_id` is only unique *within* a report ("detail" exists under every one), so
  keying on it alone merged two reports' identically-named selections into one bucket.
  The emitted `selection_id` stays the bare id — the contract the frontend radio and
  `GET /api/reports/{alv_id}`'s `selection_id` share.

  Tree-level `report_key` / `report_label` are **`null`** when the tree is empty or spans
  several reports (an unscoped call for a user permitted more than one). There is no
  single owning report to name, and naming an arbitrary one mislabels the rest — pass
  `?report_key=` when you need them. The frontend always does.

  A supplied `report_key` that resolves to nothing this caller can see returns **`404`**,
  **identically** for a report that does not exist, one the caller is not permitted to
  see, and one whose rows are missing because the catalogue could not be loaded — so the
  gate cannot be used to discover that an unpermitted report exists. Never `403`. The
  **unscoped** call still degrades to an empty `selections` list rather than 404-ing, so
  the app shell always renders.
- `GET /api/reports/{alv_id}` — one report's **render-ready** form definition:
  fields ordered by `display_order`, controls + validations resolved. `404` on miss.

These serve from an in-memory cache warmed at startup from a **single** warehouse
read (`alv_app/cache.py`). A cold / stopped serverless warehouse auto-starts on that
first read; if the read fails the cache stays empty and the endpoints degrade
gracefully (empty catalogue / 404) rather than 500-ing.

**Submit path (tasks 7.1/7.2/7.4/7.5):**

- `POST /api/reports/{alv_id}/submit` — body `{ "values": { param_name: str } }`.
  1. **7.1** build the `{param_name: value}` Job payload from the field defs
     (honoring `normalize` / `omit_if_blank` / `default`) — `alv_app/submit.py`;
  2. **7.2** canonical JSON (stable key order) + SHA-256 `param_hash`;
  3. **7.4** INSERT a `QUEUED` `request_log` row (`alv_app/request_log.py`, warehouse
     statement-exec as the app SP — needs `MODIFY`), then `jobs run-now` on the bound
     `job_id` (`alv_app/databricks_client.py`) and UPDATE the row with the `run_id`;
  4. **7.5** return `request_no` immediately (non-blocking).
  - `409` when the report's `job_id` is `NULL` (not bound to a job yet); `404`
    unknown report; `502` on a warehouse-write or run-now failure.
  - Task 7.3 (cache lookup) and status polling (8.x) are intentionally NOT done here.
  - Grants the app SP needs for this path: see `docs/APP_PREREQUISITES.md`.

**Downloads path (`request_log` — status polling 8.x / output 9.x):**

- `GET /api/requests` — one **filtered, searched, sorted, paginated** page of
  `request_log` rows. All narrowing happens **in SQL, before the limit**
  (`alv_app/downloads.py`), so this is a page of the whole matching set. Query params,
  all optional and server-validated:

  | Param | Default | Notes |
  |---|---|---|
  | `scope` | `accessible` | `accessible` = every row for a report you may see, **including other users' rows** (intended — the report permission is what grants it). `mine` = only rows you submitted. |
  | `q` | — | Free-text search on the **report name**. The label lives in the metadata cache, not in `request_log`, so it is resolved to an `alv_id` allowlist and filtered in SQL — never client-side. |
  | `sort` | `submitted_at_desc` | Allowlisted: `submitted_at_desc` / `submitted_at_asc`. |
  | `limit` | `DOWNLOADS_PAGE_SIZE` (50) | Clamped to `DOWNLOADS_MAX_PAGE_SIZE` (200). |
  | `offset` | `0` | Rows to skip. |

  Response (`RequestsOut`) carries `requests` plus `limit` / `offset` / `has_more` /
  `scope` / `sort` / `q`. `has_more` is **exact** (the query fetches one row beyond the
  page and drops it — no second `COUNT(*)`), and `scope`/`sort` echo what the server
  actually applied (an unknown value falls back to the default). Every user-supplied
  value is a **bound parameter**; the `ORDER BY` comes from a fixed allowlist. A
  warehouse failure degrades to an empty page, never a 500.

  Rows are gated by the same `report_permissions` visibility as everything else, in
  **every** scope: the filter is an `alv_id` allowlist resolved from the
  permission-aware cache, so a row whose report you may not see — or whose `alv_id` no
  longer resolves — cannot match it. An empty allowlist serves an empty page **without
  querying**.

- `GET /api/requests/{request_no}/status` — the live run status, advancing
  `request_log` when it changed and capturing the output pointer on success (8.x/9.x).
- `GET /api/requests/{request_no}/params` — the **effective job payload** one run was
  dispatched with (`RequestParamsOut`). A dedicated endpoint, not a column on every
  list row: the payload is unbounded free text and only wanted for one expanded row.
  Behind the **same permission gate** as status/download (`404` on deny) — parameters
  are as sensitive as the file. A null / empty / malformed stored payload returns `200`
  with `parse_ok=false` and a reason rather than 500-ing.
  The payload is server-**normalized** with `omit_if_blank` params absent, so it is
  what the Job received — the UI labels it "Parameters sent to the job", not "what the
  user entered".
- `GET /api/requests/{request_no}/download` — the App-proxied UC Volume download
  (`404` unknown/denied, `409` no output yet, `422` non-Volume path, `502` read error).

`request_log.expires_at` is written as `generated_at + RESULT_TTL_DAYS` on the same
UPDATE that captures `generated_at`, so a COMPLETED run always carries both. It is
groundwork for a later result-cache feature — **nothing reads it yet**, and existing
rows are not backfilled.

## Deploy layout (source-code deploy)

The **deploy source root is `src/alv-frontend/backend/`**. Chosen so that:

- `alv_app` is importable at the root → `uvicorn alv_app.main:app` just works;
- there is **no `package.json` at the deploy root** (the Apps build runtime would
  otherwise auto-detect it and run `npm build`, which fails) — `package.json` lives
  only in `src/alv-frontend/frontend/`;
- the built SPA is reachable from the backend with **no copy/symlink step**: Vite's
  `outDir` is `../backend/static`, so `npm run build` (run from `src/alv-frontend/frontend/`)
  emits straight into the deploy root. `alv_app/main.py` mounts `./static` at `/`
  **after** the `/api/*` routes (via `StaticFiles(..., html=True)`), so `/` serves
  the shell and `/api/*` still resolve. The built `static/` is committed so the
  runtime command is just `uvicorn` (no build step on Apps; public npm is firewalled).

`app.yaml` binds `$DATABRICKS_APP_PORT` (fallback 8000) via an `sh -c` wrapper —
never a hardcoded port. `requirements.txt` at the deploy root pins the runtime deps
to `uv.lock` (Apps does not read `pyproject.toml`/`uv.lock`).

To deploy: build the frontend, then sync `src/alv-frontend/backend/` to a workspace path and
`databricks apps deploy alv-bricks --source-code-path <that path>`.

The shell layout loosely echoes the existing SAP ALV Retail Ledger screens: a top
**header** (brand + signed-in user), a left **nav** for report *selections*
(Detail / Sequence Wise / Time Wise / Agent Closing Balance — static placeholders),
and a **main content area** for the eventual selection-criteria form.

---

## Run locally

Two processes. Backend on `:8000`, frontend dev server on `:5173` (Vite proxies
`/api/*` to the backend).

### 1. Backend (uv) — against the live warehouse

The catalogue is read from the **already-deployed** metadata table
`classic_stable_lakebase_catalog.alv_metadata.alv_catalog` via the SQL warehouse
(`f399753196bda967`). Locally the SDK authenticates with the **`fevm-lakebase`**
profile. The warehouse may be STOPPED — the first read auto-starts it (a generous
`wait_timeout` covers the cold start), so the initial `/api/reports` may take a few
seconds.

```bash
cd src/alv-frontend/backend
uv sync
# Point at the deployed metadata + warehouse, and the SDK at the fevm-lakebase profile.
CATALOG=classic_stable_lakebase_catalog \
SCHEMA_NAME=alv_metadata \
DATABRICKS_WAREHOUSE_ID=f399753196bda967 \
DATABRICKS_CONFIG_PROFILE=fevm-lakebase \
  uv run uvicorn alv_app.main:app --reload --port 8000
```

(or copy `.env.example` → `.env` — it already carries these defaults — and just run
`uv run uvicorn alv_app.main:app --reload --port 8000`.)

Verify:

```bash
curl localhost:8000/api/health
curl localhost:8000/api/reports          # 14 reports grouped into 4 selections
curl localhost:8000/api/reports/retail_ledger__detail__agent_item   # one form def
```

Tests (**no workspace needed** — they mock the warehouse read with the real
`src/report_specs/retail_ledger.input_fields.json` fixture): `uv run pytest`.

> If your network requires the Databricks pip proxy, prefix with
> `UV_DEFAULT_INDEX="https://pypi-proxy.cloud.databricks.com/simple"`.
> Catalog/schema/warehouse are all env-configurable (`CATALOG`, `SCHEMA_NAME`,
> `DATABRICKS_WAREHOUSE_ID`) — nothing is hardcoded; `app.yaml` carries the deploy
> defaults.

### 2. Frontend (npm + Vite)

```bash
cd src/alv-frontend/frontend
npm install --registry=https://npm-proxy.cloud.databricks.com/   # public npm is firewalled
npm run dev          # http://localhost:5173
```

Build + typecheck (the acceptance check) — emits into `../backend/static`:

```bash
npm run build        # runs `tsc -b` then `vite build`
```

Tests (**Vitest** + jsdom + Testing Library — no backend needed, `fetch` is stubbed):

```bash
npm test             # vitest run (one pass); `npm run test:watch` to iterate
```

`src/App.test.tsx` is a **routing regression suite**: it renders the real `App` (real
router, real components, real hooks) over a fake two-report API, clicks a card by its
visible label, and asserts the `alv_id` the app resolves belongs to the report that was
clicked — for **both** reports. It is deliberately black-box, because the routing bug it
guards has recurred across five identity keys and each recurrence broke a different link
of the chain.

Open `http://localhost:5173` — the **home page** shows the ALV report cards
(`GET /api/report-groups`): one active card per seeded, permitted report plus greyed
"coming soon" placeholders. Clicking a card opens **that report's** catalogue UI at
`/report/<report_key>`: the left nav lists the report **selections** from
`GET /api/reports?report_key=<report_key>`; choosing a selection shows its **report
types** (radios); picking one loads that report's metadata-driven form
(`GET /api/reports/{alv_id}`) with fields ordered by `display_order`, defaults
applied, and client-side validation (mandatory, date-range span/offset, from≤to,
regex, max-length) driven by the metadata `validations` vocabulary. **Submit** posts
the form values to `POST /api/reports/{alv_id}/submit` once client-side validation
passes and shows the returned `request_no` + `QUEUED` state (no status polling yet).
Submitting needs the row's `job_id` bound (else a clean 409) — see
`docs/APP_PREREQUISITES.md`. The brand in the header links back to the home cards.

### Report URLs

The report key is the **first** path segment and the `alv_id` an optional **second**:

| URL | Resolves to |
|---|---|
| `/report/<report_key>` | that report, auto-picking its first selection's first report type |
| `/report/<report_key>/<alv_id>` | that report type, within that report |
| `/report/<alv_id>` (legacy) | looked up, then replace-navigated to the two-segment URL |
| `/report` | redirects **home** — with several reports permitted there is no defensible "first" one |

Two segments in a fixed order, so react-router matches on **position** and the two ids
are never told apart by inspecting them. Sniffing a single shared segment by shape was
rejected: `alv_id`'s `report_key__…` form is a **seeding convention, not a contract**
(`alv_app/cache.py`, `alv_app/downloads.py` both say so), so parsing separators would be
a guess that breaks the first time a spec author writes an `alv_id` by hand. The legacy
one-segment route resolves its segment by **asking the backend** — as a `report_key`
first, then as an `alv_id` whose `report_key` field is authoritative — rather than
guessing.

---

## Environment variables

Backend config is env-var driven (`alv_app/config.py`); no secrets are committed.
Copy `backend/.env.example` → `backend/.env` for local overrides.

| Var | Default | Purpose |
|---|---|---|
| `DEV_MODE` | `true` | When true, `/api/me` uses a fixed dev identity if no SSO headers are present (local dev). Set `false` when deployed. |
| `DEV_USER_EMAIL` / `DEV_USER_NAME` | `local.dev@example.com` / `Local Developer` | The dev-fallback identity. |
| `CATALOG` / `SCHEMA_NAME` | `alv_bricks` / `metadata` | Unity Catalog location of `alv_catalog`. Set to `classic_stable_lakebase_catalog` / `alv_metadata` for the deployed pilot metadata (see `app.yaml` / `.env.example`). |
| `DATABRICKS_WAREHOUSE_ID` | — | SQL warehouse id used to read `alv_catalog` (SDK statement-execution). Required locally (pilot: `f399753196bda967`); wired via `app.yaml` `valueFrom: sql-warehouse` on deploy. |
| `PGHOST` / `PGPORT` / `PGDATABASE` / `PGUSER` / `PGPASSWORD` / `PGSSLMODE` | — / `5432` / — / — / — / `require` | Lakebase/Postgres for the psycopg connection factory (declared only; no queries yet). Auto-injected on deploy when a Lakebase resource is attached. |
| `DATABRICKS_HOST` / `DATABRICKS_CLIENT_ID` / `DATABRICKS_CLIENT_SECRET` | — | App service-principal OAuth creds. **Auto-injected on deploy** — do not set by hand. Locally the SDK can use a `databricks auth login` profile instead. |
| `RESULT_TTL_DAYS` | `7` | Result retention: `request_log.expires_at = generated_at + this`, written on the same path that captures `generated_at`. Groundwork for the later result-cache feature; nothing reads the column yet. Optional — the default is the intended value. |
| `DOWNLOADS_PAGE_SIZE` | `50` | Default page size for `GET /api/requests`. Optional. |
| `DOWNLOADS_MAX_PAGE_SIZE` | `200` | Hard cap a client-supplied `?limit=` is clamped to, so a crafted query can't ask for the whole table. Optional. |
| `VITE_BACKEND_URL` (frontend) | `http://localhost:8000` | Dev-proxy target for `/api/*`. |

---

## The SSO-header identity contract

Databricks Apps runs behind a Databricks-managed reverse proxy. Users authenticate
via Databricks **SSO**; once the session exists, the proxy injects the authenticated
user's identity into **every** request forwarded to the app as HTTP headers. The app
does **no** login of its own — it trusts these headers because the platform sets
them and the client cannot bypass the proxy.

Headers read by the backend (`alv_app/identity.py`; Starlette lower-cases them):

| Header | Mapped to | Notes |
|---|---|---|
| `X-Forwarded-Email` | `email` | User's email. |
| `X-Forwarded-Preferred-Username` | `preferred_username` | Preferred username / UPN. |
| `X-Forwarded-User` | `user_id` | Stable user id (SCIM/AAD object id). |
| `X-Forwarded-Access-Token` | `has_user_token` (presence only) | User's on-behalf-of OAuth token. **Secret** — never logged or returned; only its presence is surfaced. Present only when user authorization (OBO) is enabled with scopes. |
| `X-Real-Ip` | `real_ip` | Originating client IP. |

`GET /api/me` returns these fields plus an app **service-principal** auth-check:
`Config()` (Databricks SDK) auto-detects the injected SP OAuth creds and the backend
calls `current_user.me()` to prove app auth works
(`service_principal` / `service_principal_ok`). App auth (SP) is for shared
operations; user auth (OBO) is for per-user access — see the databricks-app-python
skill, `1-authorization.md`.

**Local behavior:** there is no proxy locally, so these headers are absent. With
`DEV_MODE=true` (default) `/api/me` returns the dev-fallback identity
(`authenticated: false`); you can also simulate a real request by sending the headers
yourself, e.g. `curl -H "X-Forwarded-Email: you@ril.com" localhost:8000/api/me`.

---

## Two auth models (summary)

- **App authorization (service principal).** Each app gets a dedicated SP; Databricks
  injects `DATABRICKS_CLIENT_ID` / `DATABRICKS_CLIENT_SECRET`. The SDK `Config()` /
  `WorkspaceClient()` pick these up with no code — used for shared data access, the
  Jobs API dispatch, and `request_log` writes in later tasks.
- **User authorization (on-behalf-of).** The `X-Forwarded-Access-Token` header carries
  the user's token so the app can act as the user (Unity Catalog row/column filters,
  audit). Public Preview — a workspace admin must enable it and select OAuth scopes.

---

## How it deploys as a Databricks App (source-code deploy)

The app deploys via the **source-code** pattern: push files to a workspace path,
then tell Apps to deploy from that path. `src/alv-frontend/backend/` is the **deploy source
root** (see "Deploy layout" above). The full step-by-step runbook — including
common pitfalls — is in **`docs/APP_DEPLOY_RUNBOOK.md`**. Quick reference below.

### First-time setup

```bash
# 1. Build the frontend (public npm is firewalled — use the Databricks proxy)
cd src/alv-frontend/frontend
npm install --registry=https://npm-proxy.cloud.databricks.com/
npm run build          # emits into ../backend/static/; commit the result

# 2. Create the app (once only)
databricks apps create alv-bricks -p fevm-lakebase

# 3. Upload source to workspace (first time — use workspace import per file;
#    do NOT use import-dir — it will upload .venv; see pitfalls below)
databricks workspace mkdirs \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
# Then upload each file individually (see docs/APP_DEPLOY_RUNBOOK.md)

# 4. Deploy
databricks apps deploy alv-bricks \
  --source-code-path "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
```

### Updating the deployed app (iterative deploys)

For each feature iteration:

```bash
# 1. Rebuild the frontend if any frontend files changed
cd src/alv-frontend/frontend && npm run build

# 2. Upload only the changed files — one file at a time with --format RAW
cd /path/to/repo
databricks workspace import \
  --file "src/alv-frontend/backend/alv_app/<changed_file>.py" \
  --format RAW --overwrite \
  "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src/alv_app/<changed_file>.py" \
  -p fevm-lakebase

# 3. Deploy (app must be RUNNING; start it first if STOPPED)
databricks apps deploy alv-bricks \
  --source-code-path "/Workspace/Users/idris.chakera@databricks.com/alv-frontend-src" \
  -p fevm-lakebase
```

### ⚠ Critical pitfalls — read before touching the workspace

| Pitfall | What happens | Fix |
|---|---|---|
| **`workspace import-dir` uploads `.venv`** | The `.venv/` directory (hundreds of MB, binary `.so` files) gets pushed into the workspace. The next `apps deploy` fails with `permission denied` trying to snapshot it. | **Never use `workspace import-dir` on `src/alv-frontend/backend/`**. Use `workspace import --format RAW --overwrite` per file, or `databricks sync` (which respects `.gitignore`). |
| **Deploying with `.venv` already in workspace** | `apps deploy` fails: `error updating files: failed to create file python/source_code/.venv/bin/python: open … permission denied` | Delete `.venv` from the workspace first: `databricks workspace delete "/Workspace/…/alv-frontend-src/.venv" --recursive -p fevm-lakebase`, then redeploy. |
| **App in STOPPED state** | `apps deploy` returns `Cannot deploy app alv-bricks as it is not in RUNNING state` | Run `databricks apps start alv-bricks -p fevm-lakebase` and wait for `compute: ACTIVE` before deploying. |
| **Pending deployment lock** | `Cannot deploy … there is a pending deployment in progress for less than 20 minutes` | Wait ~20 min, or use `--force-lock` flag. |
| **`static/` assets not updated** | Old JS/CSS filenames (Vite content-hash) remain in workspace; browser serves stale bundle | Upload all three new static files after `npm run build`: `static/index.html`, `static/assets/index-<hash>.js`, `static/assets/index-<hash>.css`. Delete the old hashed assets from the workspace. |
| **`requirements.txt` not updated** | New Python dependency added to `pyproject.toml` but not reflected in `requirements.txt`; Apps installs from `requirements.txt` only | Run `uv pip compile pyproject.toml -o src/alv-frontend/backend/requirements.txt` and upload the updated file. |

See **`docs/APP_DEPLOY_RUNBOOK.md`** for the full annotated runbook with verification
steps and recovery procedures.

Grounding: Databricks skills `databricks-app-python` (auth, deployment) and
`databricks-app-apx` (FastAPI + React full-stack pattern).
