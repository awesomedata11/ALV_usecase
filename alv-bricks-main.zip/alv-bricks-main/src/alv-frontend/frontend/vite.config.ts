// defineConfig comes from vitest/config (a superset of vite's — it re-exports the Vite
// config type plus the `test` key), so the Vitest block below typechecks under `tsc -b`.
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

// Backend port for the local dev proxy. Matches the FastAPI backend (uvicorn :8000).
const BACKEND = process.env.VITE_BACKEND_URL ?? "http://localhost:8000";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    // Emit the built SPA into the backend deploy root (app/backend/static) so the
    // FastAPI static mount serves it in production with no copy/symlink step. The
    // built assets are committed so the Databricks Apps runtime command is just
    // uvicorn (no build step there — public npm is firewalled anyway).
    outDir: "../backend/static",
    emptyOutDir: true,
  },
  // Vitest. jsdom because the tests render the real router + components; `globals`
  // so `describe`/`it`/`expect` need no import (matching the pytest-style suites on the
  // backend). Only *.test.tsx under src/ is collected — node_modules and the built
  // ../backend/static bundle are never scanned.
  test: {
    environment: "jsdom",
    globals: true,
    include: ["src/**/*.test.{ts,tsx}"],
    setupFiles: ["./src/setupTests.ts"],
  },
  server: {
    port: 5173,
    // Proxy /api/* to the FastAPI backend so the FE can call it same-origin in dev.
    // In production on Databricks Apps the backend serves both API and static build,
    // so no proxy is needed there.
    proxy: {
      "/api": {
        target: BACKEND,
        changeOrigin: true,
      },
    },
  },
});
