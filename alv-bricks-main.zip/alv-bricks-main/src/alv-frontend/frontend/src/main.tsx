import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter } from "react-router-dom";
import { App } from "./App";
import { FormDraftProvider } from "./formDraft";
import { isClientError } from "./api/client";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Retry transient (network / 5xx) failures once, but NEVER a 4xx: a 404 from the
      // permission gate is a definitive answer, and retrying it is what made a denied
      // report hang on "Opening report…".
      retry: (failureCount, error) => !isClientError(error) && failureCount < 1,
      refetchOnWindowFocus: false,
    },
  },
});

// HashRouter (not BrowserRouter) on purpose: the FastAPI backend serves the SPA via
// StaticFiles(html=True), which 404s any deep path it can't find as a file. A hash
// route ("/#/report/…") keeps the server seeing only "/", so deep links and full
// reloads work with NO backend change, while still giving real history entries so
// browser Back/Forward walk the in-app view history.
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <FormDraftProvider>
          <App />
        </FormDraftProvider>
      </HashRouter>
    </QueryClientProvider>
  </React.StrictMode>,
);
