// Theme state — light/dark toggle persisted in localStorage.
//
// The chosen theme is applied as a `data-theme` attribute on <html>; the CSS
// tokens in index.css re-declare the color palette under [data-theme="dark"].
// On first load we respect the OS `prefers-color-scheme` (falling back to
// light), then persist whatever the user picks. An inline script in index.html
// applies the stored theme BEFORE React mounts to avoid a flash-of-wrong-theme.
import { useCallback, useEffect, useState } from "react";

export type Theme = "light" | "dark";

const STORAGE_KEY = "alv-theme";

// Resolve the initial theme: stored preference wins; otherwise the OS setting;
// otherwise light. Safe if localStorage/matchMedia are unavailable.
export function getInitialTheme(): Theme {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === "light" || stored === "dark") return stored;
    if (window.matchMedia?.("(prefers-color-scheme: dark)").matches) return "dark";
  } catch {
    /* no-op — default to light below */
  }
  return "light";
}

function applyTheme(theme: Theme) {
  document.documentElement.setAttribute("data-theme", theme);
}

export function useTheme(): { theme: Theme; toggleTheme: () => void } {
  const [theme, setTheme] = useState<Theme>(getInitialTheme);

  // Keep the <html> attribute and localStorage in sync with state.
  useEffect(() => {
    applyTheme(theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      /* ignore persistence failures (e.g. private mode) */
    }
  }, [theme]);

  const toggleTheme = useCallback(
    () => setTheme((t) => (t === "dark" ? "light" : "dark")),
    [],
  );

  return { theme, toggleTheme };
}
