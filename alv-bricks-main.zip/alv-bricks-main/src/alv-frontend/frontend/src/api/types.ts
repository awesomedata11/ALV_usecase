// API response types — mirror the backend Pydantic models (alv_app/models.py).
// Kept hand-written for the skeleton; a later task may generate these from OpenAPI.

export interface Health {
  status: string;
  app: string;
  version: string;
}

export interface Me {
  email: string | null;
  preferred_username: string | null;
  user_id: string | null;
  real_ip: string | null;
  authenticated: boolean;
  has_user_token: boolean;
  // Whether this caller may use the admin console (ALV_ADMINS gate). Only shows/hides
  // the Admin nav; the endpoints enforce independently (404 for a non-admin).
  is_admin: boolean;
  service_principal: string | null;
  service_principal_ok: boolean;
  service_principal_detail: string | null;
}

// --- Admin console (report_permissions grant/revoke) --------------------------
export interface Grant {
  report_key: string;
  principal_type: "group" | "user";
  principal_name: string;
  is_active: boolean;
  granted_by: string | null;
}

export interface GrantsList {
  report_key: string;
  grants: Grant[];
}

// Per-token result of a grant/revoke — outcome is one of granted/revoked/invalid.
export interface GrantTokenResult {
  token: string;
  principal_type: "group" | "user" | null;
  principal_name: string | null;
  outcome: "granted" | "revoked" | "invalid";
  detail: string | null;
}

export interface GrantResult {
  report_key: string;
  results: GrantTokenResult[];
  grants: Grant[];
}

// --- Admin report onboarding (paste manifest → alv_catalog) --------------------
// Result of a successful onboard. `report_keys` / `alv_ids` echo what was added;
// `warnings` surfaces non-fatal notes (e.g. a placeholder job_id stored NULL/unbound).
// `detail` is the message to show — crucially that the report is added but still HIDDEN
// until access is granted (visibility is deny-by-default; onboarding never auto-grants).
export interface OnboardResult {
  ok: boolean;
  row_count: number;
  report_keys: string[];
  alv_ids: string[];
  warnings: string[];
  detail: string;
}

// --- Home page report groups (report cards) -----------------------------------
export interface ReportGroup {
  report_key: string;
  report_label: string | null;
  runnable_count: number;
}

export interface ReportGroups {
  groups: ReportGroup[];
}

// --- Catalogue + form definition (tasks 3.2/4.x/5.x) --------------------------
// Mirror the backend Pydantic models (alv_app/models.py + alv_app/fields.py).

export interface ReportType {
  report_type_code: string | null;
  report_type_label: string | null;
  report_type_order: number | null;
  alv_id: string;
  alv_name: string | null;
  description: string | null;
}

export interface Selection {
  selection_id: string;
  selection_label: string | null;
  selection_order: number | null;
  report_types: ReportType[];
}

// The nav tree. report_key/report_label identify the ONE report the tree describes,
// and are null when it is empty or spans several (an unscoped GET /api/reports for a
// user permitted more than one report). Request it scoped — useCatalogue(reportKey) —
// whenever you need them; never fall back to a hardcoded label.
export interface Catalogue {
  report_key: string | null;
  report_label: string | null;
  selections: Selection[];
}

// A validation rule from the metadata vocabulary (docs/CONFIGURATION_GUIDE.md §4).
export interface FieldValidation {
  rule:
    | "from_lte_to"
    | "max_span"
    | "max_offset_from_today"
    | "to_required_if_from"
    | "no_filter_when_equal"
    | "regex"
    | "max_length";
  message_key: string;
  applies_to?: "from" | "to" | null;
  unit?: "days" | "months" | "years" | null;
  value?: number | null;
  pattern?: string | null;
}

export interface FieldPart {
  param_name: string;
  display_label: string;
  default?: unknown;
}

export interface FormField {
  kind: "scalar" | "composite";
  control: "text" | "date" | "date_range" | "time_range";
  data_type: "string" | "date" | "time";
  display_label: string;
  display_order: number;
  mandatory: boolean;
  validations: FieldValidation[];
  // scalar-only
  param_name?: string | null;
  selection_type?: "single" | "multi" | null;
  default?: unknown;
  omit_if_blank?: boolean | null;
  normalize?: string[];
  allowed_values?: unknown[] | null;
  // composite-only
  parts?: { from: FieldPart; to: FieldPart } | null;
}

export interface ReportForm {
  alv_id: string;
  report_key: string;
  report_label: string | null;
  selection_id: string;
  selection_label: string | null;
  report_type_code: string | null;
  report_type_label: string | null;
  alv_name: string | null;
  description: string | null;
  fields: FormField[];
  has_sample_query?: boolean;
}

// --- Submit (tasks 7.1/7.2/7.4/7.5) -------------------------------------------
export interface SubmitIn {
  values: Record<string, string>;
}

export interface SubmitOut {
  request_no: string;
  alv_id: string;
  run_id: number | null;
  status: string;
  param_hash: string;
}

// --- Result cache reuse (task 7.3) --------------------------------------------
// A reusable prior run for the same report + parameters. It is the LATEST qualifying
// run when several exist. `submitted_by`/`generated_at` are shown in the reuse popup
// (cross-user reuse is intended, so this may be a different user). The raw output path
// is never sent — the download is App-proxied by request_no; `has_output` only confirms
// a pointer exists.
export interface CacheHit {
  request_no: string;
  submitted_by: string | null;
  generated_at: string | null;
  expires_at: string | null;
  row_count: number | null;
  has_output: boolean;
}

// Response to a pre-submit cache check. `hit` is null when there is nothing to reuse
// (or the cache read failed) — the frontend then proceeds to a normal submit.
export interface CacheCheck {
  alv_id: string;
  param_hash: string;
  hit: CacheHit | null;
}

// --- Downloads (request_log list) ---------------------------------------------
export interface RequestRow {
  request_no: string;
  alv_id: string | null;
  report_label: string | null;
  status: string | null;
  submitted_by: string | null;
  submitted_at: string | null;
  run_id: number | null;
  output_path: string | null;
}

// One page of request_log rows. Filtering / search / sort / pagination all happen
// server-side (in SQL), so this is a page of the whole matching set — never a
// client-side slice. `has_more` is exact, so "Next" needs no separate count.
// scope/sort/q are echoed back AS THE SERVER RESOLVED THEM (an unknown scope or sort
// falls back to the default), which is how the UI knows what was actually applied.
export interface Requests {
  requests: RequestRow[];
  limit: number;
  offset: number;
  has_more: boolean;
  scope: RequestScope;
  sort: RequestSort;
  q: string | null;
}

// "accessible" = every run for a report I can see, including other users' runs
// (intended: the report permission is what grants it). "mine" = only my own runs.
export type RequestScope = "accessible" | "mine";

export type RequestSort = "submitted_at_desc" | "submitted_at_asc";

export interface RequestsQuery {
  scope: RequestScope;
  q: string;
  sort: RequestSort;
  limit: number;
  offset: number;
}

// --- Run parameters info view --------------------------------------------------
// `parameters` is the EFFECTIVE JOB PAYLOAD: server-normalized, with omit_if_blank
// params absent entirely. It is what the Job received, not a transcript of what the
// user typed — the UI must label it that way. `parse_ok` is false when the stored
// payload was null/empty/malformed (an old row), in which case `detail` says why.
export interface RequestParams {
  request_no: string;
  alv_id: string | null;
  report_label: string | null;
  submitted_at: string | null;
  param_hash: string | null;
  parameters: Record<string, string | null>;
  parse_ok: boolean;
  detail: string | null;
}

// --- Parameter templates (variants) -------------------------------------------
// A template is a named snapshot of the RAW form values for ONE report type (alv_id),
// owned by the current user. `values` is the same flat map the form holds and submit/
// preview post — loading a template sets it directly.
//
// A DYNAMIC template additionally marks some DATE fields as relative-date presets
// (value_kinds). On load the backend resolves those presets to concrete dates (in the
// report timezone) and returns them in `values`, so the frontend still just fills the
// form; `value_kinds` comes back too so the UI can badge dynamic fields and re-open the
// save editor with the right presets selected.

// The relative-date presets a dynamic field may use (mirrors alv_app/dynamic_values.py).
export type DynamicPreset =
  | "TODAY"
  | "CUR_DATE_PLUS_N_DAYS"
  | "FIRST_DAY_CUR_MONTH"
  | "LAST_DAY_CUR_MONTH"
  | "FIRST_DAY_NEXT_MONTH"
  | "LAST_DAY_NEXT_MONTH"
  | "FIRST_DAY_PREV_MONTH"
  | "LAST_DAY_PREV_MONTH";

// One field's dynamic rule. `n` is present only for CUR_DATE_PLUS_N_DAYS (± days).
export interface DynamicKind {
  kind: "dynamic";
  preset: DynamicPreset;
  n?: number;
}

// The value_kinds map: only the dynamic fields appear (everything else is static).
export type ValueKinds = Record<string, DynamicKind>;

export interface TemplateSummary {
  template_id: string;
  // The report type this template fills — the report-wide list shows its labels and Load
  // navigates here.
  alv_id: string;
  template_name: string;
  selection_label: string | null;
  report_type_label: string | null;
  created_at: string | null;
  updated_at: string | null;
  is_dynamic: boolean;
}

export interface TemplatesList {
  alv_id: string;
  templates: TemplateSummary[];
}

export interface TemplateDetail {
  template_id: string;
  alv_id: string;
  template_name: string;
  values: Record<string, string>;
  value_kinds: ValueKinds;
}

export interface SaveTemplateIn {
  template_name: string;
  values: Record<string, string>;
  value_kinds?: ValueKinds;
}

// --- Sample data preview -------------------------------------------------------
export interface PreviewIn {
  values: Record<string, string>;
}

export interface PreviewOut {
  columns: string[];
  rows: unknown[][];
  row_count: number;
  truncated: boolean;
}

// --- Output-file preview (a completed run's result FILE, read off the Volume) --
// The on-screen twin of Download — NOT the SQL "Preview Sample Data" above. `format`
// selects the render: "csv" ⇒ columns+rows table; "text" ⇒ raw `text` block; "binary"
// ⇒ no body (unpreviewable file type).
export interface OutputPreview {
  format: "csv" | "text" | "binary";
  columns: string[];
  rows: unknown[][];
  text: string | null;
  row_count: number;
  truncated: boolean;
  filename: string;
}

// --- Status polling (task 8.x) ------------------------------------------------
export interface RequestStatus {
  request_no: string;
  status: string | null;
  run_id: number | null;
  updated: boolean;
  // Set once a SUCCESS run's output pointer is captured (task 9.x) — lets the
  // Downloads page enable the download the moment polling resolves to COMPLETED.
  output_path: string | null;
}
