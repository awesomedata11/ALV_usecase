// An HTTP error carrying the status code, so callers (and the query retry policy) can
// tell a definitive 4xx (e.g. 404 "not permitted / not found") from a transient 5xx.
export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

// Whether an error is a client (4xx) error — those are definitive answers, so retrying
// them just delays the inevitable (this is what made a denied report hang on a 404).
export function isClientError(err: unknown): boolean {
  return err instanceof ApiError && err.status >= 400 && err.status < 500;
}

// Thin fetch wrapper. Calls are same-origin (`/api/...`): in dev the Vite proxy
// forwards to the FastAPI backend; in production the app serves API + static build
// from the same origin.
export async function apiGet<T>(path: string): Promise<T> {
  const resp = await fetch(path, { headers: { Accept: "application/json" } });
  if (!resp.ok) {
    throw new ApiError(resp.status, `GET ${path} failed: ${resp.status} ${resp.statusText}`);
  }
  return (await resp.json()) as T;
}

// POST JSON. On error, prefer the backend's `detail` message (FastAPI HTTPException)
// so the UI can show e.g. "report not bound to a job yet" verbatim.
export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const resp = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    let detail = `${resp.status} ${resp.statusText}`;
    try {
      const data = await resp.json();
      if (data && typeof data.detail === "string") detail = data.detail;
    } catch {
      /* non-JSON error body — keep the status text */
    }
    throw new ApiError(resp.status, detail);
  }
  return (await resp.json()) as T;
}

// DELETE. Same error handling as apiPost (prefer the backend's `detail`).
export async function apiDelete<T>(path: string): Promise<T> {
  const resp = await fetch(path, {
    method: "DELETE",
    headers: { Accept: "application/json" },
  });
  if (!resp.ok) {
    let detail = `${resp.status} ${resp.statusText}`;
    try {
      const data = await resp.json();
      if (data && typeof data.detail === "string") detail = data.detail;
    } catch {
      /* non-JSON error body — keep the status text */
    }
    throw new ApiError(resp.status, detail);
  }
  return (await resp.json()) as T;
}
