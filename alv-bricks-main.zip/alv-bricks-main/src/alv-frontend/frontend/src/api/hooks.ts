// TanStack Query hooks. The sample `useMe` hook hits /api/me to prove FE<->BE wiring.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError, apiDelete, apiGet, apiPost } from "./client";
import type {
  CacheCheck,
  Catalogue,
  GrantResult,
  GrantsList,
  Health,
  Me,
  OnboardResult,
  OutputPreview,
  PreviewIn,
  PreviewOut,
  ReportForm,
  ReportGroups,
  RequestParams,
  RequestStatus,
  Requests,
  RequestsQuery,
  SaveTemplateIn,
  SubmitIn,
  SubmitOut,
  TemplateDetail,
  TemplatesList,
  TemplateSummary,
} from "./types";

export function useMe() {
  return useQuery({
    queryKey: ["me"],
    queryFn: () => apiGet<Me>("/api/me"),
  });
}

export function useHealth() {
  return useQuery({
    queryKey: ["health"],
    queryFn: () => apiGet<Health>("/api/health"),
  });
}

// Home page — the distinct seeded reports backing the ACTIVE report cards.
export function useReportGroups() {
  return useQuery({
    queryKey: ["report-groups"],
    queryFn: () => apiGet<ReportGroups>("/api/report-groups"),
    staleTime: 5 * 60 * 1000,
  });
}

// Task 4.1 — the active catalogue (selection → report types), loaded once.
//
// Pass a reportKey to get the catalogue SCOPED to that one report
// (`?report_key=…`). The report view always scopes: an unscoped tree spans every
// report the user may see, so resolving "the first selection's first report type"
// against it lands in whichever report happens to sort first — the report-routing
// bug. A scoped tree makes that auto-pick correct by construction, and its
// report_key/report_label always identify the report on screen.
//
// The key is part of the queryKey, so each report's tree caches separately and
// switching back to one is instant. A reportKey the user may not see (or that does
// not exist) 404s — indistinguishable by design (see the backend endpoint docstring).
export function useCatalogue(reportKey?: string | null) {
  const key = reportKey ?? null;
  const path = key
    ? `/api/reports?report_key=${encodeURIComponent(key)}`
    : "/api/reports";
  return useQuery({
    queryKey: ["reports", key],
    queryFn: () => apiGet<Catalogue>(path),
    staleTime: 5 * 60 * 1000, // metadata changes rarely; avoid refetch churn
  });
}

// Task 4.2 — one report's render-ready form def; enabled only once an alv_id is picked.
export function useReportForm(alvId: string | null) {
  return useQuery({
    queryKey: ["report", alvId],
    queryFn: () => apiGet<ReportForm>(`/api/reports/${alvId}`),
    enabled: !!alvId,
    staleTime: 5 * 60 * 1000,
  });
}

// Downloads page — one SERVER-FILTERED page of request_log rows. scope / search /
// sort / paging are all query params the backend applies in SQL before its limit, so
// the hook never filters client-side. The whole query is part of the queryKey, so
// each distinct view is cached separately and paging back is instant.
//
// Short staleTime so re-opening the page picks up newly submitted runs without
// hammering the warehouse; placeholderData keeps the previous page's rows on screen
// while the next one loads (no flash of empty table between pages).
export function useRequests(query: RequestsQuery) {
  const params = new URLSearchParams({
    scope: query.scope,
    sort: query.sort,
    limit: String(query.limit),
    offset: String(query.offset),
  });
  // Only send q when there is one — an empty param would echo back as a "search".
  if (query.q.trim()) params.set("q", query.q.trim());

  return useQuery({
    queryKey: ["requests", query.scope, query.sort, query.q.trim(), query.limit, query.offset],
    queryFn: () => apiGet<Requests>(`/api/requests?${params.toString()}`),
    staleTime: 30 * 1000,
    placeholderData: (previous) => previous,
  });
}

// The parameters one run was dispatched with. Fetched lazily — `enabled` is false
// until the user actually opens a row's info view, so expanding one row never costs
// a request for the other 49. The payload is immutable once written, so it is cached
// indefinitely (no staleTime churn on repeated open/close).
export function useRequestParams(requestNo: string | null) {
  return useQuery({
    queryKey: ["request-params", requestNo],
    queryFn: () => apiGet<RequestParams>(`/api/requests/${encodeURIComponent(requestNo!)}/params`),
    enabled: !!requestNo,
    staleTime: Infinity,
  });
}

// The on-screen preview of a completed run's OUTPUT FILE (read off the Volume, no SQL).
// A completed run's output is immutable, so it's cached indefinitely; enabled only once
// a request_no is present (the preview screen always has one from the route).
export function useOutputPreview(requestNo: string | null) {
  return useQuery({
    queryKey: ["output-preview", requestNo],
    queryFn: () =>
      apiGet<OutputPreview>(
        `/api/requests/${encodeURIComponent(requestNo!)}/output-preview`,
      ),
    enabled: !!requestNo,
    staleTime: Infinity,
  });
}

// Task 8.x — poll one request's live status. Enabled only while the row is
// non-terminal (QUEUED/RUNNING); refetches on an interval and stops once terminal
// (the endpoint advances request_log.status server-side when the run state changes).
const TERMINAL = new Set(["SUCCESS", "SUCCEEDED", "COMPLETED", "FAILED", "ERROR", "CANCELLED", "CANCELED"]);

export function isTerminalStatus(status: string | null | undefined): boolean {
  return TERMINAL.has((status ?? "").toUpperCase());
}

export function useRequestStatus(requestNo: string, currentStatus: string | null) {
  const active = !isTerminalStatus(currentStatus);
  return useQuery({
    queryKey: ["request-status", requestNo],
    queryFn: () => apiGet<RequestStatus>(`/api/requests/${requestNo}/status`),
    enabled: active,
    // Poll every 5s while non-terminal; stop once the live status is terminal.
    refetchInterval: (query) =>
      isTerminalStatus(query.state.data?.status) ? false : 5000,
  });
}

// Task 7.x — submit a report run; returns the request_no + run_id (non-blocking).
export function useSubmitReport(alvId: string) {
  return useMutation({
    mutationFn: (body: SubmitIn) =>
      apiPost<SubmitOut>(`/api/reports/${alvId}/submit`, body),
  });
}

// Task 7.3 — pre-submit result-cache check. Given the same form values a submit would
// send, the backend computes the param_hash and looks for an identical, still-valid
// COMPLETED run to offer for reuse. `hit` is null when there is nothing to reuse (or the
// cache read failed) — the caller then submits normally. Optional by design: a rejected
// mutation is treated as "no hit" at the call site so a check failure never blocks submit.
export function useCacheCheck(alvId: string) {
  return useMutation({
    mutationFn: (body: SubmitIn) =>
      apiPost<CacheCheck>(`/api/reports/${alvId}/cache-check`, body),
  });
}

export function usePreviewReport(alvId: string) {
  return useMutation({
    mutationFn: (body: PreviewIn) =>
      apiPost<PreviewOut>(`/api/reports/${alvId}/preview`, body),
  });
}

// --- Parameter templates (variants) -------------------------------------------
// The caller's saved templates for ONE report type (alv_id). Owner-scoped server-side;
// short staleTime so a save/delete on another tab surfaces on reopen. Enabled only once
// an alv_id is resolved.
export function useTemplates(alvId: string | null) {
  return useQuery({
    queryKey: ["templates", alvId],
    queryFn: () => apiGet<TemplatesList>(`/api/reports/${alvId}/templates`),
    enabled: !!alvId,
    staleTime: 30 * 1000,
  });
}

// Load one template's values on demand (to fill the form). Not a hook-query — callers
// invoke it imperatively when the user picks a template, so it never fires until asked.
export function fetchTemplate(alvId: string, templateId: string) {
  return apiGet<TemplateDetail>(
    `/api/reports/${alvId}/templates/${encodeURIComponent(templateId)}`,
  );
}

// Save (create/overwrite) a template of the current form values. Re-using a name
// overwrites it. On success we refresh the report's template list.
export function useSaveTemplate(alvId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: SaveTemplateIn) =>
      apiPost<TemplateSummary>(`/api/reports/${alvId}/templates`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["templates", alvId] }),
  });
}

// Rename / delete take the row's OWN alv_id (templates are listed report-wide, so a row
// may belong to a different report type than the screen's entry-point alv_id). The list
// query is keyed by the screen's alv_id (listAlvId), so that is what we invalidate.
export function useRenameTemplate(listAlvId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (args: { alvId: string; templateId: string; template_name: string }) =>
      apiPost<TemplateSummary>(
        `/api/reports/${args.alvId}/templates/${encodeURIComponent(args.templateId)}/rename`,
        { template_name: args.template_name },
      ),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["templates", listAlvId] }),
  });
}

export function useDeleteTemplate(listAlvId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (args: { alvId: string; templateId: string }) =>
      apiDelete<{ status: string }>(
        `/api/reports/${args.alvId}/templates/${encodeURIComponent(args.templateId)}`,
      ),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["templates", listAlvId] }),
  });
}

// --- Admin console (report_permissions grant/revoke) --------------------------
// Every seeded report for the console's report picker — UNFILTERED by permission
// (an admin grants access to reports they may not open themselves). Admin-gated: a
// non-admin gets 404, so this is only ever called from the admin screen.
export function useAdminReports(enabled: boolean) {
  return useQuery({
    queryKey: ["admin-reports"],
    queryFn: () => apiGet<ReportGroups>("/api/admin/reports"),
    enabled,
    staleTime: 5 * 60 * 1000,
  });
}

// A manifest that failed the backend's collect-all validation (422). Carries the FULL
// list of problems so the onboarding UI can list every one at once, rather than a single
// message. A definitive client error (not retried) — see the onboard mutation below.
export class OnboardValidationError extends Error {
  errors: string[];
  constructor(errors: string[]) {
    super("the manifest is not valid");
    this.name = "OnboardValidationError";
    this.errors = errors;
  }
}

// Onboard a new report by POSTing the pasted manifest TEXT. A dedicated fetch (not
// apiPost) because a 422 carries a structured {detail, errors} body we must surface as an
// OnboardValidationError, not a flat message. On success every visibility-derived query is
// invalidated (the new report shows in the picker) — though it stays hidden until granted.
export function useOnboardReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (manifest: string): Promise<OnboardResult> => {
      const resp = await fetch("/api/admin/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ manifest }),
      });
      if (!resp.ok) {
        let data: unknown = null;
        try {
          data = await resp.json();
        } catch {
          /* non-JSON error body */
        }
        const detail = (data as { detail?: unknown } | null)?.detail;
        // 422 validation shape: detail = { detail: string, errors: string[] }.
        if (
          resp.status === 422 &&
          detail &&
          typeof detail === "object" &&
          Array.isArray((detail as { errors?: unknown }).errors)
        ) {
          throw new OnboardValidationError((detail as { errors: string[] }).errors);
        }
        throw new ApiError(
          resp.status,
          typeof detail === "string" ? detail : `${resp.status} ${resp.statusText}`,
        );
      }
      return (await resp.json()) as OnboardResult;
    },
    onSuccess: () => {
      // The new report appears in the admin picker + (once granted) the catalogue views.
      qc.invalidateQueries({ queryKey: ["admin-reports"] });
      qc.invalidateQueries({ queryKey: ["report-groups"] });
      qc.invalidateQueries({ queryKey: ["reports"] });
    },
  });
}

// List every grant (active + inactive) for one report. Enabled only once a report is
// picked; short staleTime so a grant/revoke by another admin surfaces on reopen.
export function useReportGrants(reportKey: string | null) {
  return useQuery({
    queryKey: ["admin-grants", reportKey],
    queryFn: () =>
      apiGet<GrantsList>(`/api/admin/permissions/${encodeURIComponent(reportKey!)}`),
    enabled: !!reportKey,
    staleTime: 30 * 1000,
  });
}

// Grant a comma-separated principal list. On success we prime the grants query with the
// refreshed list the endpoint returns (it already reflects the write), so the panel
// updates without a second round-trip.
// A grant/revoke changes what reports the caller (and others) may see, so after either
// we prime the grants panel from the response AND invalidate every visibility-derived
// query — the home cards, every catalogue tree, AND the Downloads list (its rows are
// filtered to the reports the caller may access) — so the admin's own view reflects the
// change immediately instead of serving the stale, cached list.
function invalidateVisibility(qc: ReturnType<typeof useQueryClient>) {
  qc.invalidateQueries({ queryKey: ["report-groups"] });
  qc.invalidateQueries({ queryKey: ["reports"] });
  qc.invalidateQueries({ queryKey: ["requests"] });
}

export function useGrantReport(reportKey: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (principals: string) =>
      apiPost<GrantResult>(
        `/api/admin/permissions/${encodeURIComponent(reportKey)}/grant`,
        { principals },
      ),
    onSuccess: (data) => {
      qc.setQueryData(["admin-grants", reportKey], {
        report_key: data.report_key,
        grants: data.grants,
      });
      invalidateVisibility(qc);
    },
  });
}

// Revoke one grant (soft-delete). Same cache-priming as grant.
export function useRevokeReport(reportKey: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { principal_type: "group" | "user"; principal_name: string }) =>
      apiPost<GrantResult>(
        `/api/admin/permissions/${encodeURIComponent(reportKey)}/revoke`,
        body,
      ),
    onSuccess: (data) => {
      qc.setQueryData(["admin-grants", reportKey], {
        report_key: data.report_key,
        grants: data.grants,
      });
      invalidateVisibility(qc);
    },
  });
}
