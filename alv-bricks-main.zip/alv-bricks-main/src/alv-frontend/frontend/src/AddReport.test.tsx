// Home report-onboarding flow test: for an admin, an "+" tile on the Home grid opens a
// manifest paste modal; a valid paste shows a success message (and the deny-by-default
// "hidden until granted" note); an invalid paste lists every collected error. A non-admin
// never sees the tile. Black-box over a fake API, like Templates.test.tsx — it exercises
// the real HomePage, AddReportModal, hooks, and the structured-422 error parsing.
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter } from "react-router-dom";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { HomePage } from "./components/HomePage";

let isAdmin: boolean;
let lastPostedManifest: string | null;

function json(body: unknown, status = 200): Promise<Response> {
  return Promise.resolve(
    new Response(JSON.stringify(body), {
      status,
      headers: { "Content-Type": "application/json" },
    }),
  );
}

async function fakeFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const url = typeof input === "string" ? input : input.toString();
  const method = (init?.method ?? "GET").toUpperCase();

  if (url.startsWith("/api/me")) {
    return json({ email: "admin@example.com", is_admin: isAdmin });
  }
  // One permitted report so the grid renders a normal card alongside the "+" tile.
  if (url.startsWith("/api/report-groups")) {
    return json({
      groups: [{ report_key: "retail_ledger", report_label: "Retail Ledger", runnable_count: 14 }],
    });
  }
  // Onboard a report.
  if (url === "/api/admin/reports" && method === "POST") {
    const body = JSON.parse(String(init?.body ?? "{}"));
    lastPostedManifest = body.manifest;
    let parsed: unknown;
    try {
      parsed = JSON.parse(body.manifest);
    } catch {
      return json(
        { detail: { detail: "the manifest is not valid", errors: ["manifest: not valid JSON (…)."] } },
        422,
      );
    }
    const rows = (parsed as { catalog_rows?: unknown[] })?.catalog_rows;
    if (!Array.isArray(rows) || rows.length === 0) {
      return json(
        {
          detail: {
            detail: "the manifest is not valid",
            errors: ["manifest: 'catalog_rows' must be a non-empty array."],
          },
        },
        422,
      );
    }
    const first = rows[0] as Record<string, unknown>;
    if (!first.report_label) {
      return json(
        {
          detail: {
            detail: "the manifest is not valid",
            errors: [
              "catalog_rows[0]: missing required key 'report_label'.",
              "catalog_rows[0]: missing required key 'selection_label'.",
            ],
          },
        },
        422,
      );
    }
    const rk = String(first.report_key);
    return json({
      ok: true,
      row_count: rows.length,
      report_keys: [rk],
      alv_ids: [`${rk}__detail__main`],
      warnings: ["catalog_rows[0]: job_id is a placeholder; seeding NULL (unbound)."],
      detail:
        "Report added. It is hidden from everyone until you grant access to a group or user on the Manage report access screen below.",
    });
  }
  return json({ detail: `unexpected: ${method} ${url}` }, 404);
}

function renderHome() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <HomePage onOpenReport={() => {}} />
      </HashRouter>
    </QueryClientProvider>,
  );
}

const VALID_MANIFEST = JSON.stringify({
  catalog_rows: [
    {
      report_key: "brand_new_report",
      report_label: "Brand New",
      selection_id: "detail",
      selection_label: "Detail",
      selection_order: 1,
      input_fields_json: { schema_version: 1, fields: [] },
    },
  ],
});

describe("home report onboarding", () => {
  beforeEach(() => {
    isAdmin = true;
    lastPostedManifest = null;
    vi.stubGlobal("fetch", vi.fn(fakeFetch));
  });
  afterEach(() => vi.unstubAllGlobals());

  it("shows the + tile for an admin and adds a valid manifest", async () => {
    const user = userEvent.setup();
    renderHome();

    await user.click(await screen.findByRole("button", { name: "Add a report" }));
    const box = await screen.findByLabelText("Report manifest JSON");
    // paste (not type): the manifest contains { and [ which userEvent.type treats as
    // special-key syntax.
    await user.click(box);
    await user.paste(VALID_MANIFEST);
    await user.click(screen.getByRole("button", { name: "Add report" }));

    expect(await screen.findByText(/Added brand_new_report/)).toBeTruthy();
    expect(
      screen.getByText(/hidden from everyone until you grant access to a group or user/),
    ).toBeTruthy();
    expect(lastPostedManifest).toBe(VALID_MANIFEST);
  });

  it("lists every validation error for an invalid manifest (422)", async () => {
    const user = userEvent.setup();
    renderHome();

    await user.click(await screen.findByRole("button", { name: "Add a report" }));
    const box = await screen.findByLabelText("Report manifest JSON");
    await user.click(box);
    await user.paste(
      JSON.stringify({ catalog_rows: [{ report_key: "x", selection_id: "s", input_fields_json: {} }] }),
    );
    await user.click(screen.getByRole("button", { name: "Add report" }));

    expect(await screen.findByText(/The manifest is not valid/)).toBeTruthy();
    expect(screen.getByText(/missing required key 'report_label'/)).toBeTruthy();
    expect(screen.getByText(/missing required key 'selection_label'/)).toBeTruthy();
  });

  it("hides the + tile from a non-admin", async () => {
    isAdmin = false;
    renderHome();

    // The report card renders, but the onboarding tile does not.
    expect(await screen.findByRole("button", { name: /Retail Ledger/ })).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Add a report" })).toBeNull();
  });
});
