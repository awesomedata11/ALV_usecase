// Relative-date presets for dynamic templates — the UI-facing catalogue. Mirrors the
// backend enum in alv_app/dynamic_values.py (keep the two in step). Each preset resolves
// to ONE date relative to today; only CUR_DATE_PLUS_N_DAYS takes an integer `n` (± days).
//
// Resolution happens SERVER-SIDE at load — this module only powers the save editor (the
// dropdown labels + which preset needs an `n` input) and the live "resolves to today"
// preview, computed locally so the user sees the effect before saving.
import type { DynamicPreset } from "./api/types";

export interface PresetMeta {
  preset: DynamicPreset;
  label: string;
  needsN: boolean;
}

// Order = dropdown order. Labels match the list Idris gave.
export const PRESETS: PresetMeta[] = [
  { preset: "TODAY", label: "Current date", needsN: false },
  { preset: "CUR_DATE_PLUS_N_DAYS", label: "Current date ± n days", needsN: true },
  { preset: "FIRST_DAY_CUR_MONTH", label: "First day of current month", needsN: false },
  { preset: "LAST_DAY_CUR_MONTH", label: "Last day of current month", needsN: false },
  { preset: "FIRST_DAY_NEXT_MONTH", label: "First day of next month", needsN: false },
  { preset: "LAST_DAY_NEXT_MONTH", label: "Last day of next month", needsN: false },
  { preset: "FIRST_DAY_PREV_MONTH", label: "First day of previous month", needsN: false },
  { preset: "LAST_DAY_PREV_MONTH", label: "Last day of previous month", needsN: false },
];

export function presetLabel(preset: DynamicPreset): string {
  return PRESETS.find((p) => p.preset === preset)?.label ?? preset;
}

export function presetNeedsN(preset: DynamicPreset): boolean {
  return PRESETS.find((p) => p.preset === preset)?.needsN ?? false;
}

// Local mirror of the backend resolver, for the save editor's "resolves to today"
// preview ONLY. The authoritative resolution is server-side (report timezone); this is a
// best-effort local echo so the user sees the effect. Returns an ISO yyyy-mm-dd string.
export function resolvePresetLocally(preset: DynamicPreset, n: number, today = new Date()): string {
  const y = today.getFullYear();
  const m = today.getMonth(); // 0-based
  const d = today.getDate();
  const iso = (dt: Date) =>
    `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
  switch (preset) {
    case "TODAY":
      return iso(new Date(y, m, d));
    case "CUR_DATE_PLUS_N_DAYS":
      return iso(new Date(y, m, d + (Number.isFinite(n) ? n : 0)));
    case "FIRST_DAY_CUR_MONTH":
      return iso(new Date(y, m, 1));
    case "LAST_DAY_CUR_MONTH":
      return iso(new Date(y, m + 1, 0));
    case "FIRST_DAY_NEXT_MONTH":
      return iso(new Date(y, m + 1, 1));
    case "LAST_DAY_NEXT_MONTH":
      return iso(new Date(y, m + 2, 0));
    case "FIRST_DAY_PREV_MONTH":
      return iso(new Date(y, m - 1, 1));
    case "LAST_DAY_PREV_MONTH":
      return iso(new Date(y, m, 0));
    default:
      return "";
  }
}
