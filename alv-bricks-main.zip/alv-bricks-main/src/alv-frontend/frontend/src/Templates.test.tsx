// Templates flow test: the contextual "Templates" nav item appears once a report is
// open, the screen lists the caller's templates for that report type, and Load fills the
// form (via the draft store) and returns to the report. Black-box over a fake API, like
// App.test.tsx — it exercises the real router, nav, screen, and hooks.
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter } from "react-router-dom";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { App } from "./App";
import { FormDraftProvider } from "./formDraft";

const ALV = "retail_ledger__detail__agent_item";

// Server-side template store, keyed by (alv_id, template_id). Reset per test.
let templates: Array<{
  template_id: string;
  template_name: string;
  values: Record<string, string>;
  value_kinds?: Record<string, unknown>;
}>;

function json(body: unknown, status = 200): Promise<Response> {
  return Promise.resolve(
    new Response(JSON.stringify(body), {
      status,
      headers: { "Content-Type": "application/json" },
    }),
  );
}

function formDef() {
  return {
    alv_id: ALV,
    report_key: "retail_ledger",
    report_label: "Retail Ledger",
    selection_id: "detail",
    selection_label: "Detail",
    report_type_code: "agent_item",
    report_type_label: "Agent Item",
    alv_name: "Retail Ledger — Detail — Agent Item",
    description: null,
    fields: [
      {
        kind: "scalar",
        control: "text",
        data_type: "string",
        display_label: "Agent",
        display_order: 1,
        mandatory: false,
        validations: [],
        param_name: "agent_id",
      },
      {
        kind: "scalar",
        control: "date",
        data_type: "date",
        display_label: "As-on date",
        display_order: 2,
        mandatory: false,
        validations: [],
        param_name: "as_on_date",
      },
    ],
    has_sample_query: false,
  };
}

async function fakeFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const url = typeof input === "string" ? input : input.toString();
  const method = (init?.method ?? "GET").toUpperCase();

  if (url.startsWith("/api/me")) {
    return json({
      email: "alice@example.com",
      preferred_username: "alice@example.com",
      user_id: "aad-1",
      real_ip: null,
      authenticated: true,
      has_user_token: true,
      is_admin: false,
      service_principal: null,
      service_principal_ok: true,
      service_principal_detail: null,
    });
  }

  // Templates list (report-wide — every row carries its own alv_id + labels).
  if (url.match(/\/api\/reports\/[^/]+\/templates$/) && method === "GET") {
    return json({
      alv_id: ALV,
      templates: templates.map((t) => ({
        template_id: t.template_id,
        alv_id: ALV,
        template_name: t.template_name,
        selection_label: "Detail",
        report_type_label: "Agent Item",
        created_at: "2026-08-01",
        updated_at: "2026-08-08",
        is_dynamic: Object.keys(t.value_kinds ?? {}).length > 0,
      })),
    });
  }
  // Save template.
  if (url.match(/\/api\/reports\/[^/]+\/templates$/) && method === "POST") {
    const body = JSON.parse(String(init?.body ?? "{}"));
    const vk = body.value_kinds ?? {};
    const t = {
      template_id: `TPL-${templates.length + 1}`,
      template_name: body.template_name,
      values: body.values,
      value_kinds: vk,
    };
    templates.push(t);
    return json({
      template_id: t.template_id,
      template_name: t.template_name,
      is_dynamic: Object.keys(vk).length > 0,
    });
  }
  // Load one template.
  const loadMatch = url.match(/\/api\/reports\/[^/]+\/templates\/([^/?]+)$/);
  if (loadMatch && method === "GET") {
    const t = templates.find((x) => x.template_id === decodeURIComponent(loadMatch[1]));
    if (!t) return json({ detail: "template not found" }, 404);
    return json({
      template_id: t.template_id,
      alv_id: ALV,
      template_name: t.template_name,
      values: t.values,
      value_kinds: t.value_kinds ?? {},
    });
  }

  // Catalogue scoped to retail_ledger.
  if (url.startsWith("/api/reports?") || url === "/api/reports") {
    return json({
      report_key: "retail_ledger",
      report_label: "Retail Ledger",
      selections: [
        {
          selection_id: "detail",
          selection_label: "Detail",
          selection_order: 1,
          report_types: [
            { report_type_code: "agent_item", report_type_label: "Agent Item", report_type_order: 1, alv_id: ALV, alv_name: "Agent Item", description: null },
          ],
        },
      ],
    });
  }

  // Form def.
  if (url.match(/^\/api\/reports\/[^/?]+$/)) {
    return json(formDef());
  }

  return json({ detail: `unexpected: ${url}` }, 404);
}

function renderApp() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <FormDraftProvider>
          <App />
        </FormDraftProvider>
      </HashRouter>
    </QueryClientProvider>,
  );
}

describe("templates flow", () => {
  beforeEach(() => {
    templates = [];
    window.location.hash = `#/report/retail_ledger/${ALV}`;
    vi.stubGlobal("fetch", vi.fn(fakeFetch));
  });
  afterEach(() => vi.unstubAllGlobals());

  it("shows the Templates nav item only while a report is open", async () => {
    renderApp();
    // On the report, the contextual Templates item is present.
    expect(await screen.findByRole("button", { name: "Templates" })).toBeTruthy();

    // Navigate Home — the item disappears (no report context).
    await userEvent.setup().click(screen.getByRole("button", { name: "Home" }));
    await waitFor(() =>
      expect(screen.queryByRole("button", { name: "Templates" })).toBeNull(),
    );
  });

  it("the report-name breadcrumb on the Templates screen navigates to the report", async () => {
    // Regression: the crumb linked to `#/report/...` under HashRouter, so react-router
    // never matched it and only Home worked. It must link to the plain path.
    const user = userEvent.setup();
    window.location.hash = `#/report/retail_ledger/${ALV}/templates`;
    renderApp();

    const crumb = await screen.findByRole("link", { name: "Retail Ledger" });
    await user.click(crumb);
    await waitFor(() =>
      expect(window.location.hash).toBe(`#/report/retail_ledger/${ALV}`),
    );
  });

  it("save from the form then load it back fills the field", async () => {
    const user = userEvent.setup();
    renderApp();

    // Fill the Agent field and save a template (the save opens a modal).
    const agent = await screen.findByLabelText("Agent");
    await user.type(agent, "AG001");
    await user.click(screen.getByRole("button", { name: "Save as template" }));
    await user.type(await screen.findByPlaceholderText("e.g. Last month"), "Last Month");
    await user.click(screen.getByRole("button", { name: "Save template" }));

    await waitFor(() => expect(templates.length).toBe(1));

    // Go to the Templates screen and load it.
    await user.click(screen.getByRole("button", { name: "Templates" }));
    const row = await screen.findByText("Last Month");
    const table = row.closest("table")!;
    await user.click(within(table).getByRole("button", { name: "Load" }));

    // Back on the form, the field is filled from the template.
    await waitFor(() =>
      expect((screen.getByLabelText("Agent") as HTMLInputElement).value).toBe("AG001"),
    );
  });

  it("saves a dynamic date field via the modal (posts value_kinds)", async () => {
    const user = userEvent.setup();
    renderApp();

    await screen.findByLabelText("Agent");
    await user.click(screen.getByRole("button", { name: "Save as template" }));
    await user.type(await screen.findByPlaceholderText("e.g. Last month"), "MTD");
    // Mark the As-on date field dynamic and pick "First day of current month".
    await user.click(screen.getByRole("checkbox", { name: /Dynamic/i }));
    await user.selectOptions(
      screen.getByRole("combobox"),
      "First day of current month",
    );
    await user.click(screen.getByRole("button", { name: "Save template" }));

    await waitFor(() => expect(templates.length).toBe(1));
    // value_kinds carried the dynamic preset for the date field.
    expect(templates[0].value_kinds).toEqual({
      as_on_date: { kind: "dynamic", preset: "FIRST_DAY_CUR_MONTH" },
    });
    // The Templates list flags it dynamic.
    await user.click(screen.getByRole("button", { name: "Templates" }));
    expect(await screen.findByText("dynamic")).toBeTruthy();
  });

  it("lists saved templates on the Templates screen", async () => {
    templates = [
      { template_id: "TPL-1", template_name: "Q1", values: {} },
      { template_id: "TPL-2", template_name: "Q2", values: {} },
    ];
    const user = userEvent.setup();
    renderApp();
    await user.click(await screen.findByRole("button", { name: "Templates" }));
    expect(await screen.findByText("Q1")).toBeTruthy();
    expect(screen.getByText("Q2")).toBeTruthy();
  });
});
