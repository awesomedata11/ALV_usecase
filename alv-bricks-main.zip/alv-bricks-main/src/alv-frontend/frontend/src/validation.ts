// Client-side validation (task 5.4). Driven ENTIRELY by the metadata `validations`
// vocabulary + field attributes — there is NO per-report hardcoded rule here. The
// same rule names the backend enforces (docs/CONFIGURATION_GUIDE.md §4) are
// dispatched below; messages come from resolveMessage(message_key).
//
// Values are held in a flat map keyed by param_name (composite parts contribute
// their own from/to param_names). This mirrors the payload the backend Job will
// receive, so validation runs over the same shape a submit would build.
import type { FieldValidation, FormField } from "./api/types";
import { resolveMessage } from "./messages";

export type Values = Record<string, string>;
// One error message per param_name (composite errors attach to the `from` part).
export type Errors = Record<string, string>;

function isBlank(v: string | undefined): boolean {
  return v === undefined || v.trim() === "";
}

// Parse an ISO date (yyyy-mm-dd from <input type=date>) to a UTC-midnight Date.
function parseDate(v: string): Date | null {
  if (isBlank(v)) return null;
  const d = new Date(v + "T00:00:00Z");
  return isNaN(d.getTime()) ? null : d;
}

// Compare "HH:MM" / "HH:MM:SS" strings lexically-safe by normalizing to seconds.
function timeToSeconds(v: string): number | null {
  if (isBlank(v)) return null;
  const m = v.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (!m) return null;
  return +m[1] * 3600 + +m[2] * 60 + (m[3] ? +m[3] : 0);
}

// Subtract `value` units from today (for max_offset_from_today lower bound).
function offsetFromToday(unit: string, value: number): Date {
  const d = new Date();
  const utc = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  if (unit === "days") utc.setUTCDate(utc.getUTCDate() - value);
  else if (unit === "months") utc.setUTCMonth(utc.getUTCMonth() - value);
  else if (unit === "years") utc.setUTCFullYear(utc.getUTCFullYear() - value);
  return utc;
}

// Inclusive day span between two dates (1 May–31 May = 31, per design §7).
function inclusiveDaySpan(from: Date, to: Date): number {
  const ms = to.getTime() - from.getTime();
  return Math.floor(ms / 86_400_000) + 1;
}

function spanCapDays(unit: string, value: number): number {
  if (unit === "months") return value * 31; // coarse; pilot only uses days
  if (unit === "years") return value * 366;
  return value;
}

// --- per-rule handlers, all reading only metadata + values --------------------
function checkComposite(field: FormField, values: Values, errors: Errors): void {
  const parts = field.parts;
  if (!parts) return;
  const fromKey = parts.from.param_name;
  const toKey = parts.to.param_name;
  const fromRaw = values[fromKey];
  const toRaw = values[toKey];

  // mandatory: both endpoints required when the field is mandatory.
  if (field.mandatory && (isBlank(fromRaw) || isBlank(toRaw))) {
    errors[fromKey] = `${field.display_label} is required.`;
    return;
  }

  const isDate = field.control === "date_range";
  const fromV = isDate ? parseDate(fromRaw ?? "") : (timeToSeconds(fromRaw ?? "") as number | null);
  const toV = isDate ? parseDate(toRaw ?? "") : (timeToSeconds(toRaw ?? "") as number | null);

  for (const rule of field.validations) {
    const msg = resolveMessage(rule.message_key);
    switch (rule.rule) {
      case "from_lte_to": {
        if (fromV != null && toV != null) {
          const a = isDate ? (fromV as Date).getTime() : (fromV as number);
          const b = isDate ? (toV as Date).getTime() : (toV as number);
          if (a > b) errors[fromKey] = msg;
        }
        break;
      }
      case "to_required_if_from": {
        if (!isBlank(fromRaw) && isBlank(toRaw)) errors[toKey] = msg;
        break;
      }
      case "max_span": {
        if (isDate && fromV != null && toV != null && rule.unit && rule.value != null) {
          const span = inclusiveDaySpan(fromV as Date, toV as Date);
          if (span > spanCapDays(rule.unit, rule.value)) errors[fromKey] = msg;
        }
        break;
      }
      case "max_offset_from_today": {
        if (isDate && rule.unit && rule.value != null) {
          const lower = offsetFromToday(rule.unit, rule.value);
          const target = rule.applies_to === "to" ? (toV as Date | null) : (fromV as Date | null);
          const key = rule.applies_to === "to" ? toKey : fromKey;
          if (target != null && target.getTime() < lower.getTime()) errors[key] = msg;
        }
        break;
      }
      // no_filter_when_equal is an omission hint, not a user error — skip in UI.
      default:
        break;
    }
  }
}

function checkScalar(field: FormField, values: Values, errors: Errors): void {
  const key = field.param_name;
  if (!key) return;
  const raw = values[key];

  if (field.mandatory && isBlank(raw)) {
    errors[key] = `${field.display_label} is required.`;
    return;
  }
  if (isBlank(raw)) return; // optional + blank ⇒ nothing else to check

  for (const rule of field.validations as FieldValidation[]) {
    const msg = resolveMessage(rule.message_key);
    switch (rule.rule) {
      case "max_length": {
        if (rule.value != null && raw.length > rule.value) errors[key] = msg;
        break;
      }
      case "regex": {
        if (rule.pattern) {
          try {
            if (!new RegExp(rule.pattern).test(raw)) errors[key] = msg;
          } catch {
            /* invalid pattern in metadata — ignore client-side, backend re-checks */
          }
        }
        break;
      }
      case "max_offset_from_today": {
        if (field.data_type === "date" && rule.unit && rule.value != null) {
          const d = parseDate(raw);
          const lower = offsetFromToday(rule.unit, rule.value);
          if (d != null && d.getTime() < lower.getTime()) errors[key] = msg;
        }
        break;
      }
      default:
        break;
    }
  }
}

// Validate the whole form. Returns a map of param_name -> message (empty = valid).
export function validateForm(fields: FormField[], values: Values): Errors {
  const errors: Errors = {};
  for (const field of fields) {
    if (field.kind === "composite") checkComposite(field, values, errors);
    else checkScalar(field, values, errors);
  }
  return errors;
}

// Seed initial values from field defaults (task 5.3 — apply default).
export function initialValues(fields: FormField[]): Values {
  const v: Values = {};
  for (const field of fields) {
    if (field.kind === "composite" && field.parts) {
      v[field.parts.from.param_name] = strOrEmpty(field.parts.from.default);
      v[field.parts.to.param_name] = strOrEmpty(field.parts.to.default);
    } else if (field.param_name) {
      v[field.param_name] = strOrEmpty(field.default);
    }
  }
  return v;
}

function strOrEmpty(d: unknown): string {
  return d === null || d === undefined ? "" : String(d);
}
