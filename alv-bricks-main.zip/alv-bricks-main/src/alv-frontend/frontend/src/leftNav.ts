// Left-nav layout state — collapsed/expanded flag + the user's chosen expanded
// width, both persisted in localStorage (same approach as theme.ts).
//
// Defaults: EXPANDED, at the historical default rail width. On reload we restore
// whatever the user last picked. Persistence failures (private mode, etc.) are
// swallowed so the UI still works — we just fall back to the defaults.
import { useCallback, useEffect, useState } from "react";

const COLLAPSED_KEY = "alv-nav-collapsed";
const WIDTH_KEY = "alv-nav-width";

// Expanded-width bounds (px). Collapsed uses a separate fixed width in CSS.
export const NAV_MIN_WIDTH = 160;
export const NAV_MAX_WIDTH = 360;
// Default first-load width. Deliberately narrow (matches the width the user tends to
// resize down to) — the rail is still drag-resizable up to NAV_MAX_WIDTH and the
// chosen width persists to localStorage, so only the no-stored-value default is 160.
export const NAV_DEFAULT_WIDTH = 160;

// Keep a width inside the allowed range.
export function clampWidth(w: number): number {
  return Math.min(NAV_MAX_WIDTH, Math.max(NAV_MIN_WIDTH, Math.round(w)));
}

// Resolve the initial collapsed state: stored preference wins; default expanded.
// Safe if localStorage is unavailable.
export function getInitialCollapsed(): boolean {
  try {
    return localStorage.getItem(COLLAPSED_KEY) === "true";
  } catch {
    return false;
  }
}

// Resolve the initial expanded width: stored (clamped) value wins; else default.
export function getInitialWidth(): number {
  try {
    const stored = localStorage.getItem(WIDTH_KEY);
    if (stored !== null) {
      const n = Number(stored);
      if (Number.isFinite(n)) return clampWidth(n);
    }
  } catch {
    /* no-op — default below */
  }
  return NAV_DEFAULT_WIDTH;
}

export function useLeftNav(): {
  collapsed: boolean;
  toggleCollapsed: () => void;
  width: number;
  setWidth: (w: number) => void;
} {
  const [collapsed, setCollapsed] = useState<boolean>(getInitialCollapsed);
  const [width, setWidthState] = useState<number>(getInitialWidth);

  // Persist collapsed state.
  useEffect(() => {
    try {
      localStorage.setItem(COLLAPSED_KEY, String(collapsed));
    } catch {
      /* ignore persistence failures (e.g. private mode) */
    }
  }, [collapsed]);

  // Persist the chosen expanded width.
  useEffect(() => {
    try {
      localStorage.setItem(WIDTH_KEY, String(width));
    } catch {
      /* ignore persistence failures */
    }
  }, [width]);

  const toggleCollapsed = useCallback(() => setCollapsed((c) => !c), []);
  // Always clamp on the way in so callers (drag/keyboard) can't exceed bounds.
  const setWidth = useCallback((w: number) => setWidthState(clampWidth(w)), []);

  return { collapsed, toggleCollapsed, width, setWidth };
}
