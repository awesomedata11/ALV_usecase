// Tests for the output-file preview feature (docs/OUTPUT_FILE_PREVIEW_APPROACH.md):
//   1. The preview SCREEN renders a CSV table / a raw-text block / a binary notice from
//      GET /api/requests/{no}/output-preview.
//   2. The Downloads row shows a "Preview" control, enabled (a link to the preview
//      screen) only when the run is COMPLETED with an output_path, disabled otherwise.
import { render, screen, waitFor, within } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { afterEach, describe, expect, it, vi } from "vitest";
import { OutputPreviewPage } from "./components/OutputPreviewPage";
import { DownloadsPage } from "./components/DownloadsPage";

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function withClient(ui: React.ReactNode) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return <QueryClientProvider client={qc}>{ui}</QueryClientProvider>;
}

function renderPreview() {
  return render(
    withClient(
      <MemoryRouter initialEntries={["/downloads/REQ-1/preview"]}>
        <Routes>
          <Route path="/downloads/:requestNo/preview" element={<OutputPreviewPage />} />
        </Routes>
      </MemoryRouter>,
    ),
  );
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("OutputPreviewPage", () => {
  it("renders a CSV output file as a table", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation((input) => {
      const url = typeof input === "string" ? input : input.toString();
      if (url.includes("/output-preview")) {
        return Promise.resolve(
          jsonResponse({
            format: "csv",
            columns: ["agent", "amount"],
            rows: [
              ["AG001", "100"],
              ["AG002", "200"],
            ],
            text: null,
            row_count: 2,
            truncated: false,
            filename: "retail_ledger.csv",
          }),
        );
      }
      return Promise.resolve(jsonResponse({}, 404));
    });

    renderPreview();

    // Header cells + a data cell prove the table rendered from the parsed response.
    expect(await screen.findByText("agent")).toBeInTheDocument();
    expect(screen.getByText("amount")).toBeInTheDocument();
    expect(screen.getByText("AG001")).toBeInTheDocument();
    expect(screen.getByText("retail_ledger.csv")).toBeInTheDocument();
  });

  it("renders the raw-text fallback for a non-CSV file", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(() =>
      Promise.resolve(
        jsonResponse({
          format: "text",
          columns: [],
          rows: [],
          text: "line one\nline two",
          row_count: 2,
          truncated: false,
          filename: "out.txt",
        }),
      ),
    );

    renderPreview();
    expect(await screen.findByText(/line one/)).toBeInTheDocument();
  });

  it("shows a notice for a binary (unpreviewable) file", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(() =>
      Promise.resolve(
        jsonResponse({
          format: "binary",
          columns: [],
          rows: [],
          text: null,
          row_count: 0,
          truncated: false,
          filename: "out.parquet",
        }),
      ),
    );

    renderPreview();
    expect(await screen.findByText(/Preview is not available/)).toBeInTheDocument();
  });
});

// --- Downloads-page Preview control -------------------------------------------
function renderDownloads() {
  return render(
    withClient(
      <MemoryRouter initialEntries={["/downloads"]}>
        <DownloadsPage />
      </MemoryRouter>,
    ),
  );
}

function downloadsListFetch(row: Record<string, unknown>) {
  return (input: RequestInfo | URL) => {
    const url = typeof input === "string" ? input : input.toString();
    if (url.includes("/api/requests?") || url.match(/\/api\/requests(\?|$)/)) {
      return Promise.resolve(
        jsonResponse({
          requests: [row],
          limit: 50,
          offset: 0,
          has_more: false,
          scope: "accessible",
          sort: "submitted_at_desc",
          q: "",
        }),
      );
    }
    // Status poll for the row (terminal ⇒ not actually polled, but be safe).
    return Promise.resolve(jsonResponse({}, 404));
  };
}

describe("DownloadsPage Preview control", () => {
  it("links to the preview screen when the run is COMPLETED with output", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(
      downloadsListFetch({
        request_no: "REQ-1",
        alv_id: "retail_ledger__detail__agent_item",
        report_label: "Retail Ledger",
        status: "COMPLETED",
        submitted_by: "u@example.com",
        submitted_at: null,
        output_path: "/Volumes/c/s/out.csv",
      }),
    );

    renderDownloads();

    const link = await screen.findByRole("link", { name: "Preview" });
    expect(link).toHaveAttribute("href", expect.stringContaining("/downloads/REQ-1/preview"));
  });

  it("disables Preview when the run has no output", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(
      downloadsListFetch({
        request_no: "REQ-2",
        alv_id: "retail_ledger__detail__agent_item",
        report_label: "Retail Ledger",
        status: "RUNNING",
        submitted_by: "u@example.com",
        submitted_at: null,
        output_path: null,
      }),
    );

    renderDownloads();

    const btn = await screen.findByRole("button", { name: "Preview" });
    expect(btn).toBeDisabled();
  });
});
