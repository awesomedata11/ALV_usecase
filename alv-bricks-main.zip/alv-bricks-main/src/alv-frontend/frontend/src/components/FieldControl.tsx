// Renders ONE metadata field as its control (tasks 5.2/5.3). The control is chosen
// purely from `control` + `data_type` + `selection_type` in the metadata — no
// per-report logic. Composite range controls (date_range/time_range) render two
// inputs from their `parts.from` / `parts.to`.
import type { FormField } from "../api/types";
import type { Errors, Values } from "../validation";

interface Props {
  field: FormField;
  values: Values;
  errors: Errors;
  onChange: (paramName: string, value: string) => void;
}

// Map data_type -> native <input type> for scalar/part inputs.
function inputType(dataType: string): string {
  if (dataType === "date") return "date";
  if (dataType === "time") return "time";
  return "text";
}

export function FieldControl({ field, values, errors, onChange }: Props) {
  const required = field.mandatory;

  // --- Composite range: from / to (task 5.2) ---------------------------------
  if (field.kind === "composite" && field.parts) {
    const { from, to } = field.parts;
    const type = inputType(field.data_type);
    // A composite error is attached to either endpoint's param_name.
    const err = errors[from.param_name] ?? errors[to.param_name];
    return (
      <div className="field">
        <label className="field__label">
          {field.display_label}
          {required && <span className="field__req">*</span>}
        </label>
        <div className="field__range">
          <input
            type={type}
            step={field.data_type === "time" ? 1 : undefined}
            aria-label={`${field.display_label} ${from.display_label}`}
            value={values[from.param_name] ?? ""}
            onChange={(e) => onChange(from.param_name, e.target.value)}
          />
          <span className="field__range-sep">to</span>
          <input
            type={type}
            step={field.data_type === "time" ? 1 : undefined}
            aria-label={`${field.display_label} ${to.display_label}`}
            value={values[to.param_name] ?? ""}
            onChange={(e) => onChange(to.param_name, e.target.value)}
          />
        </div>
        {err && <div className="field__error">{err}</div>}
      </div>
    );
  }

  // --- Scalar (task 5.2/5.3) -------------------------------------------------
  const key = field.param_name!;
  const err = errors[key];
  const value = values[key] ?? "";
  const multi = field.selection_type === "multi";

  // Dropdown from allowed_values when present (task 5.3). The pilot spec has none,
  // but this renders one with no backend change if the contract later adds them.
  const hasOptions = Array.isArray(field.allowed_values) && field.allowed_values.length > 0;

  return (
    <div className="field">
      <label className="field__label" htmlFor={key}>
        {field.display_label}
        {required && <span className="field__req">*</span>}
      </label>
      {hasOptions ? (
        <select
          id={key}
          multiple={multi}
          value={value}
          onChange={(e) => onChange(key, e.target.value)}
        >
          {!multi && <option value="">—</option>}
          {field.allowed_values!.map((opt) => {
            const s = String(opt);
            return (
              <option key={s} value={s}>
                {s}
              </option>
            );
          })}
        </select>
      ) : (
        <input
          id={key}
          type={inputType(field.data_type)}
          step={field.data_type === "time" ? 1 : undefined}
          value={value}
          onChange={(e) => onChange(key, e.target.value)}
        />
      )}
      {err && <div className="field__error">{err}</div>}
    </div>
  );
}
