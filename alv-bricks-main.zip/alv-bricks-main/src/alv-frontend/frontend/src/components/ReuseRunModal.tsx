// Result-cache reuse modal (task 7.3). Shown after Submit when the backend's cache-check
// finds an identical, still-valid COMPLETED run for the same report + parameters. The
// user chooses: reuse that output (download it immediately) or run the Job again.
//
// The candidate is always the LATEST qualifying run (the backend orders by generated_at
// DESC), so "Reuse output" downloads the most recent matching file — never an older one.
//
// Reuse is Option A ("point to the existing run"): no new request_log row is created; the
// button downloads the existing run's output via the same App-proxied endpoint the
// Downloads page uses (GET /api/requests/{request_no}/download). Cross-user reuse is
// intended, so `submitted_by` may name a different user (shown, not masked — consistent
// with the Downloads page).
import type { CacheHit } from "../api/types";

interface Props {
  hit: CacheHit;
  // Run the Job anyway (the normal submit path). The parent triggers the submit.
  onRerun: () => void;
  onClose: () => void;
}

// Same-origin path the browser hits to download a run's output (matches DownloadsPage).
// The backend streams the file with a Content-Disposition attachment, so hitting this
// URL downloads the file rather than navigating the SPA.
function downloadHref(requestNo: string): string {
  return `/api/requests/${encodeURIComponent(requestNo)}/download`;
}

// Format a warehouse ISO timestamp for display in the VIEWER's local timezone (IST for
// this pilot), falling back to the raw string if it is not parseable. Mirrors the
// Downloads page's "Submitted At" (`formatSubmittedAt`) so the two always read the same
// way, rather than showing the raw UTC `…Z` string.
function formatTs(raw: string | null): string {
  if (!raw) return "";
  const d = new Date(raw);
  return isNaN(d.getTime()) ? raw : d.toLocaleString();
}

export function ReuseRunModal({ hit, onRerun, onClose }: Props) {
  const who = hit.submitted_by || "another user";

  // Download the existing output, then close. An anchor with `download` is used (not a
  // location change) so the SPA is never navigated away from.
  const onReuse = () => {
    const a = document.createElement("a");
    a.href = downloadHref(hit.request_no);
    a.setAttribute("download", "");
    document.body.appendChild(a);
    a.click();
    a.remove();
    onClose();
  };

  return (
    <div
      className="modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Identical report run found"
    >
      <div className="modal">
        <div className="modal__header">
          <h2 className="modal__title">Identical report run found</h2>
          <button type="button" className="modal__close" aria-label="Close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="modal__body">
          <p>
            A report with these exact parameters was already run
            {hit.generated_at ? (
              <>
                {" "}
                on <strong>{formatTs(hit.generated_at)}</strong>
              </>
            ) : null}{" "}
            by <strong>{who}</strong>. Its output file is still available
            {hit.expires_at ? (
              <>
                {" "}
                (until <strong>{formatTs(hit.expires_at)}</strong>)
              </>
            ) : null}
            .
          </p>
          {hit.row_count != null && (
            <p className="muted">
              {hit.row_count} row{hit.row_count !== 1 ? "s" : ""} in the cached output.
            </p>
          )}
          <p className="muted">
            This is the most recent matching run. Reuse it to get the result immediately, or
            run the job again to produce a fresh file.
          </p>
        </div>

        <div className="modal__footer">
          <button type="button" className="btn btn--secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="button" className="btn btn--secondary" onClick={onRerun}>
            Run the job again
          </button>
          <button
            type="button"
            className="btn btn--primary"
            onClick={onReuse}
            disabled={!hit.has_output}
            title={!hit.has_output ? "No output file is available for this run" : undefined}
          >
            Reuse output
          </button>
        </div>
      </div>
    </div>
  );
}
