// Main content area (tasks 4.2 + 5.x). Renders the report page body as it appears
// in screenshot 2: a "Selection" section on top (the report SELECTIONS — Detail /
// Sequence Wise / Time Wise / Agent Closing Balance), then a "Reports" section (the
// report types under the chosen selection), then the metadata-driven form for the
// resolved alv_id. A selection with no report type (Agent Closing Balance) resolves
// directly to its one form. Both option groups share the same section styling.
import type { Catalogue } from "../api/types";
import { useReportForm } from "../api/hooks";
import { Breadcrumb } from "./Breadcrumb";
import { ReportForm } from "./ReportForm";

interface Props {
  catalogue: Catalogue | undefined;
  isLoading: boolean;
  isError: boolean;
  error: unknown;
  selectionId: string | null;
  alvId: string | null;
  onSelectSelection: (selectionId: string) => void;
  onSelectReportType: (alvId: string) => void;
}

export function MainArea({
  catalogue,
  isLoading,
  isError,
  error,
  selectionId,
  alvId,
  onSelectSelection,
  onSelectReportType,
}: Props) {
  const selection = catalogue?.selections.find((s) => s.selection_id === selectionId);

  // Whether this selection is a "bare" leaf (no report type — Closing Balance).
  const hasReportTypes =
    !!selection &&
    selection.report_types.some((rt) => rt.report_type_code !== null);

  // Breadcrumb + title come from the RESOLVED REPORT'S OWN ROW (the same
  // GET /api/reports/{alv_id} response ReportForm renders its heading from — one shared
  // cached query, no extra request). Falling back to the catalogue's tree-level label
  // and finally to a hardcoded "Retail Ledger" was how the breadcrumb and the form
  // heading could name two different reports on the same screen: the tree label was
  // taken from whichever row happened to be first, and the hardcoded default was simply
  // wrong for every report but one. Ordered most- to least-specific, so whatever renders
  // is always about the report actually on screen.
  // While the row is still in flight there is no honest label to show, so the trailing
  // crumb / title are omitted rather than filled with a guess.
  const { data: resolvedForm } = useReportForm(alvId);
  const reportLabel =
    resolvedForm?.report_label ?? catalogue?.report_label ?? resolvedForm?.alv_name ?? null;

  return (
    <main className="main">
      {/* Home > <report label>. "Home" links back to the cards view; the report label
          is a plain, non-clickable trailing segment. */}
      <Breadcrumb
        crumbs={[{ label: "Home", to: "/" }, ...(reportLabel ? [{ label: reportLabel }] : [])]}
      />
      {reportLabel && <h1 className="main__title">{reportLabel}</h1>}

      {isLoading && <p className="muted">Loading catalogue…</p>}
      {isError && <p className="error">Catalogue error: {String(error)}</p>}

      {/* Selection section — the report SELECTIONS, driven from catalogue metadata
          (ordered by selection_order). Styled identically to the Reports group. */}
      {catalogue && catalogue.selections.length === 0 && (
        <p className="muted">No active reports.</p>
      )}
      {catalogue && catalogue.selections.length > 0 && (
        <section className="reports-group">
          <div className="reports-group__title">Selection</div>
          <div className="reports-group__options">
            {catalogue.selections.map((sel) => (
              <label key={sel.selection_id} className="radio">
                <input
                  type="radio"
                  name="selection"
                  checked={sel.selection_id === selectionId}
                  onChange={() => onSelectSelection(sel.selection_id)}
                  aria-current={sel.selection_id === selectionId}
                />
                <span>{sel.selection_label ?? sel.selection_id}</span>
              </label>
            ))}
          </div>
        </section>
      )}

      {selection && hasReportTypes && (
        <section className="reports-group">
          <div className="reports-group__title">Reports</div>
          <div className="reports-group__options">
            {selection.report_types.map((rt) => (
              <label key={rt.alv_id} className="radio">
                <input
                  type="radio"
                  name="report-type"
                  checked={alvId === rt.alv_id}
                  onChange={() => onSelectReportType(rt.alv_id)}
                />
                <span>{rt.report_type_label ?? rt.alv_id}</span>
              </label>
            ))}
          </div>
        </section>
      )}

      {alvId ? (
        <ReportForm alvId={alvId} />
      ) : (
        selection && hasReportTypes && <p className="muted">Choose a report to load its form.</p>
      )}
    </main>
  );
}
