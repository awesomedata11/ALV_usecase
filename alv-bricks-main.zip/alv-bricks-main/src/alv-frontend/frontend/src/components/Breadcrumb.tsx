// Breadcrumb heading, rendered at the top of each view's main content. Replaces the
// old (unintuitive) behavior where clicking the report title/brand navigated home.
//
// Shape:
//   Home                       — the home/cards view (single, non-linked crumb)
//   Home > Downloads           — the Downloads page ("Home" links back)
//   Home > Retail Ledger       — an open report ("Home" links back; the report
//                                label is a plain, non-clickable trailing segment)
//
// "Home" is always a real link (react-router <Link to="/">), so it participates in
// browser history exactly like any nav click. The trailing segment (current page)
// is rendered as plain text with aria-current="page".
import { Link } from "react-router-dom";

export interface Crumb {
  label: string;
  // When set, the crumb is a link to this path; otherwise it's the current page.
  to?: string;
}

export function Breadcrumb({ crumbs }: { crumbs: Crumb[] }) {
  return (
    <nav className="breadcrumb" aria-label="Breadcrumb">
      <ol className="breadcrumb__list">
        {crumbs.map((crumb, i) => {
          const isLast = i === crumbs.length - 1;
          return (
            <li key={i} className="breadcrumb__item">
              {crumb.to && !isLast ? (
                <Link className="breadcrumb__link" to={crumb.to}>
                  {crumb.label}
                </Link>
              ) : (
                <span className="breadcrumb__current" aria-current="page">
                  {crumb.label}
                </span>
              )}
              {!isLast && (
                <span className="breadcrumb__sep" aria-hidden="true">
                  ›
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
