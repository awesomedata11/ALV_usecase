import { useMe } from "../api/hooks";
import type { Theme } from "../theme";
import { ThemeToggle } from "./ThemeToggle";

interface Props {
  // Navigate to the home/cards view (fired by clicking the brand).
  onHome: () => void;
  // Light/dark theme state + toggle (rendered top-right in the header).
  theme: Theme;
  onToggleTheme: () => void;
}

// Persistent top header, rendered ONCE at the app shell level. Layout: brand/logo on
// the LEFT (the ALV brand, which still doubles as a "back to home" affordance); on the
// RIGHT the "Welcome, {user}" greeting + the dark-mode toggle. In-page back-navigation
// is now handled by the per-view breadcrumb (see Breadcrumb), so the brand always reads
// as "ALV-Bricks" regardless of view. Primary app navigation (Home / Downloads) lives
// in the left nav rail. Identity is resolved by the backend from the Databricks Apps
// X-Forwarded-* headers (useMe() also proves FE<->BE wiring).
export function Header({ onHome, theme, onToggleTheme }: Props) {
  const { data, isLoading, isError, error } = useMe();

  return (
    <header className="app-header">
      <button
        type="button"
        className="app-header__brand app-header__brand--button"
        onClick={onHome}
        title="Back to all ALV reports"
      >
        <span className="app-header__logo">ALV</span>
        <span className="app-header__title">ALV-Bricks</span>
      </button>

      <div className="app-header__right">
        <div className="app-header__user">
          {isLoading && <span className="muted">Loading identity…</span>}
          {isError && <span className="error">Identity error: {String(error)}</span>}
          {data && (
            <div className="user-badge">
              <div className="user-badge__line">
                <span className="muted">Welcome,</span>{" "}
                <strong>{data.email ?? "unknown user"}</strong>
              </div>
            </div>
          )}
        </div>

        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
      </div>
    </header>
  );
}
