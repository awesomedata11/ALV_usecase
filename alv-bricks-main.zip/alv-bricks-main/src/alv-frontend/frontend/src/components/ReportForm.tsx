// The metadata-driven selection-criteria form (tasks 5.1–5.4 + submit 7.x). Loads the
// picked report's form def (GET /api/reports/{alv_id}), renders its fields in
// display_order, applies defaults, and validates client-side against the metadata
// `validations` vocabulary. Submit (task 7.x) posts the form values to the submit
// endpoint and shows the returned request_no; client-side validation gates submit.
import { useEffect, useMemo, useState } from "react";
import {
  useCacheCheck,
  usePreviewReport,
  useReportForm,
  useSaveTemplate,
  useSubmitReport,
} from "../api/hooks";
import { FieldControl } from "./FieldControl";
import { SaveTemplateModal } from "./SaveTemplateModal";
import { ReuseRunModal } from "./ReuseRunModal";
import { useFormDrafts } from "../formDraft";
import { initialValues, validateForm, type Errors, type Values } from "../validation";
import type { CacheHit, ValueKinds } from "../api/types";

interface Props {
  alvId: string;
}

export function ReportForm({ alvId }: Props) {
  const { data: form, isLoading, isError, error } = useReportForm(alvId);
  const { getDraft, setDraft } = useFormDrafts();
  const [values, setValues] = useState<Values>({});
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState(false);
  const submit = useSubmitReport(alvId);
  const [previewPage, setPreviewPage] = useState(1);
  const [previewPageSize, setPreviewPageSize] = useState(25);
  const preview = usePreviewReport(alvId);
  const saveTemplate = useSaveTemplate(alvId);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const cacheCheck = useCacheCheck(alvId);
  const [cacheHit, setCacheHit] = useState<CacheHit | null>(null);

  // Seed the field state whenever the resolved report changes (design §3.4: re-render
  // the fields when the report type changes — the field set may differ). PRESERVE any
  // unsubmitted draft: on (re)mount for this alv_id — e.g. after navigating away to
  // Downloads and back, or a browser Back — restore the typed values + touched flag
  // from the form-draft store so in-progress work survives the unmount. Only fall back
  // to metadata defaults when there is no captured draft. Reset any previous submission
  // result so it doesn't carry across reports.
  useEffect(() => {
    if (!form) return;
    const draft = getDraft(alvId);
    if (draft) {
      setValues(draft.values);
      setTouched(draft.touched);
      setErrors(draft.touched ? validateForm(orderedFields, draft.values) : {});
    } else {
      setValues(initialValues(form.fields));
      setErrors({});
      setTouched(false);
    }
    submit.reset();
    preview.reset();
    saveTemplate.reset();
    cacheCheck.reset();
    setShowSaveModal(false);
    setCacheHit(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form, alvId]);

  const orderedFields = useMemo(
    () => (form ? [...form.fields].sort((a, b) => a.display_order - b.display_order) : []),
    [form],
  );

  if (isLoading) return <p className="muted">Loading form…</p>;
  if (isError) return <p className="error">Failed to load form: {String(error)}</p>;
  if (!form) return null;

  const onChange = (paramName: string, value: string) => {
    const next = { ...values, [paramName]: value };
    setValues(next);
    // Mirror the in-progress values into the draft store so they survive navigation.
    setDraft(alvId, { values: next, touched });
    if (touched) setErrors(validateForm(orderedFields, next));
    // Editing after a submission clears the stale result/error.
    if (submit.data || submit.isError) submit.reset();
  };

  // Save the CURRENT form values as a named template (opens the modal, which lets the
  // user also mark date fields dynamic). Validation now runs at save (decision 10) for
  // BOTH kinds — the modal validates and the backend re-validates. Returns the mutation
  // promise so the modal can await it and surface a backend 422.
  const onSaveTemplate = (name: string, valueKinds: ValueKinds) =>
    saveTemplate.mutateAsync({
      template_name: name,
      values,
      value_kinds: Object.keys(valueKinds).length ? valueKinds : undefined,
    });

  const onPreview = () => {
    setTouched(true);
    setDraft(alvId, { values, touched: true });
    const errs = validateForm(orderedFields, values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setPreviewPage(1);
    preview.mutate({ values });
  };

  // Trigger the actual run. Split out so both the normal path and the reuse modal's
  // "Run the job again" button share it.
  const doSubmit = () => {
    setCacheHit(null);
    submit.mutate({ values });
  };

  const onSubmit = async () => {
    // Client-side validation gates submit (task 5.4): validate first, bail on errors.
    setTouched(true);
    setDraft(alvId, { values, touched: true });
    const errs = validateForm(orderedFields, values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    // Task 7.3 — before running the Job, ask whether an identical run can be reused. On a
    // hit, offer the reuse popup; otherwise submit normally. The check is OPTIONAL: if it
    // fails (or finds nothing), fall through to a normal submit so a cache-read problem
    // never blocks a submission.
    try {
      const res = await cacheCheck.mutateAsync({ values });
      if (res.hit) {
        setCacheHit(res.hit);
        return;
      }
    } catch {
      /* cache check failed — proceed with a normal submit */
    }
    doSubmit();
  };

  const hasErrors = Object.keys(errors).length > 0;
  const result = submit.data;

  return (
    <section className="report-form">
      <h2 className="report-form__title">{form.alv_name ?? form.report_label}</h2>
      {form.description && <p className="muted">{form.description}</p>}

      <div className="report-form__fields">
        {orderedFields.map((field) => (
          <FieldControl
            key={field.display_order}
            field={field}
            values={values}
            errors={errors}
            onChange={onChange}
          />
        ))}
      </div>

      <div className="report-form__actions">
        {/* Save the current values as a reusable template (load / manage them from the
            Templates nav item). Opens a modal that also lets the user mark date fields
            dynamic. Save is validation-gated (decision 10): the modal + backend both
            validate. */}
        <button
          type="button"
          className="btn btn--secondary"
          onClick={() => {
            saveTemplate.reset();
            setShowSaveModal(true);
          }}
        >
          Save as template
        </button>
        <button
          type="button"
          className="btn btn--secondary"
          onClick={onPreview}
          disabled={!form?.has_sample_query || submit.isPending || preview.isPending}
          title={!form?.has_sample_query ? "No sample data defined for this report" : undefined}
        >
          {preview.isPending ? "Loading preview…" : "Preview Sample Data"}
        </button>
        <button
          type="button"
          className="btn btn--primary"
          onClick={onSubmit}
          disabled={submit.isPending || cacheCheck.isPending}
        >
          {cacheCheck.isPending ? "Checking…" : submit.isPending ? "Submitting…" : "Submit"}
        </button>
        {touched && !result && (
          <span className={hasErrors ? "error" : "ok"}>
            {hasErrors ? "Please fix the highlighted fields." : "All fields valid."}
          </span>
        )}
      </div>

      {/* Template save outcome (the modal closes itself on success; errors stay in it). */}
      {saveTemplate.isSuccess && !showSaveModal && (
        <div className="submit-result ok" role="status">
          Template <strong>{saveTemplate.data?.template_name}</strong> saved. Open{" "}
          <strong>Templates</strong> in the left nav to load it.
        </div>
      )}

      {/* Submission outcome (task 7.5): the returned request_no + a submitted state.
          No status polling yet (task 8.x) — just confirm it was queued. */}
      {result && (
        <div className="submit-result ok" role="status">
          <strong>Submitted.</strong> Request <code>{result.request_no}</code> is{" "}
          <span className="status-badge status-badge--queued">{result.status}</span>
          {result.run_id != null && <> (run {result.run_id})</>}.
        </div>
      )}
      {submit.isError && (
        <div className="submit-result error" role="alert">
          Submit failed: {String((submit.error as Error)?.message ?? submit.error)}
        </div>
      )}

      {(preview.data || preview.isError) && (
        <section className="preview-section">
          <div className="preview-header">
            <h3 className="preview-title">Sample Data</h3>
            {preview.data && (
              <div className="preview-controls">
                <span className="preview-count">
                  {preview.data.row_count} row{preview.data.row_count !== 1 ? "s" : ""}
                  {preview.data.truncated ? " (truncated)" : ""}
                </span>
                <label className="preview-pagesize-label">
                  Rows per page:
                  <select
                    className="preview-pagesize-select"
                    value={previewPageSize}
                    onChange={e => { setPreviewPageSize(Number(e.target.value)); setPreviewPage(1); }}
                  >
                    {[10, 25, 50, 100].map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </label>
              </div>
            )}
          </div>
          {preview.isError && (
            <p className="error">Preview failed: {String((preview.error as Error)?.message ?? preview.error)}</p>
          )}
          {preview.data && preview.data.row_count === 0 && (
            <p className="muted">No matching sample data for the given inputs.</p>
          )}
          {preview.data && preview.data.rows.length > 0 && (() => {
            const totalPages = Math.max(1, Math.ceil(preview.data!.rows.length / previewPageSize));
            const safePage = Math.min(previewPage, totalPages);
            const start = (safePage - 1) * previewPageSize;
            const pageRows = preview.data!.rows.slice(start, start + previewPageSize);
            return (
              <>
                <div className="preview-table-wrap">
                  <table className="preview-table">
                    <thead>
                      <tr>{preview.data!.columns.map((col, i) => <th key={i}>{col}</th>)}</tr>
                    </thead>
                    <tbody>
                      {pageRows.map((row, ri) => (
                        <tr key={ri}>
                          {(row as unknown[]).map((cell, ci) => (
                            <td key={ci}>{cell === null || cell === undefined ? "" : String(cell)}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {totalPages > 1 && (
                  <div className="preview-pagination">
                    <button className="btn btn--secondary btn--sm" disabled={safePage <= 1} onClick={() => setPreviewPage(p => Math.max(1, p - 1))}>← Prev</button>
                    <span className="preview-page-info">Page {safePage} of {totalPages}</span>
                    <button className="btn btn--secondary btn--sm" disabled={safePage >= totalPages} onClick={() => setPreviewPage(p => Math.min(totalPages, p + 1))}>Next →</button>
                  </div>
                )}
              </>
            );
          })()}
        </section>
      )}

      {showSaveModal && (
        <SaveTemplateModal
          fields={orderedFields}
          values={values}
          isSaving={saveTemplate.isPending}
          onSave={onSaveTemplate}
          onClose={() => setShowSaveModal(false)}
        />
      )}

      {/* Task 7.3 — reuse popup: shown when the pre-submit cache check found an identical,
          still-valid run. "Run the job again" falls through to the normal submit. */}
      {cacheHit && (
        <ReuseRunModal
          hit={cacheHit}
          onRerun={doSubmit}
          onClose={() => setCacheHit(null)}
        />
      )}
    </section>
  );
}
