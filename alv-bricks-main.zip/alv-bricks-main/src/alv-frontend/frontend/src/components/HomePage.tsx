// Home page — a grid of ALV report cards. Every card is data-driven from
// GET /api/report-groups: one card per seeded report_key the caller is PERMITTED to see
// (the backend filters on report_permissions — group or user grant). Clicking a card
// opens the catalogue UI (selection → report type → form).
//
// Zero cards is a NORMAL state (a user with no grants), so we show a short empty state.
import { useState } from "react";
import type { ReportGroup } from "../api/types";
import { useMe, useReportGroups } from "../api/hooks";
import { Breadcrumb } from "./Breadcrumb";
import { AddReportModal } from "./AddReportModal";

// Sort hint only — the pilot report stays first in the grid; every other seeded
// report follows in the (stable) order GET /api/report-groups returns them.
const FIRST_REPORT_KEY = "retail_ledger";

interface Props {
  onOpenReport: (reportKey: string) => void;
}

export function HomePage({ onOpenReport }: Props) {
  const { data, isLoading, isError, error } = useReportGroups();
  // Admin-only "+" card. Sourced from the same cached /api/me the nav uses; the onboard
  // endpoint enforces admin independently (404 for a non-admin), so this only gates the UI.
  const { data: me } = useMe();
  const isAdmin = me?.is_admin ?? false;
  const [addOpen, setAddOpen] = useState(false);

  // Active cards are data-driven: one per seeded report_key. Keep retail_ledger first
  // (sort hint), otherwise preserve the API's stable order. Empty/undefined ⇒ no
  // active cards (placeholders still render); never crash.
  const activeGroups: ReportGroup[] = [...(data?.groups ?? [])].sort((a, b) => {
    if (a.report_key === b.report_key) return 0;
    if (a.report_key === FIRST_REPORT_KEY) return -1;
    if (b.report_key === FIRST_REPORT_KEY) return 1;
    return 0; // stable: leave remaining groups in API order
  });

  return (
    <main className="home">
      <div className="home__heading">
        {/* Home is the root view — a single, current (non-linked) crumb. */}
        <Breadcrumb crumbs={[{ label: "Home" }]} />
        <h1 className="home__title">Choose an ALV report</h1>
      </div>

      {isError && <p className="error">Could not load reports: {String(error)}</p>}

      {isLoading ? (
        // Skeleton grid while the report-groups fetch is in flight.
        <div className="card-grid" aria-hidden="true">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="report-card report-card--skeleton">
              <div className="skeleton-line skeleton-line--title" />
              <div className="skeleton-line skeleton-line--sub" />
              <div className="skeleton-line skeleton-line--meta" />
            </div>
          ))}
        </div>
      ) : (
      <>
      {/* No permitted reports — the user is in none of the groups mapped in
          report_permissions (or nothing is seeded yet). Deliberately vague about
          WHICH reports exist: the backend does not disclose that either. */}
      {!isError && activeGroups.length === 0 && !isAdmin && (
        <div className="empty-state">
          <p className="empty-state__title">No reports available to you</p>
          <p>
            You do not currently have access to any ALV reports. Ask your
            administrator to add you to the relevant reporting group.
          </p>
        </div>
      )}

      <div className="card-grid">
        {/* One data-driven card per seeded, permitted report_key (from /api/report-groups). */}
        {activeGroups.map((g) => {
          const label = g.report_label ?? g.report_key;
          return (
            <button
              key={g.report_key}
              type="button"
              className="report-card report-card--active"
              onClick={() => onOpenReport(g.report_key)}
              title={`Open ${label}`}
            >
              <div className="report-card__title">{label}</div>
              <div className="report-card__subtitle">Applications</div>
              <div className="report-card__meta">
                {g.runnable_count} report{g.runnable_count === 1 ? "" : "s"} available
              </div>
            </button>
          );
        })}

        {/* Admin-only onboarding tile — same size as a report card. Opens the paste-a-
            manifest modal. Rendered last so it trails the report cards; shows even when
            the admin has zero permitted reports (so a fresh workspace can be seeded). */}
        {isAdmin && (
          <button
            type="button"
            className="report-card report-card--add"
            onClick={() => setAddOpen(true)}
            title="Add a report"
          >
            <span className="report-card--add__plus" aria-hidden="true">
              +
            </span>
            <span className="report-card--add__label">Add a report</span>
          </button>
        )}
      </div>
      </>
      )}

      {addOpen && <AddReportModal onClose={() => setAddOpen(false)} />}
    </main>
  );
}
