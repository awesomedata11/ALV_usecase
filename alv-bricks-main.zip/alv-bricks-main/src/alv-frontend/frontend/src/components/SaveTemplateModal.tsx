// Save-as-template modal. Replaces the old inline name box: it names the template AND
// lets the user mark the report's DATE fields as dynamic (a relative-date preset that
// resolves at load), per the dynamic-templates feature.
//
// Layout: a name field, then a row per date field (scalar `date` and each side of a
// `date_range`) with a Static | Dynamic toggle. Dynamic reveals a preset dropdown; the
// "± n days" preset reveals a number input. A date_range also offers a one-click "From
// month start to today" shortcut that sets from=FIRST_DAY_CUR_MONTH, to=TODAY. A live
// "resolves to today" line shows the effect. Non-date fields are saved as static as-is.
//
// VALIDATE-BEFORE-SAVE (decision 10): before POSTing, the modal resolves dynamic presets
// to today's dates, merges over the static values, and runs the SAME validation.ts
// vocabulary. If it fails it shows the exact error(s) and does NOT save. The backend
// re-validates and can still return a 422 (its errors are surfaced too).
import { useMemo, useState } from "react";
import type { FormField, ValueKinds, DynamicPreset } from "../api/types";
import { validateForm, type Values } from "../validation";
import { PRESETS, presetNeedsN, resolvePresetLocally } from "../dynamicPresets";
import { ApiError } from "../api/client";

interface Props {
  fields: FormField[];
  values: Values;
  isSaving: boolean;
  // Save handler: resolves value_kinds server-side. Rejects with an ApiError on 422.
  onSave: (name: string, valueKinds: ValueKinds) => Promise<unknown>;
  onClose: () => void;
}

// The date params a template may mark dynamic: scalar `date` fields + date_range endpoints.
interface DateParam {
  param_name: string;
  label: string;
}

function dateParams(fields: FormField[]): DateParam[] {
  const out: DateParam[] = [];
  for (const f of fields) {
    if (f.kind === "composite" && f.control === "date_range" && f.parts) {
      out.push({ param_name: f.parts.from.param_name, label: `${f.display_label} — from` });
      out.push({ param_name: f.parts.to.param_name, label: `${f.display_label} — to` });
    } else if (f.kind === "scalar" && f.data_type === "date" && f.param_name) {
      out.push({ param_name: f.param_name, label: f.display_label });
    }
  }
  return out;
}

// Per-date-param editor state: static, or dynamic with a preset (+ n for ± days).
interface KindState {
  dynamic: boolean;
  preset: DynamicPreset;
  n: number;
}

export function SaveTemplateModal({ fields, values, isSaving, onSave, onClose }: Props) {
  const dParams = useMemo(() => dateParams(fields), [fields]);
  const rangeFields = useMemo(
    () => fields.filter((f) => f.kind === "composite" && f.control === "date_range" && f.parts),
    [fields],
  );

  const [name, setName] = useState("");
  const [kinds, setKinds] = useState<Record<string, KindState>>(() => {
    const init: Record<string, KindState> = {};
    for (const p of dParams) init[p.param_name] = { dynamic: false, preset: "TODAY", n: -1 };
    return init;
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saveError, setSaveError] = useState<string | null>(null);

  // Assemble the value_kinds map from the dynamic rows.
  const buildValueKinds = (): ValueKinds => {
    const vk: ValueKinds = {};
    for (const p of dParams) {
      const k = kinds[p.param_name];
      if (k?.dynamic) {
        vk[p.param_name] = presetNeedsN(k.preset)
          ? { kind: "dynamic", preset: k.preset, n: k.n }
          : { kind: "dynamic", preset: k.preset };
      }
    }
    return vk;
  };

  // Resolve dynamic params to today's dates, merged over the static values — the shape
  // the backend will validate. Used by the pre-save validation + the live preview.
  const resolvedValues = (): Values => {
    const merged: Values = { ...values };
    for (const p of dParams) {
      const k = kinds[p.param_name];
      if (k?.dynamic) merged[p.param_name] = resolvePresetLocally(k.preset, k.n);
    }
    return merged;
  };

  const setKind = (param: string, patch: Partial<KindState>) => {
    setKinds((prev) => ({ ...prev, [param]: { ...prev[param], ...patch } }));
  };

  // "From month start to today" shortcut for a date_range: from=first-of-month, to=today.
  const applyMonthToDate = (fromParam: string, toParam: string) => {
    setKinds((prev) => ({
      ...prev,
      [fromParam]: { ...prev[fromParam], dynamic: true, preset: "FIRST_DAY_CUR_MONTH" },
      [toParam]: { ...prev[toParam], dynamic: true, preset: "TODAY" },
    }));
  };

  const onSubmit = async () => {
    setSaveError(null);
    if (!name.trim()) {
      setErrors({ __name: "Please enter a template name." });
      return;
    }
    // Validate-before-save: resolve dynamic → today, then run the form validation.
    const errs = validateForm(fields, resolvedValues());
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    try {
      await onSave(name.trim(), buildValueKinds());
      onClose();
    } catch (e) {
      // Backend re-validation (422) or any other save error.
      if (e instanceof ApiError && e.status === 422) {
        setSaveError(e.message);
      } else {
        setSaveError(String((e as Error)?.message ?? e));
      }
    }
  };

  const fieldError = Object.entries(errors).find(([k]) => k !== "__name");

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-label="Save as template">
      <div className="modal">
        <div className="modal__header">
          <h2 className="modal__title">Save as template</h2>
          <button type="button" className="modal__close" aria-label="Close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="modal__body">
          <label className="field">
            <span className="field__label">Template name</span>
            <input
              type="text"
              autoFocus
              maxLength={128}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Last month"
            />
          </label>
          {errors.__name && <p className="error">{errors.__name}</p>}

          {dParams.length > 0 && (
            <div className="tpl-dynamic">
              <h3 className="tpl-dynamic__title">Date fields</h3>
              <p className="muted tpl-dynamic__hint">
                Keep a date <strong>static</strong> to save the exact value, or make it{" "}
                <strong>dynamic</strong> so it resolves relative to the date the template is
                loaded.
              </p>

              {rangeFields.map((f) => (
                <div key={`shortcut-${f.display_order}`} className="tpl-dynamic__shortcut">
                  <button
                    type="button"
                    className="btn btn--secondary btn--sm"
                    onClick={() => applyMonthToDate(f.parts!.from.param_name, f.parts!.to.param_name)}
                  >
                    {f.display_label}: from month start to today
                  </button>
                </div>
              ))}

              {dParams.map((p) => {
                const k = kinds[p.param_name];
                return (
                  <div key={p.param_name} className="tpl-dynamic__row">
                    <div className="tpl-dynamic__name">{p.label}</div>
                    <div className="tpl-dynamic__controls">
                      <label className="tpl-dynamic__toggle">
                        <input
                          type="checkbox"
                          checked={k.dynamic}
                          onChange={(e) => setKind(p.param_name, { dynamic: e.target.checked })}
                        />
                        Dynamic
                      </label>
                      {k.dynamic && (
                        <>
                          <select
                            value={k.preset}
                            onChange={(e) =>
                              setKind(p.param_name, { preset: e.target.value as DynamicPreset })
                            }
                          >
                            {PRESETS.map((pm) => (
                              <option key={pm.preset} value={pm.preset}>
                                {pm.label}
                              </option>
                            ))}
                          </select>
                          {presetNeedsN(k.preset) && (
                            <input
                              type="number"
                              className="tpl-dynamic__n"
                              value={k.n}
                              onChange={(e) => setKind(p.param_name, { n: Number(e.target.value) })}
                              aria-label="days offset"
                            />
                          )}
                          <span className="tpl-dynamic__preview muted">
                            → {resolvePresetLocally(k.preset, k.n)}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {fieldError && (
            <p className="error">
              This template is not valid: {fieldError[1]}
            </p>
          )}
          {saveError && <p className="error">Could not save: {saveError}</p>}
        </div>

        <div className="modal__footer">
          <button type="button" className="btn btn--secondary" onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="btn btn--primary"
            onClick={onSubmit}
            disabled={isSaving || !name.trim()}
          >
            {isSaving ? "Saving…" : "Save template"}
          </button>
        </div>
      </div>
    </div>
  );
}
