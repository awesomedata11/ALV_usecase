// Admin console — grant / revoke report access. Reachable only from the Admin nav
// item, which shows only when GET /api/me reports is_admin (the endpoints enforce
// independently: a non-admin gets 404). Flow: pick a report from the dropdown → see
// its current grants (group + user, active + revoked) → add principals (a comma-
// separated list of emails and/or group names) → revoke individual grants.
//
// A token containing '@' is a user email; anything else is a group name (the backend
// uses the same heuristic). Per-token results are surfaced so a partially-bad list
// still applies the good tokens. Grants take effect immediately (the backend clears
// the permission cache on every write).
import { useMemo, useState } from "react";
import {
  useAdminReports,
  useGrantReport,
  useReportGrants,
  useRevokeReport,
} from "../api/hooks";
import type { Grant, GrantTokenResult } from "../api/types";
import { Breadcrumb } from "./Breadcrumb";
import { Spinner } from "./Spinner";

export function AdminPage() {
  // Enabled unconditionally — the page only mounts for an admin (nav-gated), and the
  // endpoint 404s a non-admin anyway.
  const reports = useAdminReports(true);
  const [reportKey, setReportKey] = useState<string>("");

  // Default the dropdown to the first report once the list loads.
  const options = reports.data?.groups ?? [];
  const selected = reportKey || options[0]?.report_key || "";

  return (
    <main className="admin">
      <div className="admin__heading">
        <Breadcrumb crumbs={[{ label: "Home", to: "/" }, { label: "Admin" }]} />
        <h1 className="admin__title">Manage report access</h1>
        <p className="muted">
          Grant or revoke access to a report for a workspace group or an individual
          user. Type a comma-separated list mixing group names and user emails.
        </p>
      </div>

      {reports.isError && (
        <p className="error">Could not load reports: {String(reports.error)}</p>
      )}

      <div className="field admin__report-picker">
        <label className="field__label" htmlFor="admin-report">
          Report
        </label>
        <select
          id="admin-report"
          value={selected}
          disabled={reports.isLoading || options.length === 0}
          onChange={(e) => setReportKey(e.target.value)}
        >
          {options.map((g) => (
            <option key={g.report_key} value={g.report_key}>
              {g.report_label ?? g.report_key}
            </option>
          ))}
        </select>
      </div>

      {selected ? <GrantsPanel reportKey={selected} /> : null}
    </main>
  );
}

// The grant/revoke panel for one report. Kept as a child keyed on reportKey so its
// input + result state resets cleanly when the admin switches reports.
function GrantsPanel({ reportKey }: { reportKey: string }) {
  const grantsQuery = useReportGrants(reportKey);
  const grant = useGrantReport(reportKey);
  const revoke = useRevokeReport(reportKey);
  const [principals, setPrincipals] = useState("");

  const results: GrantTokenResult[] = grant.data?.results ?? [];

  const onGrant = () => {
    if (!principals.trim()) return;
    grant.mutate(principals, {
      onSuccess: () => setPrincipals(""),
    });
  };

  const grants = grantsQuery.data?.grants ?? [];
  const { active, revoked } = useMemo(() => {
    const a: Grant[] = [];
    const r: Grant[] = [];
    for (const g of grants) (g.is_active ? a : r).push(g);
    return { active: a, revoked: r };
  }, [grants]);

  return (
    <section className="admin__panel" key={reportKey}>
      {/* Add grants */}
      <div className="admin__grant-row">
        <div className="field admin__grant-input">
          <label className="field__label" htmlFor="admin-principals">
            Add access for
          </label>
          <input
            id="admin-principals"
            type="text"
            placeholder="alice@example.com, alv-report_ledger_group"
            value={principals}
            onChange={(e) => setPrincipals(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") onGrant();
            }}
          />
        </div>
        <button
          type="button"
          className="btn btn--primary"
          disabled={!principals.trim() || grant.isPending}
          onClick={onGrant}
        >
          {grant.isPending ? "Granting…" : "Grant access"}
        </button>
      </div>

      {grant.isError && (
        <p className="error">Could not grant: {String(grant.error)}</p>
      )}

      {/* Per-token results of the last grant */}
      {results.length > 0 && (
        <ul className="admin__results">
          {results.map((r, i) => (
            <li key={`${r.token}-${i}`} className={`admin__result admin__result--${r.outcome}`}>
              <span className="admin__result-token">{r.token}</span>
              <span className="admin__result-outcome">
                {r.outcome === "granted"
                  ? `granted (${r.principal_type})`
                  : r.outcome === "invalid"
                    ? `invalid${r.detail ? `: ${r.detail}` : ""}`
                    : r.outcome}
              </span>
            </li>
          ))}
        </ul>
      )}

      {/* Current grants */}
      <h2 className="admin__section-title">Current access</h2>
      {grantsQuery.isLoading ? (
        <Spinner />
      ) : grantsQuery.isError ? (
        <p className="error">Could not load grants: {String(grantsQuery.error)}</p>
      ) : active.length === 0 ? (
        <div className="empty-state">
          <p className="empty-state__title">No one has access yet</p>
          <p>This report is hidden from everyone until you grant access above.</p>
        </div>
      ) : (
        <table className="admin__table">
          <thead>
            <tr>
              <th>Type</th>
              <th>Principal</th>
              <th>Granted by</th>
              <th aria-label="Actions" />
            </tr>
          </thead>
          <tbody>
            {active.map((g) => (
              <tr key={`${g.principal_type}:${g.principal_name}`}>
                <td>
                  <span className={`admin__pill admin__pill--${g.principal_type}`}>
                    {g.principal_type}
                  </span>
                </td>
                <td>{g.principal_name}</td>
                <td className="muted">{g.granted_by ?? "—"}</td>
                <td className="admin__table-actions">
                  <button
                    type="button"
                    className="btn btn--secondary btn--sm"
                    disabled={revoke.isPending}
                    onClick={() =>
                      revoke.mutate({
                        principal_type: g.principal_type,
                        principal_name: g.principal_name,
                      })
                    }
                  >
                    Revoke
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {revoke.isError && (
        <p className="error">Could not revoke: {String(revoke.error)}</p>
      )}

      {/* Previously-revoked grants: shown muted so an admin can see history and re-grant. */}
      {revoked.length > 0 && (
        <details className="admin__revoked">
          <summary>{revoked.length} revoked grant{revoked.length === 1 ? "" : "s"}</summary>
          <ul>
            {revoked.map((g) => (
              <li key={`${g.principal_type}:${g.principal_name}`}>
                <span className={`admin__pill admin__pill--${g.principal_type}`}>
                  {g.principal_type}
                </span>{" "}
                {g.principal_name}
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  );
}
