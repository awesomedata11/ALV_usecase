// Output-file preview screen — shows the first rows of a completed run's OUTPUT FILE,
// read off the UC Volume by the backend (GET /api/requests/{request_no}/output-preview).
//
// This is the on-screen twin of the Download action, NOT the report form's "Preview
// Sample Data" (which runs a SQL query against a sample table). It runs no SQL — the
// backend parses the actual generated file and returns a capped table (or a raw-text /
// binary fallback). Reached from the Downloads page "Preview" button.
import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useOutputPreview } from "../api/hooks";
import { Breadcrumb } from "./Breadcrumb";
import { Spinner } from "./Spinner";

const PAGE_SIZE = 100;

// Same-origin download link for the full result (the preview is capped).
function downloadHref(requestNo: string): string {
  return `/api/requests/${encodeURIComponent(requestNo)}/download`;
}

export function OutputPreviewPage() {
  const { requestNo } = useParams<{ requestNo: string }>();
  const { data, isLoading, isError, error } = useOutputPreview(requestNo ?? null);
  const [page, setPage] = useState(1);

  const totalPages = useMemo(
    () => (data ? Math.max(1, Math.ceil(data.rows.length / PAGE_SIZE)) : 1),
    [data],
  );
  const safePage = Math.min(page, totalPages);
  const pageRows = useMemo(() => {
    if (!data) return [];
    const start = (safePage - 1) * PAGE_SIZE;
    return data.rows.slice(start, start + PAGE_SIZE);
  }, [data, safePage]);

  return (
    <main className="main">
      <Breadcrumb
        crumbs={[
          { label: "Home", to: "/" },
          { label: "Downloads", to: "/downloads" },
          { label: "Preview" },
        ]}
      />
      <h1 className="main__title">Output preview</h1>
      <p className="muted">
        Request <code>{requestNo}</code>
        {data ? <> · <code>{data.filename}</code></> : null}
      </p>

      {isLoading && <Spinner label="Reading output file…" />}
      {isError && (
        <p className="error">Could not load preview: {String((error as Error)?.message ?? error)}</p>
      )}

      {data && (
        <section className="preview-section">
          <div className="preview-header">
            {data.format !== "binary" && (
              <div className="preview-controls">
                <span className="preview-count">
                  {data.row_count} {data.format === "csv" ? "row" : "line"}
                  {data.row_count !== 1 ? "s" : ""}
                  {data.truncated ? " shown (truncated)" : ""}
                </span>
              </div>
            )}
            <a className="btn btn--secondary btn--sm" href={downloadHref(requestNo!)} download>
              Download full file
            </a>
          </div>

          {data.truncated && (
            <p className="muted">
              Showing the first part of this file. Download for the complete result.
            </p>
          )}

          {/* CSV → a table (client-side paginated). */}
          {data.format === "csv" && data.rows.length > 0 && (
            <>
              <div className="preview-table-wrap">
                <table className="preview-table">
                  <thead>
                    <tr>
                      {data.columns.map((col, i) => (
                        <th key={i}>{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {pageRows.map((row, ri) => (
                      <tr key={ri}>
                        {(row as unknown[]).map((cell, ci) => (
                          <td key={ci}>{cell === null || cell === undefined ? "" : String(cell)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {totalPages > 1 && (
                <div className="preview-pagination">
                  <button
                    className="btn btn--secondary btn--sm"
                    disabled={safePage <= 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                  >
                    ← Prev
                  </button>
                  <span className="preview-page-info">
                    Page {safePage} of {totalPages}
                  </span>
                  <button
                    className="btn btn--secondary btn--sm"
                    disabled={safePage >= totalPages}
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  >
                    Next →
                  </button>
                </div>
              )}
            </>
          )}

          {data.format === "csv" && data.rows.length === 0 && (
            <p className="muted">This file has no data rows.</p>
          )}

          {/* Non-CSV text → a raw block. */}
          {data.format === "text" && (
            <pre className="preview-text-block">{data.text}</pre>
          )}

          {/* Unpreviewable file type. */}
          {data.format === "binary" && (
            <p className="muted">
              Preview is not available for this file type. Use “Download full file” to
              open it.
            </p>
          )}
        </section>
      )}
    </main>
  );
}
