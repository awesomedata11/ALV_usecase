// Small inline loading indicator: an accent-colored spinner with an optional
// label. Used on the async fetches (home report-groups, downloads list).
interface Props {
  label?: string;
}

export function Spinner({ label = "Loading…" }: Props) {
  return (
    <div className="loading-row" role="status" aria-live="polite">
      <span className="spinner" aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
}
