// Downloads page — lists runs from request_log (GET /api/requests) as a table:
// Request No, Report, Status, Submitted By, Submitted At, and per-row Parameters +
// Download actions.
//
// Filtering, search, sort and paging are ALL server-side: the controls below feed
// query params that the backend applies in SQL before its limit, so a scope change or
// a search re-queries the whole table rather than re-filtering the rows already on
// screen. Nothing here filters client-side.
//
// The Download button triggers the App-proxied UC Volume download
// (GET /api/requests/{request_no}/download) once a run has produced output; until then
// it stays disabled with a clear "no output yet" hint.
import { useEffect, useId, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { outputPreviewPath } from "../App";
import type { RequestRow, RequestScope, RequestSort } from "../api/types";
import {
  isTerminalStatus,
  useRequestParams,
  useRequestStatus,
  useRequests,
} from "../api/hooks";
import { Breadcrumb } from "./Breadcrumb";
import { Spinner } from "./Spinner";

const PAGE_SIZE = 50;
// Wait this long after the last keystroke before re-querying. Long enough that typing
// a report name is one request, short enough to feel immediate.
const SEARCH_DEBOUNCE_MS = 300;

// Same-origin path the browser hits to download a run's output. The backend streams
// the file as an attachment (Content-Disposition), so a plain anchor navigation is
// enough — no fetch/blob dance and the filename comes from the response header.
function downloadHref(requestNo: string): string {
  return `/api/requests/${encodeURIComponent(requestNo)}/download`;
}

// Map a request_log status to a colored badge variant. QUEUED reads as an accent
// pill; running/success/error get their own status colors; anything else stays
// neutral. Defensive to case + null.
function statusBadgeClass(status: string | null): string {
  switch ((status ?? "").toUpperCase()) {
    case "QUEUED":
    case "PENDING":
      return "status-badge status-badge--queued";
    case "RUNNING":
    case "IN_PROGRESS":
      return "status-badge status-badge--running";
    case "COMPLETED":
    case "SUCCESS":
    case "SUCCEEDED":
      return "status-badge status-badge--success";
    case "FAILED":
    case "ERROR":
    case "CANCELLED":
    case "CANCELED":
      return "status-badge status-badge--error";
    default:
      return "status-badge";
  }
}

// Format the warehouse ISO timestamp for display; fall back to the raw string if it
// isn't parseable (the backend passes request_log.submitted_at through as text).
function formatSubmittedAt(raw: string | null): string {
  if (!raw) return "—";
  const d = new Date(raw);
  return isNaN(d.getTime()) ? raw : d.toLocaleString();
}

// Debounce a rapidly-changing value (the search box) so each keystroke doesn't fire a
// warehouse query. Returns the value as it was SEARCH_DEBOUNCE_MS ago at rest.
function useDebounced<T>(value: T, delayMs: number): T {
  const [settled, setSettled] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setSettled(value), delayMs);
    return () => window.clearTimeout(timer);
  }, [value, delayMs]);
  return settled;
}

// One row's live state — polls the status endpoint for non-terminal rows and merges
// the result over the seeded list values. The poll (useRequestStatus) also carries
// the captured output_path (task 9.x), so a run that completes while the page is open
// enables its Download button without a manual refresh. Shared by the status badge
// and the download action so each row polls exactly once.
function useRowState(row: RequestRow): { status: string | null; ready: boolean } {
  const { data } = useRequestStatus(row.request_no, row.status);
  const status = data?.status ?? row.status;
  // Prefer the live output_path once polled; fall back to the seeded list value.
  const outputPath = data?.output_path ?? row.output_path;
  const ready =
    isTerminalStatus(status) &&
    (status ?? "").toUpperCase() !== "FAILED" &&
    (status ?? "").toUpperCase() !== "CANCELLED" &&
    (status ?? "").toUpperCase() !== "CANCELED" &&
    !!outputPath;
  return { status, ready };
}

// Status cell — shows the row's status badge from the shared live state.
function StatusCell({ status }: { status: string | null }) {
  return <span className={statusBadgeClass(status)}>{status ?? "—"}</span>;
}

// Preview action — opens the on-screen output-file preview screen (the read-only twin
// of Download). Same readiness gate as Download: enabled only when the run is COMPLETED
// with a captured output_path; disabled with a hint otherwise. A router Link (not an
// anchor) so it navigates within the SPA.
function PreviewAction({ row, ready }: { row: RequestRow; ready: boolean }) {
  if (!ready) {
    return (
      <button
        type="button"
        className="btn btn--secondary"
        disabled
        title="No output available yet"
      >
        Preview
      </button>
    );
  }
  return (
    <Link
      className="btn btn--secondary"
      to={outputPreviewPath(row.request_no)}
      title="View the output file on-screen"
    >
      Preview
    </Link>
  );
}

// Download action — a real App-proxied download once the run has produced output.
// Enabled only when the run is COMPLETED with a captured output_path; otherwise it
// stays disabled with a "no output yet" hint (never exposes the storage path). The
// anchor's `download` attr + the backend's Content-Disposition drive the filename.
function DownloadAction({ row, ready }: { row: RequestRow; ready: boolean }) {
  if (!ready) {
    return (
      <button
        type="button"
        className="btn btn--secondary"
        disabled
        title="No output available yet"
      >
        Download
      </button>
    );
  }
  return (
    <a
      className="btn btn--secondary"
      href={downloadHref(row.request_no)}
      download
      title="Download output"
    >
      Download
    </a>
  );
}

// The expanded parameters panel for one row. Fetched only once opened (the hook is
// disabled until then), so expanding one row costs one request, not fifty.
//
// The payload is the EFFECTIVE JOB PAYLOAD — server-normalized, with omit_if_blank
// params dropped — so it is labelled "Parameters sent to the job", never "what the
// user entered". A null/empty/malformed stored payload comes back parse_ok=false and
// is shown as an explanatory note rather than an error.
function ParamsPanel({ requestNo, colSpan }: { requestNo: string; colSpan: number }) {
  const { data, isLoading, isError, error } = useRequestParams(requestNo);
  const entries = Object.entries(data?.parameters ?? {});

  return (
    <tr className="params-row">
      <td colSpan={colSpan}>
        <div className="params-panel">
          <p className="params-panel__title">Parameters sent to the job</p>
          <p className="muted params-panel__note">
            The effective payload the run was dispatched with — normalized by the
            server, with optional blank parameters omitted.
          </p>

          {isLoading && <Spinner label="Loading parameters…" />}
          {isError && (
            <p className="error">Could not load parameters: {String(error)}</p>
          )}

          {data && !data.parse_ok && (
            <p className="muted">{data.detail ?? "No parameters are available."}</p>
          )}

          {data?.parse_ok && entries.length === 0 && (
            <p className="muted">This run was dispatched with no parameters.</p>
          )}

          {entries.length > 0 && (
            <dl className="params-list">
              {entries.map(([name, value]) => (
                <div className="params-list__item" key={name}>
                  <dt>
                    <code>{name}</code>
                  </dt>
                  {/* A null value means the parameter WAS sent, but blank — say so
                      rather than rendering an ambiguous empty cell. */}
                  <dd>
                    {value === null ? (
                      <span className="muted">(blank)</span>
                    ) : (
                      <code>{value}</code>
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          )}
        </div>
      </td>
    </tr>
  );
}

// A single request row: polls once, feeding both the status badge and the download.
// The Parameters toggle expands an adjacent panel row (aria-expanded/aria-controls so
// it reads correctly to a screen reader).
function RequestTableRow({
  row,
  colSpan,
  isOpen,
  onToggle,
}: {
  row: RequestRow;
  colSpan: number;
  isOpen: boolean;
  onToggle: () => void;
}) {
  const { status, ready } = useRowState(row);
  const panelId = `params-${row.request_no}`;

  return (
    <>
      <tr>
        <td>
          <code>{row.request_no}</code>
        </td>
        <td>{row.report_label ?? row.alv_id ?? "—"}</td>
        <td>
          <StatusCell status={status} />
        </td>
        <td>{row.submitted_by ?? "—"}</td>
        <td>{formatSubmittedAt(row.submitted_at)}</td>
        <td className="downloads-table__actions">
          <button
            type="button"
            className="btn btn--secondary"
            onClick={onToggle}
            aria-expanded={isOpen}
            aria-controls={panelId}
            title="Show the parameters this run was dispatched with"
          >
            {isOpen ? "Hide parameters" : "Parameters"}
          </button>
          <PreviewAction row={row} ready={ready} />
          <DownloadAction row={row} ready={ready} />
        </td>
      </tr>
      {isOpen && <ParamsPanel requestNo={row.request_no} colSpan={colSpan} />}
    </>
  );
}

const COLUMN_COUNT = 6;

export function DownloadsPage() {
  // Default view: "Accessible by me", newest first.
  const [scope, setScope] = useState<RequestScope>("accessible");
  const [sort, setSort] = useState<RequestSort>("submitted_at_desc");
  const [searchInput, setSearchInput] = useState("");
  const [offset, setOffset] = useState(0);
  const [openRow, setOpenRow] = useState<string | null>(null);

  const search = useDebounced(searchInput, SEARCH_DEBOUNCE_MS);
  const searchId = useId();

  // Any change to what's being listed invalidates the current page position — page 3
  // of one filter is meaningless in another. Reset to the first page (and collapse an
  // open panel, whose row may not be in the new result set).
  const firstRender = useRef(true);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    setOffset(0);
    setOpenRow(null);
  }, [scope, sort, search]);

  const { data, isLoading, isError, error, isFetching } = useRequests({
    scope,
    sort,
    q: search,
    limit: PAGE_SIZE,
    offset,
  });

  const requests = data?.requests ?? [];
  const hasMore = data?.has_more ?? false;
  const pageStart = requests.length > 0 ? offset + 1 : 0;
  const pageEnd = offset + requests.length;
  const isSearching = search.trim().length > 0;

  return (
    <main className="main">
      {/* Home > Downloads. "Home" links back to the cards view. */}
      <Breadcrumb crumbs={[{ label: "Home", to: "/" }, { label: "Downloads" }]} />
      <h1 className="main__title">Downloads</h1>
      <p className="muted">
        Report runs you can access. Download is enabled once a run completes.
      </p>

      {/* Controls. Every one of these is a server-side query param. */}
      <div className="downloads-controls">
        {/* Scope toggle — a radiogroup so arrow keys move between the two options. */}
        <div
          className="segmented"
          role="radiogroup"
          aria-label="Which runs to show"
        >
          <button
            type="button"
            role="radio"
            aria-checked={scope === "accessible"}
            className={`segmented__option${scope === "accessible" ? " is-active" : ""}`}
            onClick={() => setScope("accessible")}
          >
            Accessible by me
          </button>
          <button
            type="button"
            role="radio"
            aria-checked={scope === "mine"}
            className={`segmented__option${scope === "mine" ? " is-active" : ""}`}
            onClick={() => setScope("mine")}
          >
            Owned by me
          </button>
        </div>

        <div className="downloads-controls__search">
          <label className="downloads-controls__label" htmlFor={searchId}>
            Search report
          </label>
          <input
            id={searchId}
            type="search"
            value={searchInput}
            placeholder="Report name…"
            onChange={(e) => setSearchInput(e.target.value)}
          />
        </div>

        <div className="downloads-controls__sort">
          <label className="downloads-controls__label" htmlFor={`${searchId}-sort`}>
            Sort
          </label>
          <select
            id={`${searchId}-sort`}
            value={sort}
            onChange={(e) => setSort(e.target.value as RequestSort)}
          >
            <option value="submitted_at_desc">Newest first</option>
            <option value="submitted_at_asc">Oldest first</option>
          </select>
        </div>
      </div>

      {isLoading && <Spinner label="Loading runs…" />}
      {isError && <p className="error">Could not load runs: {String(error)}</p>}

      {!isLoading && !isError && requests.length === 0 && (
        <div className="empty-state">
          <p className="empty-state__title">
            {isSearching
              ? "No runs match that search"
              : scope === "mine"
                ? "You have no runs yet"
                : "No runs yet"}
          </p>
          <p>
            {isSearching
              ? "Try a different report name, or clear the search."
              : scope === "mine"
                ? "Runs you submit will appear here. Switch to “Accessible by me” to see everyone’s runs for your reports."
                : "Submitted report runs will appear here once you run a report."}
          </p>
        </div>
      )}

      {requests.length > 0 && (
        <>
          <div className="card downloads-card">
            <table className="downloads-table">
              <thead>
                <tr>
                  <th>Request No</th>
                  <th>Report</th>
                  <th>Status</th>
                  <th>Submitted By</th>
                  <th>Submitted At</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => (
                  <RequestTableRow
                    key={r.request_no}
                    row={r}
                    colSpan={COLUMN_COUNT}
                    isOpen={openRow === r.request_no}
                    onToggle={() =>
                      setOpenRow(openRow === r.request_no ? null : r.request_no)
                    }
                  />
                ))}
              </tbody>
            </table>
          </div>

          {/* Pager. `has_more` comes from the server (exact), so Next is only ever
              enabled when a next page really exists. */}
          <div className="pager">
            <p className="pager__status muted" aria-live="polite">
              Showing {pageStart}–{pageEnd}
              {isFetching && " · updating…"}
            </p>
            <div className="pager__actions">
              <button
                type="button"
                className="btn btn--secondary"
                onClick={() => {
                  setOffset(Math.max(0, offset - PAGE_SIZE));
                  setOpenRow(null);
                }}
                disabled={offset === 0}
              >
                Previous
              </button>
              <button
                type="button"
                className="btn btn--secondary"
                onClick={() => {
                  setOffset(offset + PAGE_SIZE);
                  setOpenRow(null);
                }}
                disabled={!hasMore}
              >
                Next
              </button>
            </div>
          </div>
        </>
      )}
    </main>
  );
}
