// Templates screen — the saved parameter templates for ONE report type (alv_id),
// reached from the contextual "Templates" left-nav item shown while a report is open.
// A template is a named snapshot of the form values the user saved (via "Save as
// template" on the report form); this screen lets him LOAD one back into the form,
// RENAME it, or DELETE it. Owner-private: the backend only ever returns the caller's
// own templates (404s the report itself if he may not see it).
//
// LOAD writes the template's values into the shared FormDraftProvider store (keyed by
// alv_id) and navigates to the report form, which restores that draft on mount — the
// same mechanism that preserves unsubmitted work across navigation. So loading a
// template is "seed the draft, then go to the form".
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { reportPath } from "../App";
import {
  fetchTemplate,
  useDeleteTemplate,
  useRenameTemplate,
  useReportForm,
  useTemplates,
} from "../api/hooks";
import type { TemplateSummary } from "../api/types";
import { useFormDrafts } from "../formDraft";
import { Breadcrumb } from "./Breadcrumb";
import { Spinner } from "./Spinner";

export function TemplatesPage() {
  const { reportKey, alvId } = useParams<{ reportKey: string; alvId: string }>();
  const navigate = useNavigate();
  const { setDraft } = useFormDrafts();

  // The report form def gives us the human labels + doubles as the access check: an
  // unpermitted / unknown report 404s here exactly as it does on the form itself.
  const { data: form, isError: formError, error: formErr } = useReportForm(alvId ?? null);
  const templates = useTemplates(alvId ?? null);
  const rename = useRenameTemplate(alvId ?? "");
  const del = useDeleteTemplate(alvId ?? "");

  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");

  if (!reportKey || !alvId) return null;

  const backToForm = () => navigate(reportPath(reportKey, alvId));

  const onLoad = async (t: TemplateSummary) => {
    setLoadError(null);
    setLoadingId(t.template_id);
    try {
      // Load against the TEMPLATE'S OWN report type (report-wide list) — not the screen's
      // entry-point alv_id. Seed that report type's draft, then navigate to its form.
      const detail = await fetchTemplate(t.alv_id, t.template_id);
      setDraft(t.alv_id, { values: { ...detail.values }, touched: false });
      navigate(reportPath(reportKey, t.alv_id));
    } catch (e) {
      setLoadError(String((e as Error)?.message ?? e));
    } finally {
      setLoadingId(null);
    }
  };

  const startRename = (t: TemplateSummary) => {
    setRenamingId(t.template_id);
    setRenameValue(t.template_name);
  };
  const submitRename = (t: TemplateSummary) => {
    const name = renameValue.trim();
    if (!name || name === t.template_name) {
      setRenamingId(null);
      return;
    }
    rename.mutate(
      { alvId: t.alv_id, templateId: t.template_id, template_name: name },
      { onSuccess: () => setRenamingId(null) },
    );
  };

  const reportLabel = form?.report_label ?? form?.alv_name ?? reportKey;
  const rows = templates.data?.templates ?? [];

  return (
    <main className="templates">
      <div className="templates__heading">
        <Breadcrumb
          crumbs={[
            { label: "Home", to: "/" },
            { label: reportLabel, to: reportPath(reportKey, alvId) },
            { label: "Templates" },
          ]}
        />
        <h1 className="templates__title">Saved templates</h1>
        <p className="muted">
          Your saved parameter templates for <strong>{reportLabel}</strong> — across all its
          selections and report types. Load one to fill its form, then Submit or Preview as
          usual. Only you can see your templates.
        </p>
        <button type="button" className="btn btn--secondary btn--sm" onClick={backToForm}>
          ← Back to report
        </button>
      </div>

      {formError && (
        <p className="error">Could not open this report: {String(formErr)}</p>
      )}
      {loadError && <p className="error">Could not load template: {loadError}</p>}
      {rename.isError && <p className="error">Could not rename: {String(rename.error)}</p>}
      {del.isError && <p className="error">Could not delete: {String(del.error)}</p>}

      {templates.isLoading ? (
        <Spinner />
      ) : templates.isError ? (
        <p className="error">Could not load templates: {String(templates.error)}</p>
      ) : rows.length === 0 ? (
        <div className="empty-state">
          <p className="empty-state__title">No templates yet</p>
          <p>
            Fill this report's form and use <strong>Save as template</strong> to store
            the values for reuse.
          </p>
        </div>
      ) : (
        <table className="templates__table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Selection</th>
              <th>Report</th>
              <th>Last updated</th>
              <th aria-label="Actions" />
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.template_id}>
                <td>
                  {renamingId === t.template_id ? (
                    <input
                      type="text"
                      className="templates__rename-input"
                      value={renameValue}
                      autoFocus
                      maxLength={128}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") submitRename(t);
                        if (e.key === "Escape") setRenamingId(null);
                      }}
                    />
                  ) : (
                    <>
                      {t.template_name}
                      {t.is_dynamic && (
                        <span className="tpl-badge" title="Has relative date values that resolve when loaded">
                          dynamic
                        </span>
                      )}
                    </>
                  )}
                </td>
                <td className="muted">{t.selection_label ?? "—"}</td>
                <td className="muted">{t.report_type_label ?? "—"}</td>
                <td className="muted">{t.updated_at ?? t.created_at ?? "—"}</td>
                <td className="templates__actions">
                  {renamingId === t.template_id ? (
                    <>
                      <button
                        type="button"
                        className="btn btn--primary btn--sm"
                        disabled={rename.isPending}
                        onClick={() => submitRename(t)}
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        className="btn btn--secondary btn--sm"
                        onClick={() => setRenamingId(null)}
                      >
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        className="btn btn--primary btn--sm"
                        disabled={loadingId === t.template_id}
                        onClick={() => onLoad(t)}
                      >
                        {loadingId === t.template_id ? "Loading…" : "Load"}
                      </button>
                      <button
                        type="button"
                        className="btn btn--secondary btn--sm"
                        onClick={() => startRename(t)}
                      >
                        Rename
                      </button>
                      <button
                        type="button"
                        className="btn btn--secondary btn--sm"
                        disabled={del.isPending}
                        onClick={() => del.mutate({ alvId: t.alv_id, templateId: t.template_id })}
                      >
                        Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
