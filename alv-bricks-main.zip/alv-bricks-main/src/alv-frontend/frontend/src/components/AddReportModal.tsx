// Add-a-report modal — opened from the admin-only "+" card on the Home grid. The admin
// pastes the SAME { "catalog_rows": [...] } manifest the seed job consumes; the backend
// validates it (collect-all → every problem at once), MERGEs it into alv_catalog, and
// refreshes the catalogue. The added report is HIDDEN until it is granted on the Admin
// screen — deny-by-default, so onboarding never auto-grants. Permissioning stays on Admin.
import { useState } from "react";
import { OnboardValidationError, useOnboardReport } from "../api/hooks";
import type { OnboardResult } from "../api/types";

interface Props {
  onClose: () => void;
}

export function AddReportModal({ onClose }: Props) {
  const [manifest, setManifest] = useState("");
  const [result, setResult] = useState<OnboardResult | null>(null);
  const onboard = useOnboardReport();

  const validationErrors =
    onboard.error instanceof OnboardValidationError ? onboard.error.errors : null;
  const otherError =
    onboard.isError && !validationErrors ? String(onboard.error) : null;

  const submit = () => {
    if (!manifest.trim()) return;
    setResult(null);
    onboard.mutate(manifest, {
      onSuccess: (data) => {
        setResult(data);
        setManifest("");
      },
    });
  };

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-label="Add a report">
      <div className="modal modal--wide">
        <div className="modal__header">
          <h2 className="modal__title">Add a report</h2>
          <button type="button" className="modal__close" aria-label="Close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="modal__body">
          <p className="muted">
            Paste a report manifest — the same{" "}
            <code>{'{ "catalog_rows": [ … ] }'}</code> JSON the seed job consumes. It is
            validated before anything is written. A new report is <strong>hidden from
            everyone</strong> until you grant access to it on the Admin screen.
          </p>
          <label className="field__label" htmlFor="add-report-manifest">
            Report manifest JSON
          </label>
          <textarea
            id="add-report-manifest"
            className="add-report__manifest"
            rows={14}
            spellCheck={false}
            autoFocus
            placeholder='{ "catalog_rows": [ { "report_key": "…", … } ] }'
            value={manifest}
            onChange={(e) => setManifest(e.target.value)}
          />

          {validationErrors && (
            <div className="error add-report__errors">
              <p>The manifest is not valid. Fix these and try again:</p>
              <ul>
                {validationErrors.map((e, i) => (
                  <li key={i}>{e}</li>
                ))}
              </ul>
            </div>
          )}
          {otherError && <p className="error">Could not add report: {otherError}</p>}

          {result && (
            <div className="add-report__success">
              <p className="add-report__success-title">
                Added {result.report_keys.join(", ")} ({result.row_count} row
                {result.row_count === 1 ? "" : "s"}).
              </p>
              <p>{result.detail}</p>
              {result.warnings.length > 0 && (
                <ul className="muted">
                  {result.warnings.map((w, i) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>

        <div className="modal__footer">
          <button type="button" className="btn btn--secondary" onClick={onClose}>
            {result ? "Done" : "Cancel"}
          </button>
          <button
            type="button"
            className="btn btn--primary"
            disabled={!manifest.trim() || onboard.isPending}
            onClick={submit}
          >
            {onboard.isPending ? "Adding…" : "Add report"}
          </button>
        </div>
      </div>
    </div>
  );
}
