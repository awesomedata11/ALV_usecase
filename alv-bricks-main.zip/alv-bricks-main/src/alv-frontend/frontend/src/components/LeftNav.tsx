// Left nav — the app's PRIMARY navigation rail (Home / Downloads), rendered
// persistently beside every view so the user can always switch app sections. The
// report SELECTIONS that used to live here now render in the main page body
// (see MainArea), matching screenshot 2 where "Selection" is a section of the page.
//
// The rail has two capabilities:
//   COLLAPSE — a toggle at the top switches between EXPANDED (heading + icon+label
//     items) and COLLAPSED (a narrow icon-only rail). Active-view highlighting and
//     keyboard access work in both states.
//   RESIZE — when expanded, a draggable handle on the right edge lets the user set
//     the rail width (pointer events, clamped to [NAV_MIN_WIDTH, NAV_MAX_WIDTH]);
//     arrow keys nudge it for keyboard users. Collapsed uses a fixed narrow width.
import { useCallback, useEffect, useRef } from "react";
import type { View } from "../App";
import { NAV_MAX_WIDTH, NAV_MIN_WIDTH } from "../leftNav";

interface Props {
  // The current view — drives active-link highlighting (aria-current).
  view: View;
  // Navigate to the home/cards view.
  onHome: () => void;
  // Navigate to the Downloads page.
  onDownloads: () => void;
  // Navigate to the Admin console.
  onAdmin: () => void;
  // Whether to show the Admin item (caller is an admin per /api/me). The endpoints
  // enforce independently; this only hides the entry point from non-admins.
  showAdmin: boolean;
  // Navigate to the Templates screen for the report currently open.
  onTemplates: () => void;
  // Whether to show the (contextual) Templates item — only while a report type is open.
  showTemplates: boolean;
  // Collapsed (icon-only) vs expanded (icon + label) rail.
  collapsed: boolean;
  // Toggle collapsed/expanded.
  onToggleCollapsed: () => void;
  // Current expanded width (px) — only meaningful when not collapsed.
  width: number;
  // Set a new expanded width (the hook clamps to bounds).
  onSetWidth: (w: number) => void;
}

// Inline SVGs drawn with currentColor so they stay crisp in light AND dark mode.
function HomeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V21h14V9.5" />
    </svg>
  );
}

function DownloadIcon() {
  // Download / down-arrow-to-tray glyph.
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3v12" />
      <path d="m7 10 5 5 5-5" />
      <path d="M4 21h16" />
    </svg>
  );
}

function AdminIcon() {
  // Shield/gear glyph for the admin console.
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3Z" />
      <circle cx="12" cy="11" r="2.2" />
    </svg>
  );
}

function TemplatesIcon() {
  // Stacked-layers / saved-forms glyph for the templates screen.
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m12 3 9 5-9 5-9-5 9-5Z" />
      <path d="m3 12 9 5 9-5" />
    </svg>
  );
}

// Hamburger when expanded (click to collapse); chevron-right when collapsed
// (click to expand).
function ToggleIcon({ collapsed }: { collapsed: boolean }) {
  return collapsed ? (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m9 6 6 6-6 6" />
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4 6h16M4 12h16M4 18h16" />
    </svg>
  );
}

export function LeftNav({
  view,
  onHome,
  onDownloads,
  onAdmin,
  showAdmin,
  onTemplates,
  showTemplates,
  collapsed,
  onToggleCollapsed,
  width,
  onSetWidth,
}: Props) {
  // Latest width in a ref so the pointermove handler (bound once per drag) always
  // reads the current base without re-subscribing.
  const widthRef = useRef(width);
  widthRef.current = width;

  // Track a live drag: pointerdown on the handle -> pointermove on window updates
  // width -> pointerup ends. We compute from the pointer's clientX relative to the
  // rail's left edge, so the handle tracks the cursor 1:1 with no transition lag.
  const dragRef = useRef<{ startX: number; startWidth: number } | null>(null);

  const onHandlePointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (collapsed) return;
      e.preventDefault();
      dragRef.current = { startX: e.clientX, startWidth: widthRef.current };
      // Flag on <body> so CSS can suppress the width transition + set a global cursor.
      document.body.classList.add("nav-resizing");

      const onMove = (ev: PointerEvent) => {
        if (!dragRef.current) return;
        const delta = ev.clientX - dragRef.current.startX;
        onSetWidth(dragRef.current.startWidth + delta);
      };
      const onUp = () => {
        dragRef.current = null;
        document.body.classList.remove("nav-resizing");
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
      };
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
    },
    [collapsed, onSetWidth],
  );

  // Clean up the global flag if we unmount mid-drag.
  useEffect(() => {
    return () => document.body.classList.remove("nav-resizing");
  }, []);

  // Keyboard resize: arrow keys nudge the width (separator a11y).
  const onHandleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      const step = e.shiftKey ? 24 : 8;
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        onSetWidth(widthRef.current - step);
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        onSetWidth(widthRef.current + step);
      }
    },
    [onSetWidth],
  );

  return (
    <nav
      className={"left-nav" + (collapsed ? " left-nav--collapsed" : "")}
      aria-label="Primary navigation"
      // Expanded width drives a CSS var; collapsed falls back to the fixed width in CSS.
      style={collapsed ? undefined : { ["--left-nav-width" as string]: `${width}px` }}
    >
      <button
        type="button"
        className="left-nav__toggle"
        onClick={onToggleCollapsed}
        aria-label={collapsed ? "Expand navigation" : "Collapse navigation"}
        aria-expanded={!collapsed}
        title={collapsed ? "Expand navigation" : "Collapse navigation"}
      >
        <ToggleIcon collapsed={collapsed} />
      </button>

      {!collapsed && <div className="left-nav__section-title">Navigation</div>}

      <ul className="left-nav__list">
        <li>
          <button
            type="button"
            className={"left-nav__item" + (view === "home" ? " left-nav__item--active" : "")}
            aria-current={view === "home" ? "page" : undefined}
            onClick={onHome}
            title={collapsed ? "Home" : undefined}
            aria-label={collapsed ? "Home" : undefined}
          >
            <span className="left-nav__icon">
              <HomeIcon />
            </span>
            {!collapsed && <span className="left-nav__label">Home</span>}
          </button>
        </li>
        <li>
          <button
            type="button"
            className={
              "left-nav__item" + (view === "downloads" ? " left-nav__item--active" : "")
            }
            aria-current={view === "downloads" ? "page" : undefined}
            onClick={onDownloads}
            title={collapsed ? "Downloads" : undefined}
            aria-label={collapsed ? "Downloads" : undefined}
          >
            <span className="left-nav__icon">
              <DownloadIcon />
            </span>
            {!collapsed && <span className="left-nav__label">Downloads</span>}
          </button>
        </li>
        {showTemplates && (
          <li>
            <button
              type="button"
              className={
                "left-nav__item" + (view === "templates" ? " left-nav__item--active" : "")
              }
              aria-current={view === "templates" ? "page" : undefined}
              onClick={onTemplates}
              title={collapsed ? "Templates" : undefined}
              aria-label={collapsed ? "Templates" : undefined}
            >
              <span className="left-nav__icon">
                <TemplatesIcon />
              </span>
              {!collapsed && <span className="left-nav__label">Templates</span>}
            </button>
          </li>
        )}
        {showAdmin && (
          <li>
            <button
              type="button"
              className={"left-nav__item" + (view === "admin" ? " left-nav__item--active" : "")}
              aria-current={view === "admin" ? "page" : undefined}
              onClick={onAdmin}
              title={collapsed ? "Admin" : undefined}
              aria-label={collapsed ? "Admin" : undefined}
            >
              <span className="left-nav__icon">
                <AdminIcon />
              </span>
              {!collapsed && <span className="left-nav__label">Admin</span>}
            </button>
          </li>
        )}
      </ul>

      {/* Resize grabber on the right edge — expanded only. */}
      {!collapsed && (
        <div
          className="left-nav__resize"
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize navigation"
          aria-valuenow={width}
          aria-valuemin={NAV_MIN_WIDTH}
          aria-valuemax={NAV_MAX_WIDTH}
          tabIndex={0}
          onPointerDown={onHandlePointerDown}
          onKeyDown={onHandleKeyDown}
        />
      )}
    </nav>
  );
}
