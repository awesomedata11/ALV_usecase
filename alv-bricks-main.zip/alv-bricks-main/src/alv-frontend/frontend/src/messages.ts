// Message catalogue (task 5.4). The metadata carries only `message_key`s — never
// inline user text (D-IFJ-9). This small map resolves them to readable strings.
//
// NOTE: this is a FRONTEND-local stopgap. The canonical message catalogue (task
// 2.2) is not yet delivered; the keys below are every key present in the pilot
// retail_ledger spec, worded to match the SAP screens. When the real catalogue
// lands, replace this map (or fetch it) — resolveMessage() already falls back
// gracefully for any unknown key so nothing breaks in the meantime.
const MESSAGES: Record<string, string> = {
  ALV_DATE_FROM_GT_TO: "From date must be on or before the To date.",
  ALV_DATE_TOO_OLD: "Date cannot be more than 12 months in the past.",
  ALV_DATE_SPAN_EXCEEDED: "Date range cannot exceed 31 days.",
  ALV_TIME_NO_FILTER: "Equal From/To times apply no time filter.",
  ALV_TIME_TO_REQUIRED: "To time is required when a From time is given.",
  ALV_TIME_FROM_GT_TO: "From time must be on or before the To time.",
};

// Humanize an unknown key like ALV_SOMETHING_ODD -> "Something odd" as a fallback.
function humanize(key: string): string {
  const stripped = key.replace(/^ALV_/, "").replace(/_/g, " ").toLowerCase();
  return stripped.charAt(0).toUpperCase() + stripped.slice(1);
}

export function resolveMessage(key: string): string {
  return MESSAGES[key] ?? humanize(key);
}
