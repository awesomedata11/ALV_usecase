// Regression guard for the report-routing bug: clicking the card for report N must
// open a report type BELONGING TO N.
//
// The shipped bug was a chain, and any link of it reintroduces the same symptom:
//   1. App.tsx's `openReport` was declared `() => navigate("/report")` — it DROPPED the
//      reportKey argument HomePage passes. TypeScript accepted it silently: a zero-arg
//      function is assignable to `(reportKey: string) => void`, so no compile error.
//   2. Bare "/report" was then resolved by ARRAY INDEX — selections[0].report_types[0]
//      — against a catalogue spanning every permitted report.
//   3. Because the two report specs are byte-identical clones apart from
//      report_key/report_label, all 28 rows tie on (selection_order, report_type_order),
//      so the winner came down to alv_id alphabetical: cc_recharge sorted first and
//      every card opened CC Recharge Data.
//
// This bug class has recurred across five identity keys, so the test asserts the
// END-TO-END invariant rather than any one link: render the real App (real router, real
// components, real hooks) over a fake API, click a card by its visible label, and check
// the alv_id the app actually resolves belongs to the clicked report. It is deliberately
// black-box — it would still fail if the argument were dropped, if the auto-pick went
// back to being unscoped, or if `onSelectSelection` cross-navigated.
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter } from "react-router-dom";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { App } from "./App";
import { FormDraftProvider } from "./formDraft";

// --- The fake catalogue: two reports that are clones apart from their identity -------
// Same selection_ids, same report_type_codes, same selection_order / report_type_order —
// exactly the shape of the real report_specs manifests, which is what makes an
// index-based pick ambiguous. cc_recharge is listed FIRST so that any resolution falling
// back to "the first one" picks the wrong report whenever retail_ledger is clicked.
const REPORTS = [
  { key: "cc_recharge", label: "CC Recharge Data" },
  { key: "retail_ledger", label: "Retail Ledger" },
];

const SELECTIONS = [
  { id: "detail", label: "Detail", order: 1, types: ["agent_item", "agent_detail_pg"] },
  { id: "sequence_wise", label: "Sequence Wise", order: 2, types: ["agent_summary"] },
];

function rowsFor(reportKey: string) {
  return SELECTIONS.map((sel) => ({
    selection_id: sel.id,
    selection_label: sel.label,
    selection_order: sel.order,
    report_types: sel.types.map((code, i) => ({
      report_type_code: code,
      report_type_label: code,
      report_type_order: i + 1,
      alv_id: `${reportKey}__${sel.id}__${code}`,
      alv_name: `${reportKey} ${sel.id} ${code}`,
      description: null,
    })),
  }));
}

// alv_id → its owning report_key. The ONLY source of truth the assertions use, so the
// test never parses an alv_id (its `report_key__…` shape is a seeding convention, not a
// contract — see alv_app/cache.py).
const OWNER = new Map<string, string>();
for (const r of REPORTS) {
  for (const sel of rowsFor(r.key)) {
    for (const rt of sel.report_types) OWNER.set(rt.alv_id, r.key);
  }
}

// Records every GET /api/reports/{alv_id} the app made — i.e. the report types it
// actually RESOLVED and rendered a form for.
let requestedAlvIds: string[] = [];

function fakeFetch(input: RequestInfo | URL): Promise<Response> {
  const url = typeof input === "string" ? input : input.toString();
  const json = (body: unknown, status = 200) =>
    Promise.resolve(
      new Response(JSON.stringify(body), {
        status,
        headers: { "Content-Type": "application/json" },
      }),
    );

  // GET /api/me — identity + admin flag. Non-admin here (the routing suite is not
  // about the admin nav), so the Admin item stays hidden.
  if (url.startsWith("/api/me")) {
    return json({
      email: "user@example.com",
      preferred_username: "user@example.com",
      user_id: "aad-1",
      real_ip: null,
      authenticated: true,
      has_user_token: true,
      is_admin: false,
      service_principal: null,
      service_principal_ok: true,
      service_principal_detail: null,
    });
  }

  if (url.startsWith("/api/report-groups")) {
    return json({
      groups: REPORTS.map((r) => ({
        report_key: r.key,
        report_label: r.label,
        runnable_count: 2,
      })),
    });
  }

  // GET /api/reports[?report_key=…] — the catalogue, scoped when asked. Mirrors the
  // backend: a scoped tree carries that report's key/label; an unscoped one spans every
  // report and carries NEITHER (null), because no single report owns it.
  if (url.startsWith("/api/reports?") || url === "/api/reports") {
    const key = new URL(url, "http://test").searchParams.get("report_key");
    if (key) {
      const report = REPORTS.find((r) => r.key === key);
      if (!report) return json({ detail: `report not found: ${key}` }, 404);
      return json({
        report_key: report.key,
        report_label: report.label,
        selections: rowsFor(report.key),
      });
    }
    return json({
      report_key: null,
      report_label: null,
      selections: REPORTS.flatMap((r) => rowsFor(r.key)),
    });
  }

  // GET /api/reports/{alv_id} — one report type's form def.
  const formMatch = url.match(/^\/api\/reports\/([^/?]+)$/);
  if (formMatch) {
    const alvId = decodeURIComponent(formMatch[1]);
    const owner = OWNER.get(alvId);
    if (!owner) return json({ detail: `report not found: ${alvId}` }, 404);
    requestedAlvIds.push(alvId);
    const report = REPORTS.find((r) => r.key === owner)!;
    return json({
      alv_id: alvId,
      report_key: owner,
      report_label: report.label,
      selection_id: alvId.includes("sequence_wise") ? "sequence_wise" : "detail",
      selection_label: null,
      report_type_code: null,
      report_type_label: null,
      alv_name: alvId,
      description: null,
      fields: [],
      has_sample_query: false,
    });
  }

  return json({ detail: `unexpected request: ${url}` }, 404);
}

function renderApp() {
  // retry:false so a 404 in a test fails fast instead of being retried; a fresh
  // QueryClient per test keeps one test's catalogue out of the next one's cache.
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <FormDraftProvider>
          <App />
        </FormDraftProvider>
      </HashRouter>
    </QueryClientProvider>,
  );
}

describe("report routing", () => {
  beforeEach(() => {
    requestedAlvIds = [];
    window.location.hash = "#/";
    vi.stubGlobal("fetch", vi.fn(fakeFetch));
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  // The core guard, run for BOTH reports — one report passing proves nothing when the
  // failure mode is "every card opens whichever report sorts first".
  for (const report of REPORTS) {
    it(`clicking "${report.label}" resolves an alv_id belonging to ${report.key}`, async () => {
      const user = userEvent.setup();
      renderApp();

      const card = await screen.findByTitle(`Open ${report.label}`);
      await user.click(card);

      // Wait until the app has resolved a report type (fetched a form def).
      await waitFor(() => expect(requestedAlvIds.length).toBeGreaterThan(0));

      // EVERY report type it resolved must belong to the report that was clicked.
      for (const alvId of requestedAlvIds) {
        expect(OWNER.get(alvId), `alv_id ${alvId} is not a known report type`).toBe(
          report.key,
        );
      }

      // And the URL is scoped to that report, so a reload / bookmark reopens it.
      expect(window.location.hash).toContain(`/report/${report.key}`);
    });
  }

  // The breadcrumb/title and the form heading are derived from the resolved report's own
  // row, so they can never name a different report than the one that was opened.
  for (const report of REPORTS) {
    it(`shows "${report.label}" as the heading after opening it`, async () => {
      const user = userEvent.setup();
      renderApp();

      await user.click(await screen.findByTitle(`Open ${report.label}`));

      await waitFor(() =>
        expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent(report.label),
      );
      // The OTHER report's label must not be on screen at all.
      const other = REPORTS.find((r) => r.key !== report.key)!;
      expect(screen.queryByText(other.label)).toBeNull();
    });
  }

  // Switching selection must stay inside the current report. Under the merged tree a
  // selection bucket held both reports' report types, so "its first report type" could
  // be the other report's row — a silent cross-navigation with no user-visible cause.
  it("switching selection stays within the opened report", async () => {
    const user = userEvent.setup();
    renderApp();

    await user.click(await screen.findByTitle("Open Retail Ledger"));
    await waitFor(() => expect(requestedAlvIds.length).toBeGreaterThan(0));

    const sequenceRadio = await screen.findByLabelText("Sequence Wise");
    await user.click(sequenceRadio);

    await waitFor(() => expect(window.location.hash).toContain("sequence_wise"));
    for (const alvId of requestedAlvIds) {
      expect(OWNER.get(alvId)).toBe("retail_ledger");
    }
  });

  // A deep link to an alv_id that is not in the routed report (hand-edited URL, renamed
  // row, revoked permission) must not render a context-less form.
  it("redirects a deep link whose alv_id is not in the routed report", async () => {
    window.location.hash = "#/report/retail_ledger/cc_recharge__detail__agent_item";
    renderApp();

    await waitFor(() => expect(requestedAlvIds.length).toBeGreaterThan(0));
    // It recovered to a retail_ledger report type; the cc_recharge id was never fetched.
    for (const alvId of requestedAlvIds) {
      expect(OWNER.get(alvId)).toBe("retail_ledger");
    }
    expect(requestedAlvIds).not.toContain("cc_recharge__detail__agent_item");
  });

  // The legacy one-segment deep link still works: it resolves the alv_id's owning report
  // and rewrites to the two-segment URL.
  it("upgrades a legacy /report/<alv_id> deep link to the scoped URL", async () => {
    window.location.hash = "#/report/retail_ledger__sequence_wise__agent_summary";
    renderApp();

    await waitFor(() =>
      expect(window.location.hash).toContain(
        "/report/retail_ledger/retail_ledger__sequence_wise__agent_summary",
      ),
    );
    for (const alvId of requestedAlvIds) {
      expect(OWNER.get(alvId)).toBe("retail_ledger");
    }
  });
});
