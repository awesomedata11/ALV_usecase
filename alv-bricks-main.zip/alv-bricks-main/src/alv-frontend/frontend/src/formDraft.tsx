// Transient form-draft store — preserves UNSUBMITTED report-form state (typed field
// values + touched flag) across client-side navigation. The ReportForm component
// unmounts when the user navigates away (to Downloads, Home, or via browser Back),
// which would otherwise discard everything they'd typed. Lifting the draft into a
// provider that lives ABOVE the router keeps it alive for the whole session so
// navigating back to a report restores the in-progress selections + values.
//
// Backed by a ref (not state) on purpose: writing a draft must NOT re-render the app
// or the form — the ReportForm owns its own local state for responsiveness and only
// mirrors into this store. Reads happen on (re)mount, so the ref always has the
// latest value with zero render churn. Keyed by alv_id (a report's unique id), so
// each report keeps its own independent draft.
import { createContext, useCallback, useContext, useRef } from "react";
import type { ReactNode } from "react";
import type { Values } from "./validation";

export interface FormDraft {
  values: Values;
  touched: boolean;
}

interface FormDraftStore {
  // Returns the stored draft for a report, or undefined if none has been captured.
  getDraft: (alvId: string) => FormDraft | undefined;
  // Persist (overwrite) the draft for a report.
  setDraft: (alvId: string, draft: FormDraft) => void;
  // Drop a report's draft (e.g. to force a fresh re-seed of defaults).
  clearDraft: (alvId: string) => void;
}

const FormDraftContext = createContext<FormDraftStore | null>(null);

export function FormDraftProvider({ children }: { children: ReactNode }) {
  const store = useRef<Record<string, FormDraft>>({});

  const getDraft = useCallback((alvId: string) => store.current[alvId], []);
  const setDraft = useCallback((alvId: string, draft: FormDraft) => {
    store.current[alvId] = draft;
  }, []);
  const clearDraft = useCallback((alvId: string) => {
    delete store.current[alvId];
  }, []);

  return (
    <FormDraftContext.Provider value={{ getDraft, setDraft, clearDraft }}>
      {children}
    </FormDraftContext.Provider>
  );
}

export function useFormDrafts(): FormDraftStore {
  const ctx = useContext(FormDraftContext);
  if (!ctx) {
    throw new Error("useFormDrafts must be used within a FormDraftProvider");
  }
  return ctx;
}
