import { useEffect } from "react";
import { Navigate, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import { Header } from "./components/Header";
import { HomePage } from "./components/HomePage";
import { DownloadsPage } from "./components/DownloadsPage";
import { OutputPreviewPage } from "./components/OutputPreviewPage";
import { AdminPage } from "./components/AdminPage";
import { TemplatesPage } from "./components/TemplatesPage";
import { LeftNav } from "./components/LeftNav";
import { MainArea } from "./components/MainArea";
import { useCatalogue, useMe, useReportForm } from "./api/hooks";
import { useTheme } from "./theme";
import { useLeftNav } from "./leftNav";

// App shell with real client-side routing (react-router HashRouter — see main.tsx for
// why hash and not browser history). Three views, each a real URL + history entry:
//   HOME  ("/")                          — a grid of ALV report cards.
//   REPORT ("/report/:reportKey"         — the catalogue UI for ONE report: a
//           "/report/:reportKey/:alvId")   "Selection" section on top, a "Reports"
//                                          section below, and the metadata-driven form
//                                          for the resolved alv_id. With no :alvId it
//                                          auto-picks the first report type WITHIN
//                                          that report.
//   DOWNLOADS ("/downloads")             — a flat table of recent runs from request_log.
//
// URL SHAPE: the report key is the FIRST segment, the alv_id an optional SECOND one —
// "/report/retail_ledger/retail_ledger__detail__agent_item". Two segments in a fixed
// order, so react-router matches on POSITION and the two ids are never told apart by
// inspecting them. Sniffing one shared segment by shape was rejected outright: alv_id's
// `report_key__…` form is a SEEDING CONVENTION, not a contract (alv_app/cache.py and
// alv_app/downloads.py both say so), so parsing separators would be a guess that breaks
// silently the first time a spec author writes an alv_id by hand.
//
// The legacy one-segment deep link "/report/<alv_id>" still works. It CANNOT be a
// separate route — "/report/:reportKey" and "/report/:alvId" are the identical pattern,
// so react-router has nothing to choose between. Instead the single one-segment route
// resolves the segment (ReportEntry): a report key if the scoped catalogue returns one,
// otherwise an alv_id looked up via GET /api/reports/{alv_id}, whose report_key is
// authoritative. A bare "/report" redirects home — with several reports permitted there
// is no defensible "first" one, and picking by sort order is precisely the bug this
// shape removes.
//
// The Header AND the LeftNav render ONCE here at the shell level (outside <Routes>) so
// they are PERSISTENT on every view — the LeftNav is the app's primary navigation rail
// (Home / Downloads), always available. Because they stay mounted, and because report
// nav state (selection, report type) now lives in the URL, browser Back/Forward walk
// the in-app view history and navigating back to a report restores from the (cached)
// query with no refetch/flash. Unsubmitted form values are preserved by FormDraftProvider
// (see formDraft.tsx + ReportForm), which survives the route unmount.
export type View = "home" | "report" | "downloads" | "admin" | "templates";

// Build a report URL. reportKey always present; alvId optional (omit to let ReportView
// auto-pick the first report type within that report).
export function reportPath(reportKey: string, alvId?: string | null): string {
  const base = `/report/${encodeURIComponent(reportKey)}`;
  return alvId ? `${base}/${encodeURIComponent(alvId)}` : base;
}

// Build the templates URL for one report type. Templates are scoped to a resolved
// alv_id (its field set), reached from the contextual "Templates" nav item.
export function templatesPath(reportKey: string, alvId: string): string {
  return `/report/${encodeURIComponent(reportKey)}/${encodeURIComponent(alvId)}/templates`;
}

// Build the output-file preview URL for one run. Nested under /downloads so the
// Downloads nav item stays active on the preview screen (see the `view` derivation).
export function outputPreviewPath(requestNo: string): string {
  return `/downloads/${encodeURIComponent(requestNo)}/preview`;
}

// Report view: resolves ONE report from the URL's :reportKey, fetches that report's
// catalogue SCOPED to it, resolves the alv_id, and navigates by pushing new
// /report/:reportKey/:alvId URLs so selection / report-type changes are real history
// entries. Data comes from the shared useCatalogue query cache — no extra fetch on
// back-navigation.
//
// EVERY resolution here is scoped to the routed reportKey. The catalogue is fetched
// scoped, so the auto-pick, the owning-selection lookup, and the selection→first-report-
// type jump all operate on one report's rows and cannot cross into another's.
function ReportView({ reportKey }: { reportKey: string }) {
  const { alvId: alvIdParam } = useParams<{ alvId?: string }>();
  const navigate = useNavigate();
  const { data: catalogue, isLoading, isError, error } = useCatalogue(reportKey);

  const alvId = alvIdParam ?? null;

  // Does the routed alv_id actually exist in THIS report's catalogue?
  const alvIdIsKnown =
    !!alvId &&
    !!catalogue?.selections.some((s) => s.report_types.some((rt) => rt.alv_id === alvId));

  // Resolve the URL against the loaded catalogue:
  //  · no alv_id      ⇒ auto-pick the first report type WITHIN this report;
  //  · unknown alv_id ⇒ a deep link to a report type this report does not contain
  //                     (renamed row, revoked permission, hand-edited URL). Fall back
  //                     to this report's first report type rather than rendering a form
  //                     with no selection context; if the report resolved to no report
  //                     types at all, go home.
  // Both are replace-navigations, so the bad URL does not linger in history.
  useEffect(() => {
    if (!catalogue) return; // still loading / errored — leave the URL alone
    if (alvId && alvIdIsKnown) return;

    const first = catalogue.selections.find((s) => s.report_types.length > 0);
    if (!first) {
      navigate("/", { replace: true });
      return;
    }
    navigate(reportPath(reportKey, first.report_types[0].alv_id), { replace: true });
  }, [alvId, alvIdIsKnown, catalogue, navigate, reportKey]);

  // Derive the owning selection from the alv_id (every report type belongs to exactly
  // one selection WITHIN this report). Drives the "Selection" radio's checked state.
  const selection = catalogue?.selections.find((s) =>
    s.report_types.some((rt) => rt.alv_id === alvId),
  );
  const selectionId = selection?.selection_id ?? null;

  // Selecting a selection lands on its FIRST report type (matches prior behavior); a
  // report-type radio navigates straight to that alv_id. Both stay within reportKey and
  // push history entries.
  const onSelectSelection = (sid: string) => {
    const sel = catalogue?.selections.find((s) => s.selection_id === sid);
    if (sel && sel.report_types.length > 0) {
      navigate(reportPath(reportKey, sel.report_types[0].alv_id));
    }
  };
  const onSelectReportType = (nextAlvId: string) => {
    navigate(reportPath(reportKey, nextAlvId));
  };

  return (
    <MainArea
      catalogue={catalogue}
      isLoading={isLoading}
      isError={isError}
      error={error}
      selectionId={selectionId}
      // Only render the form once the id is confirmed to belong to THIS report — the
      // effect above is mid-redirect otherwise, and ReportForm would fetch the wrong
      // (or a nonexistent) report in the meantime.
      alvId={alvIdIsKnown ? alvId : null}
      onSelectSelection={onSelectSelection}
      onSelectReportType={onSelectReportType}
    />
  );
}

// The one-segment "/report/:key" route. Because a report_key and an alv_id are
// indistinguishable as URL text (see the shape note above), this resolves which one the
// segment is by ASKING THE BACKEND rather than by parsing:
//
//   1. treat it as a report_key — GET /api/reports?report_key=<key>. A 200 means it is
//      one, and ReportView takes over reading the very same cached query;
//   2. on 404, treat it as a legacy alv_id — GET /api/reports/<key>, whose report_key
//      field is authoritative — and replace-navigate to the two-segment URL;
//   3. neither resolves (unknown, or a report this user may not see — the backend
//      returns 404 for both, deliberately) ⇒ home.
function ReportEntry() {
  const { reportKey: segment } = useParams<{ reportKey: string }>();
  const navigate = useNavigate();

  const key = segment ?? null;
  const asReport = useCatalogue(key);
  // Only look the segment up as an alv_id once it has failed as a report_key, so the
  // normal path costs exactly one request.
  const asAlvId = useReportForm(asReport.isError ? key : null);

  const legacyReportKey = asAlvId.data?.report_key ?? null;

  useEffect(() => {
    if (!asReport.isError) return; // still loading, or it IS a report key
    if (asAlvId.isLoading) return;
    if (legacyReportKey && key) {
      navigate(reportPath(legacyReportKey, key), { replace: true });
      return;
    }
    if (asAlvId.isError) navigate("/", { replace: true });
  }, [asAlvId.isError, asAlvId.isLoading, asReport.isError, key, legacyReportKey, navigate]);

  if (!key) return <Navigate to="/" replace />;
  if (asReport.isError) return <p className="muted">Opening report…</p>;
  return <ReportView reportKey={key} />;
}

// Two-segment "/report/:reportKey/:alvId" — unambiguous, so it goes straight to the view.
function ReportRoute() {
  const { reportKey } = useParams<{ reportKey: string }>();
  if (!reportKey) return <Navigate to="/" replace />;
  return <ReportView reportKey={reportKey} />;
}

export function App() {
  const { theme, toggleTheme } = useTheme();
  const { collapsed, toggleCollapsed, width, setWidth } = useLeftNav();
  const navigate = useNavigate();
  const location = useLocation();
  // Whether to surface the Admin nav (the endpoints enforce independently — this only
  // hides the entry point). Defaults false until /api/me resolves.
  const { data: me } = useMe();
  const isAdmin = me?.is_admin ?? false;

  // Derive the current view from the URL — drives left-nav active highlighting.
  // A "/report/.../templates" path is its own "templates" view; a plain report path is
  // "report". Match templates FIRST (it is a longer /report/... path).
  const view: View = /\/templates$/.test(location.pathname)
    ? "templates"
    : location.pathname.startsWith("/report")
      ? "report"
      : location.pathname.startsWith("/downloads")
        ? "downloads"
        : location.pathname.startsWith("/admin")
          ? "admin"
          : "home";

  // The report context the user is currently in (reportKey + resolved alvId), parsed
  // from the URL. It drives the CONTEXTUAL "Templates" nav item: templates are scoped
  // to a resolved report type, so the item only appears once we have both ids. Matches
  // both "/report/:reportKey/:alvId" and "/report/:reportKey/:alvId/templates".
  const reportCtx = (() => {
    const m = location.pathname.match(/^\/report\/([^/]+)\/([^/]+)(?:\/templates)?\/?$/);
    if (!m) return null;
    const rk = decodeURIComponent(m[1]);
    const alv = decodeURIComponent(m[2]);
    // Guard against the one-segment "/report/:key" case (no alvId) — the regex needs
    // two segments, so m[2] is always the alv_id here.
    return { reportKey: rk, alvId: alv };
  })();

  const goHome = () => navigate("/");
  const goDownloads = () => navigate("/downloads");
  const goAdmin = () => navigate("/admin");
  const goTemplates = () =>
    reportCtx && navigate(templatesPath(reportCtx.reportKey, reportCtx.alvId));
  // Opening a report card lands on that REPORT's URL; ReportView then resolves the
  // first report type WITHIN it. Passing the key through is the whole fix: this used to
  // drop its argument and navigate to a report-agnostic "/report", where the view
  // auto-picked by sort order and so opened whichever report sorted first.
  const openReport = (reportKey: string) => navigate(reportPath(reportKey));

  return (
    <div className="app-shell">
      {/* Persistent header on ALL views — brand (back-to-home) + greeting + theme. */}
      <Header onHome={goHome} theme={theme} onToggleTheme={toggleTheme} />

      {/* Persistent app-shell body: the left nav rail (Home / Downloads) is always
          present so navigation is available on every view; the routed content
          renders beside it. */}
      <div className="app-body">
        <LeftNav
          view={view}
          onHome={goHome}
          onDownloads={goDownloads}
          onAdmin={goAdmin}
          showAdmin={isAdmin}
          onTemplates={goTemplates}
          showTemplates={reportCtx !== null}
          collapsed={collapsed}
          onToggleCollapsed={toggleCollapsed}
          width={width}
          onSetWidth={setWidth}
        />

        <Routes>
          <Route path="/" element={<HomePage onOpenReport={openReport} />} />
          <Route path="/downloads" element={<DownloadsPage />} />
          {/* Output-file preview for one run — the on-screen twin of Download. */}
          <Route path="/downloads/:requestNo/preview" element={<OutputPreviewPage />} />
          {/* Admin console. The route exists for any authenticated user; the backend
              endpoints 404 a non-admin, and AdminPage surfaces that as an error. The
              nav entry is hidden from non-admins (showAdmin). */}
          <Route path="/admin" element={<AdminPage />} />
          {/* Bare "/report" has no report to show — see the URL-shape note. */}
          <Route path="/report" element={<Navigate to="/" replace />} />
          {/* Templates for a resolved report type — MUST precede the two-segment report
              route so "/report/:reportKey/:alvId/templates" is not swallowed by it. */}
          <Route path="/report/:reportKey/:alvId/templates" element={<TemplatesPage />} />
          <Route path="/report/:reportKey" element={<ReportEntry />} />
          <Route path="/report/:reportKey/:alvId" element={<ReportRoute />} />
          {/* Unknown path → home (keeps deep-link / stale-hash entry from dead-ending). */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </div>
  );
}
