// Vitest setup (wired via vite.config.ts `test.setupFiles`).
//
// Registers @testing-library/jest-dom's DOM matchers (toHaveTextContent, toBeVisible, …)
// on Vitest's expect, and auto-unmounts rendered components after each test so one
// test's DOM never leaks into the next.
import "@testing-library/jest-dom/vitest";
import { cleanup } from "@testing-library/react";
import { afterEach } from "vitest";

afterEach(() => {
  cleanup();
});
