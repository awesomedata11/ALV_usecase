// Result-cache reuse flow (task 7.3). Black-box over a fake API, like Templates.test.tsx.
// Submit first runs a cache-check: on a hit the reuse modal appears (reuse the existing
// output, or run the job again); on no hit (or a failed check) submit proceeds normally.
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter } from "react-router-dom";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { App } from "./App";
import { FormDraftProvider } from "./formDraft";

const ALV = "retail_ledger__detail__agent_item";
const HASH = "a".repeat(64);

// Per-test knobs: what the cache-check returns, and how many times each write was hit.
let cacheHit: Record<string, unknown> | null;
let cacheCheckStatus: number;
let counts: { check: number; submit: number };

function json(body: unknown, status = 200): Promise<Response> {
  return Promise.resolve(
    new Response(JSON.stringify(body), {
      status,
      headers: { "Content-Type": "application/json" },
    }),
  );
}

function formDef() {
  return {
    alv_id: ALV,
    report_key: "retail_ledger",
    report_label: "Retail Ledger",
    selection_id: "detail",
    selection_label: "Detail",
    report_type_code: "agent_item",
    report_type_label: "Agent Item",
    alv_name: "Retail Ledger — Detail — Agent Item",
    description: null,
    fields: [
      {
        kind: "scalar",
        control: "text",
        data_type: "string",
        display_label: "Agent",
        display_order: 1,
        mandatory: false,
        validations: [],
        param_name: "agent_id",
      },
    ],
    has_sample_query: false,
  };
}

async function fakeFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const url = typeof input === "string" ? input : input.toString();
  const method = (init?.method ?? "GET").toUpperCase();

  if (url.startsWith("/api/me")) {
    return json({
      email: "alice@example.com",
      preferred_username: "alice@example.com",
      user_id: "aad-1",
      real_ip: null,
      authenticated: true,
      has_user_token: true,
      is_admin: false,
      service_principal: null,
      service_principal_ok: true,
      service_principal_detail: null,
    });
  }

  if (url.match(/\/api\/reports\/[^/]+\/cache-check$/) && method === "POST") {
    counts.check += 1;
    if (cacheCheckStatus !== 200) return json({ detail: "boom" }, cacheCheckStatus);
    return json({ alv_id: ALV, param_hash: HASH, hit: cacheHit });
  }

  if (url.match(/\/api\/reports\/[^/]+\/submit$/) && method === "POST") {
    counts.submit += 1;
    return json({
      request_no: "REQ-NEW",
      alv_id: ALV,
      run_id: 42,
      status: "QUEUED",
      param_hash: HASH,
    });
  }

  if (url.startsWith("/api/reports?") || url === "/api/reports") {
    return json({
      report_key: "retail_ledger",
      report_label: "Retail Ledger",
      selections: [
        {
          selection_id: "detail",
          selection_label: "Detail",
          selection_order: 1,
          report_types: [
            { report_type_code: "agent_item", report_type_label: "Agent Item", report_type_order: 1, alv_id: ALV, alv_name: "Agent Item", description: null },
          ],
        },
      ],
    });
  }

  if (url.match(/^\/api\/reports\/[^/?]+$/)) {
    return json(formDef());
  }

  return json({ detail: `unexpected: ${url}` }, 404);
}

function renderApp() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <FormDraftProvider>
          <App />
        </FormDraftProvider>
      </HashRouter>
    </QueryClientProvider>,
  );
}

const A_HIT = {
  request_no: "REQ-OLD",
  submitted_by: "bob@example.com",
  generated_at: "2026-08-15T10:00:00Z",
  expires_at: "2026-08-22T10:00:00Z",
  row_count: 7,
  has_output: true,
};

describe("result-cache reuse flow", () => {
  beforeEach(() => {
    cacheHit = null;
    cacheCheckStatus = 200;
    counts = { check: 0, submit: 0 };
    window.location.hash = `#/report/retail_ledger/${ALV}`;
    vi.stubGlobal("fetch", vi.fn(fakeFetch));
  });
  afterEach(() => vi.unstubAllGlobals());

  it("offers reuse when an identical run exists, and 'Run the job again' submits", async () => {
    const user = userEvent.setup();
    cacheHit = A_HIT;
    renderApp();

    await user.click(await screen.findByRole("button", { name: "Submit" }));

    // The reuse modal appears, naming the original submitter — not a new submit yet.
    await screen.findByRole("dialog", { name: "Identical report run found" });
    expect(screen.getByText(/bob@example.com/)).toBeTruthy();
    expect(counts.check).toBe(1);
    expect(counts.submit).toBe(0);

    await user.click(screen.getByRole("button", { name: "Run the job again" }));

    // Now the job runs and the submitted result shows.
    await screen.findByText(/REQ-NEW/);
    expect(counts.submit).toBe(1);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("'Reuse output' downloads the existing run and does not submit", async () => {
    const user = userEvent.setup();
    cacheHit = A_HIT;
    const clickSpy = vi
      .spyOn(HTMLAnchorElement.prototype, "click")
      .mockImplementation(() => {});
    renderApp();

    await user.click(await screen.findByRole("button", { name: "Submit" }));
    await screen.findByRole("dialog", { name: "Identical report run found" });
    await user.click(screen.getByRole("button", { name: "Reuse output" }));

    // A download of the existing run was triggered (via an anchor), no new run.
    expect(clickSpy).toHaveBeenCalledTimes(1);
    expect(counts.submit).toBe(0);
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    clickSpy.mockRestore();
  });

  it("submits directly when there is no cache hit", async () => {
    const user = userEvent.setup();
    cacheHit = null;
    renderApp();

    await user.click(await screen.findByRole("button", { name: "Submit" }));

    await screen.findByText(/REQ-NEW/);
    expect(counts.check).toBe(1);
    expect(counts.submit).toBe(1);
    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("degrades to a normal submit when the cache check fails", async () => {
    const user = userEvent.setup();
    cacheCheckStatus = 500;
    renderApp();

    await user.click(await screen.findByRole("button", { name: "Submit" }));

    // The check errored, but submission is not blocked.
    await screen.findByText(/REQ-NEW/);
    expect(counts.check).toBe(1);
    expect(counts.submit).toBe(1);
    expect(screen.queryByRole("dialog")).toBeNull();
  });
});
