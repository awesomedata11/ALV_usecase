"""App configuration — env-var driven, no secrets committed.

All values come from the environment. On a deployed Databricks App the platform
auto-injects the service-principal OAuth credentials (``DATABRICKS_CLIENT_ID`` /
``DATABRICKS_CLIENT_SECRET``) and ``DATABRICKS_HOST``; the Databricks SDK ``Config()``
picks those up on its own, so they are intentionally NOT modelled here. What we
model here is only the app-specific configuration the code reads directly.

See ``app/README.md`` for the full env-var contract.
"""

from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """App settings, populated from environment variables (case-insensitive)."""

    model_config = SettingsConfigDict(env_prefix="", case_sensitive=False, extra="ignore")

    # --- Unity Catalog metadata location (the tables the App will later read) -------
    # Defaults mirror the metadata library's default `{catalog}.{schema}` (docs/METADATA_TABLE.md).
    catalog: str = "alv_bricks"
    schema_name: str = "metadata"

    # --- SQL warehouse (used later for alv_catalog / request_log queries) -----------
    # On a deployed app this is wired via app.yaml `valueFrom: sql-warehouse`.
    databricks_warehouse_id: str | None = None

    # --- Lakebase / Postgres (psycopg) connection factory inputs --------------------
    # Declared for task 1.1 only — no real queries yet. On a deployed app with a
    # Lakebase resource these are auto-injected (PGHOST, PGPORT, ...). Locally they
    # are optional; the factory raises a clear error if asked to connect unconfigured.
    pghost: str | None = None
    pgport: int = 5432
    pgdatabase: str | None = None
    pguser: str | None = None
    pgpassword: str | None = None
    pgsslmode: str = "require"

    # --- Report visibility (report_permissions → group/user gating) -----------------
    # How long a user's group set (from /Me with their OBO token) and the
    # report_key → principals mapping are cached. Workspace SCIM allows 255 GET/min
    # FIXED, so a per-user TTL cache is mandatory, not an optimization.
    permissions_user_ttl_seconds: int = 300
    permissions_map_ttl_seconds: int = 300

    # --- Admin console (who may grant/revoke report access) -------------------------
    # Comma-separated list of admin PRINCIPALS: emails and/or Databricks group display
    # names, mixed freely. A caller is an admin if their (lower-cased) email is listed,
    # OR any of their /Me groups is listed. This is the BOOTSTRAP admin surface — it is
    # config-driven (env_parameters/*.yaml → app.yaml), deliberately NOT stored in the
    # grant table, so admin rights cannot be granted through the console they gate.
    # Empty (the default) means NO admins: every /api/admin/* route 404s. Fail closed.
    alv_admins: str = ""

    def admin_principals(self) -> frozenset[str]:
        """The configured admin principals, trimmed, lower-cased, non-empty."""
        return frozenset(
            tok.strip().lower() for tok in self.alv_admins.split(",") if tok.strip()
        )

    # --- Dynamic templates (relative date presets) ----------------------------------
    # The timezone whose "today" resolves a dynamic template's relative date presets
    # (e.g. "first day of previous month") at load time. RIL is India, so the report
    # clock is Asia/Kolkata by default; configurable without a code change. Only the
    # endpoint reads the clock — the resolver takes an explicit date, staying pure.
    report_timezone: str = "Asia/Kolkata"

    # --- Result retention (request_log.expires_at) ----------------------------------
    # How long a produced output file is considered still on offer. Written as
    # ``expires_at = generated_at + result_ttl_days`` on the SAME path that captures
    # ``generated_at`` (see alv_app.request_log.update_status), so a COMPLETED run
    # always carries both. Groundwork for the later result-cache reuse feature — the
    # App does NOT read this column yet.
    result_ttl_days: int = 7

    # --- Downloads list (GET /api/requests) -----------------------------------------
    # Page size defaults + the hard cap the endpoint clamps a client-supplied
    # ``limit`` to, so a crafted query can never ask for the whole table.
    downloads_page_size: int = 50
    downloads_max_page_size: int = 200

    # --- Output-file preview (GET /api/requests/{request_no}/output-preview) ---------
    # The on-screen preview of a completed run's OUTPUT FILE (not a SQL sample). Bounded
    # two ways so a huge export never buffers in the App tier: a ROW cap on what is
    # returned, and a hard BYTE ceiling on how much of the file is read off the Volume
    # (sized to comfortably hold ``output_preview_max_rows`` wide CSV rows).
    output_preview_max_rows: int = 1000
    output_preview_max_bytes: int = 8 * 1024 * 1024  # 8 MiB

    # --- Local dev toggles ----------------------------------------------------------
    # When true, /api/me trusts the dev fallback identity instead of requiring the
    # Databricks-injected SSO headers (which only exist when deployed).
    dev_mode: bool = True
    dev_user_email: str = "local.dev@example.com"
    dev_user_name: str = "Local Developer"

    # DANGEROUS — local dev only. When true, every report is visible to everyone and
    # report_permissions is not consulted at all. Defaults to the SAFE value (False)
    # so it can never ship open by accident: it must be switched on explicitly, and
    # :func:`alv_app.entitlements.permission_bypass_active` logs a loud WARNING every
    # time it takes effect. It is additionally REFUSED unless ``dev_mode`` is also on,
    # so setting it in a deployed app.yaml (which sets DEV_MODE=false) does nothing.
    dev_bypass_permissions: bool = False


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance (read env once per process)."""
    return Settings()
