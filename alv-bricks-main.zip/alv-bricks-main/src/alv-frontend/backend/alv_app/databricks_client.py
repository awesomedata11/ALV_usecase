"""Databricks SDK wiring for the app service principal.

On a deployed Databricks App the platform auto-injects the app's service-principal
OAuth credentials (``DATABRICKS_CLIENT_ID`` / ``DATABRICKS_CLIENT_SECRET``) and
``DATABRICKS_HOST``. The SDK ``Config()`` / ``WorkspaceClient()`` detect these on
their own — we never read or hardcode tokens (see the databricks-app-python skill,
1-authorization.md: "App Authorization (Service Principal)").

This module keeps the wiring THIN (task 1.1): a cached client factory plus one
simple auth-check call used by the health/identity endpoints to prove the SP works.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class AuthCheck:
    """Result of the service-principal auth-check call."""

    ok: bool
    # The service principal's own identity (username / application id) when reachable.
    service_principal: str | None
    detail: str | None


@lru_cache
def get_workspace_client():
    """Return a cached Databricks ``WorkspaceClient`` authenticated as the app SP.

    Uses the SDK's default credential chain (``Config()``): on a deployed app this
    resolves the injected service-principal OAuth credentials automatically. Import
    is done lazily so the module (and the app) still import without the SDK present.

    Raises:
        RuntimeError: if the SDK is not installed.
    """
    try:
        from databricks.sdk import WorkspaceClient
    except ImportError as exc:  # pragma: no cover - defensive
        raise RuntimeError(
            "databricks-sdk is not installed; add it to the backend dependencies."
        ) from exc

    # No args: Config() auto-detects host + SP OAuth creds from the environment.
    return WorkspaceClient()


class JobTriggerError(RuntimeError):
    """Raised when the Jobs run-now call cannot be performed."""


def trigger_job_run(job_id: int, job_parameters: dict[str, str]) -> int:
    """Trigger a run of the bound Job via ``jobs run-now`` as the app SP (task 7.4).

    Uses the SP :class:`WorkspaceClient` (``Config()`` default auth on deploy — the
    SP needs CAN_MANAGE_RUN on the Job, see docs/APP_PREREQUISITES.md). The App owns
    the run lifecycle: run-now returns the **job run id**, persisted to
    ``request_log.run_id`` for later status polling (task 8.x, CONTRACT.md §Background).

    Args:
        job_id: the bound customer Job id (from ``alv_catalog.job_id``).
        job_parameters: ``{param_name: str}`` values (run-now takes string values).

    Returns:
        The Databricks job ``run_id``.

    Raises:
        JobTriggerError: if the SDK is missing, the call fails, or no run_id returns.
    """
    try:
        client = get_workspace_client()
        run = client.jobs.run_now(job_id=job_id, job_parameters=job_parameters)
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise JobTriggerError(f"jobs run-now failed for job_id={job_id}: {exc}") from exc

    run_id = getattr(run, "run_id", None)
    if run_id is None:
        raise JobTriggerError(f"jobs run-now returned no run_id for job_id={job_id}")
    return int(run_id)


@dataclass(frozen=True)
class RunStatus:
    """Result of reading a Job run's live state (task 8.x status polling).

    ``status`` is our own vocabulary (QUEUED / RUNNING / SUCCESS / FAILED /
    CANCELLED) mapped from the Databricks run lifecycle + result state. ``ok`` is
    ``False`` when the run state could not be read (SDK missing, call failed, or no
    state on the run) — the endpoint then leaves the stored status unchanged rather
    than 500-ing, mirroring :func:`auth_check`'s degrade-gracefully contract.
    """

    ok: bool
    status: str | None
    detail: str | None


# Databricks run lifecycle/result → our status vocabulary (CONTRACT.md §Background).
# life_cycle_state drives QUEUED/RUNNING; on TERMINATED we read result_state.
_LIFECYCLE_TO_STATUS = {
    "PENDING": "QUEUED",
    "BLOCKED": "QUEUED",
    "QUEUED": "QUEUED",
    "WAITING_FOR_RETRY": "QUEUED",
    "RUNNING": "RUNNING",
    "TERMINATING": "RUNNING",
}
_RESULT_TO_STATUS = {
    "SUCCESS": "SUCCESS",
    "FAILED": "FAILED",
    "ERROR": "FAILED",
    "TIMEDOUT": "FAILED",
    "CANCELED": "CANCELLED",
}


def _map_run_state(life_cycle_state: str | None, result_state: str | None) -> str | None:
    """Map a Databricks run (lifecycle, result) pair to our status vocabulary.

    Returns ``None`` when the lifecycle state is unrecognized (or missing) and no
    result mapping applies, so the caller can leave the stored status untouched.

    Args:
        life_cycle_state: ``state.life_cycle_state`` value (upper-cased name).
        result_state: ``state.result_state`` value (upper-cased name), set once the
            run has TERMINATED.
    """
    lc = (life_cycle_state or "").upper()
    if lc in ("TERMINATED", "INTERNAL_ERROR", "SKIPPED"):
        # Terminal: the outcome comes from result_state. INTERNAL_ERROR/SKIPPED with
        # no usable result_state fall through to FAILED.
        rs = (result_state or "").upper()
        return _RESULT_TO_STATUS.get(rs, "FAILED")
    return _LIFECYCLE_TO_STATUS.get(lc)


def get_run_status(run_id: int) -> RunStatus:
    """Read a Job run's live state and map it to our status vocabulary (task 8.x).

    Calls ``jobs.get_run(run_id=...)`` as the app SP (``Config()`` default auth on
    deploy — the SP needs CAN_MANAGE_RUN on the Job) and maps
    ``state.life_cycle_state`` / ``state.result_state`` via :func:`_map_run_state`.

    Args:
        run_id: the Databricks job ``run_id`` stored on the request_log row.

    Returns:
        A :class:`RunStatus`. ``ok=False`` (with ``detail``, ``status=None``) when the
        SDK is absent, the call fails, or the run carries no mappable state — the
        endpoint then keeps the stored status. Never raises.
    """
    try:
        client = get_workspace_client()
        run = client.jobs.get_run(run_id=run_id)
    except Exception as exc:  # noqa: BLE001 - poll must never raise out of the endpoint
        return RunStatus(ok=False, status=None, detail=str(exc))

    state = getattr(run, "state", None)
    if state is None:
        return RunStatus(ok=False, status=None, detail="run has no state")

    life = getattr(state, "life_cycle_state", None)
    result = getattr(state, "result_state", None)
    # SDK enums carry a ``.value`` (the wire name); fall back to str() defensively.
    life_name = getattr(life, "value", None) or (str(life) if life is not None else None)
    result_name = getattr(result, "value", None) or (str(result) if result is not None else None)

    status = _map_run_state(life_name, result_name)
    if status is None:
        return RunStatus(
            ok=False,
            status=None,
            detail=f"unmapped run state: life_cycle_state={life_name} result_state={result_name}",
        )
    return RunStatus(ok=True, status=status, detail=None)


# --- Output pointer capture (task 9.x — CONTRACT mechanism (a)) -----------------
@dataclass(frozen=True)
class RunOutput:
    """The Job's returned output pointer, parsed from ``notebook_output.result`` (9.x).

    Populated by :func:`get_run_output` on a SUCCESS run per CONTRACT mechanism (a):
    the notebook ends with ``dbutils.notebook.exit(json.dumps({...}))`` and the App
    reads that string back via ``jobs.get_run_output``. ``ok=False`` (with ``detail``)
    when the pointer couldn't be read/parsed (SDK missing, call failed, truncated
    exit value, or malformed JSON) — the caller then leaves ``output_path`` NULL and
    never crashes, per the task's graceful-degradation requirement.
    """

    ok: bool
    status: str | None
    output_path: str | None
    row_count: int | None
    generated_at: str | None
    detail: str | None


def _coerce_row_count(value: object) -> int | None:
    """Coerce the JSON ``row_count`` (int/str/None) to int, or None if unusable."""
    if value is None:
        return None
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None


def get_run_output(job_run_id: int) -> RunOutput:
    """Read a SUCCESS run's returned output pointer (task 9.x, CONTRACT mechanism (a)).

    Resolves the task run id from the job run id (``jobs.get_run(run_id).tasks[0]``,
    per CONTRACT.md "Run id nuance"), calls ``jobs.get_run_output(task_run_id)``, and
    parses ``notebook_output.result`` — the frozen JSON pointer
    (``{status, output_path, row_count, generated_at, ...}``). Runs as the app SP.

    Never raises: returns ``ok=False`` (with ``detail``) when the SDK is absent, a
    call fails, the exit value was ``truncated`` (>~5 MB — a bug on the RIL side; the
    contract mandates a pointer, never data), the notebook produced no output, or the
    JSON is malformed. The caller then leaves ``output_path`` NULL and reflects the
    run's failure in ``status`` rather than crashing the poll.

    Args:
        job_run_id: the Databricks **job** run id stored on the request_log row (the
            same id used for status polling). The task run id is resolved here.

    Returns:
        A :class:`RunOutput`. ``status`` is the payload's own ``status`` (e.g.
        ``COMPLETED`` / ``FAILED``); ``output_path`` is the UC Volume / storage path.
    """
    try:
        client = get_workspace_client()
        run = client.jobs.get_run(run_id=job_run_id)
    except Exception as exc:  # noqa: BLE001 - poll must never raise out of the endpoint
        return RunOutput(False, None, None, None, None, str(exc))

    tasks = getattr(run, "tasks", None) or []
    if not tasks:
        return RunOutput(False, None, None, None, None, "run has no tasks")
    task_run_id = getattr(tasks[0], "run_id", None)
    if task_run_id is None:
        return RunOutput(False, None, None, None, None, "task has no run_id")

    try:
        out = client.jobs.get_run_output(run_id=int(task_run_id))
    except Exception as exc:  # noqa: BLE001
        return RunOutput(False, None, None, None, None, str(exc))

    notebook_output = getattr(out, "notebook_output", None)
    if notebook_output is None:
        return RunOutput(False, None, None, None, None, "run has no notebook_output")
    if getattr(notebook_output, "truncated", False):
        # The contract mandates a pointer, not data; a truncated exit value is a
        # RIL-side bug we surface rather than parse a partial JSON.
        return RunOutput(False, None, None, None, None, "notebook exit value was truncated")

    result = getattr(notebook_output, "result", None)
    if not result:
        return RunOutput(False, None, None, None, None, "notebook_output has no result")

    try:
        payload = json.loads(result)
    except (TypeError, ValueError) as exc:
        return RunOutput(False, None, None, None, None, f"malformed output JSON: {exc}")
    if not isinstance(payload, dict):
        return RunOutput(False, None, None, None, None, "output JSON is not an object")

    return RunOutput(
        ok=True,
        status=payload.get("status"),
        output_path=payload.get("output_path"),
        row_count=_coerce_row_count(payload.get("row_count")),
        generated_at=payload.get("generated_at"),
        detail=None,
    )


# --- App-proxied Volume download (task 9.x — CONTRACT §4.2) ---------------------
class VolumeDownloadError(RuntimeError):
    """Raised when a UC Volume file read cannot be performed (task 9.x §4.2)."""


def download_volume_file(output_path: str):
    """Open a UC Volume file for streaming as the app SP (task 9.x, CONTRACT §4.2).

    App-proxied download: the App reads the file via the Databricks SDK Files API
    (``w.files.download`` for ``/Volumes/...`` paths) using its own service principal
    and streams the bytes to the browser — NOT a direct storage URL (§4.2: AuthZ
    chokepoint, no cloud creds in the browser).

    Args:
        output_path: the ``/Volumes/<catalog>/<schema>/.../file`` path from
            ``request_log.output_path``.

    Returns:
        A binary file-like object (``DownloadResponse.contents``) the caller streams.

    Raises:
        VolumeDownloadError: if the SDK is missing, the download call fails, or the
            response carries no readable contents. The endpoint maps this to a 502.
    """
    try:
        client = get_workspace_client()
        resp = client.files.download(output_path)
    except Exception as exc:  # noqa: BLE001 - surface as our typed error (endpoint → 502)
        raise VolumeDownloadError(f"could not read volume file {output_path}: {exc}") from exc

    contents = getattr(resp, "contents", None)
    if contents is None:
        raise VolumeDownloadError(f"volume file {output_path} returned no contents")
    return contents


def read_volume_prefix(output_path: str, max_bytes: int) -> tuple[bytes, bool]:
    """Read at most ``max_bytes`` from the head of a UC Volume file, App-proxied.

    Reuses :func:`download_volume_file` (same App-SP Files-API seam) but reads only a
    BOUNDED prefix and closes the stream immediately — so previewing a 1,000,000-row
    export never buffers the whole file in the App tier (the streaming download reads
    the whole file; a preview must not).

    Reads ``max_bytes + 1`` so the caller can tell "the file is exactly this big" from
    "there is more beyond the cap": the extra byte is dropped from the returned data and
    reported via the ``truncated`` flag.

    Args:
        output_path: the ``/Volumes/...`` path from ``request_log.output_path``.
        max_bytes: the hard ceiling on how many bytes to return.

    Returns:
        ``(data, truncated)`` — ``data`` is at most ``max_bytes`` bytes; ``truncated``
        is True when the file continues past the cap.

    Raises:
        VolumeDownloadError: propagated from :func:`download_volume_file` (missing SDK,
            failed read, or empty response). The endpoint maps this to a 502.
    """
    contents = download_volume_file(output_path)
    try:
        data = contents.read(max_bytes + 1)
    except Exception as exc:  # noqa: BLE001 - surface as our typed error (endpoint → 502)
        raise VolumeDownloadError(
            f"could not read volume file {output_path}: {exc}"
        ) from exc
    finally:
        close = getattr(contents, "close", None)
        if callable(close):
            close()

    if data is None:
        data = b""
    truncated = len(data) > max_bytes
    return data[:max_bytes], truncated


def auth_check() -> AuthCheck:
    """Make one simple SDK call to confirm the app service principal can authenticate.

    Calls ``current_user.me()`` — the lightest identity call — and reports whether
    it succeeded. This is a liveness/auth probe only; it performs no business logic.

    Returns:
        An :class:`AuthCheck`. ``ok=False`` (with ``detail``) when the SDK is absent
        or the call fails (e.g. running locally with no Databricks credentials),
        so the endpoint degrades gracefully instead of 500-ing.
    """
    try:
        client = get_workspace_client()
        me = client.current_user.me()
        return AuthCheck(
            ok=True,
            service_principal=getattr(me, "user_name", None),
            detail=None,
        )
    except Exception as exc:  # noqa: BLE001 - probe must never raise
        return AuthCheck(ok=False, service_principal=None, detail=str(exc))
