"""Data-access seam: find a reusable prior run in ``request_log`` (task 7.3).

Backs the result-cache lookup (``POST /api/reports/{alv_id}/cache-check``). When a
user is about to submit a report, the App asks here whether an identical run —
same ``alv_id`` + ``param_hash`` — already COMPLETED within its retention window,
so the user can be offered the existing output instead of running the Job again.

Reads the App-owned ``request_log`` table via the SAME statement-execution seam as
the Downloads list (:mod:`alv_app.downloads`) and the write path
(:mod:`alv_app.request_log`), i.e. as the app service principal. Every user-supplied
value is a **bound parameter** (:class:`BoundParam` → ``StatementParameterListItem``);
nothing user-controlled is ever formatted into the SQL string.

## What counts as a reuse candidate

A row is a hit only if it is the same report + parameters, actually finished with an
output pointer, and still inside its TTL (see :func:`build_cache_lookup_sql`):

* ``alv_id = :alv_id`` AND ``param_hash = :param_hash`` — the cache key (D12).
* ``status = 'COMPLETED'`` — a QUEUED / RUNNING / FAILED / EXPIRED row is never a hit.
* ``output_path IS NOT NULL`` — a completed run with no captured pointer is unusable.
* ``expires_at > current_timestamp()`` — the file is still within retention. A row
  expiring exactly now is NOT a hit (strict ``>``; fail-safe — never serve a just-expired
  result).

## Latest wins (the E2 / "recommend the latest file" rule)

If the same parameters were run more than once and several rows still qualify, the
newest output is the one to offer — ``ORDER BY generated_at DESC`` (then
``submitted_at DESC, request_no DESC`` as a stable tiebreak) with ``LIMIT 1``. So a
third user submitting parameters that already have two cached outputs is pointed at the
**latest** file, never an older one.

## Never a control on its own, and never blocking

The cache lookup does not decide who may see a run — the endpoint applies the same
``report_permissions`` gate as every other report-scoped path BEFORE calling here. And
a warehouse failure here is surfaced as :class:`CacheSourceError`; the endpoint turns
that into "no hit" so a cache-read problem degrades to a normal (re)run rather than
blocking the submission. The feature is strictly optional.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from .config import Settings

log = logging.getLogger("alv_reports.cache_source")

# Columns read for a reuse candidate. output_path is read to confirm a usable pointer
# exists, but is NEVER returned to the client (the raw storage path is not exposed — the
# download is App-proxied by request_no); the endpoint surfaces only its presence.
_COLUMNS = [
    "request_no",
    "alv_id",
    "submitted_by",
    "generated_at",
    "expires_at",
    "output_path",
    "row_count",
]


class CacheSourceError(RuntimeError):
    """Raised when the ``request_log`` cache lookup cannot be performed."""


@dataclass(frozen=True)
class BoundParam:
    """One bound statement parameter (mirrors :class:`alv_app.downloads.BoundParam`)."""

    name: str
    value: str
    type: str


def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.request_log`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`request_log`"


def build_cache_lookup_sql(
    settings: Settings, *, alv_id: str, param_hash: str
) -> tuple[str, list[BoundParam]]:
    """Build the parameterized reuse-candidate lookup. Pure (no I/O), so the SQL shape
    — and the guarantee that ``alv_id`` / ``param_hash`` are bound, never interpolated —
    is directly unit-testable. Returns ``(sql, params)``.

    Only the fully-qualified table name (from Settings, backtick-quoted) is formatted
    into the string; ``alv_id`` and ``param_hash`` are ``:markers``. See the module
    docstring for the hit definition and the latest-wins ordering.
    """
    sql = (
        f"SELECT {', '.join(_COLUMNS)} FROM {_fqtn(settings)} "
        "WHERE alv_id = :alv_id AND param_hash = :param_hash "
        "AND status = 'COMPLETED' AND output_path IS NOT NULL "
        "AND expires_at > current_timestamp() "
        # Latest wins: newest generated output first, with a stable tiebreak so the
        # pick is deterministic when two rows share a generated_at.
        "ORDER BY generated_at DESC, submitted_at DESC, request_no DESC "
        "LIMIT 1"
    )
    params = [
        BoundParam(name="alv_id", value=alv_id, type="STRING"),
        BoundParam(name="param_hash", value=param_hash, type="STRING"),
    ]
    return sql, params


def _execute(settings: Settings, sql: str, params: list[BoundParam]) -> list[list[object]]:
    """Run the parameterized read on the warehouse as the app SP; return the data array.

    Raises:
        CacheSourceError: if the warehouse id is unset, the SDK is missing, or the
            statement does not succeed.
    """
    if not settings.databricks_warehouse_id:
        raise CacheSourceError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot read request_log."
        )

    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import StatementParameterListItem, StatementState
    except ImportError as exc:  # pragma: no cover - defensive
        raise CacheSourceError("databricks-sdk is not installed.") from exc

    sdk_params = [
        StatementParameterListItem(name=p.name, value=p.value, type=p.type) for p in params
    ]
    # Log the SQL SHAPE + bound-param count, never the bound values (the param_hash is
    # not sensitive, but keeping this symmetric with the other seams is the safe habit).
    log.info(
        "request_log cache-check (warehouse %s): sql=%s bound_params=%d",
        settings.databricks_warehouse_id,
        sql,
        len(sdk_params),
    )

    try:
        client = WorkspaceClient()  # Config() default auth (profile locally, SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=sql,
            parameters=sdk_params,
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise CacheSourceError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise CacheSourceError(f"statement did not succeed: {detail}")

    return resp.result.data_array if (resp.result and resp.result.data_array) else []


def find_cached_run(
    settings: Settings, *, alv_id: str, param_hash: str
) -> dict[str, object] | None:
    """Return the newest reusable ``request_log`` row for *(alv_id, param_hash)*, or None.

    A hit is a COMPLETED run with a captured ``output_path`` still inside its TTL; when
    several qualify the latest (by ``generated_at``) is returned — see the module
    docstring. The result is NOT cached: reuse must reflect the live table (a run may
    have just completed, or just expired).

    Args:
        settings: app settings carrying ``catalog`` / ``schema_name`` /
            ``databricks_warehouse_id``.
        alv_id: the report the caller is submitting.
        param_hash: the canonical-payload hash the endpoint computed server-side.

    Returns:
        A dict keyed by :data:`_COLUMNS` (``row_count`` coerced to int or None), or
        ``None`` when nothing qualifies.

    Raises:
        CacheSourceError: on warehouse/SDK failure. The endpoint degrades this to "no
            hit" so a cache-read problem never blocks the submission.
    """
    sql, params = build_cache_lookup_sql(settings, alv_id=alv_id, param_hash=param_hash)
    data = _execute(settings, sql, params)
    if not data:
        return None
    row = dict(zip(_COLUMNS, data[0]))
    row["row_count"] = _as_int(row.get("row_count"))
    return row


def _as_int(v: object) -> int | None:
    """Coerce a warehouse string/number to int, or None."""
    if v is None or v == "":
        return None
    try:
        return int(v)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
