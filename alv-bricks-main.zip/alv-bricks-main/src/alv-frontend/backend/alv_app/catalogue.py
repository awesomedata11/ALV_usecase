"""Shape cached rows into the API response models (task 3.2).

Pure transforms over :class:`~alv_app.cache.CachedReport` — no I/O — so they are
directly unit-testable. :func:`build_catalogue` groups the flat rows into the
nav tree the frontend renders (selection → report types, screenshot 2);
:func:`to_form_out` projects one row's render-ready form.
"""

from __future__ import annotations

from .cache import CachedReport
from .models import (
    CatalogueOut,
    ReportFormOut,
    ReportGroupOut,
    ReportGroupsOut,
    ReportTypeOut,
    SelectionOut,
)


def build_report_groups(groups: list[tuple[str, str | None, int]]) -> ReportGroupsOut:
    """Shape the cache's ``(report_key, report_label, runnable_count)`` tuples.

    Pure transform over :meth:`MetadataCache.report_groups` output — the home page's
    active cards (task: report cards). Frontend-static placeholders are not included.
    """
    return ReportGroupsOut(
        groups=[
            ReportGroupOut(report_key=rk, report_label=label, runnable_count=count)
            for rk, label, count in groups
        ]
    )


def build_catalogue(
    reports: list[CachedReport], report_key: str | None = None
) -> CatalogueOut:
    """Group active reports into ``report_key`` → selections → report types.

    Args:
        reports: Active, permitted rows, pre-sorted by (selection_order,
            report_type_order, report_key) — :meth:`MetadataCache.active_reports`
            does that — so insertion order here is display order.
        report_key: Optional filter, applied BEFORE grouping. When given, only that
            report's rows are grouped and the tree's ``report_key`` / ``report_label``
            describe that report. When omitted the behaviour is unchanged for a
            single-report tree (back-compat); see below for a spanning tree.

    Returns:
        The nav tree. ``report_key`` / ``report_label`` identify the ONE report the
        tree describes, and are ``None`` when it spans several (there is no single
        owning report to name — previously ``reports[0]``'s label was applied to the
        whole tree, which mislabelled every other report in it).

    Selections are keyed by **(report_key, selection_id)**, not ``selection_id``
    alone: ``selection_id`` is only unique *within* a report ("detail" exists under
    every report), so keying on it merged two reports' identically-named selections
    into one bucket and cross-linked their report types. The emitted
    ``selection_id`` stays the bare id — it is the contract the frontend radio and
    ``GET /api/reports/{alv_id}``'s ``selection_id`` share.
    """
    if report_key is not None:
        reports = [r for r in reports if str(r.report_key) == report_key]

    # Identify the tree only when it describes exactly one report.
    keys = {str(r.report_key) for r in reports}
    if report_key is not None:
        tree_key: str | None = report_key
    elif len(keys) == 1:
        tree_key = next(iter(keys))
    else:
        tree_key = None  # empty, or spanning several reports
    tree_label = next(
        (r.report_label for r in reports if str(r.report_key) == tree_key), None
    )

    # Preserve first-seen (sorted) order of selections and their report types.
    selections: dict[tuple[str, str], SelectionOut] = {}
    for r in reports:
        sid = str(r.selection_id)
        key = (str(r.report_key), sid)
        sel = selections.get(key)
        if sel is None:
            sel = SelectionOut(
                selection_id=sid,
                selection_label=r.selection_label,
                selection_order=r.selection_order,
                report_types=[],
            )
            selections[key] = sel
        sel.report_types.append(
            ReportTypeOut(
                report_type_code=r.report_type_code,
                report_type_label=r.report_type_label,
                report_type_order=r.report_type_order,
                alv_id=r.alv_id,
                alv_name=r.alv_name,
                description=r.description,
            )
        )

    return CatalogueOut(
        report_key=tree_key,
        report_label=tree_label,
        selections=list(selections.values()),
    )


def to_form_out(report: CachedReport) -> ReportFormOut:
    """Project one cached report into its render-ready form response."""
    return ReportFormOut(
        alv_id=report.alv_id,
        report_key=str(report.report_key),
        report_label=report.report_label,
        selection_id=str(report.selection_id),
        selection_label=report.selection_label,
        report_type_code=report.report_type_code,
        report_type_label=report.report_type_label,
        alv_name=report.alv_name,
        description=report.description,
        fields=report.fields,
        has_sample_query=report.has_sample_query,
    )
