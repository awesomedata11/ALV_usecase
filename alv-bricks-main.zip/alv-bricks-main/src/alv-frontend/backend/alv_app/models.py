"""API response models."""

from __future__ import annotations

from pydantic import BaseModel

from .fields import FormField


class HealthOut(BaseModel):
    """Liveness response."""

    status: str
    app: str
    version: str


class MeOut(BaseModel):
    """Current-user identity, as resolved from the Databricks Apps SSO headers.

    Never includes the on-behalf-of access token itself — only whether one was
    present (`has_user_token`).
    """

    email: str | None
    preferred_username: str | None
    user_id: str | None
    real_ip: str | None
    # False when the identity is the local dev fallback (no real SSO headers).
    authenticated: bool
    has_user_token: bool
    # Whether this caller may use the admin console (ALV_ADMINS gate). The endpoints
    # enforce independently; this only lets the frontend show/hide the Admin nav.
    is_admin: bool = False
    # App service-principal auth-check (SDK current_user.me()).
    service_principal: str | None
    service_principal_ok: bool
    service_principal_detail: str | None


# --- Catalogue (task 3.2) -------------------------------------------------------
class ReportTypeOut(BaseModel):
    """Navigation level 2 — one report-type leaf under a selection.

    Resolves to exactly one runnable report (one ``alv_id`` / Job). For a
    selection with no report type (Agent Closing Balance) the single leaf carries
    ``report_type_code = None`` and the selection's own labels.
    """

    report_type_code: str | None
    report_type_label: str | None
    report_type_order: int | None
    alv_id: str
    alv_name: str | None
    description: str | None


class SelectionOut(BaseModel):
    """Navigation level 1 — a selection grouping its report types (screenshot 2)."""

    selection_id: str
    selection_label: str | None
    selection_order: int | None
    report_types: list[ReportTypeOut]


class CatalogueOut(BaseModel):
    """The active catalogue, shaped for nav grouping (selection → report types).

    ``report_key`` / ``report_label`` identify the ONE report this tree describes.
    Both are ``None`` when the tree is empty or spans several reports (an unscoped
    ``GET /api/reports`` for a user permitted more than one): there is no single
    owning report to name, and naming an arbitrary one mislabels the rest.
    Request ``?report_key=`` to get a scoped, always-identified tree.
    """

    report_key: str | None
    report_label: str | None
    selections: list[SelectionOut]


# --- Home page report groups (report cards) -------------------------------------
class ReportGroupOut(BaseModel):
    """One seeded ALV report, for the home-page card grid.

    ``runnable_count`` counts active rows whose ``job_id`` is bound; a report is
    only actually runnable once its Job exists (all 14 pilot rows are unbound /
    ``NULL`` until the deploy-time job-binding step — see docs/APP_PREREQUISITES.md).
    """

    report_key: str
    report_label: str | None
    runnable_count: int


class ReportGroupsOut(BaseModel):
    """The distinct seeded reports backing the active home-page cards."""

    groups: list[ReportGroupOut]


class ReportFormOut(BaseModel):
    """One report's render-ready form definition (GET /api/reports/{alv_id})."""

    alv_id: str
    report_key: str
    report_label: str | None
    selection_id: str
    selection_label: str | None
    report_type_code: str | None
    report_type_label: str | None
    alv_name: str | None
    description: str | None
    fields: list[FormField]
    has_sample_query: bool = False


# --- Preview (sample data preview feature) -------------------------------------
class PreviewIn(BaseModel):
    """POST body for a preview request: the current form values to filter by.

    ``values`` mirrors the same flat param-name map used by :class:`SubmitIn`.
    Blank / absent values are silently skipped in the WHERE clause.
    """

    values: dict[str, str] = {}


class PreviewOut(BaseModel):
    """Response from ``POST /api/reports/{alv_id}/preview``.

    ``columns`` holds the display names in spec order; ``rows`` is a list of
    row arrays (same order). ``truncated`` is True when the result set was
    capped at the configured limit, signalling that more rows may exist.
    """

    columns: list[str]
    rows: list[list]
    row_count: int
    truncated: bool


# --- Output-file preview (view a completed run's result on-screen) --------------
class OutputPreviewOut(BaseModel):
    """Response from ``GET /api/requests/{request_no}/output-preview``.

    The on-screen twin of the download: the first rows of the file a completed run
    produced on the UC Volume, parsed server-side (NO SQL — contrast :class:`PreviewOut`,
    which runs a query against a sample table).

    ``format`` selects how the UI renders the body:
      * ``"csv"``    — ``columns`` + ``rows`` (a table);
      * ``"text"``   — ``text`` (a raw first-N-lines block, for non-CSV text files);
      * ``"binary"`` — no body; the UI shows "preview not available for this file type".

    ``truncated`` is True when the file continues past the row or byte cap; the UI then
    points the user at Download for the full result.
    """

    format: str
    columns: list[str] = []
    rows: list[list] = []
    text: str | None = None
    row_count: int
    truncated: bool
    filename: str


# --- Submit (tasks 7.1 / 7.2 / 7.4 / 7.5) ---------------------------------------
class SubmitIn(BaseModel):
    """POST body for a report submission: the raw form values.

    ``values`` is keyed by ``param_name`` (composite parts carry their own
    ``from``/``to`` keys) — the same flat map the frontend holds and validates. The
    backend re-derives the Job payload from the field defs (never trusts the client
    to have normalized / omitted correctly).
    """

    values: dict[str, str] = {}


class SubmitOut(BaseModel):
    """Response to a submission — returned immediately, non-blocking (task 7.5).

    ``request_no`` is the app-generated id the user tracks; ``run_id`` is the
    triggered Job run (for later status polling, task 8.x). ``status`` is always
    ``QUEUED`` here — the App does not wait for the run.
    """

    request_no: str
    alv_id: str
    run_id: int | None
    status: str
    param_hash: str


# --- Result cache reuse (task 7.3) ----------------------------------------------
class CacheHitOut(BaseModel):
    """A reusable prior run for the same report + parameters (the cache candidate).

    Returned by ``POST /api/reports/{alv_id}/cache-check`` when an identical run
    already COMPLETED within its retention window. It is the **latest** such run when
    several exist (see :mod:`alv_app.cache_source`), so the user is always offered the
    freshest output.

    ``submitted_by`` and ``generated_at`` are shown in the reuse popup (consistent with
    the Downloads page, which displays ``submitted_by`` openly for every permitted run);
    cross-user reuse is intended, so this may name a different user. The raw
    ``output_path`` is deliberately NOT included — the download is App-proxied by
    ``request_no`` and the storage path is never exposed; ``has_output`` only confirms a
    pointer exists.
    """

    request_no: str
    submitted_by: str | None
    generated_at: str | None
    expires_at: str | None
    row_count: int | None
    has_output: bool


class CacheCheckOut(BaseModel):
    """Response to a pre-submit cache check (``POST .../cache-check``).

    ``param_hash`` is the server-computed cache key for the submitted values (the same
    hash ``submit`` would compute), echoed so the frontend can correlate. ``hit`` is the
    reusable run, or ``None`` when there is nothing to reuse — in which case the frontend
    proceeds to a normal submit. A warehouse failure ALSO yields ``hit=None`` (the check
    degrades to "no reuse" rather than blocking submission).
    """

    alv_id: str
    param_hash: str
    hit: CacheHitOut | None = None


# --- Downloads (request_log list) -----------------------------------------------
class RequestOut(BaseModel):
    """One ``request_log`` row for the Downloads list.

    ``report_label`` is a human label resolved from the metadata cache when the
    row's ``alv_id`` is known (falls back to ``None`` otherwise — the frontend then
    shows the ``alv_id``). ``output_path`` is the Job's output pointer once a run
    completes; the download action is a stub until the UC Volume proxy lands.
    """

    request_no: str
    alv_id: str | None
    report_label: str | None
    status: str | None
    submitted_by: str | None
    submitted_at: str | None
    run_id: int | None
    output_path: str | None


class RequestsOut(BaseModel):
    """One page of ``request_log`` rows backing the Downloads page.

    Filtering / search / sort / pagination all happen in SQL (``alv_app.downloads``),
    so this really is a page of the whole matching set — not a client-side slice of the
    newest N rows.

    ``has_more`` is exact (the query fetches one row beyond the page and drops it), so
    the UI can enable "Next" without a second COUNT query. ``scope``/``q``/``sort`` are
    echoed back as the SERVER resolved them: an unknown ``scope`` or ``sort`` falls back
    to the default and the echo is how the UI can tell.
    """

    requests: list[RequestOut]
    limit: int
    offset: int
    has_more: bool
    scope: str
    sort: str
    q: str | None = None


# --- Run parameters info view ---------------------------------------------------
class RequestParamsOut(BaseModel):
    """The parameters a run was dispatched with (GET /api/requests/{request_no}/params).

    ``parameters`` is the parsed ``request_log.param_payload_json`` — the **effective
    job payload**: server-normalized (trim/case ops applied) with ``omit_if_blank``
    params absent entirely. It is therefore what the Job received, NOT a transcript of
    what the user typed; the UI must label it that way.

    ``parse_ok`` is False when the stored payload was null, empty, or not parseable as
    a JSON object — the endpoint still returns 200 with an empty ``parameters`` map and
    a ``detail`` hint, because a malformed old row is a data condition, not a fault.
    """

    request_no: str
    alv_id: str | None
    report_label: str | None
    submitted_at: str | None
    param_hash: str | None
    parameters: dict[str, str | None]
    parse_ok: bool
    detail: str | None = None


# --- Status polling (task 8.x) --------------------------------------------------
class RequestStatusOut(BaseModel):
    """Live status for one request (GET /api/requests/{request_no}/status).

    ``status`` is the current value: the live run state when readable (and persisted
    if it changed), else the stored value unchanged. ``run_id`` is echoed for the FE;
    ``updated`` flags whether this poll advanced the stored status (diagnostic only).
    ``output_path`` is set once a SUCCESS run's output pointer has been captured (9.x)
    so the frontend can enable the download the moment polling resolves to COMPLETED
    (the raw storage path is never otherwise exposed — the download is App-proxied).
    """

    request_no: str
    status: str | None
    run_id: int | None
    updated: bool
    output_path: str | None = None


# --- Admin console (report_permissions grant/revoke) ----------------------------
class GrantOut(BaseModel):
    """One report_permissions grant, as the admin console lists it."""

    report_key: str
    principal_type: str  # 'group' | 'user'
    principal_name: str
    is_active: bool
    granted_by: str | None = None


class GrantsListOut(BaseModel):
    """All grants (active AND inactive) for one report, for the admin console."""

    report_key: str
    grants: list[GrantOut]


class GrantIn(BaseModel):
    """POST body to grant a report to one or more principals.

    ``principals`` is a comma-separated free-text list mixing user emails and group
    names (a token containing '@' is treated as a user, else a group). Each token is
    reported back individually in :class:`GrantResultOut`.
    """

    principals: str


class GrantTokenResult(BaseModel):
    """The outcome for one principal token in a grant/revoke request."""

    token: str
    principal_type: str | None = None
    principal_name: str | None = None
    outcome: str  # 'granted' | 'revoked' | 'invalid'
    detail: str | None = None


class GrantResultOut(BaseModel):
    """Per-token results of a grant/revoke, plus the refreshed grant list."""

    report_key: str
    results: list[GrantTokenResult]
    grants: list[GrantOut]


class RevokeIn(BaseModel):
    """POST body to revoke one grant (soft-delete)."""

    principal_type: str  # 'group' | 'user'
    principal_name: str


# --- Admin report onboarding (paste manifest → alv_catalog) ---------------------
class OnboardReportIn(BaseModel):
    """POST body to onboard a report: the RAW pasted manifest JSON text.

    Carried as a string (not a parsed object) so the backend owns EVERY validation
    failure mode uniformly — a JSON parse error, a non-object top level, and the per-row
    contract checks all come back as one flat error list (see :class:`OnboardErrorOut`).
    The text is the same ``{"catalog_rows": [ ... ]}`` manifest the seed job consumes.
    """

    manifest: str


class OnboardReportOut(BaseModel):
    """Result of a successful report onboarding (POST /api/admin/reports).

    ``report_keys`` / ``alv_ids`` echo what was added; ``warnings`` surfaces non-fatal
    notes (e.g. a placeholder ``job_id`` stored NULL/unbound). ``detail`` is the message
    the UI shows — crucially, that the report is added but still hidden until access is
    granted (visibility is deny-by-default; onboarding never auto-grants).
    """

    ok: bool
    row_count: int
    report_keys: list[str]
    alv_ids: list[str]
    warnings: list[str] = []
    detail: str


class OnboardErrorOut(BaseModel):
    """422 body when a pasted manifest is invalid.

    ``errors`` is the flat list of every collected problem (manifest shape, missing keys,
    duplicate ``alv_id``, bad ``input_fields_json``) so the UI can list them all at once.
    """

    detail: str
    errors: list[str]


# --- Parameter templates (variants) ---------------------------------------------
class TemplateSummaryOut(BaseModel):
    """One saved template as the (report-wide) list view shows it (no values).

    ``alv_id`` is the runnable report type the template fills; ``selection_label`` /
    ``report_type_label`` are its human labels (resolved from the metadata cache) so the
    report-wide list can show which selection + report type each template belongs to, and
    Load can navigate to that report type. ``is_dynamic`` badges relative-date templates.
    """

    template_id: str
    alv_id: str
    template_name: str
    selection_label: str | None = None
    report_type_label: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    is_dynamic: bool = False


class TemplatesListOut(BaseModel):
    """The caller's templates for a whole report (``GET .../templates``).

    ``alv_id`` echoes the report type whose screen was opened (the entry point); the list
    itself spans every report type under that report's ``report_key``.
    """

    alv_id: str
    templates: list[TemplateSummaryOut]


class TemplateDetailOut(BaseModel):
    """One template with its resolved form values, to load into the form.

    ``values`` is the flat ``{param_name: value}`` map the form holds — with any dynamic
    (relative-date) fields already **resolved** against the report-timezone "now", merged
    over the saved static values — so the frontend can set it directly. ``value_kinds`` is
    the raw ``{param: {kind, preset, n?}}`` map (empty when fully static) so the UI can
    badge dynamic fields and re-open the save editor with the right presets selected.
    """

    template_id: str
    alv_id: str
    template_name: str
    values: dict[str, str]
    value_kinds: dict[str, object] = {}


class SaveTemplateIn(BaseModel):
    """POST body to save (create/overwrite) a template.

    ``values`` mirrors :class:`SubmitIn.values` (the raw form map). ``value_kinds`` marks
    which date fields are DYNAMIC — ``{param_name: {"kind": "dynamic", "preset": ...,
    "n"?: int}}`` — and is empty/omitted for a fully static template. Re-using an existing
    ``template_name`` for the same report overwrites that template (upsert).
    """

    template_name: str
    values: dict[str, str] = {}
    value_kinds: dict[str, object] = {}


class TemplateValidationErrorOut(BaseModel):
    """422 body when a template fails the report's field validations at save.

    ``errors`` is a ``{param_name: message}`` map (the same shape + messages the form
    shows), so the save modal can surface the exact failing field(s).
    """

    detail: str
    errors: dict[str, str]


class RenameTemplateIn(BaseModel):
    """POST body to rename a template in place."""

    template_name: str
