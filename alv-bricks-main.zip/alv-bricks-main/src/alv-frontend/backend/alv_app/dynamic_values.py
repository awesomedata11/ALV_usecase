"""Dynamic templates — relative date presets + save-time validation (pure helpers).

A **dynamic template** stores, for chosen `date` fields, a *named relative rule* (a
"preset") instead of a literal date. On load the App resolves each preset against "now"
(Asia/Kolkata — see :attr:`alv_app.config.Settings.report_timezone`) so a template like
"first day of previous month" always fills the right date.

This module is **pure** (no I/O, no clock of its own — "now" is always injected) so the
grammar and the validation port are unit-testable without a warehouse or a wall clock. It
owns three concerns:

1. **The preset set** (:class:`Preset`) — a *closed* vocabulary. Anything outside it is
   rejected at save (fail-closed). Only ``CUR_DATE_PLUS_N_DAYS`` takes an integer ``n``.
   There is **no work-day / holiday logic** (dropped from the design) — every preset is
   plain calendar arithmetic.
2. **Parsing + resolving** (:func:`parse_value_kinds`, :func:`resolve_value_kinds`) — turn
   the stored ``value_kinds`` map into concrete ``date`` values, merged over the static
   values, so the form fills exactly as a static template would.
3. **A server-side port of the form-validation rules** (:func:`validate_values`) — the same
   vocabulary the frontend `validation.ts` enforces, so a template that would fail the
   report's validations is refused **at save** (decision 10), for BOTH static and dynamic
   templates. The frontend also validates first; this is the never-trust-the-client guard.

Only ``date`` fields may be dynamic (decision 4); ``time_range`` stays static in v1.
"""

from __future__ import annotations

import calendar
import re
from dataclasses import dataclass
from datetime import date, timedelta
from enum import Enum
from typing import Any

from .fields import FormField


class DynamicValueError(ValueError):
    """Raised when a ``value_kinds`` map is malformed (endpoint -> 422)."""


class Preset(str, Enum):
    """The closed set of relative-date presets a dynamic field may use.

    Labels (for reference; the UI owns display text):

    * ``TODAY``                — Current date
    * ``CUR_DATE_PLUS_N_DAYS`` — Current date ± n days (``n`` may be negative)
    * ``FIRST_DAY_CUR_MONTH``  — First day of current month
    * ``LAST_DAY_CUR_MONTH``   — Last day of current month
    * ``FIRST_DAY_NEXT_MONTH`` — First day of next month
    * ``LAST_DAY_NEXT_MONTH``  — Last day of next month
    * ``FIRST_DAY_PREV_MONTH`` — First day of previous month
    * ``LAST_DAY_PREV_MONTH``  — Last day of previous month
    """

    TODAY = "TODAY"
    CUR_DATE_PLUS_N_DAYS = "CUR_DATE_PLUS_N_DAYS"
    FIRST_DAY_CUR_MONTH = "FIRST_DAY_CUR_MONTH"
    LAST_DAY_CUR_MONTH = "LAST_DAY_CUR_MONTH"
    FIRST_DAY_NEXT_MONTH = "FIRST_DAY_NEXT_MONTH"
    LAST_DAY_NEXT_MONTH = "LAST_DAY_NEXT_MONTH"
    FIRST_DAY_PREV_MONTH = "FIRST_DAY_PREV_MONTH"
    LAST_DAY_PREV_MONTH = "LAST_DAY_PREV_MONTH"


# The only preset that carries an ``n`` parameter.
_PARAM_PRESETS = frozenset({Preset.CUR_DATE_PLUS_N_DAYS})


@dataclass(frozen=True)
class DynamicSpec:
    """One field's dynamic rule: a preset and (only for ± n days) an integer offset."""

    preset: Preset
    n: int | None = None


# --- calendar helpers (pure) ----------------------------------------------------
def _first_of_month(y: int, m: int) -> date:
    return date(y, m, 1)


def _last_of_month(y: int, m: int) -> date:
    return date(y, m, calendar.monthrange(y, m)[1])


def _shift_month(y: int, m: int, delta: int) -> tuple[int, int]:
    """Return ``(year, month)`` shifted by ``delta`` months (handles Jan/Dec rollover)."""
    idx = (y * 12 + (m - 1)) + delta
    return idx // 12, idx % 12 + 1


def resolve(spec: DynamicSpec, now: date) -> date:
    """Resolve one :class:`DynamicSpec` to a concrete date, relative to ``now``.

    ``now`` is the current date in the report timezone (injected by the caller, never
    read from a clock here). Real calendar arithmetic throughout — month lengths and
    year rollover are exact.
    """
    p = spec.preset
    if p is Preset.TODAY:
        return now
    if p is Preset.CUR_DATE_PLUS_N_DAYS:
        # n is validated present-and-int by parse_value_kinds; default defensively to 0.
        return now + timedelta(days=spec.n or 0)
    if p is Preset.FIRST_DAY_CUR_MONTH:
        return _first_of_month(now.year, now.month)
    if p is Preset.LAST_DAY_CUR_MONTH:
        return _last_of_month(now.year, now.month)
    if p is Preset.FIRST_DAY_NEXT_MONTH:
        y, m = _shift_month(now.year, now.month, 1)
        return _first_of_month(y, m)
    if p is Preset.LAST_DAY_NEXT_MONTH:
        y, m = _shift_month(now.year, now.month, 1)
        return _last_of_month(y, m)
    if p is Preset.FIRST_DAY_PREV_MONTH:
        y, m = _shift_month(now.year, now.month, -1)
        return _first_of_month(y, m)
    if p is Preset.LAST_DAY_PREV_MONTH:
        y, m = _shift_month(now.year, now.month, -1)
        return _last_of_month(y, m)
    # Unreachable — Preset is a closed enum — but keep it explicit.
    raise DynamicValueError(f"unhandled preset {p!r}")


# --- parsing the value_kinds map ------------------------------------------------
def parse_value_kinds(
    raw: Any, fields: list[FormField]
) -> dict[str, DynamicSpec]:
    """Validate + normalize a ``value_kinds`` map into ``{param_name: DynamicSpec}``.

    Enforces the contract (fail-closed, collect-none — first bad entry raises):

    * the map is a JSON object (or None/empty ⇒ ``{}`` = fully static);
    * every key is a ``date`` param of *this* report (scalar ``date`` field or a
      ``date_range`` endpoint) — a preset on a non-date / unknown field is rejected;
    * ``kind`` is ``"dynamic"`` (the only kind stored; static fields are simply absent);
    * ``preset`` is a known :class:`Preset`;
    * ``n`` is present **and** an int for ``CUR_DATE_PLUS_N_DAYS`` and **absent** for
      every other preset.

    Args:
        raw: the parsed ``value_kinds`` object (dict), or None.
        fields: the report's fields, to check each key is a date param.

    Returns:
        ``{param_name: DynamicSpec}`` for the dynamic fields (empty when all static).

    Raises:
        DynamicValueError: on any contract violation.
    """
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise DynamicValueError("value_kinds must be an object.")

    date_params = _date_param_names(fields)
    out: dict[str, DynamicSpec] = {}
    for key, entry in raw.items():
        pname = str(key)
        if pname not in date_params:
            raise DynamicValueError(
                f"{pname!r} is not a date field of this report; it cannot be dynamic."
            )
        if not isinstance(entry, dict):
            raise DynamicValueError(f"value_kinds[{pname!r}] must be an object.")
        kind = entry.get("kind")
        if kind != "dynamic":
            raise DynamicValueError(
                f"value_kinds[{pname!r}].kind must be 'dynamic' (got {kind!r})."
            )
        preset_raw = entry.get("preset")
        try:
            preset = Preset(str(preset_raw))
        except ValueError:
            raise DynamicValueError(
                f"value_kinds[{pname!r}].preset {preset_raw!r} is not a known preset."
            )
        n = _parse_n(pname, preset, entry.get("n"))
        out[pname] = DynamicSpec(preset=preset, n=n)
    return out


def _parse_n(pname: str, preset: Preset, raw_n: Any) -> int | None:
    """Validate the ``n`` parameter's presence + type for *preset*."""
    if preset in _PARAM_PRESETS:
        if raw_n is None:
            raise DynamicValueError(
                f"value_kinds[{pname!r}] needs an integer 'n' for preset {preset.value}."
            )
        # Reject bools (a bool is an int subclass) and non-integers.
        if isinstance(raw_n, bool) or not isinstance(raw_n, int):
            # Allow an int-valued string too (the FE may send "-1"); reject anything else.
            if isinstance(raw_n, str) and re.fullmatch(r"-?\d+", raw_n.strip()):
                return int(raw_n.strip())
            raise DynamicValueError(
                f"value_kinds[{pname!r}].n must be an integer (got {raw_n!r})."
            )
        return int(raw_n)
    if raw_n is not None:
        raise DynamicValueError(
            f"value_kinds[{pname!r}] must not carry 'n' for preset {preset.value}."
        )
    return None


def resolve_value_kinds(
    specs: dict[str, DynamicSpec], now: date
) -> dict[str, str]:
    """Resolve every :class:`DynamicSpec` to an ISO ``yyyy-mm-dd`` string map."""
    return {pname: resolve(spec, now).isoformat() for pname, spec in specs.items()}


def merged_values(
    static_values: dict[str, str],
    specs: dict[str, DynamicSpec],
    now: date,
) -> dict[str, str]:
    """The concrete form values: static literals with dynamic params resolved over them.

    Dynamic params win over whatever literal happened to sit in ``static_values`` for the
    same key (that slot is ignored for a dynamic field).
    """
    out = dict(static_values or {})
    out.update(resolve_value_kinds(specs, now))
    return out


def _date_param_names(fields: list[FormField]) -> set[str]:
    """The param_names that are date-typed (scalar ``date`` or a ``date_range`` endpoint)."""
    names: set[str] = set()
    for f in fields:
        if f.kind == "composite" and f.control == "date_range" and f.parts:
            for part in f.parts.values():
                names.add(part.param_name)
        elif f.kind == "scalar" and f.data_type == "date" and f.param_name:
            names.add(f.param_name)
    return names
