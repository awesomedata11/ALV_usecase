"""Data-access seam: read ``alv_catalog`` rows from the SQL warehouse (task 3.1).

This is the ONLY place that talks to the metadata store. Keeping it behind a
small function makes the cache trivially testable (tests inject rows directly)
and keeps the deployed-auth story swappable: today it uses the Databricks SDK
statement-execution API with the app/SDK default credential chain
(``Config()``); the deployed app will use the same call with the injected
service-principal creds, and a later task can layer OBO on top **without
touching the cache or the endpoints**.

Local dev authenticates via the ``fevm-lakebase`` profile (or any SDK default
auth). The target warehouse may be STOPPED — ``execute_statement`` auto-starts a
serverless warehouse and we pass a generous ``wait_timeout``, so the first call
after idle simply takes longer rather than failing.
"""

from __future__ import annotations

import logging

from .config import Settings

log = logging.getLogger("alv_reports.catalog_source")

# Columns read from alv_catalog (docs/METADATA_TABLE.md). input_fields_json last.
# job_id / job_run_mode feed the submit path (task 7.x): the App triggers the row's
# bound Job via jobs run-now. They are read here so the render-path cache already
# carries them (no extra SQL on submit).
_COLUMNS = [
    "alv_id",
    "report_key",
    "report_label",
    "selection_id",
    "selection_label",
    "selection_order",
    "report_type_code",
    "report_type_label",
    "report_type_order",
    "alv_name",
    "description",
    "job_id",
    "job_run_mode",
    "is_active",
    "input_fields_json",
]


class CatalogSourceError(RuntimeError):
    """Raised when the warehouse read cannot be performed."""


def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.alv_catalog`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`alv_catalog`"


def fetch_catalog_rows(settings: Settings) -> list[dict[str, object]]:
    """Read all ``alv_catalog`` rows via the SQL warehouse.

    Args:
        settings: app settings carrying ``catalog`` / ``schema_name`` /
            ``databricks_warehouse_id``.

    Returns:
        One dict per row keyed by column name (``is_active`` coerced to ``bool``).

    Raises:
        CatalogSourceError: if the warehouse id is unset, the SDK is missing, or
            the statement fails. The cache turns this into a graceful empty
            catalogue + log rather than a crash.
    """
    if not settings.databricks_warehouse_id:
        raise CatalogSourceError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot read alv_catalog. "
            "Set it locally (see app/README.md) or attach a sql-warehouse resource "
            "on deploy (app.yaml valueFrom)."
        )

    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import StatementState
    except ImportError as exc:  # pragma: no cover - defensive
        raise CatalogSourceError("databricks-sdk is not installed.") from exc

    sql = f"SELECT {', '.join(_COLUMNS)} FROM {_fqtn(settings)}"
    log.info("reading alv_catalog: %s (warehouse %s)", _fqtn(settings), settings.databricks_warehouse_id)

    try:
        client = WorkspaceClient()  # Config() default auth (profile locally, SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=sql,
            # Generous timeout so a cold/stopped serverless warehouse can auto-start.
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise CatalogSourceError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise CatalogSourceError(f"statement did not succeed: {detail}")

    data = resp.result.data_array if (resp.result and resp.result.data_array) else []
    rows: list[dict[str, object]] = []
    for arr in data:
        row = dict(zip(_COLUMNS, arr))
        # data_array returns everything as strings; coerce the one bool we branch on.
        row["is_active"] = str(row.get("is_active")).lower() == "true"
        rows.append(row)
    log.info("read %d alv_catalog row(s)", len(rows))
    return rows
