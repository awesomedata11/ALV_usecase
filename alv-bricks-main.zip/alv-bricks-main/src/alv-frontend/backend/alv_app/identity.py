"""Databricks Apps SSO user identity — read from injected request headers.

## The SSO-header contract

Databricks Apps sits behind a Databricks-managed reverse proxy. A user reaches the
app through Databricks SSO; once the session is established, the proxy injects the
authenticated user's identity into **every** request forwarded to the app as HTTP
headers. The app never runs its own login — it trusts these headers because they
are set by the platform proxy and cannot be reached around by the client.

Headers Databricks Apps inject (all lower-cased by ASGI/Starlette):

| Header                          | Meaning                                                    |
|---------------------------------|------------------------------------------------------------|
| `X-Forwarded-Email`             | The user's email address.                                  |
| `X-Forwarded-Preferred-Username`| The user's preferred username (often the email/UPN).       |
| `X-Forwarded-User`              | The user's stable id (SCIM/AAD user identifier).           |
| `X-Forwarded-Access-Token`      | The user's OAuth access token (on-behalf-of / OBO).        |
| `X-Real-Ip`                     | The originating client IP.                                 |

`X-Forwarded-Access-Token` is only present when **user authorization** (on-behalf-of)
is enabled on the app (Public Preview) with the required OAuth scopes. It is a
**secret** — never log, print, or persist it.

These headers only exist when the app is **deployed** on Databricks. Running locally
there is no proxy, so `dev_mode` (see config) falls back to a fixed dev identity so
`/api/me` still works for local FE↔BE wiring.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from starlette.requests import Request

from .config import Settings

# Canonical Databricks Apps identity header names (matched case-insensitively).
HEADER_EMAIL = "X-Forwarded-Email"
HEADER_PREFERRED_USERNAME = "X-Forwarded-Preferred-Username"
HEADER_USER_ID = "X-Forwarded-User"
HEADER_ACCESS_TOKEN = "X-Forwarded-Access-Token"
HEADER_REAL_IP = "X-Real-Ip"


@dataclass(frozen=True)
class UserIdentity:
    """The current user's identity, resolved from SSO headers (or the dev fallback).

    ``user_token`` carries the raw on-behalf-of OAuth token when one was injected. It
    is a **SECRET**: it is used only to build a short-lived user-scoped SDK client for
    ``/Me`` (:mod:`alv_app.entitlements`), and must NEVER be logged, persisted, or
    placed in a response model. :class:`~alv_app.models.MeOut` deliberately exposes
    only the ``has_user_token`` flag; ``repr`` is suppressed on the field below so an
    accidental ``log.info("%s", ident)`` cannot leak it either.
    """

    email: str | None
    preferred_username: str | None
    user_id: str | None
    real_ip: str | None
    # True when identity came from real Databricks SSO headers; False for the dev fallback.
    authenticated: bool
    # True when an on-behalf-of user token was present (never expose the token itself).
    has_user_token: bool
    # The raw OBO token. SECRET — repr=False so it can never be printed/logged via
    # the dataclass repr. Defaulted so existing constructions stay valid.
    user_token: str | None = field(default=None, repr=False)


def resolve_identity(request: Request, settings: Settings) -> UserIdentity:
    """Resolve the current user from the Databricks Apps SSO headers.

    Args:
        request: The incoming request (Starlette headers are case-insensitive).
        settings: App settings; controls the local dev fallback.

    Returns:
        A :class:`UserIdentity`. When no SSO headers are present and ``dev_mode`` is
        on, returns a fixed local dev identity (``authenticated=False``). The OBO
        token, when injected, is carried on ``user_token`` — a secret; see the
        :class:`UserIdentity` docstring.
    """
    headers = request.headers
    email = headers.get(HEADER_EMAIL)
    preferred_username = headers.get(HEADER_PREFERRED_USERNAME)
    user_id = headers.get(HEADER_USER_ID)
    real_ip = headers.get(HEADER_REAL_IP)
    # Retain the VALUE (not just its presence) — it is the only way to read the
    # END USER's group memberships via /Me (a non-admin SP cannot look them up).
    # An empty/whitespace header counts as absent so it never reaches the SDK.
    raw_token = headers.get(HEADER_ACCESS_TOKEN)
    user_token = raw_token.strip() if raw_token and raw_token.strip() else None
    has_user_token = user_token is not None

    if email or user_id:
        # Real request forwarded by the Databricks proxy.
        return UserIdentity(
            email=email,
            preferred_username=preferred_username,
            user_id=user_id,
            real_ip=real_ip,
            authenticated=True,
            has_user_token=has_user_token,
            user_token=user_token,
        )

    if settings.dev_mode:
        # Local dev: no proxy, so synthesize a fixed identity for FE↔BE wiring.
        return UserIdentity(
            email=settings.dev_user_email,
            preferred_username=settings.dev_user_email,
            user_id="local-dev-user",
            real_ip=request.client.host if request.client else None,
            authenticated=False,
            has_user_token=False,
        )

    # Deployed but no identity headers — misconfiguration; represent as anonymous.
    return UserIdentity(
        email=None,
        preferred_username=None,
        user_id=None,
        real_ip=real_ip,
        authenticated=False,
        has_user_token=False,
    )
