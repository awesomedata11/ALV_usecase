"""Data-access seam: read ``request_log`` rows from the SQL warehouse.

Backs the Downloads page (``GET /api/requests``). Reads the App-owned
``request_log`` table (run tracking + result cache — docs/METADATA_TABLE.md) via
the SAME statement-execution seam as the read path
(:mod:`alv_app.catalog_source`) and the write path (:mod:`alv_app.request_log`),
i.e. as the app service principal (``Config()`` default auth on deploy).

Kept behind small functions so the endpoint stays thin and the tests inject rows
directly (no live workspace needed). A warehouse failure is surfaced as the typed
:class:`DownloadsSourceError`; the endpoint turns that into a graceful empty page
(never a 500), mirroring the catalogue's degrade-on-failure story.

## Filtering happens in SQL, before the limit

Everything that narrows the list — the report-visibility filter, the ``mine`` /
``accessible`` scope, and the report-name search — is applied **in the WHERE clause**,
so the page limit is the last thing to run. The previous shape (``LIMIT 100`` then a
Python filter) could hand back fewer than a page of rows with no way to reach page 2,
and any search would only ever have seen the newest 100 rows across all users.

**Every user-supplied value is a bound parameter** (:class:`BoundParam` →
``StatementParameterListItem``), following :mod:`alv_app.preview`. Nothing
user-controlled is ever formatted into the SQL string: the sort key comes from the
fixed :data:`_SORT_KEYS` allowlist, and ``limit``/``offset`` are bound ints.

## The visibility filter is an alv_id allowlist

``request_log`` stores ``alv_id``, not ``report_key``, and the report **label** the
user searches on lives only in the in-memory metadata cache — neither is a column
here. Rather than do string surgery on ``alv_id`` (its ``report_key__…`` shape is a
seeding convention, not a contract), the caller resolves the concrete set of
``alv_id`` s that are BOTH permitted and label-matching from the cache — the same
``alv_id`` → ``report_key`` mapping the per-request gate uses — and passes it here as
:class:`RequestQuery.alv_ids`. Consequences, both wanted:

* a row whose ``alv_id`` no longer resolves in the catalogue is excluded, exactly as
  the per-request gate denies what it cannot attribute to a report (fail closed);
* an empty allowlist means "nothing is visible", and the caller must not call here at
  all — :func:`fetch_requests_page` refuses to run a broad query for it.

The allowlist travels as ONE bound JSON-array parameter matched with
``array_contains(from_json(...))``, not one marker per id, so a user with many
reports can't approach the statement API's 256-parameter cap.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any

from .config import Settings

log = logging.getLogger("alv_reports.downloads")

# Columns read from request_log for the downloads list (docs/METADATA_TABLE.md).
# submitted_at is ordered DESC; output_path is the download pointer.
_COLUMNS = [
    "request_no",
    "alv_id",
    "status",
    "submitted_by",
    "submitted_at",
    "run_id",
    "output_path",
]

# Columns for the parameters info view (GET /api/requests/{request_no}/params).
# alv_id is read so the endpoint can enforce the report-visibility gate on the row.
_PARAM_COLUMNS = ["request_no", "alv_id", "param_payload_json", "param_hash", "submitted_at"]

# Page-size defaults. The real values come from Settings (downloads_page_size /
# downloads_max_page_size); these back the standalone-call defaults.
_DEFAULT_LIMIT = 50
_MAX_LIMIT = 200

# Sort allowlist: request-supplied sort keys are LOOKED UP here, never interpolated.
# Every entry ends with request_no so pagination is stable when timestamps tie.
_SORT_KEYS: dict[str, str] = {
    "submitted_at_desc": "submitted_at DESC, request_no DESC",
    "submitted_at_asc": "submitted_at ASC, request_no ASC",
}
DEFAULT_SORT = "submitted_at_desc"

# Scope vocabulary (see RequestQuery.scope).
SCOPE_ACCESSIBLE = "accessible"
SCOPE_MINE = "mine"
_SCOPES = (SCOPE_ACCESSIBLE, SCOPE_MINE)


class DownloadsSourceError(RuntimeError):
    """Raised when the ``request_log`` read cannot be performed."""


@dataclass(frozen=True)
class BoundParam:
    """One bound statement parameter (mirrors :class:`alv_app.preview.BoundParam`)."""

    name: str
    value: str
    type: str


@dataclass(frozen=True)
class RequestQuery:
    """The resolved, server-side-validated shape of a Downloads list request.

    Built by the endpoint from the query string (:func:`build_request_query`) so the
    data layer never sees a raw client value it has to trust.

    Attributes:
        alv_ids: The ``alv_id`` allowlist — reports that are BOTH permitted for this
            caller AND matching the search term. ``None`` means "do not filter by
            report at all", which is ONLY legitimate for the dev permission bypass.
            An EMPTY tuple means "nothing matches" and must short-circuit to an empty
            page rather than a query.
        identities: The caller's identity strings for ``scope='mine'`` (email /
            preferred_username / user_id, already lower-cased). Empty with
            ``scope='mine'`` means the caller cannot be identified — no rows.
        scope: ``accessible`` (every permitted report's rows, including other users')
            or ``mine`` (only rows this caller submitted).
        sort: A key of :data:`_SORT_KEYS`.
        limit: Page size, already clamped to the configured maximum.
        offset: Rows to skip.
    """

    alv_ids: tuple[str, ...] | None
    identities: tuple[str, ...] = ()
    scope: str = SCOPE_ACCESSIBLE
    sort: str = DEFAULT_SORT
    limit: int = _DEFAULT_LIMIT
    offset: int = 0


@dataclass
class RequestPage:
    """One page of ``request_log`` rows plus the paging signal the UI needs.

    ``has_more`` is derived by asking the warehouse for one row more than the page
    size and discarding it — an exact answer with no second COUNT(*) query.
    """

    rows: list[dict[str, object]] = field(default_factory=list)
    has_more: bool = False


def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.request_log`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`request_log`"


def clamp_limit(settings: Settings, raw: int | None) -> int:
    """Clamp a client-supplied page size into ``[1, downloads_max_page_size]``."""
    hard_max = max(1, int(settings.downloads_max_page_size or _MAX_LIMIT))
    if raw is None:
        return min(max(1, int(settings.downloads_page_size or _DEFAULT_LIMIT)), hard_max)
    return min(max(1, int(raw)), hard_max)


def normalize_scope(raw: str | None) -> str:
    """Map a client-supplied scope onto the vocabulary (unknown ⇒ the default)."""
    value = (raw or "").strip().lower()
    return value if value in _SCOPES else SCOPE_ACCESSIBLE


def normalize_sort(raw: str | None) -> str:
    """Map a client-supplied sort key onto the allowlist (unknown ⇒ the default).

    The RETURN VALUE is a key of :data:`_SORT_KEYS`, never SQL — the ORDER BY text is
    looked up from the allowlist at build time, so a crafted ``sort`` cannot reach the
    statement.
    """
    value = (raw or "").strip().lower()
    return value if value in _SORT_KEYS else DEFAULT_SORT


def identity_match_values(ident: Any) -> tuple[str, ...]:
    """The lower-cased identity strings a caller's own rows could be stamped with.

    ``submitted_by`` is written as ``email or preferred_username or user_id`` by
    precedence (``main._submitted_by``), and that precedence has changed over the life
    of the table, so a caller's historical rows may carry ANY of the three. ``scope=mine``
    therefore matches on all of them, compared lower-cased on both sides (emails and
    usernames are case-insensitive in practice; the opaque id is unaffected by folding).

    De-duplicated and order-preserving — email and preferred_username are usually equal.
    """
    out: list[str] = []
    for value in (
        getattr(ident, "email", None),
        getattr(ident, "preferred_username", None),
        getattr(ident, "user_id", None),
    ):
        if not value:
            continue
        folded = str(value).strip().lower()
        if folded and folded not in out:
            out.append(folded)
    return tuple(out)


def build_requests_sql(query: RequestQuery, settings: Settings) -> tuple[str, list[BoundParam]]:
    """Build the parameterized list statement for *query*.

    Pure (no I/O) so the SQL shape — and the guarantee that every user-supplied value
    is bound — is directly unit-testable. Returns ``(sql, params)``.

    The only values formatted into the string are the fully-qualified table name (from
    Settings, backtick-quoted) and the ORDER BY clause looked up from
    :data:`_SORT_KEYS`. Everything else is a ``:marker``.
    """
    conditions: list[str] = []
    params: list[BoundParam] = []

    # Report-visibility + search filter: a single bound JSON array of allowed alv_ids.
    # None ⇒ unfiltered (dev bypass only, and then the search is applied by the caller
    # having already resolved alv_ids — see build_request_query).
    if query.alv_ids is not None:
        conditions.append(
            "array_contains(from_json(:alv_ids, 'array<string>'), alv_id)"
        )
        params.append(
            BoundParam(
                name="alv_ids",
                value=json.dumps(list(query.alv_ids), separators=(",", ":")),
                type="STRING",
            )
        )

    # scope=mine: the row's submitted_by matches one of the caller's identity forms.
    if query.scope == SCOPE_MINE:
        markers: list[str] = []
        for i, value in enumerate(query.identities):
            marker = f"me{i}"
            markers.append(f":{marker}")
            params.append(BoundParam(name=marker, value=value, type="STRING"))
        if markers:
            conditions.append(f"lower(submitted_by) IN ({','.join(markers)})")
        else:
            # Caller has no identity at all ⇒ they own nothing. Keep this explicit
            # (a false predicate) rather than silently widening to every row.
            conditions.append("1 = 0")

    sql = f"SELECT {', '.join(_COLUMNS)} FROM {_fqtn(settings)}"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += f" ORDER BY {_SORT_KEYS[query.sort]}"
    # Fetch one extra row to answer has_more exactly without a second COUNT query.
    sql += " LIMIT :row_limit OFFSET :row_offset"
    params.append(BoundParam(name="row_limit", value=str(int(query.limit) + 1), type="INT"))
    params.append(BoundParam(name="row_offset", value=str(int(query.offset)), type="INT"))
    return sql, params


def _execute(
    settings: Settings, sql: str, params: list[BoundParam], *, what: str
) -> list[list[object]]:
    """Run a parameterized read on the warehouse as the app SP; return the data array.

    Args:
        settings: app settings carrying ``databricks_warehouse_id``.
        sql: SQL with ``:named`` markers.
        params: the bound parameters.
        what: short description used in error/log messages.

    Raises:
        DownloadsSourceError: if the warehouse id is unset, the SDK is missing, or the
            statement does not succeed.
    """
    if not settings.databricks_warehouse_id:
        raise DownloadsSourceError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot read request_log."
        )

    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import StatementParameterListItem, StatementState
    except ImportError as exc:  # pragma: no cover - defensive
        raise DownloadsSourceError("databricks-sdk is not installed.") from exc

    sdk_params = [
        StatementParameterListItem(name=p.name, value=p.value, type=p.type) for p in params
    ]
    # Log the SQL SHAPE + bound-param count, never the bound values (they carry the
    # caller's identity and search term).
    log.info(
        "request_log %s (warehouse %s): sql=%s bound_params=%d",
        what,
        settings.databricks_warehouse_id,
        sql,
        len(sdk_params),
    )

    try:
        client = WorkspaceClient()  # Config() default auth (profile locally, SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=sql,
            parameters=sdk_params,
            # Generous timeout so a cold/stopped serverless warehouse can auto-start.
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise DownloadsSourceError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise DownloadsSourceError(f"statement did not succeed: {detail}")

    return resp.result.data_array if (resp.result and resp.result.data_array) else []


def fetch_requests_page(settings: Settings, query: RequestQuery) -> RequestPage:
    """Read one filtered, sorted, paginated page of ``request_log`` rows.

    The filter (report visibility + scope + search) is applied in SQL BEFORE the limit,
    so the page is a real page: ``has_more`` is exact and ``offset`` genuinely walks the
    whole matching set.

    Args:
        settings: app settings carrying ``catalog`` / ``schema_name`` /
            ``databricks_warehouse_id``.
        query: the resolved query (see :class:`RequestQuery`).

    Returns:
        A :class:`RequestPage` — at most ``query.limit`` rows plus ``has_more``.
        An empty ``alv_ids`` allowlist returns an empty page WITHOUT querying:
        "no permitted reports" is answered locally, never by scanning the table.

    Raises:
        DownloadsSourceError: if the warehouse id is unset, the SDK is missing, or
            the statement fails. The endpoint turns this into a graceful empty page.
    """
    if query.alv_ids is not None and not query.alv_ids:
        log.info("request_log list short-circuited: no permitted/matching reports")
        return RequestPage(rows=[], has_more=False)

    sql, params = build_requests_sql(query, settings)
    data = _execute(settings, sql, params, what="list")

    rows: list[dict[str, object]] = []
    for arr in data:
        row = dict(zip(_COLUMNS, arr))
        # data_array returns everything as strings; coerce the one int we expose.
        row["run_id"] = _as_int(row.get("run_id"))
        rows.append(row)

    # The (limit + 1)-th row only exists to prove there is a next page — drop it.
    has_more = len(rows) > query.limit
    if has_more:
        rows = rows[: query.limit]
    log.info("read %d request_log row(s) (has_more=%s)", len(rows), has_more)
    return RequestPage(rows=rows, has_more=has_more)


def fetch_request(settings: Settings, request_no: str) -> dict[str, object] | None:
    """Read a single ``request_log`` row's status fields by ``request_no`` (task 8.x).

    Targeted read backing the status-poll and download endpoints: returns just the
    columns they need (``request_no``, ``alv_id``, ``status``, ``run_id``,
    ``output_path``) so it stays cheap versus scanning the recent list. Parameterized
    on ``request_no``. ``alv_id`` is read so those endpoints can enforce report
    visibility (``report_permissions``) on the row before revealing its status or
    streaming its output.

    Args:
        settings: app settings carrying ``catalog`` / ``schema_name`` /
            ``databricks_warehouse_id``.
        request_no: the app-generated request id (PK) to look up.

    Returns:
        A dict keyed by column name (``run_id`` coerced to ``int`` or None), or
        ``None`` when no row matches.

    Raises:
        DownloadsSourceError: if the warehouse id is unset, the SDK is missing, or
            the statement fails. The endpoint turns this into the stored status.
    """
    cols = ["request_no", "alv_id", "status", "run_id", "output_path"]
    sql = (
        f"SELECT {', '.join(cols)} FROM {_fqtn(settings)} "
        "WHERE request_no = :request_no LIMIT 1"
    )
    params = [BoundParam(name="request_no", value=request_no, type="STRING")]
    data = _execute(settings, sql, params, what=f"row {request_no}")
    if not data:
        return None
    row = dict(zip(cols, data[0]))
    row["run_id"] = _as_int(row.get("run_id"))
    return row


def fetch_request_params(settings: Settings, request_no: str) -> dict[str, object] | None:
    """Read one row's stored parameter payload (backs the parameters info view).

    Separate from :func:`fetch_request` so the status/download hot path never pulls the
    (potentially large) ``param_payload_json`` blob it has no use for. ``alv_id`` is
    read so the endpoint can apply the SAME report-visibility gate as download —
    parameters are as sensitive as the file they produced.

    Args:
        settings: app settings carrying ``catalog`` / ``schema_name`` /
            ``databricks_warehouse_id``.
        request_no: the app-generated request id (PK) to look up.

    Returns:
        A dict with ``request_no`` / ``alv_id`` / ``param_payload_json`` /
        ``param_hash`` / ``submitted_at``, or ``None`` when no row matches. The
        payload is returned RAW (a possibly-null, possibly-malformed string) — the
        endpoint parses it defensively.

    Raises:
        DownloadsSourceError: on the same conditions as the other reads.
    """
    sql = (
        f"SELECT {', '.join(_PARAM_COLUMNS)} FROM {_fqtn(settings)} "
        "WHERE request_no = :request_no LIMIT 1"
    )
    params = [BoundParam(name="request_no", value=request_no, type="STRING")]
    data = _execute(settings, sql, params, what=f"params for {request_no}")
    if not data:
        return None
    return dict(zip(_PARAM_COLUMNS, data[0]))


def _as_int(v: object) -> int | None:
    """Coerce a warehouse string/number to int, or None."""
    if v is None or v == "":
        return None
    try:
        return int(v)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
