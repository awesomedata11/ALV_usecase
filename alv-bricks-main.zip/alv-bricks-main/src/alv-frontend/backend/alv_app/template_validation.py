"""Server-side port of the form-validation vocabulary (for save-time template checks).

Templates are validated **at save** for BOTH static and dynamic kinds (decision 10): a
template whose values would fail the report's field validations cannot be saved. The
frontend (`src/alv-frontend/frontend/src/validation.ts`) validates first and shows the error; this
module is the never-trust-the-client backend guard — it runs the SAME rule vocabulary over
the resolved values so the two agree.

It is a faithful port of `validation.ts`:

* rules: ``mandatory`` (implicit from the field), ``from_lte_to``, ``to_required_if_from``,
  ``max_span``, ``max_offset_from_today``, ``regex``, ``max_length``;
* ``no_filter_when_equal`` is an omission hint, not a user error — skipped, as in the UI;
* the inclusive day span (1 May–31 May = 31) and the coarse month/year span caps match the
  frontend exactly, so a value that passes here passes there and vice versa.

Pure (no I/O). ``today`` is injected (the report-timezone "now") so ``max_offset_from_today``
resolves against the same clock the dynamic resolver uses.

Returns a ``{param_name: message}`` map (empty ⇒ valid), mirroring the frontend ``Errors``
shape, so the endpoint can hand the exact per-field messages back to the modal.
"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from .fields import FormField
from .messages import resolve_message


def _is_blank(v: str | None) -> bool:
    return v is None or v.strip() == ""


def _parse_date(v: str | None) -> date | None:
    if _is_blank(v):
        return None
    try:
        return datetime.strptime(v.strip(), "%Y-%m-%d").date()  # type: ignore[union-attr]
    except (ValueError, TypeError):
        return None


def _time_to_seconds(v: str | None) -> int | None:
    if _is_blank(v):
        return None
    m = re.fullmatch(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", v.strip())  # type: ignore[union-attr]
    if not m:
        return None
    return int(m[1]) * 3600 + int(m[2]) * 60 + (int(m[3]) if m[3] else 0)


def _offset_from_today(today: date, unit: str | None, value: float) -> date:
    """Lower bound for max_offset_from_today (today minus value units)."""
    v = int(value)
    if unit == "days":
        return today - timedelta(days=v)
    if unit == "months":
        # Match the frontend's setUTCMonth semantics via calendar-agnostic month math.
        idx = (today.year * 12 + (today.month - 1)) - v
        y, m = idx // 12, idx % 12 + 1
        day = min(today.day, _days_in_month(y, m))
        return date(y, m, day)
    if unit == "years":
        y = today.year - v
        day = min(today.day, _days_in_month(y, today.month))
        return date(y, today.month, day)
    return today


def _days_in_month(y: int, m: int) -> int:
    import calendar

    return calendar.monthrange(y, m)[1]


def _inclusive_day_span(frm: date, to: date) -> int:
    return (to - frm).days + 1


def _span_cap_days(unit: str | None, value: float) -> int:
    if unit == "months":
        return int(value) * 31  # coarse; matches validation.ts (pilot uses days)
    if unit == "years":
        return int(value) * 366
    return int(value)


def _check_composite(field: FormField, values: dict[str, str], errors: dict[str, str], today: date) -> None:
    parts = field.parts
    if not parts:
        return
    from_key = parts["from"].param_name
    to_key = parts["to"].param_name
    from_raw = values.get(from_key)
    to_raw = values.get(to_key)

    if field.mandatory and (_is_blank(from_raw) or _is_blank(to_raw)):
        errors[from_key] = f"{field.display_label} is required."
        return

    is_date = field.control == "date_range"
    from_v = _parse_date(from_raw) if is_date else _time_to_seconds(from_raw)
    to_v = _parse_date(to_raw) if is_date else _time_to_seconds(to_raw)

    for rule in field.validations:
        msg = resolve_message(rule.message_key)
        name = rule.rule
        if name == "from_lte_to":
            if from_v is not None and to_v is not None and from_v > to_v:  # type: ignore[operator]
                errors[from_key] = msg
        elif name == "to_required_if_from":
            if not _is_blank(from_raw) and _is_blank(to_raw):
                errors[to_key] = msg
        elif name == "max_span":
            if is_date and from_v is not None and to_v is not None and rule.unit and rule.value is not None:
                if _inclusive_day_span(from_v, to_v) > _span_cap_days(rule.unit, rule.value):  # type: ignore[arg-type]
                    errors[from_key] = msg
        elif name == "max_offset_from_today":
            if is_date and rule.unit and rule.value is not None:
                lower = _offset_from_today(today, rule.unit, rule.value)
                target = to_v if rule.applies_to == "to" else from_v
                key = to_key if rule.applies_to == "to" else from_key
                if target is not None and target < lower:  # type: ignore[operator]
                    errors[key] = msg
        # no_filter_when_equal: omission hint, not an error — skip (as in the UI).


def _check_scalar(field: FormField, values: dict[str, str], errors: dict[str, str], today: date) -> None:
    key = field.param_name
    if not key:
        return
    raw = values.get(key)

    if field.mandatory and _is_blank(raw):
        errors[key] = f"{field.display_label} is required."
        return
    if _is_blank(raw):
        return  # optional + blank ⇒ nothing else to check

    for rule in field.validations:
        msg = resolve_message(rule.message_key)
        name = rule.rule
        if name == "max_length":
            if rule.value is not None and len(raw) > int(rule.value):  # type: ignore[arg-type]
                errors[key] = msg
        elif name == "regex":
            if rule.pattern:
                try:
                    if not re.search(rule.pattern, raw):  # type: ignore[arg-type]
                        errors[key] = msg
                except re.error:
                    pass  # invalid metadata pattern — mirror the FE (ignore)
        elif name == "max_offset_from_today":
            if field.data_type == "date" and rule.unit and rule.value is not None:
                d = _parse_date(raw)
                lower = _offset_from_today(today, rule.unit, rule.value)
                if d is not None and d < lower:
                    errors[key] = msg


def validate_values(
    fields: list[FormField], values: dict[str, str], today: date
) -> dict[str, str]:
    """Validate resolved form values against the report's rules; return ``{param: message}``.

    Empty map ⇒ valid. Mirrors ``validateForm`` in `validation.ts` exactly (same rules,
    same span math), so the save-time backend guard agrees with the client. ``today`` is
    the report-timezone current date, used only by ``max_offset_from_today``.
    """
    errors: dict[str, str] = {}
    for field in fields:
        if field.kind == "composite":
            _check_composite(field, values, errors, today)
        else:
            _check_scalar(field, values, errors, today)
    return errors
