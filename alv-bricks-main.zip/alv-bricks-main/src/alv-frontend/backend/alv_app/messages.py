"""Message catalogue — resolve a ``message_key`` to readable text (backend copy).

The metadata carries only ``message_key`` s, never inline user text (D-IFJ-9). The
frontend has its own copy (`src/alv-frontend/frontend/src/messages.ts`); this backend copy lets the
save-time template validation (:mod:`alv_app.template_validation`) return the SAME human
messages the UI shows, so a 422 from the server reads identically to a client-side error.

NOTE: like the frontend map, this is a stopgap until the canonical catalogue (task 2.2) is
delivered. Keep the two maps in step; :func:`resolve_message` falls back gracefully for any
unknown key so nothing breaks in the meantime.
"""

from __future__ import annotations

_MESSAGES: dict[str, str] = {
    "ALV_DATE_FROM_GT_TO": "From date must be on or before the To date.",
    "ALV_DATE_TOO_OLD": "Date cannot be more than 12 months in the past.",
    "ALV_DATE_SPAN_EXCEEDED": "Date range cannot exceed 31 days.",
    "ALV_TIME_NO_FILTER": "Equal From/To times apply no time filter.",
    "ALV_TIME_TO_REQUIRED": "To time is required when a From time is given.",
    "ALV_TIME_FROM_GT_TO": "From time must be on or before the To time.",
}


def _humanize(key: str) -> str:
    """Fallback: ALV_SOMETHING_ODD -> 'Something odd' (mirrors the frontend)."""
    stripped = key.replace("ALV_", "", 1).replace("_", " ").lower()
    return stripped[:1].upper() + stripped[1:] if stripped else key


def resolve_message(key: str) -> str:
    """Resolve a ``message_key`` to display text, humanizing an unknown key."""
    return _MESSAGES.get(key) or _humanize(key)
