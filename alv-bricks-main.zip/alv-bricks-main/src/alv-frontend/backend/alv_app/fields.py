"""Render-ready parsing of a row's ``input_fields_json`` (task 3.1).

## Why a thin app-local parser (and not ``dbx_alv_reports.InputFieldsParser``)

The metadata library (``src/alv-backend/dbx_alv_reports``) owns the canonical
``InputFieldsParser`` + typed ``InputFieldsSpec``. Reusing it here would avoid
duplication, BUT the App's Databricks-Apps **deploy source root is
``src/alv-frontend/backend/`` only** — the library (``src/alv-backend/``) is never synced to
the Apps runtime (see ``src/alv-frontend/README.md`` "Deploy layout"). Importing ``dbx_alv_reports`` would therefore
work locally and then fail at deploy time. The library also pulls a Spark/driver
oriented dependency chain (``metadata_tables`` → ``uc_utils``) via its package
``__init__``, which does not belong in a request-serving web backend.

So this module implements a **thin parser that honors the SAME contract**
(``src/alv-backend/dbx_alv_reports/json_specifications/input_fields.schema.json`` +
``docs/input_fields_json_design.md``): same ``schema_version`` fail-fast (D-IFJ-2),
same scalar/composite split, the same validation vocabulary, and the same
"unknown rule ⇒ fail the load" rule (D-IFJ-10). It produces **render-ready**
Pydantic objects (ordered, controls/validations resolved) that double as the API
response contract for ``GET /api/reports/{alv_id}`` — parsed ONCE at cache load,
never on the render path.

If the schema contract changes, update both this module and the library's parser
(and the shared ``input_fields.schema.json``).
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

# --- contract constants (mirror input_fields.schema.json / the library) ---------
SUPPORTED_SCHEMA_VERSION = 1
SCALAR_CONTROLS = {"text", "date"}
COMPOSITE_CONTROLS = {"date_range", "time_range"}

# Validation vocabulary (docs/CONFIGURATION_GUIDE.md §4 / input_fields_json_design.md §5).
KNOWN_RULES = {
    "from_lte_to",
    "max_span",
    "max_offset_from_today",
    "to_required_if_from",
    "no_filter_when_equal",
    "regex",
    "max_length",
}
_RULE_REQUIRED_PARAMS = {
    "max_span": ("unit", "value"),
    "max_offset_from_today": ("unit", "value"),
    "regex": ("pattern",),
    "max_length": ("value",),
}


class SpecError(ValueError):
    """Raised when an ``input_fields_json`` blob violates the contract."""


# --- render-ready models (also the API response contract) -----------------------
class FieldValidation(BaseModel):
    """One validation rule, resolved for client-side enforcement (task 5.4)."""

    rule: str
    message_key: str
    applies_to: str | None = None
    unit: str | None = None
    value: float | int | None = None
    pattern: str | None = None


class FieldPart(BaseModel):
    """One endpoint (``from``/``to``) of a composite range control."""

    param_name: str
    display_label: str
    default: Any = None


class FormField(BaseModel):
    """A render-ready form field — scalar (text/date) or composite (range).

    ``kind`` lets the frontend switch once (scalar vs composite) instead of
    re-deriving it from ``control``. All fields the renderer needs are resolved
    here so the render path does zero parsing.
    """

    kind: str  # "scalar" | "composite"
    control: str  # text | date | date_range | time_range
    data_type: str  # string | date | time
    display_label: str
    display_order: int
    mandatory: bool
    validations: list[FieldValidation] = []

    # scalar-only
    param_name: str | None = None
    selection_type: str | None = None
    default: Any = None
    omit_if_blank: bool | None = None
    normalize: list[str] = []
    # Forward-looking (task 5.3): the current contract/schema has no enumerated
    # options — every pilot field is free-text or a date/time control (D-IFJ-8
    # removed the report_type radio from the form). We still read `allowed_values`
    # defensively so that if the contract later adds it, dropdowns render with no
    # backend change. `None` today for all 14 rows.
    allowed_values: list[Any] | None = None

    # composite-only
    parts: dict[str, FieldPart] | None = None


def _parse_validations(raw: Any, where: str, control: str) -> list[FieldValidation]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise SpecError(f"{where}: validations must be an array.")
    out: list[FieldValidation] = []
    for i, rule in enumerate(raw):
        rwhere = f"{where}.validations[{i}]"
        if not isinstance(rule, dict):
            raise SpecError(f"{rwhere}: validation must be an object.")
        name = rule.get("rule")
        if name not in KNOWN_RULES:
            # D-IFJ-10: unknown rule ⇒ fail the load, never silently skip.
            raise SpecError(
                f"{rwhere}: unknown validation rule {name!r} (known: {sorted(KNOWN_RULES)})."
            )
        if not rule.get("message_key"):
            raise SpecError(f"{rwhere}: rule {name!r} requires a message_key (D-IFJ-9).")
        for req in _RULE_REQUIRED_PARAMS.get(name, ()):  # required params present
            if req not in rule:
                raise SpecError(f"{rwhere}: rule {name!r} requires param {req!r}.")
        out.append(
            FieldValidation(
                rule=name,
                message_key=rule["message_key"],
                applies_to=rule.get("applies_to"),
                unit=rule.get("unit"),
                value=rule.get("value"),
                pattern=rule.get("pattern"),
            )
        )
    return out


def _parse_scalar(d: dict[str, Any], where: str) -> FormField:
    pname = d.get("param_name")
    if not isinstance(pname, str) or not pname:
        raise SpecError(f"{where}: scalar field requires a non-empty param_name.")
    control = d["control"]
    return FormField(
        kind="scalar",
        control=control,
        data_type=d["data_type"],
        display_label=d["display_label"],
        display_order=d["display_order"],
        mandatory=bool(d["mandatory"]),
        validations=_parse_validations(d.get("validations"), where, control),
        param_name=pname,
        selection_type=d.get("selection_type"),
        default=d.get("default"),
        omit_if_blank=d.get("omit_if_blank"),
        normalize=list(d.get("normalize", [])),
        allowed_values=d.get("allowed_values"),
    )


def _parse_composite(d: dict[str, Any], where: str) -> FormField:
    parts_raw = d.get("parts")
    if not isinstance(parts_raw, dict) or "from" not in parts_raw or "to" not in parts_raw:
        raise SpecError(f"{where}: composite control requires parts with 'from' and 'to'.")
    parts: dict[str, FieldPart] = {}
    for side in ("from", "to"):
        p = parts_raw.get(side)
        if not isinstance(p, dict) or not p.get("param_name"):
            raise SpecError(f"{where}.parts.{side}: requires a non-empty param_name.")
        parts[side] = FieldPart(
            param_name=p["param_name"],
            display_label=p.get("display_label", side),
            default=p.get("default"),
        )
    control = d["control"]
    return FormField(
        kind="composite",
        control=control,
        data_type=d["data_type"],
        display_label=d["display_label"],
        display_order=d["display_order"],
        mandatory=bool(d["mandatory"]),
        validations=_parse_validations(d.get("validations"), where, control),
        parts=parts,
    )


def parse_input_fields(blob: dict[str, Any], source: str = "<inline>") -> list[FormField]:
    """Parse one ``input_fields_json`` blob into render-ready fields.

    Args:
        blob: the parsed JSON object (``{schema_version, fields[]}``).
        source: label for error messages (e.g. the ``alv_id``).

    Returns:
        Fields sorted by ``display_order`` (render order — task 5.1).

    Raises:
        SpecError: if the blob violates the contract (bad ``schema_version``,
            unknown control/rule, missing required keys). Callers at cache-load
            catch this to skip + log a single bad row without crashing startup.
    """
    if not isinstance(blob, dict):
        raise SpecError(f"{source}: input_fields_json must be a JSON object.")
    if blob.get("schema_version") != SUPPORTED_SCHEMA_VERSION:  # D-IFJ-2 fail-fast
        raise SpecError(
            f"{source}: unsupported schema_version {blob.get('schema_version')!r} "
            f"(expected {SUPPORTED_SCHEMA_VERSION})."
        )
    fields = blob.get("fields")
    if not isinstance(fields, list) or not fields:
        raise SpecError(f"{source}: 'fields' must be a non-empty array.")

    parsed: list[FormField] = []
    seen_params: set[str] = set()
    for idx, f in enumerate(fields):
        where = f"{source}.fields[{idx}]"
        if not isinstance(f, dict):
            raise SpecError(f"{where}: must be an object.")
        control = f.get("control")
        if control in COMPOSITE_CONTROLS:
            field = _parse_composite(f, where)
        elif control in SCALAR_CONTROLS:
            field = _parse_scalar(f, where)
        else:
            raise SpecError(
                f"{where}: unknown control {control!r} "
                f"(expected one of {sorted(SCALAR_CONTROLS | COMPOSITE_CONTROLS)})."
            )
        # param_name uniqueness within the row (D6).
        for pn in _field_param_names(field):
            if pn in seen_params:
                raise SpecError(f"{where}: duplicate param_name {pn!r} within the row (D6).")
            seen_params.add(pn)
        parsed.append(field)

    parsed.sort(key=lambda f: f.display_order)
    return parsed


def _field_param_names(field: FormField) -> list[str]:
    if field.kind == "composite" and field.parts:
        return [p.param_name for p in field.parts.values()]
    return [field.param_name] if field.param_name else []
