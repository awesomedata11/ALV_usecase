"""Admin report onboarding: validate a manifest + MERGE it into ``alv_catalog``.

This is the App-side, Spark-free re-implementation of what the seed job
(:class:`dbx_alv_reports.seed.report_seeder.ReportSeeder`) does — so an ALV admin can
onboard a new report from the UI by pasting the SAME manifest JSON the job consumes
(a ``{"catalog_rows": [ ... ]}`` object), instead of editing a spec file and running a
job.

## Why re-implement (and not import the library)

Exactly the same reason :mod:`alv_app.fields` re-implements the parser: the App's
Databricks-Apps deploy source root is ``src/alv-frontend/backend/`` only — the metadata
library (``src/alv-backend/dbx_alv_reports``) is never synced to the Apps runtime, and it
pulls a Spark/driver dependency chain the request-serving backend must not import. So
this module mirrors the CONTRACT:

* validation mirrors :meth:`ReportSeeder.validate_manifest` (manifest shape + required
  identity keys + duplicate ``alv_id`` detection), delegating the per-row field-contract
  checks to the app-local :func:`alv_app.fields.parse_input_fields` (the same parser the
  cache loads with) — **collect-all**, never fail on the first error;
* row derivation mirrors :func:`ReportSeeder.slug_alv_id` / :meth:`ReportSeeder.derive_rows`
  exactly (``alv_id`` slug, ``alv_name`` join, placeholder ``job_id`` → NULL); and
* the write is a bound-parameter ``MERGE INTO alv_catalog`` as the **App SP**, mirroring
  :func:`alv_app.admin.upsert_grant` — one MERGE per row (the statement-execution API
  has no temp-view seam), every value bound, ``input_fields_json`` stored as a compact
  JSON string. NEVER interpolated.

## Deny-by-default visibility (important)

Onboarding a report does **not** grant anyone access to it. Report visibility is
deny-by-default via ``report_permissions`` (see :mod:`alv_app.entitlements`): a report
with no grant is hidden from everyone. A freshly-added report is therefore invisible
until an admin grants it on the existing permissions screen. The endpoint refreshes the
metadata cache so the new report appears there (and in the admin report picker)
immediately, but it deliberately does NOT auto-grant — that would silently widen access.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from .config import Settings
from .fields import SpecError, parse_input_fields

log = logging.getLogger("alv_reports.report_admin")

# Identity keys every catalog_rows entry must carry (mirrors ReportSeeder.validate_manifest).
_REQUIRED_ROW_KEYS = (
    "report_key",
    "report_label",
    "selection_id",
    "selection_label",
    "selection_order",
    "input_fields_json",
)

# alv_catalog columns written by the MERGE, in a fixed order (mirrors the seeder's
# _SEED_COLUMNS + metadata_tables.ALV_CATALOG_TABLE). Audit cols (created_at/updated_at)
# are set in SQL, never bound.
_CATALOG_COLUMNS = (
    "alv_id",
    "report_key",
    "report_label",
    "selection_id",
    "selection_label",
    "selection_order",
    "report_type_code",
    "report_type_label",
    "report_type_order",
    "alv_name",
    "description",
    "job_id",
    "job_run_mode",
    "input_fields_json",
    "is_active",
)

# The bound-parameter SQL type for each column (matches the alv_catalog DDL). A typed
# NULL (value=None) keeps a placeholder job_id / absent order genuinely NULL.
_COLUMN_TYPES = {
    "alv_id": "STRING",
    "report_key": "STRING",
    "report_label": "STRING",
    "selection_id": "STRING",
    "selection_label": "STRING",
    "selection_order": "INT",
    "report_type_code": "STRING",
    "report_type_label": "STRING",
    "report_type_order": "INT",
    "alv_name": "STRING",
    "description": "STRING",
    "job_id": "BIGINT",
    "job_run_mode": "STRING",
    "input_fields_json": "STRING",
    "is_active": "BOOLEAN",
}


class ReportAdminError(RuntimeError):
    """Raised when an ``alv_catalog`` onboarding write cannot be performed."""


# --- pure validation + derivation (no warehouse) --------------------------------
def slug_alv_id(report_key: str, selection_id: str, report_type_code: str | None) -> str:
    """Natural-key slug ``report_key__selection_id[__report_type_code]`` (mirrors seeder)."""
    parts = [report_key, selection_id]
    if report_type_code:
        parts.append(report_type_code)
    return "__".join(parts)


def _coerce_job_id(raw: Any, source: str, warnings: list[str]) -> int | None:
    """Return an int ``job_id``, or ``None`` for a placeholder/unbound value (with a warning).

    Mirrors :func:`ReportSeeder._coerce_job_id`: an int or an all-digit string is kept; a
    non-numeric placeholder (e.g. ``"JOB_PLACEHOLDER_01"``) seeds as NULL (unbound) so the
    submit path returns a clean "not bound to a job yet" error until RIL supplies the real
    id.
    """
    if raw is None:
        return None
    if isinstance(raw, bool):  # guard: bool is an int subclass, never a job id
        warnings.append(f"{source}: job_id {raw!r} is not a valid id; seeding NULL (unbound).")
        return None
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str) and raw.isdigit():
        return int(raw)
    warnings.append(
        f"{source}: job_id {raw!r} is not numeric (placeholder); seeding NULL (unbound). "
        "Bind the real job_id before the report can be run."
    )
    return None


def validate_manifest(manifest: dict[str, Any]) -> list[str]:
    """Validate a manifest's shape + every embedded ``input_fields_json``.

    Mirrors :meth:`ReportSeeder.validate_manifest`, but delegates each row's field-contract
    checks to the app-local :func:`alv_app.fields.parse_input_fields`. Collects ALL errors
    across every row (never fails on the first — CLAUDE.md "Configuration: JSON → validated
    object") so an admin sees every problem in one pass.

    Args:
        manifest: the parsed manifest object (a ``{"catalog_rows": [...]}`` dict).

    Returns:
        A list of human-readable error strings — empty iff the manifest is valid.
    """
    errors: list[str] = []
    rows = manifest.get("catalog_rows")
    if not isinstance(rows, list) or not rows:
        return ["manifest: 'catalog_rows' must be a non-empty array."]

    seen_alv_ids: dict[str, int] = {}
    for i, row in enumerate(rows):
        src = f"catalog_rows[{i}]"
        if not isinstance(row, dict):
            errors.append(f"{src}: must be an object.")
            continue
        for req in _REQUIRED_ROW_KEYS:
            if req not in row:
                errors.append(f"{src}: missing required key {req!r}.")
        rk, sid = row.get("report_key"), row.get("selection_id")
        if rk and sid:
            alv_id = row.get("alv_id") or slug_alv_id(rk, sid, row.get("report_type_code"))
            if alv_id in seen_alv_ids:
                errors.append(
                    f"{src}: duplicate alv_id {alv_id!r} (also catalog_rows[{seen_alv_ids[alv_id]}])."
                )
            else:
                seen_alv_ids[alv_id] = i
        ifj = row.get("input_fields_json")
        if isinstance(ifj, dict):
            # parse_input_fields raises on the first contract violation IN THIS row;
            # catching it here keeps the whole-manifest pass collect-all (we still see
            # every OTHER row's problems), matching how the cache tolerates one bad row.
            # A malformed field (e.g. missing data_type) surfaces as KeyError/TypeError from
            # the parser rather than SpecError — treat those as a validation error too, so a
            # pasted manifest can never 500 the endpoint.
            try:
                parse_input_fields(ifj, source=f"{src}.input_fields_json")
            except SpecError as exc:
                errors.append(str(exc))
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(
                    f"{src}.input_fields_json: malformed field definition ({exc!r})."
                )
        elif ifj is not None:
            errors.append(f"{src}: input_fields_json must be an object.")
    return errors


def load_and_validate(raw_text: str) -> tuple[dict[str, Any] | None, list[str]]:
    """Parse pasted manifest text and validate it, owning EVERY failure mode.

    The admin pastes raw JSON text; this owns the whole trust boundary — a JSON parse
    error, a non-object top level, and the per-row contract failures all come back as the
    same flat error list, so the UI shows them uniformly.

    Returns:
        ``(manifest, errors)`` — ``manifest`` is the parsed object on success (``errors``
        empty), or ``None`` when there is any error.
    """
    try:
        manifest = json.loads(raw_text)
    except (ValueError, TypeError) as exc:
        return None, [f"manifest: not valid JSON ({exc})."]
    if not isinstance(manifest, dict):
        return None, [
            "manifest: the top-level value must be a JSON object with a 'catalog_rows' array."
        ]
    errors = validate_manifest(manifest)
    return (manifest if not errors else None), errors


def derive_rows(manifest: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    """Derive ``alv_catalog`` rows from an **already-validated** manifest (no re-validation).

    Mirrors :meth:`ReportSeeder.derive_rows`: derives the ``alv_id`` slug and ``alv_name``
    join, coerces a placeholder ``job_id`` to NULL, and serializes ``input_fields_json`` to
    a compact JSON string.

    Returns:
        ``(rows, warnings)`` — ``warnings`` covers unbound placeholder ``job_id`` s.
    """
    rows: list[dict[str, Any]] = []
    warnings: list[str] = []
    for row in manifest["catalog_rows"]:
        rk = row["report_key"]
        sid = row["selection_id"]
        rtc = row.get("report_type_code")
        alv_id = row.get("alv_id") or slug_alv_id(rk, sid, rtc)
        name = row.get("alv_name") or " — ".join(
            p
            for p in (row.get("report_label"), row.get("selection_label"), row.get("report_type_label"))
            if p
        )
        rows.append(
            {
                "alv_id": alv_id,
                "report_key": rk,
                "report_label": row.get("report_label"),
                "selection_id": sid,
                "selection_label": row.get("selection_label"),
                "selection_order": row.get("selection_order"),
                "report_type_code": rtc,
                "report_type_label": row.get("report_type_label"),
                "report_type_order": row.get("report_type_order"),
                "alv_name": name,
                "description": row.get("description"),
                "job_id": _coerce_job_id(row.get("job_id"), alv_id, warnings),
                "job_run_mode": row.get("job_run_mode", "run_now"),
                "input_fields_json": json.dumps(
                    row["input_fields_json"], separators=(",", ":"), ensure_ascii=False
                ),
                "is_active": bool(row.get("is_active", True)),
            }
        )
    return rows, warnings


# --- warehouse seam (App SP, bound parameters) ----------------------------------
def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.alv_catalog`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`alv_catalog`"


def _execute(
    settings: Settings, statement: str, parameters: list[dict[str, Any]]
) -> list[list[Any]]:
    """Run a parameterized statement on the warehouse as the app SP; return data rows.

    Mirrors :func:`alv_app.admin._execute` (same client, same SDK shapes).

    Raises:
        ReportAdminError: warehouse id unset, SDK missing, or the statement failed.
    """
    if not settings.databricks_warehouse_id:
        raise ReportAdminError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot write alv_catalog."
        )
    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import (
            StatementParameterListItem,
            StatementState,
        )
    except ImportError as exc:  # pragma: no cover - defensive
        raise ReportAdminError("databricks-sdk is not installed.") from exc

    params = [
        StatementParameterListItem(name=p["name"], value=p.get("value"), type=p.get("type"))
        for p in parameters
    ]
    try:
        client = WorkspaceClient()  # Config() default auth (App SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=statement,
            parameters=params,
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise ReportAdminError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise ReportAdminError(f"statement did not succeed: {detail}")
    return resp.result.data_array if (resp.result and resp.result.data_array) else []


def _param(name: str, value: Any) -> dict[str, Any]:
    """Build one bound-parameter dict (name/value/type) for a catalog column.

    A ``None`` value is a typed SQL NULL; a bool is rendered ``true``/``false``; everything
    else is stringified (the statement API takes string-valued parameters).
    """
    typ = _COLUMN_TYPES[name]
    if value is None:
        sval: str | None = None
    elif typ == "BOOLEAN":
        sval = "true" if value else "false"
    else:
        sval = str(value)
    return {"name": name, "value": sval, "type": typ}


def upsert_report_row(settings: Settings, row: dict[str, Any]) -> None:
    """Upsert one derived row into ``alv_catalog`` (idempotent MERGE keyed on ``alv_id``).

    Every value is a bound parameter — nothing is interpolated (mirrors
    :func:`alv_app.admin.upsert_grant`). An existing ``alv_id`` is updated (and
    ``updated_at`` refreshed); a new one is inserted with both audit timestamps.
    """
    src_select = ", ".join(f":{c} AS {c}" for c in _CATALOG_COLUMNS)
    set_cols = ", ".join(f"t.{c} = s.{c}" for c in _CATALOG_COLUMNS if c != "alv_id")
    insert_cols = ", ".join(_CATALOG_COLUMNS) + ", created_at, updated_at"
    insert_vals = (
        ", ".join(f"s.{c}" for c in _CATALOG_COLUMNS)
        + ", current_timestamp(), current_timestamp()"
    )
    stmt = (
        f"MERGE INTO {_fqtn(settings)} t "
        f"USING (SELECT {src_select}) s ON t.alv_id = s.alv_id "
        f"WHEN MATCHED THEN UPDATE SET {set_cols}, t.updated_at = current_timestamp() "
        f"WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})"
    )
    params = [_param(c, row[c]) for c in _CATALOG_COLUMNS]
    _execute(settings, stmt, params)


def upsert_reports(settings: Settings, rows: list[dict[str, Any]]) -> None:
    """Upsert every derived row into ``alv_catalog`` (one bound MERGE per row).

    One MERGE per row because the statement-execution API has no temp-view seam the
    Spark seeder relies on. Rows are applied in order; a failure raises
    :class:`ReportAdminError` (partially-applied rows are possible — the MERGE is
    idempotent, so a corrected re-submit converges).
    """
    log.info("onboarding %d report row(s) into %s", len(rows), _fqtn(settings))
    for row in rows:
        upsert_report_row(settings, row)
    log.info("onboarding complete (%d row(s) upserted).", len(rows))
