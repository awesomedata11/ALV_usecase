"""Parse a completed run's OUTPUT FILE into an on-screen preview (output-file preview).

This is the read-only, on-screen twin of the **download** path — NOT the SQL-based
"Preview Sample Data" on the report form (:mod:`alv_app.preview`). It runs **no SQL**:
given a bounded byte prefix already read off the UC Volume
(:func:`alv_app.databricks_client.read_volume_prefix`), it turns those bytes into a
small, capped table (or a raw-text fallback) the frontend can render.

Everything here is **pure** (bytes in, dict out) so it is trivially unit-testable with
no workspace, no SDK, and no Spark.

Design (per docs/OUTPUT_FILE_PREVIEW_APPROACH.md, decided):
  * **CSV first** — the first non-empty line deciding the shape: a comma ⇒ parse as CSV
    (header row → columns); otherwise fall back to a raw first-N-lines **text** view.
  * **Binary guard** — a NUL byte or a high ratio of non-text bytes ⇒ ``format="binary"``
    and no preview body (the UI says "preview not available for this file type").
  * **Bounded twice** — the byte cap is applied by the reader; this module applies the
    ROW cap and reports ``truncated`` when either cap bit.
"""
from __future__ import annotations

import csv
import io

# A byte-level truncation cut the file mid-line, so the last retained line/row is very
# likely incomplete — drop it rather than show a corrupt row.
_TEXT_BYTES = set(range(32, 127)) | set(b"\t\n\r\f\b")


def _looks_binary(data: bytes) -> bool:
    """Heuristic: does *data* look like a binary (non-text) file?

    A NUL byte is decisive; otherwise more than 30% non-text bytes in the first 8 KB
    means we should not try to render it as a table or as text.
    """
    sample = data[:8192]
    if not sample:
        return False
    if b"\x00" in sample:
        return True
    nontext = sum(1 for b in sample if b not in _TEXT_BYTES)
    return nontext / len(sample) > 0.30


def build_output_preview(
    data: bytes,
    byte_truncated: bool,
    filename: str,
    max_rows: int,
) -> dict:
    """Turn a bounded byte prefix of an output file into a preview payload.

    Args:
        data: the (already byte-capped) head of the file.
        byte_truncated: True when the file continues past the byte cap — so even a
            "short" table is really truncated, and the last line is likely partial.
        filename: the derived basename (for display; never the full storage path).
        max_rows: the maximum number of data rows (CSV) / lines (text) to return.

    Returns:
        A dict with ``format`` (``"csv"`` | ``"text"`` | ``"binary"``), ``columns`` and
        ``rows`` (CSV only; empty otherwise), ``text`` (text fallback body, else None),
        ``row_count`` (rows/lines returned), ``truncated``, and ``filename``.
    """
    if _looks_binary(data):
        return {
            "format": "binary",
            "columns": [],
            "rows": [],
            "text": None,
            "row_count": 0,
            "truncated": byte_truncated,
            "filename": filename,
        }

    text = data.decode("utf-8", errors="replace")
    lines = text.splitlines()
    # A byte-level cut leaves a partial final line; drop it so we never parse half a row.
    if byte_truncated and lines:
        lines = lines[:-1]

    first_nonblank = next((ln for ln in lines if ln.strip()), "")

    if "," not in first_nonblank:
        # Not comma-delimited → raw-text fallback (first N lines).
        shown = lines[:max_rows]
        return {
            "format": "text",
            "columns": [],
            "rows": [],
            "text": "\n".join(shown),
            "row_count": len(shown),
            "truncated": byte_truncated or len(lines) > max_rows,
            "filename": filename,
        }

    # CSV. Parse the retained text via the csv module (handles quoted fields); the
    # StringIO is fed the joined retained lines so a dropped partial line is excluded.
    reader = csv.reader(io.StringIO("\n".join(lines)))
    parsed = [row for row in reader]
    # Drop a trailing wholly-empty row (a final newline yields one).
    if parsed and parsed[-1] == []:
        parsed.pop()

    if not parsed:
        return {
            "format": "csv",
            "columns": [],
            "rows": [],
            "text": None,
            "row_count": 0,
            "truncated": byte_truncated,
            "filename": filename,
        }

    header = [str(c) for c in parsed[0]]
    data_rows = parsed[1:]
    shown_rows = data_rows[:max_rows]
    return {
        "format": "csv",
        "columns": header,
        "rows": shown_rows,
        "text": None,
        "row_count": len(shown_rows),
        "truncated": byte_truncated or len(data_rows) > max_rows,
        "filename": filename,
    }
