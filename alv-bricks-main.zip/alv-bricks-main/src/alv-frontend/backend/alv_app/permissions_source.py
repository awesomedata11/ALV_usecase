"""Data-access seam: read ``report_permissions`` from the SQL warehouse.

Backs report visibility (:mod:`alv_app.entitlements`). Reads the report_key → group
mapping via the SAME statement-execution seam as the catalogue read
(:mod:`alv_app.catalog_source`), i.e. as the **app service principal** — the SP owns
the mapping table; the user's OBO token is used ONLY to read that user's own groups
from ``/Me``.

The mapping is user-independent, so it is cached with a TTL by the caller (see
:func:`alv_app.entitlements.report_permission_map`) rather than re-read per request.

Kept behind a small function so the tests inject rows directly (no live workspace)
and the endpoints stay thin. A warehouse failure surfaces as the typed
:class:`PermissionsSourceError`; the caller then **fails CLOSED** (no reports) — the
opposite of the catalogue's degrade-to-empty, because this is a security control.
"""

from __future__ import annotations

import logging

from .config import Settings

log = logging.getLogger("alv_reports.permissions_source")

# Columns read from report_permissions (docs/METADATA_TABLE.md).
_COLUMNS = ["report_key", "principal_type", "principal_name", "is_active"]


class PermissionsSourceError(RuntimeError):
    """Raised when the ``report_permissions`` read cannot be performed."""


def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.report_permissions`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`report_permissions`"


def fetch_report_permissions(settings: Settings) -> list[dict[str, object]]:
    """Read all ``report_permissions`` rows via the SQL warehouse.

    Args:
        settings: app settings carrying ``catalog`` / ``schema_name`` /
            ``databricks_warehouse_id``.

    Returns:
        One dict per row keyed by column name (``is_active`` coerced to ``bool``).

    Raises:
        PermissionsSourceError: if the warehouse id is unset, the SDK is missing, or
            the statement fails. The caller fails CLOSED on this (hides everything)
            rather than degrading open.
    """
    if not settings.databricks_warehouse_id:
        raise PermissionsSourceError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot read report_permissions. "
            "Set it locally (see app/README.md) or attach a sql-warehouse resource "
            "on deploy (app.yaml valueFrom)."
        )

    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import StatementState
    except ImportError as exc:  # pragma: no cover - defensive
        raise PermissionsSourceError("databricks-sdk is not installed.") from exc

    sql = f"SELECT {', '.join(_COLUMNS)} FROM {_fqtn(settings)}"
    log.info(
        "reading report_permissions: %s (warehouse %s)",
        _fqtn(settings),
        settings.databricks_warehouse_id,
    )

    try:
        client = WorkspaceClient()  # Config() default auth (profile locally, SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=sql,
            # Generous timeout so a cold/stopped serverless warehouse can auto-start.
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise PermissionsSourceError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise PermissionsSourceError(f"statement did not succeed: {detail}")

    data = resp.result.data_array if (resp.result and resp.result.data_array) else []
    rows: list[dict[str, object]] = []
    for arr in data:
        row = dict(zip(_COLUMNS, arr))
        # data_array returns everything as strings; coerce the one bool we branch on.
        # NULL is_active is treated as active (the column is a revoke switch, and the
        # seeder always writes it — a hand-inserted row without it still counts).
        raw_active = row.get("is_active")
        row["is_active"] = raw_active is None or str(raw_active).lower() == "true"
        rows.append(row)
    log.info("read %d report_permissions row(s)", len(rows))
    return rows
