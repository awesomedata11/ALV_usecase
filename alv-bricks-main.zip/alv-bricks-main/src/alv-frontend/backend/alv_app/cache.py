"""In-memory metadata cache (task 3.1) — parse once, serve from memory (3.2).

At startup the app reads ``alv_catalog`` from the SQL warehouse ONCE, parses each
row's ``input_fields_json`` into render-ready :class:`~alv_app.fields.FormField`
objects (via :func:`alv_app.fields.parse_input_fields`), and holds the result in
memory keyed by ``alv_id``. Both read endpoints serve from this cache — there is
**no SQL on the render path**.

Cold-start / cache-miss is handled gracefully (minimal task 3.4 territory): the
first access lazily triggers a load; a warehouse failure logs and leaves an empty
cache so the endpoints return an empty catalogue / 404 rather than 500-ing. Full
TTL / admin-reload (3.3) is intentionally out of scope.

**This cache is user-independent and stays that way.** It is loaded once at startup
as the App service principal, shared process-wide, and holds every seeded report.
Per-user report visibility (``report_permissions`` — see
:mod:`alv_app.entitlements`) is applied at REQUEST time by
:meth:`MetadataCache.visible_reports`, which every catalogue endpoint funnels
through. Nothing in the load path knows about users.
"""

from __future__ import annotations

import json
import logging
import threading

from .catalog_source import CatalogSourceError, fetch_catalog_rows
from .config import Settings
from .entitlements import filter_permitted_reports, permission_bypass_active
from .fields import FormField, SpecError, parse_input_fields
from .identity import UserIdentity
from .preview import SampleQuerySpec, parse_sample_query

log = logging.getLogger("alv_reports.cache")


class CachedReport:
    """One parsed catalogue row: identity columns + render-ready fields."""

    __slots__ = (
        "alv_id",
        "report_key",
        "report_label",
        "selection_id",
        "selection_label",
        "selection_order",
        "report_type_code",
        "report_type_label",
        "report_type_order",
        "alv_name",
        "description",
        "job_id",
        "job_run_mode",
        "is_active",
        "fields",
        "sample_query",
    )

    def __init__(self, row: dict[str, object], fields: list[FormField], sample_query: SampleQuerySpec | None = None) -> None:
        self.alv_id = str(row["alv_id"])
        self.report_key = row.get("report_key")
        self.report_label = row.get("report_label")
        self.selection_id = row.get("selection_id")
        self.selection_label = row.get("selection_label")
        self.selection_order = _as_int(row.get("selection_order"))
        self.report_type_code = row.get("report_type_code")
        self.report_type_label = row.get("report_type_label")
        self.report_type_order = _as_int(row.get("report_type_order"))
        self.alv_name = row.get("alv_name")
        self.description = row.get("description")
        # job_id is the bound customer Job (BIGINT); NULL/unbound stays None so the
        # submit path can return a clean "not bound to a job yet" error (task 7.4).
        self.job_id = _as_int(row.get("job_id"))
        self.job_run_mode = row.get("job_run_mode")
        self.is_active = bool(row.get("is_active"))
        self.fields = fields
        self.sample_query = sample_query

    @property
    def has_sample_query(self) -> bool:
        """True when the report has a parsed sample_query block."""
        return self.sample_query is not None


def _as_int(v: object) -> int | None:
    """Coerce a warehouse string/number to int, or None."""
    if v is None or v == "":
        return None
    try:
        return int(v)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None


def _label_matches(report: CachedReport, term: str) -> bool:
    """Whether *term* (already lower-cased) is a substring of the report's display text.

    Matches the same text the Downloads table shows — ``report_label``, else
    ``alv_name`` — and falls back to ``alv_id`` so a row with neither label is still
    findable by the identifier the user can see in the table.
    """
    for candidate in (report.report_label, report.alv_name, report.alv_id):
        if candidate and term in str(candidate).lower():
            return True
    return False


class MetadataCache:
    """Thread-safe, lazily-loaded cache of parsed catalogue rows keyed by alv_id."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._lock = threading.Lock()
        self._loaded = False
        self._by_id: dict[str, CachedReport] = {}

    # -- loading ------------------------------------------------------------
    def load(self, force: bool = False) -> None:
        """Read + parse the catalogue into memory (idempotent).

        Never raises: a warehouse/parse failure logs and leaves the cache empty
        (or unchanged) so callers degrade gracefully. Rows whose
        ``input_fields_json`` is individually invalid are skipped with a log —
        one bad row must not sink the whole catalogue.
        """
        with self._lock:
            if self._loaded and not force:
                return
            try:
                rows = fetch_catalog_rows(self._settings)
            except CatalogSourceError as exc:
                log.error("catalogue load failed (serving empty): %s", exc)
                self._loaded = True  # mark attempted; avoid tight reload loops
                return

            parsed: dict[str, CachedReport] = {}
            for row in rows:
                alv_id = str(row.get("alv_id"))
                try:
                    blob = row.get("input_fields_json")
                    blob = json.loads(blob) if isinstance(blob, str) else blob
                    fields = parse_input_fields(blob or {}, source=alv_id)
                except (SpecError, ValueError, TypeError) as exc:
                    log.error("skipping row %s: bad input_fields_json: %s", alv_id, exc)
                    continue
                try:
                    sq_raw = blob.get("sample_query") if isinstance(blob, dict) else None
                    sample_query = parse_sample_query(sq_raw)
                except Exception as exc:  # noqa: BLE001
                    log.warning("skipping sample_query for %s: %s", alv_id, exc)
                    sample_query = None
                parsed[alv_id] = CachedReport(row, fields, sample_query=sample_query)

            self._by_id = parsed
            self._loaded = True
            log.info("catalogue cache loaded: %d report(s)", len(parsed))

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self.load()

    # -- accessors ----------------------------------------------------------
    def active_reports(self) -> list[CachedReport]:
        """All active reports, sorted by (selection_order, report_type_order, report_key).

        ``report_key`` is an EXPLICIT tiebreak, not decoration: two reports cloned from
        the same shape tie on both order columns for every row, and without it their
        relative order fell out of ``alv_id`` alphabetical ordering — incidental, and
        the reason a cross-report auto-pick silently landed in the wrong report.
        ``alv_id`` remains the final tiebreak so the sort is still total.
        """
        self._ensure_loaded()
        active = [r for r in self._by_id.values() if r.is_active]
        return sorted(
            active,
            key=lambda r: (
                r.selection_order if r.selection_order is not None else 1_000_000,
                r.report_type_order if r.report_type_order is not None else 1_000_000,
                str(r.report_key or ""),
                r.alv_id,
            ),
        )

    def visible_reports(
        self, settings: Settings, ident: UserIdentity
    ) -> list[CachedReport]:
        """Active reports this user is permitted to see (the enforcement funnel).

        :meth:`active_reports` filtered by ``report_permissions`` group membership
        (:func:`alv_app.entitlements.filter_permitted_reports`). Every catalogue
        endpoint reads through here — or through :meth:`report_groups`, which builds
        on it — so the home-page cards, the nav tree, and the form lookup can never
        disagree about what a user may see.

        Fails CLOSED: a user whose groups cannot be read (OBO off, ``/Me`` error) or
        whose reports are unmapped gets an empty list. Order matches
        :meth:`active_reports`.
        """
        return filter_permitted_reports(settings, ident, self.active_reports())

    def listable_alv_ids(
        self, settings: Settings, ident: UserIdentity, search: str | None = None
    ) -> tuple[str, ...] | None:
        """The ``alv_id`` allowlist for a Downloads list query (report filter + search).

        ``request_log`` carries ``alv_id``, not ``report_key``, and the human report
        LABEL the user searches on is not a column there at all — it lives only here.
        So the SQL-side filter is an explicit ``alv_id`` allowlist resolved from this
        cache, using the same ``alv_id`` → ``report_key`` mapping the per-request gate
        uses (:meth:`get` → ``report_key`` → ``report_permissions``). No string surgery
        on ``alv_id`` — its ``report_key__…`` shape is a seeding convention, not a
        contract — and no duplicating the label into the table.

        Args:
            settings: App settings.
            ident: The resolved SSO identity (carries the OBO token).
            search: Optional free-text term matched case-insensitively as a substring of
                the report label (falling back to ``alv_name``, then ``alv_id``, so a
                row with no label is still findable). Blank / whitespace-only means
                "no search".

        Returns:
            The permitted-and-matching ``alv_id`` s. An EMPTY tuple means nothing is
            visible or nothing matched — the caller must serve an empty page without
            querying. ``None`` means "do not filter by report", which happens ONLY
            under the dev permission bypass with no search term.
        """
        term = (search or "").strip().lower()
        bypass = permission_bypass_active(settings)

        # Bypass + no search ⇒ nothing to narrow by; let the query run unfiltered.
        if bypass and not term:
            return None

        reports = self.active_reports() if bypass else self.visible_reports(settings, ident)
        if not term:
            return tuple(r.alv_id for r in reports)
        return tuple(r.alv_id for r in reports if _label_matches(r, term))

    def get(self, alv_id: str) -> CachedReport | None:
        """One report by ``alv_id`` (any active state), or None on miss.

        Permission-agnostic by design — the caller must gate on the returned row's
        ``report_key`` (see :func:`alv_app.entitlements.is_report_permitted`) before
        exposing anything derived from it.
        """
        self._ensure_loaded()
        return self._by_id.get(alv_id)

    def report_groups(
        self, settings: Settings, ident: UserIdentity
    ) -> list[tuple[str, str | None, int]]:
        """Distinct seeded reports for the home page (task: report cards).

        Returns one entry per ``report_key`` — ``(report_key, report_label,
        runnable_count)`` — where ``runnable_count`` is the number of active rows
        whose ``job_id`` is bound (a report is runnable only once its Job exists).
        Served from the in-memory cache (no SQL), ordered by first-seen
        ``selection_order`` / ``report_type_order`` so display order is stable.

        Filtered to the reports this user may see, so an unpermitted report yields no
        card at all (not a card with a zero count).
        """
        return self._group_reports(self.visible_reports(settings, ident))

    def all_report_groups(self) -> list[tuple[str, str | None, int]]:
        """Distinct seeded reports, **UNFILTERED** by permission — for the admin console.

        Same shape as :meth:`report_groups` but over every active report, not just the
        caller's visible ones: an admin grants access to reports they may not personally
        be able to open. Callers MUST gate this behind the admin check (:mod:`alv_app.admin`);
        it applies no permission filter of its own.
        """
        return self._group_reports(self.active_reports())

    @staticmethod
    def _group_reports(
        reports: "list[CachedReport]",
    ) -> list[tuple[str, str | None, int]]:
        """Collapse report rows to one (report_key, label, runnable_count) per report."""
        groups: dict[str, dict[str, object]] = {}
        for r in reports:  # assumed already sorted
            rk = str(r.report_key)
            g = groups.get(rk)
            if g is None:
                g = {"report_label": r.report_label, "count": 0}
                groups[rk] = g
            if r.job_id is not None:
                g["count"] = int(g["count"]) + 1  # type: ignore[arg-type]
        return [(rk, g["report_label"], int(g["count"])) for rk, g in groups.items()]  # type: ignore[arg-type]
