"""Admin console: the admin gate + the ``report_permissions`` write seam.

Two concerns live here:

1. **The admin gate** (:func:`is_admin`). A caller is an admin when their email OR one
   of their ``/Me`` groups appears in the ``ALV_ADMINS`` config list (see
   :class:`alv_app.config.Settings`). This is a BOOTSTRAP surface, deliberately
   config-driven and NOT stored in the grant table, so admin rights cannot be granted
   through the very console they gate. Fails **closed**: an empty list means nobody is
   an admin, and every ``/api/admin/*`` route 404s for a non-admin (existence hidden).

2. **The write seam** — grant / revoke rows in ``report_permissions`` as the **App SP**,
   the same statement-execution client as :mod:`alv_app.request_log`, every user value a
   bound parameter. A ``user`` grant's email is stored LOWER-CASED so the gate matches it
   case-folded (mirrors the seeder). After any write the caller invalidates the
   permission caches (:func:`alv_app.entitlements.clear_caches`) so the change is visible
   immediately rather than after the TTL.

The read used by the console (:func:`list_report_grants`) returns **all** rows for a
report — including inactive ones — so the admin can see and re-activate a revoked grant.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from .config import Settings
from .entitlements import resolve_user_groups
from .identity import UserIdentity

log = logging.getLogger("alv_reports.admin")

# The principal kinds a grant may name (mirrors the seeder / metadata contract).
PRINCIPAL_TYPES = ("group", "user")

# Columns read back for the console (includes is_active so a revoke is visible).
_READ_COLUMNS = ["report_key", "principal_type", "principal_name", "is_active", "granted_by"]


class AdminWriteError(RuntimeError):
    """Raised when a ``report_permissions`` admin write/read cannot be performed."""


@dataclass(frozen=True)
class GrantRow:
    """One ``report_permissions`` row as the console shows it."""

    report_key: str
    principal_type: str
    principal_name: str
    is_active: bool
    granted_by: str | None


# --- the admin gate -------------------------------------------------------------
def is_admin(settings: Settings, ident: UserIdentity) -> bool:
    """Whether *ident* is an ALV admin (email OR a /Me group in ``ALV_ADMINS``).

    Fails closed: no configured admins ⇒ False for everyone; any error resolving the
    caller's groups ⇒ the email check still applies, groups simply do not match. Never
    raises.
    """
    admins = settings.admin_principals()
    if not admins:
        return False

    email = ident.email.lower() if ident.email else None
    if email and email in admins:
        return True

    # Group-based admin: reuse the same OBO /Me read the report gate uses. A failure
    # there just means no group matches (the email check above already ran).
    user = resolve_user_groups(settings, ident)
    if user.ok and user.groups:
        if any(g.lower() in admins for g in user.groups):
            return True
    return False


# --- principal normalization ----------------------------------------------------
def normalize_principal(principal_type: str, principal_name: str) -> tuple[str, str]:
    """Validate + normalize one (type, name) pair for storage.

    ``user`` names are lower-cased (matched case-folded by the gate); ``group`` names
    are kept verbatim (Databricks group display names are case-sensitive). Both are
    trimmed.

    Raises:
        AdminWriteError: on an unknown type or a blank name.
    """
    ptype = (principal_type or "").strip().lower()
    if ptype not in PRINCIPAL_TYPES:
        raise AdminWriteError(
            f"principal_type must be one of {PRINCIPAL_TYPES!r}, got {principal_type!r}"
        )
    name = (principal_name or "").strip()
    if not name:
        raise AdminWriteError("principal_name must be non-empty")
    if ptype == "user":
        name = name.lower()
    return ptype, name


def classify_token(token: str) -> tuple[str, str]:
    """Classify a free-typed principal token into (principal_type, principal_name).

    Heuristic (documented in the approach doc): a token containing ``@`` is a user
    email; anything else is a group display name. Databricks group names never contain
    ``@``, so this is unambiguous. The returned pair is already normalized.

    Raises:
        AdminWriteError: on a blank token.
    """
    tok = (token or "").strip()
    if not tok:
        raise AdminWriteError("empty principal token")
    return normalize_principal("user" if "@" in tok else "group", tok)


# --- warehouse seam (App SP, bound parameters) ----------------------------------
def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.report_permissions`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`report_permissions`"


def _execute(
    settings: Settings, statement: str, parameters: list[dict[str, Any]]
) -> list[list[Any]]:
    """Run a parameterized statement on the warehouse as the app SP; return data rows.

    Mirrors :func:`alv_app.request_log._execute` (same client, same SDK shapes) but also
    returns ``result.data_array`` so the console read can reuse the seam.

    Raises:
        AdminWriteError: warehouse id unset, SDK missing, or the statement failed.
    """
    if not settings.databricks_warehouse_id:
        raise AdminWriteError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot access report_permissions."
        )
    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import (
            StatementParameterListItem,
            StatementState,
        )
    except ImportError as exc:  # pragma: no cover - defensive
        raise AdminWriteError("databricks-sdk is not installed.") from exc

    params = [
        StatementParameterListItem(name=p["name"], value=p.get("value"), type=p.get("type"))
        for p in parameters
    ]
    try:
        client = WorkspaceClient()  # Config() default auth (App SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=statement,
            parameters=params,
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise AdminWriteError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise AdminWriteError(f"statement did not succeed: {detail}")
    return resp.result.data_array if (resp.result and resp.result.data_array) else []


def list_report_grants(settings: Settings, report_key: str) -> list[GrantRow]:
    """Return every grant (active AND inactive) for *report_key*, for the console."""
    stmt = (
        f"SELECT {', '.join(_READ_COLUMNS)} FROM {_fqtn(settings)} "
        "WHERE report_key = :report_key ORDER BY principal_type, principal_name"
    )
    data = _execute(
        settings, stmt, [{"name": "report_key", "value": report_key, "type": "STRING"}]
    )
    rows: list[GrantRow] = []
    for arr in data:
        row = dict(zip(_READ_COLUMNS, arr))
        raw_active = row.get("is_active")
        active = raw_active is None or str(raw_active).lower() == "true"
        rows.append(
            GrantRow(
                report_key=str(row.get("report_key")),
                principal_type=str(row.get("principal_type")),
                principal_name=str(row.get("principal_name")),
                is_active=active,
                granted_by=row.get("granted_by") if row.get("granted_by") is None else str(row.get("granted_by")),
            )
        )
    return rows


def upsert_grant(
    settings: Settings,
    *,
    report_key: str,
    principal_type: str,
    principal_name: str,
    granted_by: str | None,
) -> None:
    """Grant a report to a principal (idempotent MERGE; (re)activates the row).

    Keyed on (report_key, principal_type, principal_name) — the table PK. An existing
    row is re-activated and its ``granted_by`` refreshed; a new row is inserted with
    ``granted_at = now``. The name is normalized (user emails lower-cased) by the caller.
    """
    ptype, name = normalize_principal(principal_type, principal_name)
    stmt = (
        f"MERGE INTO {_fqtn(settings)} t "
        "USING (SELECT :report_key AS report_key, :ptype AS principal_type, "
        ":pname AS principal_name) s "
        "ON t.report_key = s.report_key AND t.principal_type = s.principal_type "
        "AND t.principal_name = s.principal_name "
        "WHEN MATCHED THEN UPDATE SET t.is_active = true, t.granted_by = :granted_by "
        "WHEN NOT MATCHED THEN INSERT (report_key, principal_type, principal_name, "
        "is_active, granted_at, granted_by) VALUES (s.report_key, s.principal_type, "
        "s.principal_name, true, current_timestamp(), :granted_by)"
    )
    params = [
        {"name": "report_key", "value": report_key, "type": "STRING"},
        {"name": "ptype", "value": ptype, "type": "STRING"},
        {"name": "pname", "value": name, "type": "STRING"},
        {"name": "granted_by", "value": granted_by, "type": "STRING"},
    ]
    log.info("admin grant: %s -> %s:%s (by %s)", report_key, ptype, name, granted_by)
    _execute(settings, stmt, params)


def revoke_grant(
    settings: Settings, *, report_key: str, principal_type: str, principal_name: str
) -> None:
    """Revoke a grant (soft-delete: ``is_active = false``), so it can be re-activated.

    A no-op when the row does not exist (the UPDATE simply matches nothing).
    """
    ptype, name = normalize_principal(principal_type, principal_name)
    stmt = (
        f"UPDATE {_fqtn(settings)} SET is_active = false "
        "WHERE report_key = :report_key AND principal_type = :ptype "
        "AND principal_name = :pname"
    )
    params = [
        {"name": "report_key", "value": report_key, "type": "STRING"},
        {"name": "ptype", "value": ptype, "type": "STRING"},
        {"name": "pname", "value": name, "type": "STRING"},
    ]
    log.info("admin revoke: %s -> %s:%s", report_key, ptype, name)
    _execute(settings, stmt, params)
