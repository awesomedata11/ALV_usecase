"""Job-parameter payload build + canonicalization/hash (tasks 7.1 / 7.2).

Pure, I/O-free transforms so they are directly unit-testable:

* :func:`build_param_payload` — turn the submitted form values into the
  ``{param_name: value}`` payload the Job receives, honoring each field's
  ``normalize`` / ``omit_if_blank`` / ``default`` (docs/CONFIGURATION_GUIDE.md §3).
* :func:`canonical_param_json` — a stable-key-order JSON string of that payload.
* :func:`param_hash` — SHA-256 of the canonical JSON; the cache key together with
  ``alv_id`` (docs/METADATA_TABLE.md; D12 / D-IFJ-11).

The payload/hash cover **only the report's form params** — never the per-submission
plumbing (``request_no`` / ``alv_id`` / run ids). That keeps ``param_hash`` a stable
cache key across submissions of the same inputs (a later task 7.3 will look it up).
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from .fields import FormField


def _normalize(value: str, ops: list[str]) -> str:
    """Apply the field's ``normalize`` ops (trim/uppercase/lowercase) in order."""
    out = value
    for op in ops:
        if op == "trim":
            out = out.strip()
        elif op == "uppercase":
            out = out.upper()
        elif op == "lowercase":
            out = out.lower()
    return out


def _emit_scalar(field: FormField, values: dict[str, str], payload: dict[str, Any]) -> None:
    pname = field.param_name
    if not pname:
        return
    raw = values.get(pname, "")
    # Trim is applied first (if requested) so blankness is judged post-trim; the
    # remaining normalize ops (upper/lower) then apply to a non-blank value.
    norm_ops = field.normalize or []
    normalized = _normalize(raw, norm_ops)
    if normalized == "":
        # Blank: drop entirely when omit_if_blank, else fall back to the default.
        if field.omit_if_blank:
            return
        if field.default is not None:
            payload[pname] = field.default
        else:
            payload[pname] = None
        return
    payload[pname] = normalized


def _emit_composite(field: FormField, values: dict[str, str], payload: dict[str, Any]) -> None:
    if not field.parts:
        return
    for side in ("from", "to"):
        part = field.parts.get(side)
        if part is None:
            continue
        pname = part.param_name
        raw = (values.get(pname, "") or "").strip()
        if raw == "":
            # Composites have no per-part normalize; omit_if_blank lives on the field.
            if field.omit_if_blank:
                continue
            if part.default is not None:
                payload[pname] = part.default
            else:
                payload[pname] = None
            continue
        payload[pname] = raw


def build_param_payload(fields: list[FormField], values: dict[str, str]) -> dict[str, Any]:
    """Build the ``{param_name: value}`` Job payload from submitted form values.

    Args:
        fields: the report's render-ready fields (from the cache).
        values: submitted values keyed by ``param_name`` (composite parts carry
            their own ``from``/``to`` keys), as the frontend posts them.

    Returns:
        The payload dict. Keys are dropped for blank ``omit_if_blank`` fields;
        blank non-omit fields fall back to ``default`` (or ``None``); present
        values are normalized (``trim``/``uppercase``/``lowercase``).
    """
    payload: dict[str, Any] = {}
    for field in fields:
        if field.kind == "composite":
            _emit_composite(field, values, payload)
        else:
            _emit_scalar(field, values, payload)
    return payload


def canonical_param_json(payload: dict[str, Any]) -> str:
    """Serialize the payload with stable key order + compact separators (task 7.2)."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def param_hash(canonical_json: str) -> str:
    """SHA-256 hex digest of the canonical payload JSON (task 7.2)."""
    return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()
