"""Per-user parameter templates (variants) — the owner-scoped read/write seam.

A **template** is a named snapshot of the RAW form values for one runnable report
(``alv_id``), owned by one user. It lets a user re-fill a report's form without
re-typing. The owner sees ONLY his own templates.

This module is the data-access seam for ``report_templates`` (single-source DDL in
``src/dbx_alv_reports/metadata/metadata_tables.py``). It mirrors :mod:`alv_app.admin` /
:mod:`alv_app.request_log`: the App reads/writes as the **App service principal**
(``Config()`` default auth on deploy) through the SQL warehouse, and **every user value
is a bound parameter** — ``param_values_json`` is free text and is never interpolated
into the statement.

## Two gates, always in this order

The endpoints (see :mod:`alv_app.main`) apply, for every template call:

1. the **report-permission gate** (``report_permissions`` via
   :func:`alv_app.entitlements.is_report_permitted`) — a user may not touch templates for
   a report he cannot see (404, not 403);
2. the **owner gate** — every read and write here carries ``owner = :owner`` (the caller's
   lower-cased email), so a user can only ever see/change his own rows.

The owner value is resolved by the endpoint from the SSO identity and passed in already
lower-cased (:func:`owner_key`); this module binds it verbatim.

## What is stored

``param_values_json`` is the flat ``{param_name: value}`` map the form holds and
submit/preview post — NOT the normalized job payload (that is lossy for reload). Submit
still re-derives the effective payload from the field defs at run time. ``value_kinds_json``
is reserved for a later dynamic-template feature (relative dates/times); the pilot always
writes it NULL and treats every value as static.
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from typing import Any

from .config import Settings
from .identity import UserIdentity

log = logging.getLogger("alv_reports.templates")

# The longest a template name may be (defense-in-depth; the UI also caps input).
TEMPLATE_NAME_MAX_LEN = 128

# Columns read back for the list view (values NOT included — fetched on load).
# alv_id is included so the report-wide list can show which selection/report type each
# template belongs to (and Load can jump there). is_dynamic is derived from value_kinds_json.
_LIST_COLUMNS = ["template_id", "alv_id", "template_name", "created_at", "updated_at", "value_kinds_json"]
# Columns read for a single template load (adds the stored values + kinds map).
_LOAD_COLUMNS = ["template_id", "alv_id", "template_name", "param_values_json", "value_kinds_json"]


class TemplateError(RuntimeError):
    """Raised when a ``report_templates`` read/write cannot be performed."""


class TemplateValidationError(ValueError):
    """Raised when a template's name/values fail validation (endpoint -> 400/422)."""


@dataclass(frozen=True)
class TemplateSummary:
    """One template as the list view shows it (no values).

    ``alv_id`` identifies the runnable report type the template fills — the report-wide
    list shows its selection / report-type labels and Load navigates to it.
    """

    template_id: str
    alv_id: str
    template_name: str
    created_at: str | None
    updated_at: str | None
    is_dynamic: bool = False


@dataclass(frozen=True)
class TemplateDetail:
    """One template with its stored static values + raw dynamic-kinds map (load view).

    ``values`` is the stored RAW static map exactly as saved. ``value_kinds`` is the raw
    ``{param: {kind, preset, n?}}`` object (empty when the template is fully static). The
    endpoint resolves the dynamic presets against "now" and merges them over ``values``
    before returning to the client — the resolution needs the report fields + clock, which
    live at the endpoint, not in this data seam.
    """

    template_id: str
    alv_id: str
    template_name: str
    values: dict[str, str]
    value_kinds: dict[str, object]


def owner_key(ident: UserIdentity) -> str | None:
    """The owner key for *ident*: the caller's email, lower-cased, or None.

    Templates are keyed to the user's email (same identity the ``report_permissions``
    user grants use). On a deployed app the proxy always injects an email; None here
    means an unidentifiable caller (local dev / misconfig), which the endpoints treat as
    "no templates / refuse to write" — fail closed.
    """
    email = (ident.email or "").strip().lower()
    return email or None


def _validate_name(raw: str) -> str:
    """Trim + validate a template name (non-empty, length-capped)."""
    name = (raw or "").strip()
    if not name:
        raise TemplateValidationError("template name must be non-empty.")
    if len(name) > TEMPLATE_NAME_MAX_LEN:
        raise TemplateValidationError(
            f"template name must be at most {TEMPLATE_NAME_MAX_LEN} characters."
        )
    return name


def _canonical_values_json(values: dict[str, str]) -> str:
    """Serialize the raw form-values map with stable key order.

    Stable ordering keeps the stored blob deterministic (nice for diffing / auditing);
    the map is stringified defensively so a stray non-string value cannot break storage.
    """
    clean = {str(k): ("" if v is None else str(v)) for k, v in (values or {}).items()}
    return json.dumps(clean, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


# --- warehouse seam (App SP, bound parameters) ----------------------------------
def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.report_templates`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`report_templates`"


def _execute(
    settings: Settings, statement: str, parameters: list[dict[str, Any]]
) -> list[list[Any]]:
    """Run a parameterized statement on the warehouse as the app SP; return data rows.

    Mirrors :func:`alv_app.admin._execute` (same client, same SDK shapes).

    Raises:
        TemplateError: warehouse id unset, SDK missing, or the statement failed.
    """
    if not settings.databricks_warehouse_id:
        raise TemplateError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot access report_templates."
        )
    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import (
            StatementParameterListItem,
            StatementState,
        )
    except ImportError as exc:  # pragma: no cover - defensive
        raise TemplateError("databricks-sdk is not installed.") from exc

    params = [
        StatementParameterListItem(name=p["name"], value=p.get("value"), type=p.get("type"))
        for p in parameters
    ]
    try:
        client = WorkspaceClient()  # Config() default auth (App SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=statement,
            parameters=params,
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise TemplateError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise TemplateError(f"statement did not succeed: {detail}")
    return resp.result.data_array if (resp.result and resp.result.data_array) else []


def _rows_to_summaries(data: list[list[Any]]) -> list[TemplateSummary]:
    out: list[TemplateSummary] = []
    for arr in data:
        row = dict(zip(_LIST_COLUMNS, arr))
        out.append(
            TemplateSummary(
                template_id=str(row.get("template_id")),
                alv_id=str(row.get("alv_id")),
                template_name=str(row.get("template_name")),
                created_at=_as_str(row.get("created_at")),
                updated_at=_as_str(row.get("updated_at")),
                is_dynamic=bool(_parse_value_kinds_json(row.get("value_kinds_json"))),
            )
        )
    return out


def list_templates(settings: Settings, *, alv_id: str, owner: str) -> list[TemplateSummary]:
    """List *owner*'s active templates for one ``alv_id``, newest-updated first (no values)."""
    stmt = (
        f"SELECT {', '.join(_LIST_COLUMNS)} FROM {_fqtn(settings)} "
        "WHERE alv_id = :alv_id AND owner = :owner AND is_active IS NOT false "
        "ORDER BY updated_at DESC, template_name ASC"
    )
    params = [
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
    ]
    return _rows_to_summaries(_execute(settings, stmt, params))


def list_templates_for_report(
    settings: Settings, *, alv_ids: tuple[str, ...], owner: str
) -> list[TemplateSummary]:
    """List *owner*'s active templates across ALL ``alv_ids`` of one report, newest first.

    The Templates screen is report-wide: it shows every template the user saved for any
    selection / report type under the report he opened. ``alv_ids`` is the set of the
    report's runnable report-type ids (resolved from the metadata cache at the endpoint).

    The ids are bound as ONE JSON-array parameter (``array_contains(from_json(...))``),
    the same technique the Downloads list uses, so a report with many report types stays
    clear of the statement API's parameter cap. An empty ``alv_ids`` returns [] without
    querying.
    """
    if not alv_ids:
        return []
    stmt = (
        f"SELECT {', '.join(_LIST_COLUMNS)} FROM {_fqtn(settings)} "
        "WHERE array_contains(from_json(:alv_ids, 'array<string>'), alv_id) "
        "AND owner = :owner AND is_active IS NOT false "
        "ORDER BY updated_at DESC, template_name ASC"
    )
    params = [
        {"name": "alv_ids", "value": json.dumps(list(alv_ids), separators=(",", ":")), "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
    ]
    return _rows_to_summaries(_execute(settings, stmt, params))


def get_template(
    settings: Settings, *, alv_id: str, owner: str, template_id: str
) -> TemplateDetail | None:
    """Load one active template (with values) by id, owner-scoped. None on miss.

    The ``owner`` + ``alv_id`` predicates are the privacy control: a template that is
    not this caller's (or belongs to another report) simply does not match, so it reads
    as "not found" — the caller can never load someone else's row by guessing an id.
    """
    stmt = (
        f"SELECT {', '.join(_LOAD_COLUMNS)} FROM {_fqtn(settings)} "
        "WHERE template_id = :template_id AND alv_id = :alv_id AND owner = :owner "
        "AND is_active IS NOT false LIMIT 1"
    )
    params = [
        {"name": "template_id", "value": template_id, "type": "STRING"},
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
    ]
    data = _execute(settings, stmt, params)
    if not data:
        return None
    row = dict(zip(_LOAD_COLUMNS, data[0]))
    return TemplateDetail(
        template_id=str(row.get("template_id")),
        alv_id=str(row.get("alv_id")),
        template_name=str(row.get("template_name")),
        values=_parse_values(row.get("param_values_json")),
        value_kinds=_parse_value_kinds_json(row.get("value_kinds_json")),
    )


def save_template(
    settings: Settings,
    *,
    alv_id: str,
    owner: str,
    template_name: str,
    values: dict[str, str],
    value_kinds: dict[str, object] | None = None,
) -> str:
    """Create or overwrite a template, returning its ``template_id`` (upsert on name).

    Uniqueness is (``owner``, ``alv_id``, ``template_name``): re-saving an existing name
    OVERWRITES that template (its values + ``updated_at``), re-activating it if it had
    been deleted; a new name inserts a new row with a fresh ``template_id``. This is why
    the id is generated for the INSERT branch only — an overwrite keeps the existing id.

    The name is validated + trimmed and the values canonicalized here. ``value_kinds`` is
    the (already-validated, by the endpoint) ``{param: {kind, preset, n?}}`` map for the
    dynamic fields; it is stored as ``value_kinds_json`` (NULL when empty ⇒ fully static).
    The endpoint owns resolve-then-validate; this seam just persists.
    """
    name = _validate_name(template_name)
    values_json = _canonical_values_json(values)
    kinds_json = _canonical_kinds_json(value_kinds)
    new_id = _new_template_id()
    stmt = (
        f"MERGE INTO {_fqtn(settings)} t "
        "USING (SELECT :alv_id AS alv_id, :owner AS owner, :name AS template_name) s "
        "ON t.alv_id = s.alv_id AND t.owner = s.owner "
        "AND t.template_name = s.template_name "
        "WHEN MATCHED THEN UPDATE SET t.param_values_json = :values_json, "
        "t.value_kinds_json = :kinds_json, t.is_active = true, "
        "t.updated_at = current_timestamp() "
        "WHEN NOT MATCHED THEN INSERT (template_id, alv_id, owner, template_name, "
        "param_values_json, value_kinds_json, is_active, created_at, updated_at) "
        "VALUES (:new_id, s.alv_id, s.owner, s.template_name, :values_json, :kinds_json, "
        "true, current_timestamp(), current_timestamp())"
    )
    params = [
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
        {"name": "name", "value": name, "type": "STRING"},
        {"name": "values_json", "value": values_json, "type": "STRING"},
        # NULL kinds_json ⇒ bind None so the column is genuinely NULL (fully static).
        {"name": "kinds_json", "value": kinds_json, "type": "STRING"},
        {"name": "new_id", "value": new_id, "type": "STRING"},
    ]
    log.info(
        "save template: alv_id=%s owner=%s name=%r dynamic=%s",
        alv_id, owner, name, bool(value_kinds),
    )
    _execute(settings, stmt, params)
    # Resolve the id (the MERGE may have updated an existing row rather than inserting).
    existing = _template_id_for_name(settings, alv_id=alv_id, owner=owner, name=name)
    return existing or new_id


def rename_template(
    settings: Settings,
    *,
    alv_id: str,
    owner: str,
    template_id: str,
    new_name: str,
) -> bool:
    """Rename one owner-scoped template. Returns False if it did not exist.

    Guards the same uniqueness rule as :func:`save_template`: a rename onto a name that
    another of this user's templates for this report already uses is rejected
    (:class:`TemplateValidationError`), so two templates can't collide on
    (owner, alv_id, name).
    """
    name = _validate_name(new_name)
    clash = _template_id_for_name(settings, alv_id=alv_id, owner=owner, name=name)
    if clash and clash != template_id:
        raise TemplateValidationError(
            f"a template named {name!r} already exists for this report."
        )
    stmt = (
        f"UPDATE {_fqtn(settings)} SET template_name = :name, "
        "updated_at = current_timestamp() "
        "WHERE template_id = :template_id AND alv_id = :alv_id AND owner = :owner "
        "AND is_active IS NOT false"
    )
    params = [
        {"name": "name", "value": name, "type": "STRING"},
        {"name": "template_id", "value": template_id, "type": "STRING"},
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
    ]
    log.info("rename template %s: alv_id=%s owner=%s -> %r", template_id, alv_id, owner, name)
    _execute(settings, stmt, params)
    # Confirm the row exists (and is ours) so the endpoint can 404 a bad id.
    return get_template(settings, alv_id=alv_id, owner=owner, template_id=template_id) is not None


def delete_template(
    settings: Settings, *, alv_id: str, owner: str, template_id: str
) -> None:
    """Soft-delete one owner-scoped template (``is_active = false``).

    A no-op when the id is not this owner's / not this report's (the predicate matches
    nothing) — consistent with the other tables' soft-delete, and re-saving the same
    name later reactivates via the MERGE in :func:`save_template`.
    """
    stmt = (
        f"UPDATE {_fqtn(settings)} SET is_active = false, updated_at = current_timestamp() "
        "WHERE template_id = :template_id AND alv_id = :alv_id AND owner = :owner"
    )
    params = [
        {"name": "template_id", "value": template_id, "type": "STRING"},
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
    ]
    log.info("delete template %s: alv_id=%s owner=%s", template_id, alv_id, owner)
    _execute(settings, stmt, params)


def _template_id_for_name(
    settings: Settings, *, alv_id: str, owner: str, name: str
) -> str | None:
    """The active template_id for (owner, alv_id, name), or None. Owner-scoped."""
    stmt = (
        f"SELECT template_id FROM {_fqtn(settings)} "
        "WHERE alv_id = :alv_id AND owner = :owner AND template_name = :name "
        "AND is_active IS NOT false LIMIT 1"
    )
    params = [
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "owner", "value": owner, "type": "STRING"},
        {"name": "name", "value": name, "type": "STRING"},
    ]
    data = _execute(settings, stmt, params)
    if not data:
        return None
    return _as_str(data[0][0])


def _new_template_id() -> str:
    """App-generated template id."""
    return f"TPL-{uuid.uuid4().hex[:12].upper()}"


def _canonical_kinds_json(value_kinds: dict[str, object] | None) -> str | None:
    """Serialize the ``value_kinds`` map with stable key order, or None when empty.

    None/empty ⇒ NULL column ⇒ a fully static template (today's behaviour). The map is
    already validated by the endpoint (:mod:`alv_app.dynamic_values`); we just persist it.
    """
    if not value_kinds:
        return None
    return json.dumps(value_kinds, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _parse_value_kinds_json(raw: object) -> dict[str, object]:
    """Parse the stored ``value_kinds_json`` into a dict (empty on null/blank/malformed)."""
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return {}
    try:
        parsed = json.loads(raw) if isinstance(raw, str) else raw
    except (ValueError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _parse_values(raw: object) -> dict[str, str]:
    """Parse the stored ``param_values_json`` into a flat ``{name: value}`` map.

    Defensive: null / empty / non-JSON / non-object all degrade to an empty map (a
    half-written or hand-edited row can never crash a load). Values are stringified.
    """
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return {}
    try:
        parsed = json.loads(raw) if isinstance(raw, str) else raw
    except (ValueError, TypeError):
        return {}
    if not isinstance(parsed, dict):
        return {}
    return {str(k): ("" if v is None else str(v)) for k, v in parsed.items()}


def _as_str(v: object) -> str | None:
    """Coerce a warehouse cell to str, or None (empty/NULL stays None)."""
    if v is None or v == "":
        return None
    return str(v)
