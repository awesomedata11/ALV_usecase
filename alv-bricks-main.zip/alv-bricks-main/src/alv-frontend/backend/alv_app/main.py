"""ALV-Bricks Databricks App — thin FastAPI backend (tasks 1.1 / 1.2 skeleton).

It exposes:
  * ``GET /api/health``          — liveness probe (no auth).
  * ``GET /api/me``              — the current user's identity from the Databricks
                                   Apps SSO headers, plus an app SP auth-check.
  * ``GET /api/report-groups``   — distinct seeded reports for the home-page cards.
  * ``GET /api/reports``         — the active catalogue, grouped for nav (3.2).
                                   Optional ``?report_key=`` scopes the tree to one
                                   report (404 when it is unknown OR unpermitted).
  * ``GET /api/reports/{alv_id}``— one report's render-ready form def (3.2).
  * ``POST /api/reports/{alv_id}/submit`` — build the Job param payload, persist a
                                   request_log row, trigger the bound Job, return
                                   request_no (tasks 7.1/7.2/7.4/7.5).
  * ``POST /api/reports/{alv_id}/preview`` — run a sample-data preview query against
                                   the retail_ledger_sample table (sample data preview
                                   feature).
  * ``GET /api/requests``        — one filtered/searched/sorted/paginated page of
                                   request_log rows for the Downloads page (all
                                   narrowing done in SQL, before the limit).
  * ``GET /api/requests/{request_no}/params`` — the effective job payload one run was
                                   dispatched with, for the parameters info view.
  * ``GET/POST /api/admin/permissions/{report_key}[/grant|/revoke]`` — the admin
                                   console: list / grant / revoke report_permissions
                                   grants (group or user). Admin-gated (404 otherwise).

The catalogue/form endpoints serve from an in-memory cache loaded once at startup
(:mod:`alv_app.cache`) — no SQL on the render path (task 3.1/3.2). The submit
endpoint writes to ``request_log`` and triggers the Job (tasks 7.x); status polling
and output download are later tasks (8.x/9.x) and are NOT built here.

**Report visibility.** Every report-scoped endpoint — the three catalogue reads AND
the submit / preview / download write paths — is gated on ``report_permissions``
group membership (:mod:`alv_app.entitlements`). A report the caller may not see
returns **404**, identical to one that does not exist, so the gate discloses nothing.
Hiding the card is not sufficient on its own: the write paths enforce independently.

Deployed on Databricks Apps via ``uvicorn`` bound to ``DATABRICKS_APP_PORT``
(see ``app/app.yaml``).
"""

from __future__ import annotations

import json
import logging
from datetime import date
from contextlib import asynccontextmanager
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles

import posixpath
import uuid

from .cache import MetadataCache
from .catalogue import build_catalogue, build_report_groups, to_form_out
from .config import Settings, get_settings
from .databricks_client import (
    JobTriggerError,
    VolumeDownloadError,
    auth_check,
    download_volume_file,
    get_run_output,
    get_run_status,
    read_volume_prefix,
    trigger_job_run,
)
from .entitlements import clear_caches, is_report_permitted
from .identity import resolve_identity
from .admin import (
    AdminWriteError,
    classify_token,
    is_admin,
    list_report_grants,
    revoke_grant,
    upsert_grant,
)
from .report_admin import (
    ReportAdminError,
    derive_rows,
    load_and_validate,
    upsert_reports,
)
from .downloads import (
    DownloadsSourceError,
    RequestPage,
    RequestQuery,
    clamp_limit,
    fetch_request,
    fetch_request_params,
    fetch_requests_page,
    identity_match_values,
    normalize_scope,
    normalize_sort,
)
from .models import (
    CacheCheckOut,
    CacheHitOut,
    CatalogueOut,
    GrantIn,
    GrantOut,
    GrantResultOut,
    GrantsListOut,
    GrantTokenResult,
    HealthOut,
    MeOut,
    OnboardReportOut,
    OnboardReportIn,
    RenameTemplateIn,
    ReportFormOut,
    ReportGroupsOut,
    RequestOut,
    RequestParamsOut,
    RequestsOut,
    RequestStatusOut,
    RevokeIn,
    SaveTemplateIn,
    SubmitIn,
    SubmitOut,
    TemplateDetailOut,
    TemplateSummaryOut,
    TemplatesListOut,
)
from .templates import (
    TemplateError,
    TemplateValidationError,
    delete_template,
    get_template,
    list_templates_for_report,
    owner_key,
    rename_template,
    save_template,
)
from .dynamic_values import (
    DynamicValueError,
    merged_values,
    parse_value_kinds,
)
from .template_validation import validate_values
from .preview import PreviewError, run_preview
from .output_preview import build_output_preview
from .models import OutputPreviewOut, PreviewIn, PreviewOut
from .request_log import RequestLogError, insert_request_log, update_run_id, update_status
from .submit import build_param_payload, canonical_param_json, param_hash
from .cache_source import CacheSourceError, find_cached_run

APP_NAME = "alv-bricks-app"

try:
    APP_VERSION = _pkg_version("alv-app-backend")
except PackageNotFoundError:  # not installed as a dist (e.g. `uv run` from source)
    APP_VERSION = "0.1.0"

# Basic stdout logging so cache/warehouse load messages surface in `apps logs`.
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("alv_reports.main")

# Process-wide metadata cache (built from settings; loaded at startup below).
_cache = MetadataCache(get_settings())


def get_cache() -> MetadataCache:
    """FastAPI dependency: the shared metadata cache."""
    return _cache


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Warm the metadata cache at startup (graceful — never blocks boot on error)."""
    _cache.load()
    yield


app = FastAPI(
    title="ALV-Bricks App API",
    version=APP_VERSION,
    description="Backend for the ALV-Bricks Databricks App (read path — tasks 3.x/4.x/5.x).",
    lifespan=lifespan,
)


@app.get("/api/health", response_model=HealthOut, tags=["system"])
def health() -> HealthOut:
    """Liveness probe. No auth, no external calls."""
    return HealthOut(status="ok", app=APP_NAME, version=APP_VERSION)


@app.get("/api/me", response_model=MeOut, tags=["identity"])
def me(request: Request, settings: Settings = Depends(get_settings)) -> MeOut:
    """Return the current user's SSO identity + the app SP auth-check.

    The user identity comes from the Databricks Apps-injected ``X-Forwarded-*``
    headers (see :mod:`alv_app.identity`). The service-principal check makes one
    lightweight SDK call to prove app auth is wired (see
    :mod:`alv_app.databricks_client`). Both degrade gracefully when run locally.
    """
    ident = resolve_identity(request, settings)
    sp = auth_check()
    return MeOut(
        email=ident.email,
        preferred_username=ident.preferred_username,
        user_id=ident.user_id,
        real_ip=ident.real_ip,
        authenticated=ident.authenticated,
        has_user_token=ident.has_user_token,
        is_admin=is_admin(settings, ident),
        service_principal=sp.service_principal,
        service_principal_ok=sp.ok,
        service_principal_detail=sp.detail,
    )


@app.get("/api/report-groups", response_model=ReportGroupsOut, tags=["catalogue"])
def list_report_groups(
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> ReportGroupsOut:
    """Return the distinct seeded reports for the home-page card grid.

    Data-driven so the ACTIVE cards reflect what is actually seeded AND what this
    user is permitted to see (``report_permissions`` group membership); the greyed
    'coming soon' cards are frontend-static. Served from the in-memory cache (no SQL
    on the render path). Empty ``groups`` when the catalogue could not be loaded, or
    when the user may see nothing, so the home page still renders (the frontend shows
    an empty state).
    """
    ident = resolve_identity(request, settings)
    return build_report_groups(cache.report_groups(settings, ident))


# A ``?report_key=`` value is only ever compared for equality against report_key
# values already in the cache (never interpolated into SQL — the catalogue read
# happens at startup), so validation here is just about not letting an unbounded
# string through: trim it, treat blank as absent, and cap the length so a huge query
# string can't be used to bloat a log line.
_REPORT_KEY_MAX_LEN = 128


def _normalize_report_key(raw: str | None) -> str | None:
    """Server-side validation for ``?report_key=``: trimmed, length-capped, or None.

    Blank / whitespace-only means "not supplied" (same convention as the Downloads
    ``q`` param). An over-long value is kept but truncated, so it simply matches
    nothing rather than being special-cased into a different response.
    """
    key = (raw or "").strip()
    if not key:
        return None
    return key[:_REPORT_KEY_MAX_LEN]


@app.get("/api/reports", response_model=CatalogueOut, tags=["catalogue"])
def list_reports(
    request: Request,
    report_key: str | None = None,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> CatalogueOut:
    """Return the active catalogue, grouped for nav (selection → report types).

    Served entirely from the in-memory cache (task 3.2) — no SQL here — filtered to
    the reports this user is permitted to see.

    Args:
        report_key: Optional. Scope the tree to ONE report, so the returned
            ``report_key`` / ``report_label`` always identify it and the nav tree
            cannot mix two reports' selections. Trimmed and length-capped
            (:func:`_normalize_report_key`); blank counts as absent.

    Without ``report_key`` this returns every permitted report's selections, and the
    tree-level ``report_key`` / ``report_label`` are ``None`` when that spans more
    than one report — there is no single owning report to name.

    Errors:
        * ``404`` — a supplied ``report_key`` that resolves to nothing this caller can
          see. **Deliberately identical** for a report that does not exist, one the
          caller is not permitted to see (``report_permissions``), and one whose rows
          are missing because the catalogue could not be loaded — so, exactly as on
          ``GET /api/reports/{alv_id}``, the gate cannot be used to discover that an
          unpermitted report exists. Never ``403``.

    The UNSCOPED call still degrades to an empty ``selections`` list (never 404) when
    the catalogue could not be loaded or the user may see nothing, so the app shell
    always renders.
    """
    ident = resolve_identity(request, settings)
    visible = cache.visible_reports(settings, ident)

    key = _normalize_report_key(report_key)
    if key is None:
        return build_catalogue(visible)

    catalogue = build_catalogue(visible, report_key=key)
    if not catalogue.selections:
        # Same 404 whether the report is unknown, unpermitted, or unloaded.
        log.info("no visible catalogue for report_key=%s (%s)", key, _submitted_by(ident))
        raise HTTPException(status_code=404, detail=f"report not found: {key}")
    return catalogue


@app.get("/api/reports/{alv_id}", response_model=ReportFormOut, tags=["catalogue"])
def get_report(
    alv_id: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> ReportFormOut:
    """Return one report's render-ready form definition (ordered fields + rules).

    404 on cache miss (unknown or inactive ``alv_id``) **and** on a report the caller
    is not permitted to see — the same response either way, so the gate does not
    disclose that an unpermitted report exists.
    """
    report = cache.get(alv_id)
    if report is None or not report.is_active:
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")
    _require_report_permission(request, settings, report, alv_id)
    return to_form_out(report)


def _require_report_permission(
    request: Request, settings: Settings, report, alv_id: str
) -> None:
    """Raise 404 unless the caller may see *report* (``report_permissions`` gate).

    Deliberately **404, not 403**: a user must not be able to learn that a report they
    have no access to exists. Shared by every report-scoped endpoint (catalogue form,
    submit, preview) so the read and write paths cannot drift apart.

    Args:
        request: The incoming request (carries the SSO headers + OBO token).
        settings: App settings.
        report: The cached report row, whose ``report_key`` is the gating identity.
        alv_id: Echoed in the 404 detail, matching the unknown-report message.

    Raises:
        HTTPException: 404 when the report is not permitted.
    """
    ident = resolve_identity(request, settings)
    if not is_report_permitted(settings, ident, report.report_key):
        # INFO (not WARNING): entitlements already logged the reason; this line ties
        # the deny to the specific report + caller for the audit trail.
        log.info(
            "denied access to %s (report_key=%s) for %s",
            alv_id,
            report.report_key,
            _submitted_by(ident),
        )
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")


# --- Admin console (report_permissions grant/revoke) ----------------------------
def _require_admin(request: Request, settings: Settings):
    """Return the caller's identity, or raise 404 unless they are an ALV admin.

    Deliberately **404, not 403**: a non-admin must not learn that the admin console
    exists. Admin status is decided by the ``ALV_ADMINS`` config gate (email or /Me
    group), never by the grant table — see :mod:`alv_app.admin`.
    """
    ident = resolve_identity(request, settings)
    if not is_admin(settings, ident):
        log.info("denied admin access for %s", _submitted_by(ident))
        raise HTTPException(status_code=404, detail="not found")
    return ident


def _grants_out(settings: Settings, report_key: str) -> list[GrantOut]:
    """Read the report's grants and shape them for the API."""
    return [
        GrantOut(
            report_key=g.report_key,
            principal_type=g.principal_type,
            principal_name=g.principal_name,
            is_active=g.is_active,
            granted_by=g.granted_by,
        )
        for g in list_report_grants(settings, report_key)
    ]


def _known_report_key(cache: MetadataCache, report_key: str) -> bool:
    """Whether *report_key* is a seeded report (any active row carries it)."""
    return any(r.report_key == report_key for r in cache.active_reports())


@app.get("/api/admin/reports", response_model=ReportGroupsOut, tags=["admin"])
def admin_list_reports(
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> ReportGroupsOut:
    """Every seeded report (UNFILTERED by permission), for the console's report picker.

    Admin only (404 otherwise). Unlike ``/api/report-groups`` this is not narrowed to
    the caller's visible reports — an admin grants access to reports they may not open
    themselves.
    """
    _require_admin(request, settings)
    return build_report_groups(cache.all_report_groups())


@app.post("/api/admin/reports", response_model=OnboardReportOut, tags=["admin"])
def admin_onboard_report(
    body: OnboardReportIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> OnboardReportOut:
    """Onboard a new report by pasting the seed manifest JSON. Admin only (404 otherwise).

    Validates the pasted manifest app-locally (mirrors ``ReportSeeder.validate_manifest`` +
    the app-local field parser), MERGEs the derived rows into ``alv_catalog`` as the App SP
    (bound parameters, never interpolated), then refreshes the in-memory cache so the report
    appears immediately in the report picker and becomes grantable.

    **Deny-by-default:** the report is NOT auto-granted — visibility is gated by
    ``report_permissions``, so a newly-added report stays hidden from everyone (including
    the admin who added it) until access is granted on the permissions screen. Auto-granting
    would silently widen access; the returned ``detail`` tells the admin to grant it next.

    Errors:
        * ``404`` — the caller is not an ALV admin (existence hidden, never 403).
        * ``422`` — the manifest is invalid; the body is
          ``{"detail": {"detail": ..., "errors": [ ... ]}}`` with EVERY collected problem
          (bad JSON, missing keys, duplicate ``alv_id``, bad ``input_fields_json``).
        * ``502`` — the ``alv_catalog`` write failed.
    """
    ident = _require_admin(request, settings)

    manifest, errors = load_and_validate(body.manifest)
    if errors or manifest is None:
        # 422 with the FULL collected error list (collect-all), shaped like the template
        # save path's validation error so the frontend can render {detail, errors}.
        raise HTTPException(
            status_code=422,
            detail={"detail": "the manifest is not valid", "errors": errors},
        )

    rows, warnings = derive_rows(manifest)
    try:
        upsert_reports(settings, rows)
    except ReportAdminError as exc:
        log.error("report onboarding write failed (by %s): %s", _submitted_by(ident), exc)
        raise HTTPException(status_code=502, detail=f"could not add the report: {exc}")

    # Refresh the cache so the new rows show up in the admin report picker (and the
    # permissions screen) right away. No permission cache to clear — nothing was granted.
    cache.load(force=True)

    report_keys = sorted({str(r["report_key"]) for r in rows})
    alv_ids = [str(r["alv_id"]) for r in rows]
    log.info(
        "report onboarded by %s: report_keys=%s rows=%d",
        _submitted_by(ident),
        report_keys,
        len(rows),
    )
    return OnboardReportOut(
        ok=True,
        row_count=len(rows),
        report_keys=report_keys,
        alv_ids=alv_ids,
        warnings=warnings,
        detail=(
            "Report added. It is hidden from everyone until you grant access to a group "
            "or user on the Manage report access screen below."
        ),
    )


@app.get("/api/admin/permissions/{report_key}", response_model=GrantsListOut, tags=["admin"])
def admin_list_grants(
    report_key: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> GrantsListOut:
    """List every grant (active + inactive) for one report. Admin only (404 otherwise)."""
    _require_admin(request, settings)
    if not _known_report_key(cache, report_key):
        raise HTTPException(status_code=404, detail=f"report not found: {report_key}")
    try:
        return GrantsListOut(report_key=report_key, grants=_grants_out(settings, report_key))
    except AdminWriteError as exc:
        raise HTTPException(status_code=502, detail=f"could not read grants: {exc}") from exc


@app.post("/api/admin/permissions/{report_key}/grant", response_model=GrantResultOut, tags=["admin"])
def admin_grant(
    report_key: str,
    body: GrantIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> GrantResultOut:
    """Grant a report to one or more principals (comma-separated emails/groups).

    Each token is classified ('@' ⇒ user, else group), normalized, and upserted
    (idempotent, re-activates a revoked row). Per-token results are returned so a
    partially-bad list still applies the good tokens. The permission caches are cleared
    after any successful write so the change is visible immediately.
    """
    ident = _require_admin(request, settings)
    if not _known_report_key(cache, report_key):
        raise HTTPException(status_code=404, detail=f"report not found: {report_key}")

    granted_by = _submitted_by(ident)
    results: list[GrantTokenResult] = []
    wrote = False
    for token in body.principals.split(","):
        if not token.strip():
            continue
        try:
            ptype, pname = classify_token(token)
        except AdminWriteError as exc:
            results.append(GrantTokenResult(token=token.strip(), outcome="invalid", detail=str(exc)))
            continue
        try:
            upsert_grant(
                settings,
                report_key=report_key,
                principal_type=ptype,
                principal_name=pname,
                granted_by=granted_by,
            )
            wrote = True
            results.append(
                GrantTokenResult(
                    token=token.strip(),
                    principal_type=ptype,
                    principal_name=pname,
                    outcome="granted",
                )
            )
        except AdminWriteError as exc:
            results.append(
                GrantTokenResult(
                    token=token.strip(), principal_type=ptype, principal_name=pname,
                    outcome="invalid", detail=str(exc),
                )
            )

    if wrote:
        clear_caches()  # make the new grants visible immediately, not after the TTL
    return GrantResultOut(
        report_key=report_key, results=results, grants=_grants_out(settings, report_key)
    )


@app.post("/api/admin/permissions/{report_key}/revoke", response_model=GrantResultOut, tags=["admin"])
def admin_revoke(
    report_key: str,
    body: RevokeIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> GrantResultOut:
    """Revoke one grant (soft-delete). Admin only (404 otherwise)."""
    _require_admin(request, settings)
    if not _known_report_key(cache, report_key):
        raise HTTPException(status_code=404, detail=f"report not found: {report_key}")
    try:
        revoke_grant(
            settings,
            report_key=report_key,
            principal_type=body.principal_type,
            principal_name=body.principal_name,
        )
    except AdminWriteError as exc:
        raise HTTPException(status_code=502, detail=f"could not revoke: {exc}") from exc
    clear_caches()  # make the revoke visible immediately
    result = GrantTokenResult(
        token=body.principal_name,
        principal_type=body.principal_type,
        principal_name=body.principal_name,
        outcome="revoked",
    )
    return GrantResultOut(
        report_key=report_key, results=[result], grants=_grants_out(settings, report_key)
    )


def _new_request_no() -> str:
    """App-generated request id shown to the user (short, sortable-ish)."""
    return f"REQ-{uuid.uuid4().hex[:12].upper()}"


def _submitted_by(ident) -> str | None:
    """Pick the most human-readable identifier to log as ``submitted_by``.

    Prefer the email, then the preferred_username, and only fall back to the
    opaque numeric ``X-Forwarded-User`` id as a last resort — so a real deploy
    records ``idris.chakera@databricks.com`` rather than ``8241774669268934...``.
    """
    return ident.email or ident.preferred_username or ident.user_id


@app.post(
    "/api/reports/{alv_id}/cache-check",
    response_model=CacheCheckOut,
    tags=["submit"],
)
def cache_check(
    alv_id: str,
    body: SubmitIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> CacheCheckOut:
    """Pre-submit result-cache lookup (task 7.3): is an identical run reusable?

    Called by the frontend AFTER the user clicks Submit and BEFORE the run is triggered.
    Computes the SAME ``param_hash`` ``submit`` would (server-side, from the field defs —
    the single source of truth for the hash), then asks whether a prior run for this
    ``(alv_id, param_hash)`` COMPLETED within its retention window. If so, the frontend
    offers the user a choice: reuse that output or run the Job again.

    **Reuse across users is intended.** The candidate may have been submitted by another
    user who shares the report permission — per ``docs/SECURITY_AND_PERMISSIONS.md`` §8
    the report permission is the whole authorization model, and ``submitted_by`` is shown,
    not masked. **Latest wins:** when several runs qualify, the newest output is offered.

    Errors / degradation:
        * ``404`` — unknown / inactive report, or one the caller may not see
          (``report_permissions``) — checked BEFORE any warehouse read, identical in shape
          to a missing report, so an unpermitted report is never disclosed.
        * A warehouse failure is NOT an error here: it returns ``hit=None`` (200), so a
          cache-read problem degrades to a normal (re)run rather than blocking submission.
          The feature is strictly optional.
    """
    report = cache.get(alv_id)
    if report is None or not report.is_active:
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")

    # Same gate as submit — a report the caller may not see must not reveal its runs.
    _require_report_permission(request, settings, report, alv_id)

    # Compute the cache key exactly as submit would (server-side, from the field defs).
    payload = build_param_payload(report.fields, body.values or {})
    phash = param_hash(canonical_param_json(payload))

    try:
        row = find_cached_run(settings, alv_id=alv_id, param_hash=phash)
    except CacheSourceError as exc:
        # Never block a submission on a cache-read failure — degrade to "no reuse".
        log.warning("cache-check read failed for %s (offering no reuse): %s", alv_id, exc)
        return CacheCheckOut(alv_id=alv_id, param_hash=phash, hit=None)

    if row is None:
        return CacheCheckOut(alv_id=alv_id, param_hash=phash, hit=None)

    hit = CacheHitOut(
        request_no=_as_str(row.get("request_no")) or "",
        submitted_by=_as_str(row.get("submitted_by")),
        generated_at=_as_str(row.get("generated_at")),
        expires_at=_as_str(row.get("expires_at")),
        row_count=row.get("row_count"),  # already coerced to int|None by the source
        has_output=bool(row.get("output_path")),
    )
    log.info(
        "cache-check hit for %s: reusable run %s (offering reuse)", alv_id, hit.request_no
    )
    return CacheCheckOut(alv_id=alv_id, param_hash=phash, hit=hit)


@app.post(
    "/api/reports/{alv_id}/submit",
    response_model=SubmitOut,
    tags=["submit"],
)
def submit_report(
    alv_id: str,
    body: SubmitIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> SubmitOut:
    """Submit a report run: persist a request_log row, trigger the Job (7.1/7.2/7.4/7.5).

    Steps (all non-blocking — we never wait for the run, task 7.5):

    1. **7.1** Build the ``{param_name: value}`` Job payload from the submitted form,
       honoring each field's ``normalize`` / ``omit_if_blank`` / ``default``.
    2. **7.2** Canonicalize (stable key order) + SHA-256 → ``param_hash`` (cache key).
    3. **7.4** INSERT a ``QUEUED`` ``request_log`` row (app-generated ``request_no``,
       ``submitted_by`` from the SSO identity), then ``jobs run-now`` on the bound
       ``job_id`` and UPDATE the row with the returned ``run_id``.
    4. **7.5** Return ``request_no`` immediately.

    Errors:
        * ``404`` — unknown / inactive report, **or** one the caller is not permitted
          to see (``report_permissions``). Checked BEFORE anything is written or
          triggered, and before the job-binding check, so an unpermitted report cannot
          be distinguished from a non-existent one.
        * ``409`` — the report is not bound to a Job yet (``job_id`` NULL); the
          deploy-time job-binding step has not run (docs/APP_PREREQUISITES.md).
        * ``502`` — the request_log write or the run-now call failed.

    Task 7.3 (cache lookup) and status polling (8.x) are intentionally NOT done here.
    """
    report = cache.get(alv_id)
    if report is None or not report.is_active:
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")

    # Enforce visibility on the WRITE path too — hiding the card is not a control.
    _require_report_permission(request, settings, report, alv_id)

    if report.job_id is None:
        # Clean, actionable error rather than crashing on a NULL job_id (task 7.4).
        raise HTTPException(
            status_code=409,
            detail=(
                f"report '{alv_id}' is not bound to a job yet (job_id is NULL). "
                "Bind alv_catalog.job_id to the deployed job before submitting "
                "(see docs/APP_PREREQUISITES.md)."
            ),
        )

    # 7.1 — build the Job parameter payload from the field defs (server-side; never
    # trust the client to normalize/omit). Payload keys/values follow the D6 contract.
    payload = build_param_payload(report.fields, body.values or {})
    # 7.2 — canonical JSON (stable order) + SHA-256 hash (cache key with alv_id).
    canonical = canonical_param_json(payload)
    phash = param_hash(canonical)

    ident = resolve_identity(request, settings)
    request_no = _new_request_no()

    # 7.4a — persist the QUEUED row FIRST, so a triggered run is always traceable.
    try:
        insert_request_log(
            settings,
            request_no=request_no,
            alv_id=alv_id,
            submitted_by=_submitted_by(ident),
            param_payload_json=canonical,
            param_hash=phash,
        )
    except RequestLogError as exc:
        log.error("request_log insert failed for %s: %s", alv_id, exc)
        raise HTTPException(status_code=502, detail=f"could not record submission: {exc}")

    # 7.4b — trigger the Job (run-now). Job params must be string-valued; drop keys
    # whose value is None (blank + no default) so run-now doesn't get null strings.
    # We also pass request_no + alv_id for correlation (CONTRACT.md: "form values +
    # request_no"); the bound job declares these params (see the dummy job yml).
    job_parameters = {k: str(v) for k, v in payload.items() if v is not None}
    job_parameters["request_no"] = request_no
    job_parameters["alv_id"] = alv_id
    try:
        run_id = trigger_job_run(report.job_id, job_parameters)
    except JobTriggerError as exc:
        # The QUEUED row exists; surface the trigger failure. (A later task can mark
        # the row FAILED; for this pass we keep it QUEUED and report the error.)
        log.error("run-now failed for %s (job_id=%s): %s", alv_id, report.job_id, exc)
        raise HTTPException(status_code=502, detail=f"could not trigger job run: {exc}")

    # 7.4c — patch the row with the run_id (status stays QUEUED).
    try:
        update_run_id(settings, request_no=request_no, run_id=run_id)
    except RequestLogError as exc:
        # Non-fatal: the run is live and the row exists; log and still return the
        # request_no + run_id so the user can be given a handle.
        log.warning("request_log run_id update failed for %s: %s", request_no, exc)

    # 7.5 — return immediately (non-blocking).
    return SubmitOut(
        request_no=request_no,
        alv_id=alv_id,
        run_id=run_id,
        status="QUEUED",
        param_hash=phash,
    )


# --- Parameter templates (variants) ---------------------------------------------
def _require_template_access(
    request: Request, settings: Settings, cache: MetadataCache, alv_id: str
) -> str:
    """Gate a template call and return the caller's owner key.

    Applies the SAME two checks, in order, for every template endpoint:

    1. the report must exist AND be visible to the caller (``report_permissions``) — a
       user may not touch templates for a report he cannot see. **404, not 403**, exactly
       like every other report-scoped path, so existence is never disclosed;
    2. the caller must be identifiable (have an email) — templates are owned by email;
       an unidentifiable caller (local dev / misconfig) is refused with 404 too, so the
       template surface never leaks for an anonymous request.

    Returns:
        The owner key (the caller's lower-cased email) to bind into the owner-scoped SQL.

    Raises:
        HTTPException: 404 if the report is unknown/unpermitted or the caller has no email.
    """
    report = cache.get(alv_id)
    if report is None or not report.is_active:
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")
    _require_report_permission(request, settings, report, alv_id)

    ident = resolve_identity(request, settings)
    owner = owner_key(ident)
    if owner is None:
        # No email ⇒ no owner ⇒ nothing to show and nothing to write. Fail closed, and
        # keep it a 404 so the template surface is indistinguishable from "no report".
        log.info("template access denied for %s: caller has no email", alv_id)
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")
    return owner


def _report_now(settings: Settings) -> date:
    """Today's date in the configured report timezone (for resolving dynamic presets).

    Only this seam reads the clock; the resolver + validator take the date explicitly and
    stay pure. Falls back to UTC if the configured tz name is unusable, so a bad config
    never crashes a template call.
    """
    from datetime import datetime, timezone
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

    try:
        tz = ZoneInfo(settings.report_timezone)
    except (ZoneInfoNotFoundError, ValueError):
        log.warning("bad report_timezone %r; falling back to UTC", settings.report_timezone)
        tz = timezone.utc
    return datetime.now(tz).date()


@app.get(
    "/api/reports/{alv_id}/templates",
    response_model=TemplatesListOut,
    tags=["templates"],
)
def list_report_templates(
    alv_id: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> TemplatesListOut:
    """List the caller's saved templates for the WHOLE report (owner-scoped, no values).

    Report-wide: the entry point is one report type (``alv_id``), but the list spans every
    report type under that report's ``report_key`` — so a user sees all his templates for
    the report he opened, not just the one selection. Each row carries its own ``alv_id`` +
    selection / report-type labels so Load can jump to the right form.

    Values are fetched on load, not here (mirrors the parameters info-view pattern) so
    the list stays light. Gated by :func:`_require_template_access` (404 on
    unknown/unpermitted report or an unidentifiable caller). A warehouse failure degrades
    to an empty list rather than a 500, matching the catalogue/downloads paths.
    """
    owner = _require_template_access(request, settings, cache, alv_id)
    report = cache.get(alv_id)

    # Every runnable report type under this report_key (the report-wide scope), and a
    # label lookup so each template row can show its selection / report type. Restricted
    # to what this caller may see — visible_reports already applies the permission gate.
    siblings = [
        r for r in cache.visible_reports(settings, ident=resolve_identity(request, settings))
        if r.report_key == report.report_key
    ]
    labels = {
        r.alv_id: (r.selection_label or r.selection_id, r.report_type_label)
        for r in siblings
    }
    alv_ids = tuple(labels.keys())

    try:
        rows = list_templates_for_report(settings, alv_ids=alv_ids, owner=owner)
    except TemplateError as exc:
        log.error("template list failed for %s: %s (serving empty)", report.report_key, exc)
        rows = []

    out: list[TemplateSummaryOut] = []
    for r in rows:
        sel_label, rt_label = labels.get(r.alv_id, (None, None))
        out.append(
            TemplateSummaryOut(
                template_id=r.template_id,
                alv_id=r.alv_id,
                template_name=r.template_name,
                selection_label=sel_label,
                report_type_label=rt_label,
                created_at=r.created_at,
                updated_at=r.updated_at,
                is_dynamic=r.is_dynamic,
            )
        )
    return TemplatesListOut(alv_id=alv_id, templates=out)


@app.post(
    "/api/reports/{alv_id}/templates",
    response_model=TemplateSummaryOut,
    tags=["templates"],
)
def save_report_template(
    alv_id: str,
    body: SaveTemplateIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> TemplateSummaryOut:
    """Save (create or overwrite) a template of the current form values.

    Re-using an existing name for this report overwrites that template (upsert on
    ``(owner, alv_id, template_name)``). The stored values are the RAW form map — submit
    still re-derives the effective payload at run time. ``value_kinds`` marks which date
    fields are dynamic (relative-date presets).

    **Validated at save (decision 10), for BOTH static and dynamic templates.** The
    dynamic presets are resolved against the report-timezone "now", merged over the
    static values, and the result is run through the report's field validations. A
    template that would fail cannot be saved — this is the backend guard behind the
    modal's own client-side check.

    Errors:
        * ``404`` — unknown / unpermitted report, or an unidentifiable caller.
        * ``422`` — blank / over-long name, a malformed ``value_kinds`` map, **or** values
          that fail the report's validations (body carries a ``{param: message}`` map).
        * ``502`` — the warehouse write failed.
    """
    owner = _require_template_access(request, settings, cache, alv_id)
    report = cache.get(alv_id)  # present — _require_template_access already 404s otherwise

    # Parse + validate the dynamic-kinds map against this report's date fields.
    try:
        specs = parse_value_kinds(body.value_kinds or {}, report.fields)
    except DynamicValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    # Resolve dynamic presets against "now", merge over the static values, and run the
    # report's field validations. Refuse the save with the exact per-field messages.
    now = _report_now(settings)
    resolved = merged_values(body.values or {}, specs, now)
    field_errors = validate_values(report.fields, resolved, now)
    if field_errors:
        raise HTTPException(
            status_code=422,
            detail={"detail": "template values are not valid", "errors": field_errors},
        )

    try:
        template_id = save_template(
            settings,
            alv_id=alv_id,
            owner=owner,
            template_name=body.template_name,
            values=body.values or {},
            value_kinds=body.value_kinds or {},
        )
    except TemplateValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TemplateError as exc:
        log.error("template save failed for %s: %s", alv_id, exc)
        raise HTTPException(status_code=502, detail=f"could not save template: {exc}")
    return TemplateSummaryOut(
        template_id=template_id,
        alv_id=alv_id,
        template_name=body.template_name.strip(),
        is_dynamic=bool(specs),
    )


@app.get(
    "/api/reports/{alv_id}/templates/{template_id}",
    response_model=TemplateDetailOut,
    tags=["templates"],
)
def load_report_template(
    alv_id: str,
    template_id: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> TemplateDetailOut:
    """Load one of the caller's templates (with its values) to fill the form.

    Owner-scoped: a template that is not this caller's (or belongs to another report)
    reads as **404**, so an id guess can never reach someone else's template.

    Errors:
        * ``404`` — unknown / unpermitted report, unidentifiable caller, or no such
          template for this (owner, report).
        * ``502`` — the warehouse read failed.
    """
    owner = _require_template_access(request, settings, cache, alv_id)
    report = cache.get(alv_id)
    try:
        detail = get_template(settings, alv_id=alv_id, owner=owner, template_id=template_id)
    except TemplateError as exc:
        log.error("template load failed for %s/%s: %s", alv_id, template_id, exc)
        raise HTTPException(status_code=502, detail=f"could not load template: {exc}")
    if detail is None:
        raise HTTPException(status_code=404, detail=f"template not found: {template_id}")

    # Resolve dynamic (relative-date) presets against "now", merged over the saved static
    # values, so the frontend receives concrete dates it can drop straight into the form.
    # A malformed stored value_kinds map degrades to "all static" rather than 500-ing a load.
    try:
        specs = parse_value_kinds(detail.value_kinds or {}, report.fields)
        values = merged_values(detail.values, specs, _report_now(settings))
    except DynamicValueError as exc:
        log.warning("template %s has an unresolvable value_kinds map: %s", template_id, exc)
        values = detail.values
    return TemplateDetailOut(
        template_id=detail.template_id,
        alv_id=detail.alv_id,
        template_name=detail.template_name,
        values=values,
        value_kinds=detail.value_kinds,
    )


@app.post(
    "/api/reports/{alv_id}/templates/{template_id}/rename",
    response_model=TemplateSummaryOut,
    tags=["templates"],
)
def rename_report_template(
    alv_id: str,
    template_id: str,
    body: RenameTemplateIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> TemplateSummaryOut:
    """Rename one of the caller's templates in place.

    Errors:
        * ``404`` — unknown / unpermitted report, unidentifiable caller, or no such
          template for this (owner, report).
        * ``422`` — blank / over-long name, or a name already used by another of this
          user's templates for this report.
        * ``502`` — the warehouse write failed.
    """
    owner = _require_template_access(request, settings, cache, alv_id)
    try:
        ok = rename_template(
            settings,
            alv_id=alv_id,
            owner=owner,
            template_id=template_id,
            new_name=body.template_name,
        )
    except TemplateValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except TemplateError as exc:
        log.error("template rename failed for %s/%s: %s", alv_id, template_id, exc)
        raise HTTPException(status_code=502, detail=f"could not rename template: {exc}")
    if not ok:
        raise HTTPException(status_code=404, detail=f"template not found: {template_id}")
    return TemplateSummaryOut(
        template_id=template_id, alv_id=alv_id, template_name=body.template_name.strip()
    )


@app.delete("/api/reports/{alv_id}/templates/{template_id}", tags=["templates"])
def delete_report_template(
    alv_id: str,
    template_id: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> dict[str, str]:
    """Delete (soft-delete) one of the caller's templates.

    Owner-scoped, so it can only ever remove the caller's own row; a bad / foreign id is
    a harmless no-op (nothing matches). Returns ``{"status": "deleted"}``.

    Errors:
        * ``404`` — unknown / unpermitted report, or an unidentifiable caller.
        * ``502`` — the warehouse write failed.
    """
    owner = _require_template_access(request, settings, cache, alv_id)
    try:
        delete_template(settings, alv_id=alv_id, owner=owner, template_id=template_id)
    except TemplateError as exc:
        log.error("template delete failed for %s/%s: %s", alv_id, template_id, exc)
        raise HTTPException(status_code=502, detail=f"could not delete template: {exc}")
    return {"status": "deleted"}


@app.post("/api/reports/{alv_id}/preview", response_model=PreviewOut, tags=["preview"])
def preview_report(
    alv_id: str,
    body: PreviewIn,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> PreviewOut:
    """Run sample-data preview query (sample data preview feature).

    Executes a **parameterized** SELECT against ``retail_ledger_sample`` as the App
    service principal, honouring the ``sample_query`` block in the report's
    ``input_fields_json``. Only ``param_name`` s declared in the spec are bound —
    any unknown keys in ``body.values`` are ignored. Results are capped at
    ``min(default_limit, 500)`` rows.

    An INFO audit line records every dispatch (``alv_id``, submitting identity if
    resolvable, bound-param count, and returned row count) — never the raw user
    values.

    Errors:
        * ``404`` — unknown / inactive report, **or** one the caller is not permitted
          to see (``report_permissions``). Checked before the query is built, so an
          unpermitted report can never leak data through the preview.
        * ``409`` — the report has no ``sample_query`` block defined.
        * ``502`` — the warehouse query failed.
    """
    report = cache.get(alv_id)
    if report is None or not report.is_active:
        raise HTTPException(status_code=404, detail=f"report not found: {alv_id}")
    # Preview returns real rows, so it is gated exactly like submit (404, not 403).
    _require_report_permission(request, settings, report, alv_id)
    if report.sample_query is None:
        raise HTTPException(
            status_code=409,
            detail=f"report '{alv_id}' has no sample query defined.",
        )
    # Resolve the submitting identity for the audit trail (degrades to None locally).
    try:
        submitted_by = _submitted_by(resolve_identity(request, settings))
    except Exception:  # noqa: BLE001 - identity is best-effort for the audit line only
        submitted_by = None
    try:
        result = run_preview(settings, report.sample_query, body.values or {})
    except PreviewError as exc:
        log.error("preview query failed for %s: %s", alv_id, exc)
        raise HTTPException(status_code=502, detail=f"preview query failed: {exc}")
    log.info(
        "preview served: alv_id=%s submitted_by=%s bound_params=%d row_count=%d",
        alv_id,
        submitted_by,
        result.get("bound_param_count", 0),
        result["row_count"],
    )
    return PreviewOut(
        columns=result["columns"],
        rows=result["rows"],
        row_count=result["row_count"],
        truncated=result["truncated"],
    )


@app.get("/api/requests", response_model=RequestsOut, tags=["downloads"])
def list_requests(
    request: Request,
    scope: str | None = None,
    q: str | None = None,
    sort: str | None = None,
    limit: int | None = None,
    offset: int = 0,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> RequestsOut:
    """Return one filtered, searched, sorted, paginated page of ``request_log`` rows.

    Reads the App-owned ``request_log`` via the SAME warehouse-statement seam as the
    catalogue/submit paths (as the app SP). A warehouse failure degrades to an empty
    page rather than a 500, matching the catalogue.

    **All narrowing happens in SQL, before the limit** (:mod:`alv_app.downloads`), so
    this is a genuine page of the whole matching set. The earlier shape — ``LIMIT 100``
    then a Python filter — could return fewer than a page with no way to reach page 2,
    and would only ever have searched the newest 100 rows across all users.

    Query parameters (all optional, all server-validated):
        scope: ``accessible`` (DEFAULT — every row for a report this caller may see,
            *including other users' rows*, which is intended: cross-user visibility is
            granted by the report permission) or ``mine`` (only rows this caller
            submitted, matched across their email / preferred_username / user_id since
            ``submitted_by``'s form has varied over time).
        q: free-text search on the REPORT NAME. The label lives in the metadata cache,
            not in ``request_log``, so it is resolved to an ``alv_id`` allowlist here
            and filtered in SQL — never client-side
            (:meth:`MetadataCache.listable_alv_ids`).
        sort: a key of the fixed allowlist (``submitted_at_desc`` default /
            ``submitted_at_asc``). Unknown values fall back to the default.
        limit: page size (default ``downloads_page_size``, clamped to
            ``downloads_max_page_size``).
        offset: rows to skip.

    Report visibility is enforced by that same ``alv_id`` allowlist, in EVERY scope: a
    row whose report the caller may not see, or whose ``alv_id`` no longer resolves in
    the catalogue, cannot match it (fail closed — consistent with the per-request gate,
    which denies what it cannot attribute to a report). An empty allowlist serves an
    empty page WITHOUT running a broad query.
    """
    ident = resolve_identity(request, settings)
    query = build_request_query(
        cache, settings, ident, scope=scope, q=q, sort=sort, limit=limit, offset=offset
    )

    try:
        page = fetch_requests_page(settings, query)
    except DownloadsSourceError as exc:
        log.error("request_log read failed (serving empty): %s", exc)
        page = RequestPage(rows=[], has_more=False)

    requests: list[RequestOut] = []
    for row in page.rows:
        alv_id = row.get("alv_id")
        report = cache.get(str(alv_id)) if alv_id is not None else None
        # Prefer the report label; fall back to alv_name, else None (FE shows alv_id).
        label = None
        if report is not None:
            label = report.report_label or report.alv_name
        requests.append(
            RequestOut(
                request_no=str(row.get("request_no")),
                alv_id=str(alv_id) if alv_id is not None else None,
                report_label=label,
                status=_as_str(row.get("status")),
                submitted_by=_as_str(row.get("submitted_by")),
                submitted_at=_as_str(row.get("submitted_at")),
                run_id=row.get("run_id"),  # type: ignore[arg-type]
                output_path=_as_str(row.get("output_path")),
            )
        )
    return RequestsOut(
        requests=requests,
        limit=query.limit,
        offset=query.offset,
        has_more=page.has_more,
        scope=query.scope,
        sort=query.sort,
        q=(q or "").strip() or None,
    )


def build_request_query(
    cache: MetadataCache,
    settings: Settings,
    ident,
    *,
    scope: str | None,
    q: str | None,
    sort: str | None,
    limit: int | None,
    offset: int,
) -> RequestQuery:
    """Resolve raw query-string values into a validated :class:`RequestQuery`.

    The trust boundary for the Downloads list: nothing downstream sees a raw client
    value. ``scope``/``sort`` are mapped onto fixed vocabularies (unknown ⇒ default),
    ``limit`` is clamped to the configured maximum, ``offset`` is floored at 0, and the
    report filter + search are resolved to a concrete ``alv_id`` allowlist from the
    permission-aware cache. Pure apart from the cache read, so it is unit-testable.
    """
    return RequestQuery(
        alv_ids=cache.listable_alv_ids(settings, ident, search=q),
        identities=identity_match_values(ident),
        scope=normalize_scope(scope),
        sort=normalize_sort(sort),
        limit=clamp_limit(settings, limit),
        offset=max(0, int(offset or 0)),
    )


@app.get(
    "/api/requests/{request_no}/params",
    response_model=RequestParamsOut,
    tags=["downloads"],
)
def get_request_params(
    request_no: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> RequestParamsOut:
    """Return the parameters one run was dispatched with (the info view).

    A DEDICATED endpoint rather than an extra column on every list row: the payload is
    unbounded free text, only ever wanted for the one row a user expands, and keeping
    it off the list keeps the page query cheap and its response small.

    Gated by the SAME :func:`_require_request_permission` as the status and download
    paths — parameters are as sensitive as the file they produced — so a request whose
    report the caller may not see returns **404**, identical in shape to a missing one.

    What is returned is ``param_payload_json``: the **effective job payload**
    (server-normalized, ``omit_if_blank`` params absent). It is what the Job received,
    not a transcript of the user's typing, and the UI labels it accordingly.

    Errors:
        * ``404`` — no such request, the row was unreadable, **or** its report is one
          the caller may not see.

    A null / empty / malformed payload is NOT an error: the response carries
    ``parse_ok=false`` with an empty ``parameters`` map and a ``detail`` hint, so an old
    or half-written row can never 500 the info view.
    """
    try:
        row = fetch_request_params(settings, request_no)
    except DownloadsSourceError as exc:
        log.error("request_log read failed for %s (params): %s", request_no, exc)
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    if row is None:
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    _require_request_permission(request, settings, cache, row, request_no)

    alv_id = _as_str(row.get("alv_id"))
    report = cache.get(alv_id) if alv_id else None
    label = (report.report_label or report.alv_name) if report is not None else None

    parameters, parse_ok, detail = _parse_param_payload(row.get("param_payload_json"))
    return RequestParamsOut(
        request_no=request_no,
        alv_id=alv_id,
        report_label=label,
        submitted_at=_as_str(row.get("submitted_at")),
        param_hash=_as_str(row.get("param_hash")),
        parameters=parameters,
        parse_ok=parse_ok,
        detail=detail,
    )


def _parse_param_payload(
    raw: object,
) -> tuple[dict[str, str | None], bool, str | None]:
    """Parse ``param_payload_json`` defensively into a flat ``{name: value}`` map.

    ``param_payload_json`` is a free-text STRING column written by an earlier version
    of the App (and NULL on the oldest rows), so every failure mode degrades to an
    empty map + a reason rather than an exception:

    * NULL / empty / whitespace ⇒ "no parameters recorded";
    * not valid JSON ⇒ "unreadable";
    * valid JSON but not an object (a list, a bare number) ⇒ "unexpected shape".

    Values are stringified for display (``None`` is preserved so the UI can render a
    blank-but-sent parameter honestly); nested objects/arrays are JSON-rendered rather
    than dropped.

    Returns:
        ``(parameters, parse_ok, detail)`` — ``detail`` is None on success.
    """
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return {}, False, "no parameters were recorded for this run."

    try:
        parsed = json.loads(raw) if isinstance(raw, str) else raw
    except (ValueError, TypeError):
        return {}, False, "the recorded parameters could not be read."

    if not isinstance(parsed, dict):
        return {}, False, "the recorded parameters were not in the expected shape."

    out: dict[str, str | None] = {}
    for key, value in parsed.items():
        if value is None:
            out[str(key)] = None
        elif isinstance(value, (str, int, float, bool)):
            out[str(key)] = str(value)
        else:
            # Nested structure — render it rather than hide it.
            try:
                out[str(key)] = json.dumps(value, ensure_ascii=False)
            except (TypeError, ValueError):
                out[str(key)] = str(value)
    return out, True, None


def _require_request_permission(
    request: Request,
    settings: Settings,
    cache: MetadataCache,
    row: dict[str, object],
    request_no: str,
) -> None:
    """Raise 404 unless the caller may see the report behind a ``request_log`` row.

    The status / download paths are keyed by ``request_no``, not ``alv_id``, so the
    report identity comes from the row: ``alv_id`` → the cached report → its
    ``report_key`` → the ``report_permissions`` gate. Same **404, not 403** rule as
    :func:`_require_report_permission`.

    A row whose ``alv_id`` no longer resolves in the catalogue (deleted / renamed
    report) is DENIED: we cannot establish which report it belongs to, and failing
    closed is the safe direction for a security control.

    Raises:
        HTTPException: 404 when the request's report is not permitted.
    """
    alv_id = _as_str(row.get("alv_id"))
    report = cache.get(alv_id) if alv_id else None
    if report is None:
        log.warning(
            "denying request %s: its alv_id (%s) does not resolve to a known report",
            request_no,
            alv_id,
        )
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    ident = resolve_identity(request, settings)
    if not is_report_permitted(settings, ident, report.report_key):
        log.info(
            "denied request %s (alv_id=%s report_key=%s) for %s",
            request_no,
            alv_id,
            report.report_key,
            _submitted_by(ident),
        )
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")


@app.get(
    "/api/requests/{request_no}/status",
    response_model=RequestStatusOut,
    tags=["downloads"],
)
def get_request_status(
    request_no: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> RequestStatusOut:
    """Return the live status for one request, advancing request_log if it changed (8.x/9.x).

    Looks up the row's ``run_id`` + stored ``status``/``output_path`` (targeted read),
    reads the live Job run state, and — if it differs from the stored status — UPDATEs
    ``request_log`` before returning the current value.

    Output capture (task 9.x) is folded into THIS 8.x seam rather than a parallel
    mechanism: when the run resolves to ``SUCCESS`` and no ``output_path`` has been
    captured yet, we fetch the Job's returned pointer (CONTRACT mechanism (a) —
    :func:`get_run_output`) and persist ``output_path``/``row_count``/``generated_at``
    with status ``COMPLETED``. A truncated / missing / ``FAILED`` payload is handled
    gracefully — ``output_path`` stays NULL and the status reflects failure.

    Degrades gracefully throughout: if the row is missing, ``run_id`` is NULL, or the
    run state / output can't be read, the stored value is returned unchanged (never a
    500). A request whose report the caller may not see returns **404**, like a missing
    one — the status of an unpermitted report is not disclosed.
    """
    try:
        row = fetch_request(settings, request_no)
    except DownloadsSourceError as exc:
        # Can't even read the row — nothing to report; surface as 404-ish empty.
        log.error("request_log read failed for %s (status poll): %s", request_no, exc)
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    if row is None:
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    _require_request_permission(request, settings, cache, row, request_no)

    stored_status = _as_str(row.get("status"))
    stored_output_path = _as_str(row.get("output_path"))
    run_id = row.get("run_id")

    # No run bound yet (or unreadable id) ⇒ keep the stored status.
    if run_id is None:
        return RequestStatusOut(
            request_no=request_no,
            status=stored_status,
            run_id=None,
            updated=False,
            output_path=stored_output_path,
        )

    run_id = int(run_id)  # type: ignore[arg-type]
    live = get_run_status(run_id)
    # Run state unreadable (degrade) ⇒ keep the stored status.
    if not live.ok or live.status is None:
        if live.detail:
            log.info("status poll for %s kept stored status: %s", request_no, live.detail)
        return RequestStatusOut(
            request_no=request_no,
            status=stored_status,
            run_id=run_id,
            updated=False,
            output_path=stored_output_path,
        )

    # SUCCESS ⇒ capture the output pointer (9.x) and settle the row to COMPLETED /
    # FAILED. Success maps to our COMPLETED vocabulary (request_log), not "SUCCESS".
    if live.status == "SUCCESS":
        return _resolve_success_output(
            settings, request_no, run_id, stored_status, stored_output_path
        )

    # Non-terminal / failure states: advance the stored status when it changed.
    if live.status != stored_status:
        try:
            update_status(settings, request_no=request_no, status=live.status)
        except RequestLogError as exc:
            # Non-fatal: report the live status even if the write didn't land.
            log.warning("request_log status update failed for %s: %s", request_no, exc)
            return RequestStatusOut(
                request_no=request_no,
                status=live.status,
                run_id=run_id,
                updated=False,
                output_path=stored_output_path,
            )
        return RequestStatusOut(
            request_no=request_no,
            status=live.status,
            run_id=run_id,
            updated=True,
            output_path=stored_output_path,
        )

    return RequestStatusOut(
        request_no=request_no,
        status=stored_status,
        run_id=run_id,
        updated=False,
        output_path=stored_output_path,
    )


def _resolve_success_output(
    settings: Settings,
    request_no: str,
    run_id: int,
    stored_status: str | None,
    stored_output_path: str | None,
) -> RequestStatusOut:
    """Settle a SUCCESS run into COMPLETED (+ output pointer) or FAILED (task 9.x).

    Fits output-capture into the 8.x status seam: once already captured
    (``output_path`` present) it just normalizes the stored status to ``COMPLETED``;
    otherwise it reads the Job's returned pointer (:func:`get_run_output`) and persists
    it. A truncated / missing / ``FAILED`` payload degrades to status ``FAILED`` with
    ``output_path`` left NULL (never crashes). Any warehouse write failure is
    non-fatal — the resolved value is still returned.
    """
    # Already captured on an earlier poll ⇒ ensure the stored status reads COMPLETED.
    if stored_output_path:
        if stored_status != "COMPLETED":
            updated = _persist_status(settings, request_no, "COMPLETED")
            return RequestStatusOut(
                request_no=request_no,
                status="COMPLETED",
                run_id=run_id,
                updated=updated,
                output_path=stored_output_path,
            )
        return RequestStatusOut(
            request_no=request_no,
            status="COMPLETED",
            run_id=run_id,
            updated=False,
            output_path=stored_output_path,
        )

    out = get_run_output(run_id)
    # A usable pointer (readable, has a path, payload not FAILED) ⇒ COMPLETED.
    if out.ok and out.output_path and (out.status or "COMPLETED").upper() != "FAILED":
        try:
            update_status(
                settings,
                request_no=request_no,
                status="COMPLETED",
                output_path=out.output_path,
                row_count=out.row_count,
                generated_at=out.generated_at,
            )
        except RequestLogError as exc:
            log.warning("request_log output capture failed for %s: %s", request_no, exc)
            return RequestStatusOut(
                request_no=request_no,
                status="COMPLETED",
                run_id=run_id,
                updated=False,
                output_path=out.output_path,
            )
        return RequestStatusOut(
            request_no=request_no,
            status="COMPLETED",
            run_id=run_id,
            updated=True,
            output_path=out.output_path,
        )

    # Truncated / missing / FAILED payload ⇒ reflect failure, output_path stays NULL.
    log.info("output capture for %s reflected failure: %s", request_no, out.detail or out.status)
    updated = False
    if stored_status != "FAILED":
        updated = _persist_status(settings, request_no, "FAILED")
    return RequestStatusOut(
        request_no=request_no,
        status="FAILED",
        run_id=run_id,
        updated=updated,
        output_path=None,
    )


def _persist_status(settings: Settings, request_no: str, status: str) -> bool:
    """UPDATE the row's status alone; return whether the write landed (non-fatal)."""
    try:
        update_status(settings, request_no=request_no, status=status)
        return True
    except RequestLogError as exc:
        log.warning("request_log status update failed for %s: %s", request_no, exc)
        return False


def _content_type_for(filename: str) -> str:
    """Pick a sensible Content-Type from the filename (CSV common; else opaque)."""
    lower = filename.lower()
    if lower.endswith(".csv"):
        return "text/csv"
    if lower.endswith(".json"):
        return "application/json"
    if lower.endswith((".txt", ".tsv")):
        return "text/plain"
    if lower.endswith((".parquet", ".pq")):
        return "application/octet-stream"
    return "application/octet-stream"


@app.get("/api/requests/{request_no}/download", tags=["downloads"])
def download_request_output(
    request_no: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> StreamingResponse:
    """Stream a completed run's output file to the browser, App-proxied (task 9.x §4.2).

    Looks up the request_log row; if it carries an ``output_path`` on a UC Volume
    (``/Volumes/...``) the App reads the bytes via the Files API using its OWN service
    principal (:func:`download_volume_file`) and streams them back as an attachment —
    NOT a direct storage URL (§4.2: the App is the AuthZ chokepoint; no cloud creds in
    the browser). Only the derived filename is exposed to the client, never the raw
    storage path.

    Errors:
        * ``404`` — no such request, the row was unreadable, **or** the request's
          report is one the caller may not see (``report_permissions``). Checked before
          any byte is read, so an unpermitted report's output can never be streamed.
        * ``409`` — the run has no output yet (``output_path`` NULL — still running,
          failed, or not a completed run).
        * ``422`` — the stored ``output_path`` is not a supported UC Volume path.
        * ``502`` — the Volume file read failed.
    """
    try:
        row = fetch_request(settings, request_no)
    except DownloadsSourceError as exc:
        log.error("request_log read failed for %s (download): %s", request_no, exc)
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    if row is None:
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    _require_request_permission(request, settings, cache, row, request_no)

    output_path = _as_str(row.get("output_path"))
    if not output_path:
        raise HTTPException(
            status_code=409,
            detail=(
                f"no output available for request {request_no} yet "
                "(the run has not produced a downloadable file)."
            ),
        )

    # §4.2: this pilot serves UC Volume files. A non-Volume path (raw ADLS/NAS) is not
    # proxied here — reject clearly rather than leaking the storage layout.
    if not output_path.startswith("/Volumes/"):
        raise HTTPException(
            status_code=422,
            detail="output is not on a Unity Catalog Volume; download not supported.",
        )

    # Derive the download filename from the path (never expose the full storage path).
    filename = posixpath.basename(output_path) or "download"

    try:
        contents = download_volume_file(output_path)
    except VolumeDownloadError as exc:
        log.error("volume download failed for %s: %s", request_no, exc)
        raise HTTPException(status_code=502, detail="could not read the output file.")

    def _iter():
        # Stream in chunks so a large export never buffers fully in the App tier.
        try:
            while True:
                chunk = contents.read(1024 * 1024)
                if not chunk:
                    break
                yield chunk
        finally:
            close = getattr(contents, "close", None)
            if callable(close):
                close()

    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return StreamingResponse(
        _iter(), media_type=_content_type_for(filename), headers=headers
    )


@app.get(
    "/api/requests/{request_no}/output-preview",
    response_model=OutputPreviewOut,
    tags=["downloads"],
)
def preview_request_output(
    request_no: str,
    request: Request,
    cache: MetadataCache = Depends(get_cache),
    settings: Settings = Depends(get_settings),
) -> OutputPreviewOut:
    """Show the first rows of a completed run's OUTPUT FILE on-screen (no download).

    The read-only, on-screen twin of :func:`download_request_output`: it reads the same
    ``request_log.output_path`` off the same UC Volume as the same App SP, but returns a
    small **parsed, capped** preview instead of streaming the file. This runs **no SQL**
    — contrast :func:`preview_report` (``/preview``), which queries a sample table.

    Bounded twice so a 1,000,000-row export never buffers in the App tier: at most
    ``output_preview_max_bytes`` are read off the Volume, and at most
    ``output_preview_max_rows`` are returned; ``truncated`` reports either cap biting,
    and the raw file bytes never reach the browser — only parsed rows do.

    Gated by the SAME :func:`_require_request_permission` as status / params / download
    (**404** on deny), and the SAME output guards:

    Errors:
        * ``404`` — no such request, the row was unreadable, **or** the request's report
          is one the caller may not see. Checked before any byte is read.
        * ``409`` — the run has no output yet (``output_path`` NULL).
        * ``422`` — the stored ``output_path`` is not a supported UC Volume path.
        * ``502`` — the Volume file read failed.
    """
    try:
        row = fetch_request(settings, request_no)
    except DownloadsSourceError as exc:
        log.error("request_log read failed for %s (output-preview): %s", request_no, exc)
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    if row is None:
        raise HTTPException(status_code=404, detail=f"request not found: {request_no}")

    _require_request_permission(request, settings, cache, row, request_no)

    output_path = _as_str(row.get("output_path"))
    if not output_path:
        raise HTTPException(
            status_code=409,
            detail=(
                f"no output available for request {request_no} yet "
                "(the run has not produced a previewable file)."
            ),
        )

    if not output_path.startswith("/Volumes/"):
        raise HTTPException(
            status_code=422,
            detail="output is not on a Unity Catalog Volume; preview not supported.",
        )

    filename = posixpath.basename(output_path) or "output"

    try:
        data, byte_truncated = read_volume_prefix(
            output_path, settings.output_preview_max_bytes
        )
    except VolumeDownloadError as exc:
        log.error("volume preview read failed for %s: %s", request_no, exc)
        raise HTTPException(status_code=502, detail="could not read the output file.")

    preview = build_output_preview(
        data, byte_truncated, filename, settings.output_preview_max_rows
    )
    # Audit line: what was previewed and its shape, never the file contents.
    log.info(
        "output-preview %s: format=%s rows=%d truncated=%s file=%s",
        request_no,
        preview["format"],
        preview["row_count"],
        preview["truncated"],
        filename,
    )
    return OutputPreviewOut(**preview)


def _as_str(v: object) -> str | None:
    """Coerce a warehouse cell to str, or None (empty/NULL stays None)."""
    if v is None or v == "":
        return None
    return str(v)


# --- Static SPA shell -----------------------------------------------------------
# In production on Databricks Apps the FastAPI backend serves BOTH the API and the
# built React frontend. The frontend build (Vite) is emitted to `static/` next to
# the `alv_app` package (see src/alv-frontend/frontend/vite.config.ts `outDir`), which sits at
# the deploy source root (src/alv-frontend/backend/) alongside app.yaml. Resolve it robustly
# relative to this file so it works regardless of the process working directory.
#
# This mount MUST come AFTER the /api routes so those keep resolving; StaticFiles
# with html=True serves index.html at "/" and lets the SPA handle client routing.
_STATIC_DIR = Path(__file__).resolve().parent.parent / "static"

if (_STATIC_DIR / "index.html").is_file():
    app.mount("/", StaticFiles(directory=_STATIC_DIR, html=True), name="spa")
