"""ALV-Bricks Databricks App backend package (thin FastAPI scaffold)."""

from .main import app

__all__ = ["app"]
