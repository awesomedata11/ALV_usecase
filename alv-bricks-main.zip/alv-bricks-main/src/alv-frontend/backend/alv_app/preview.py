"""Sample-data preview query builder and executor (sample data preview feature).

This module runs a **user-shaped** SELECT against the shared dummy table
``retail_ledger_sample`` as the App service principal. Because the WHERE clause is
stitched from user-supplied form values, the whole module is written defensively:

* the table name is **hardcoded** and backtick-quoted from trusted settings —
  never taken from the request;
* every projected / filtered ``column_name`` is validated against a strict
  identifier allowlist at parse time (:data:`_IDENTIFIER_RE`);
* user *values* are **never** interpolated into the SQL text — they are carried as
  bound parameters (``:name`` markers + a :class:`StatementParameterListItem`
  list), so quotes / semicolons in a value can never change the query shape.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from .fields import SpecError
from .config import Settings

log = logging.getLogger("alv_reports.preview")

VALID_OPERATORS = {"=", ">=", "<=", "IN"}

# Strict SQL identifier allowlist for every column_name (defence in depth: the
# spec is trusted config, but a preview is data-exposing so we validate anyway).
_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Cap the number of elements a single IN (...) filter may expand to, so a user
# cannot force an unbounded parameter list by pasting thousands of comma-values.
_MAX_IN_ELEMENTS = 200

# Values that look like an ISO date (YYYY-MM-DD) are bound with SQL type DATE for
# a >= / <= range param; everything else binds as STRING (Spark implicit-casts).
_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class PreviewError(RuntimeError):
    """Raised when the preview warehouse query fails."""


@dataclass
class ColumnDef:
    """A column to include in the preview SELECT list.

    Attributes:
        display_name: Human-readable column header shown in the UI.
        column_name: Actual column name in the warehouse table.
    """

    display_name: str
    column_name: str


@dataclass
class ParamMapping:
    """Maps a form parameter to a WHERE-clause condition.

    Attributes:
        param_name: Key used in the submitted form values dict.
        column_name: Warehouse column to filter on.
        operator: SQL comparison operator; one of ``=``, ``>=``, ``<=``, ``IN``.
    """

    param_name: str
    column_name: str
    operator: str  # "=", ">=", "<=", "IN"


@dataclass
class SampleQuerySpec:
    """Parsed, validated representation of a ``sample_query`` block.

    Attributes:
        columns: Ordered list of columns to SELECT.
        param_mappings: Ordered list of WHERE-clause bindings.
        default_limit: Maximum rows to return (capped at 500 at query time).
    """

    columns: list[ColumnDef]
    param_mappings: list[ParamMapping]
    default_limit: int = 100


def parse_sample_query(blob: object) -> SampleQuerySpec | None:
    """Parse a raw ``sample_query`` dict into a :class:`SampleQuerySpec`.

    Args:
        blob: The value of ``input_fields_json["sample_query"]``, or ``None`` when
            the block is absent.

    Returns:
        A fully-validated :class:`SampleQuerySpec`, or ``None`` when *blob* is
        ``None`` (the report has no sample query).

    Raises:
        SpecError: If *blob* is present but violates the contract: missing or empty
            ``columns``/``param_mappings``, an unsupported operator, or a
            ``column_name`` that is not a strict SQL identifier
            (``^[A-Za-z_][A-Za-z0-9_]*$``).
    """
    if blob is None:
        return None

    if not isinstance(blob, dict):
        raise SpecError("sample_query must be a JSON object.")

    # --- columns ---------------------------------------------------------------
    raw_cols = blob.get("columns")
    if not isinstance(raw_cols, list) or not raw_cols:
        raise SpecError("sample_query.columns must be a non-empty array.")

    columns: list[ColumnDef] = []
    for i, c in enumerate(raw_cols):
        if not isinstance(c, dict):
            raise SpecError(f"sample_query.columns[{i}]: must be an object.")
        display_name = c.get("display_name")
        column_name = c.get("column_name")
        if not display_name or not isinstance(display_name, str):
            raise SpecError(f"sample_query.columns[{i}]: requires a non-empty display_name.")
        if not column_name or not isinstance(column_name, str):
            raise SpecError(f"sample_query.columns[{i}]: requires a non-empty column_name.")
        _require_identifier(column_name, f"sample_query.columns[{i}].column_name")
        columns.append(ColumnDef(display_name=display_name, column_name=column_name))

    # --- param_mappings --------------------------------------------------------
    raw_mappings = blob.get("param_mappings")
    if not isinstance(raw_mappings, list) or not raw_mappings:
        raise SpecError("sample_query.param_mappings must be a non-empty array.")

    param_mappings: list[ParamMapping] = []
    for i, m in enumerate(raw_mappings):
        if not isinstance(m, dict):
            raise SpecError(f"sample_query.param_mappings[{i}]: must be an object.")
        param_name = m.get("param_name")
        column_name = m.get("column_name")
        operator = m.get("operator")
        if not param_name or not isinstance(param_name, str):
            raise SpecError(
                f"sample_query.param_mappings[{i}]: requires a non-empty param_name."
            )
        if not column_name or not isinstance(column_name, str):
            raise SpecError(
                f"sample_query.param_mappings[{i}]: requires a non-empty column_name."
            )
        _require_identifier(column_name, f"sample_query.param_mappings[{i}].column_name")
        if operator not in VALID_OPERATORS:
            raise SpecError(
                f"sample_query.param_mappings[{i}]: unsupported operator {operator!r} "
                f"(valid: {sorted(VALID_OPERATORS)})."
            )
        param_mappings.append(
            ParamMapping(param_name=param_name, column_name=column_name, operator=operator)
        )

    default_limit = blob.get("default_limit", 100)
    try:
        default_limit = int(default_limit)
    except (TypeError, ValueError):
        default_limit = 100

    return SampleQuerySpec(
        columns=columns,
        param_mappings=param_mappings,
        default_limit=default_limit,
    )


def _require_identifier(name: str, where: str) -> None:
    """Raise :class:`SpecError` unless *name* is a strict SQL identifier.

    Args:
        name: The candidate column name to validate.
        where: Location label for the error message.

    Raises:
        SpecError: If *name* does not match ``^[A-Za-z_][A-Za-z0-9_]*$``.
    """
    if not _IDENTIFIER_RE.match(name):
        raise SpecError(
            f"{where}: {name!r} is not a valid SQL identifier "
            "(allowed: ^[A-Za-z_][A-Za-z0-9_]*$)."
        )


@dataclass
class BoundParam:
    """One bound query parameter (``:name`` marker → typed value).

    Attributes:
        name: The bind marker name (without the leading ``:``).
        value: The value to bind (always carried as a string; Spark casts).
        type: SQL type hint — ``"STRING"`` or ``"DATE"``.
    """

    name: str
    value: str
    type: str = "STRING"


def _bind_type_for(operator: str, value: str) -> str:
    """Pick a bind type: DATE for ISO-looking range values, else STRING.

    Args:
        operator: The mapping operator (``>=``/``<=`` are date-range candidates).
        value: The raw user value.

    Returns:
        ``"DATE"`` when *operator* is a range op and *value* looks like
        ``YYYY-MM-DD``; otherwise ``"STRING"`` (the safe implicit-cast fallback).
    """
    if operator in (">=", "<=") and _ISO_DATE_RE.match(value.strip()):
        return "DATE"
    return "STRING"


def build_preview_sql(
    spec: SampleQuerySpec,
    values: dict[str, str],
    catalog: str,
    schema: str,
) -> tuple[str, list[BoundParam], list[str]]:
    """Build a **parameterized** SELECT for the preview query.

    User values are NEVER interpolated into the SQL text — they are emitted as
    ``:name`` bind markers and returned as a :class:`BoundParam` list, so a value
    containing quotes / semicolons can never alter the query shape. Only trusted,
    identifier-validated column names and the hardcoded table are placed inline.

    Args:
        spec: The validated :class:`SampleQuerySpec` for the report.
        values: Raw form values keyed by ``param_name``; blank / whitespace-only
            values are skipped (no condition), and unknown keys are ignored (only
            ``param_name`` s present in the spec are bound).
        catalog: Unity Catalog catalog name (e.g. ``classic_stable_lakebase_catalog``).
        schema: Unity Catalog schema name (e.g. ``alv_metadata``).

    Returns:
        A ``(sql_string, params, column_names)`` tuple: *params* is the ordered
        list of :class:`BoundParam` s to pass to the statement API, and
        *column_names* lists every projected ``column_name`` (spec order).

    Raises:
        SpecError: If an ``IN`` filter expands to more than ``_MAX_IN_ELEMENTS``
            elements (a caller-controlled explosion guard).
    """
    # Explicit, backtick-quoted projection — never SELECT *. Column names were
    # identifier-validated at parse time; backtick-quote them defensively anyway.
    col_names = [col.column_name for col in spec.columns]
    select_clause = ", ".join(f"`{c}`" for c in col_names)
    table = f"`{catalog}`.`{schema}`.`retail_ledger_sample`"
    limit = min(spec.default_limit, 500)

    conditions: list[str] = []
    params: list[BoundParam] = []
    pidx = 0  # monotonic index → unique bind names across all conditions
    for pm in spec.param_mappings:
        val = values.get(pm.param_name, "")
        if not isinstance(val, str) or val.strip() == "":
            continue

        col = f"`{pm.column_name}`"
        if pm.operator in (">=", "<=", "="):
            marker = f"p{pidx}"
            pidx += 1
            conditions.append(f"{col} {pm.operator} :{marker}")
            params.append(
                BoundParam(name=marker, value=val, type=_bind_type_for(pm.operator, val))
            )
        elif pm.operator == "IN":
            parts = [p.strip() for p in val.split(",")]
            parts = [p for p in parts if p]
            if not parts:
                continue
            if len(parts) > _MAX_IN_ELEMENTS:
                raise SpecError(
                    f"sample_query IN filter for {pm.param_name!r} has {len(parts)} "
                    f"elements (max {_MAX_IN_ELEMENTS})."
                )
            markers: list[str] = []
            for elem in parts:
                marker = f"p{pidx}"
                pidx += 1
                markers.append(f":{marker}")
                params.append(BoundParam(name=marker, value=elem, type="STRING"))
            conditions.append(f"{col} IN ({','.join(markers)})")

    sql = f"SELECT {select_clause} FROM {table}"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += f" LIMIT {limit}"

    return sql, params, col_names


def run_preview(
    settings: Settings,
    spec: SampleQuerySpec,
    values: dict[str, str],
) -> dict:
    """Execute the preview query against the SQL warehouse as the App SP.

    Runs a **parameterized** statement (bind markers + a
    :class:`StatementParameterListItem` list) via the SDK's
    ``statement_execution.execute_statement`` on a plain :class:`WorkspaceClient`
    (the App service principal — NOT on-behalf-of the user). User values are bound,
    never interpolated.

    Args:
        settings: App settings carrying warehouse id, catalog, and schema.
        spec: The validated :class:`SampleQuerySpec` for the report.
        values: Raw form values keyed by ``param_name``; blank values are skipped
            in the WHERE clause and unknown keys are ignored.

    Returns:
        A dict with keys ``columns`` (display names), ``rows`` (list of row arrays),
        ``row_count`` (int), and ``truncated`` (bool — True when row_count equals the
        applied limit, signalling that more rows may exist).

    Raises:
        PreviewError: If the warehouse id is unset, the SDK is unavailable, or the
            statement execution fails.
    """
    if not settings.databricks_warehouse_id:
        raise PreviewError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot run preview query. "
            "Set it locally (see app/README.md) or attach a sql-warehouse resource "
            "on deploy (app.yaml valueFrom)."
        )

    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import StatementParameterListItem, StatementState
    except ImportError as exc:  # pragma: no cover - defensive
        raise PreviewError("databricks-sdk is not installed.") from exc

    sql, params, col_names = build_preview_sql(
        spec, values, settings.catalog, settings.schema_name
    )
    limit = min(spec.default_limit, 500)
    sdk_params = [
        StatementParameterListItem(name=p.name, value=p.value, type=p.type) for p in params
    ]
    # Audit line: enough to trace a dispatch (SQL shape + bound-param count) without
    # ever logging raw user values at INFO (values live only in the bound list).
    log.info(
        "preview dispatch (warehouse %s): sql=%s bound_params=%d",
        settings.databricks_warehouse_id,
        sql,
        len(sdk_params),
    )

    try:
        client = WorkspaceClient()  # App service principal (Config() auto-detects creds).
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=sql,
            parameters=sdk_params,
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001
        raise PreviewError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise PreviewError(f"statement did not succeed: {detail}")

    data_array = resp.result.data_array if (resp.result and resp.result.data_array) else []
    rows: list[list] = [list(row) for row in data_array] if data_array else []

    return {
        "columns": [col.display_name for col in spec.columns],
        "rows": rows,
        "row_count": len(rows),
        "truncated": len(rows) >= limit,
        # Diagnostic-only: lets the endpoint audit-log the bound-param count
        # without re-deriving the SQL (never carries raw user values).
        "bound_param_count": len(sdk_params),
    }
