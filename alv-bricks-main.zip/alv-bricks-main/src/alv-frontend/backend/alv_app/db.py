"""Postgres (Lakebase) connection factory — DOCUMENTED ONLY, no real queries yet.

Task 1.1 requires the ``psycopg`` dependency declared and a documented connection
factory — but NO business queries (the catalogue/request_log data access lands in
later tasks 3.x/4.x/5.x). This module is that factory and nothing more.

On a deployed Databricks App backed by a Lakebase (managed Postgres) resource, the
platform auto-injects ``PGHOST`` / ``PGPORT`` / ``PGDATABASE`` / ``PGUSER`` /
``PGPASSWORD`` (see the databricks-app-python skill, 5-lakebase.md). Those map 1:1
onto the fields in :class:`~alv_app.config.Settings`. Locally they are unset, so the
factory raises a clear error rather than attempting a bogus connection.
"""

from __future__ import annotations

from .config import Settings


def build_conninfo(settings: Settings) -> str:
    """Build a libpq connection string from settings (no connection is opened).

    Args:
        settings: App settings carrying the PG* values.

    Returns:
        A libpq ``key=value`` conninfo string suitable for ``psycopg.connect``.

    Raises:
        RuntimeError: if the required connection settings are not configured.
    """
    missing = [
        name
        for name, value in (
            ("PGHOST", settings.pghost),
            ("PGDATABASE", settings.pgdatabase),
            ("PGUSER", settings.pguser),
        )
        if not value
    ]
    if missing:
        raise RuntimeError(
            "Postgres connection is not configured; missing: "
            + ", ".join(missing)
            + ". On a deployed app these are injected by the Lakebase resource; "
            "locally, set them in the environment (see app/README.md)."
        )

    parts = [
        f"host={settings.pghost}",
        f"port={settings.pgport}",
        f"dbname={settings.pgdatabase}",
        f"user={settings.pguser}",
        f"sslmode={settings.pgsslmode}",
    ]
    if settings.pgpassword:
        parts.append(f"password={settings.pgpassword}")
    return " ".join(parts)


def get_connection(settings: Settings):
    """Open a psycopg connection to Lakebase/Postgres (factory only — no queries).

    Wired but unused by the current endpoints; later tasks will use it to read
    ``alv_catalog`` / ``request_log``. Kept as a thin factory so those tasks have a
    single documented entry point.

    Args:
        settings: App settings carrying the PG* values.

    Returns:
        An open ``psycopg.Connection``. Caller is responsible for closing it
        (prefer ``with get_connection(...) as conn:``).

    Raises:
        RuntimeError: if psycopg is not installed or settings are incomplete.
    """
    try:
        import psycopg
    except ImportError as exc:  # pragma: no cover - defensive
        raise RuntimeError(
            "psycopg is not installed; add it to the backend dependencies."
        ) from exc

    return psycopg.connect(build_conninfo(settings))
