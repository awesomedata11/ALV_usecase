"""Data-access seam: write ``request_log`` rows via the SQL warehouse (task 7.4).

The metadata tables are **Delta over the SQL warehouse** (NOT Lakebase), so the App
writes them with the SAME statement-execution client seam as the read path
(:mod:`alv_app.catalog_source`). The App writes as the **app service principal**
(``Config()`` default auth on deploy) — the SP needs ``MODIFY`` on the metadata
schema for these INSERT/UPDATE (see docs/APP_PREREQUISITES.md).

Two operations, both parameterized (never string-interpolated user values) to keep
the free-text ``param_payload_json`` injection-safe:

* :func:`insert_request_log` — the initial ``QUEUED`` row on submit.
* :func:`update_run_id`      — patch the row with the Job ``run_id`` after run-now.
* :func:`update_status`      — advance the ``status`` (and optional ``output_path``)
  once status polling reads the live run state (task 8.x).

Kept behind small functions so the endpoint stays thin and the tests inject a fake
executor (no live workspace needed).
"""

from __future__ import annotations

import logging
from typing import Any

from .config import Settings

log = logging.getLogger("alv_reports.request_log")


class RequestLogError(RuntimeError):
    """Raised when a ``request_log`` write cannot be performed."""


def _fqtn(settings: Settings) -> str:
    """Fully-qualified ``catalog.schema.request_log`` (backtick-quoted)."""
    return f"`{settings.catalog}`.`{settings.schema_name}`.`request_log`"


def _execute(settings: Settings, statement: str, parameters: list[dict[str, Any]]) -> None:
    """Run a parameterized statement on the warehouse as the app SP.

    Args:
        settings: app settings carrying ``databricks_warehouse_id``.
        statement: SQL with ``:named`` parameter markers.
        parameters: list of ``{"name","value","type"}`` dicts (SDK shape).

    Raises:
        RequestLogError: if the warehouse id is unset, the SDK is missing, or the
            statement does not succeed.
    """
    if not settings.databricks_warehouse_id:
        raise RequestLogError(
            "DATABRICKS_WAREHOUSE_ID is not set; cannot write request_log."
        )

    try:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.sql import (
            StatementParameterListItem,
            StatementState,
        )
    except ImportError as exc:  # pragma: no cover - defensive
        raise RequestLogError("databricks-sdk is not installed.") from exc

    params = [
        StatementParameterListItem(
            name=p["name"], value=p.get("value"), type=p.get("type")
        )
        for p in parameters
    ]
    try:
        client = WorkspaceClient()  # Config() default auth (SP on deploy)
        resp = client.statement_execution.execute_statement(
            warehouse_id=settings.databricks_warehouse_id,
            statement=statement,
            parameters=params,
            wait_timeout="50s",
        )
    except Exception as exc:  # noqa: BLE001 - surface as our typed error
        raise RequestLogError(f"warehouse statement failed: {exc}") from exc

    if resp.status is None or resp.status.state != StatementState.SUCCEEDED:
        detail = resp.status.error if (resp.status and resp.status.error) else resp.status
        raise RequestLogError(f"statement did not succeed: {detail}")


def insert_request_log(
    settings: Settings,
    *,
    request_no: str,
    alv_id: str,
    submitted_by: str | None,
    param_payload_json: str,
    param_hash: str,
) -> None:
    """INSERT the initial ``QUEUED`` request_log row (task 7.4).

    ``status='QUEUED'`` and ``submitted_at=now`` are set here; ``run_id`` is patched
    later by :func:`update_run_id` once run-now returns. Parameterized to keep the
    free-text payload injection-safe.
    """
    stmt = (
        f"INSERT INTO {_fqtn(settings)} "
        "(request_no, alv_id, submitted_by, param_payload_json, param_hash, status, submitted_at) "
        "VALUES (:request_no, :alv_id, :submitted_by, :param_payload_json, :param_hash, "
        "'QUEUED', current_timestamp())"
    )
    params = [
        {"name": "request_no", "value": request_no, "type": "STRING"},
        {"name": "alv_id", "value": alv_id, "type": "STRING"},
        {"name": "submitted_by", "value": submitted_by, "type": "STRING"},
        {"name": "param_payload_json", "value": param_payload_json, "type": "STRING"},
        {"name": "param_hash", "value": param_hash, "type": "STRING"},
    ]
    log.info("inserting request_log row %s (alv_id=%s)", request_no, alv_id)
    _execute(settings, stmt, params)


def update_run_id(settings: Settings, *, request_no: str, run_id: int) -> None:
    """UPDATE the request_log row with the Job ``run_id`` (status stays QUEUED, 7.4)."""
    stmt = (
        f"UPDATE {_fqtn(settings)} SET run_id = :run_id "
        "WHERE request_no = :request_no"
    )
    params = [
        {"name": "run_id", "value": str(run_id), "type": "BIGINT"},
        {"name": "request_no", "value": request_no, "type": "STRING"},
    ]
    log.info("updating request_log row %s with run_id=%s", request_no, run_id)
    _execute(settings, stmt, params)


def update_status(
    settings: Settings,
    *,
    request_no: str,
    status: str,
    output_path: str | None = None,
    row_count: int | None = None,
    generated_at: str | None = None,
) -> None:
    """UPDATE the request_log row's ``status`` (+ output pointer columns, 8.x/9.x).

    Status polling (8.x) advances the ``status`` alone; once a run reaches SUCCESS the
    output-capture path (9.x) also passes the Job's returned pointer
    (``output_path`` / ``row_count`` / ``generated_at``) so the download can be served.
    Only the columns actually supplied are written — a bare status poll never clobbers
    a previously-captured pointer with NULLs. Parameterized, same warehouse seam as
    the other writes.

    ``expires_at`` is derived here, on the SAME statement that writes ``generated_at``,
    as ``generated_at + settings.result_ttl_days`` — so a COMPLETED run can never end up
    with a captured output and no retention horizon. The arithmetic is done in SQL
    (``timestampadd``) against the same bound timestamp rather than parsed in Python,
    because ``generated_at`` arrives as an arbitrary Job-supplied string. Groundwork for
    the later result-cache feature; nothing reads the column yet.
    """
    set_clauses = ["status = :status"]
    params: list[dict[str, Any]] = [{"name": "status", "value": status, "type": "STRING"}]
    if output_path is not None:
        set_clauses.append("output_path = :output_path")
        params.append({"name": "output_path", "value": output_path, "type": "STRING"})
    if row_count is not None:
        set_clauses.append("row_count = :row_count")
        params.append({"name": "row_count", "value": str(row_count), "type": "BIGINT"})
    if generated_at is not None:
        set_clauses.append("generated_at = :generated_at")
        params.append({"name": "generated_at", "value": generated_at, "type": "TIMESTAMP"})
        # expires_at = generated_at + TTL. Both operands are bound; the TTL is an int
        # from Settings (never user input) but is bound anyway for consistency.
        set_clauses.append("expires_at = timestampadd(DAY, :ttl_days, :generated_at)")
        params.append(
            {"name": "ttl_days", "value": str(int(settings.result_ttl_days)), "type": "INT"}
        )

    stmt = (
        f"UPDATE {_fqtn(settings)} SET {', '.join(set_clauses)} "
        "WHERE request_no = :request_no"
    )
    params.append({"name": "request_no", "value": request_no, "type": "STRING"})
    log.info("updating request_log row %s status=%s", request_no, status)
    _execute(settings, stmt, params)
