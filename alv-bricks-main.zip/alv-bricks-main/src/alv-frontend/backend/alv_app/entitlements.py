"""Report visibility by principal (group or user) — the App's authorization gate.

## The model

A report is visible to a user when **any grant in ``report_permissions`` permits
them** (OR semantics): a **group** grant for a group they belong to, or a **user**
grant naming their email. A report with **no active grant is hidden from everyone** —
the default is CLOSED, so the whole gate fails safe: any error anywhere in this module
results in *fewer* reports, never more.

Gating is at **report level** (``report_key``): the home-page card and every
selection / report type underneath it move together. It supersedes the deferred
row-level auth map (D19), whose grain was data-row filtering by business dimension.

Group grants are matched against the user's ``/Me`` groups (needs the OBO token, see
below); user grants are matched against the proxy-injected ``X-Forwarded-Email`` and
so work even when OBO is off. Ad-hoc user grants are written at runtime by the admin
console (see ``alv_app.admin``); group grants come from the one-time seed and/or the
console. Both live in the same table, tagged by ``principal_type``.

## Two identities, two jobs

| What we read | As whom | Why |
|---|---|---|
| the user's groups (``/Me``) | the **END USER**, via their injected OBO token | ``GET /api/2.0/preview/scim/v2/Me`` returns the caller's own record **with** a populated ``groups`` list and needs no admin rights. Reading *another* user's groups through SCIM Groups/Users requires workspace admin, and for a non-admin SP the membership fields are **silently stripped** — so that route is unusable here. |
| ``report_permissions`` | the **App SP** | It owns the mapping table (same seam as the catalogue read). |

The SDK's ``is_account_group_member`` / ``is_member`` helpers evaluate the *session*
user, which under the App is the SP — they would report the SP's groups. They are
deliberately not used.

## Caching (mandatory, not an optimization)

Workspace SCIM is capped at **255 GET/min, fixed**, so one ``/Me`` per request would
melt under any real load. Both lookups sit behind a small TTL cache
(:class:`_TtlCache`): the group set **per user** (keyed on the proxy-supplied email /
user id — never keyless, so users can't inherit each other's groups) and the
report→groups map (user-independent, one entry). TTLs come from settings
(``permissions_user_ttl_seconds`` / ``permissions_map_ttl_seconds``).

The startup metadata cache stays SP-loaded and user-independent; all per-user
filtering happens here, at request time.

## Diagnosing "no reports"

An empty result is deliberately ambiguous to the *user* but never to the operator.
:class:`UserGroups` carries a ``reason`` code, logged at WARNING on every deny:

* ``no_user_token`` — **OBO is off** (or the header was stripped): user authorization
  is not enabled on the app. Fix the app config; the user's groups were never read.
* ``me_failed`` — the token was present but ``/Me`` errored (expired token, missing
  ``iam.current-user:read`` scope, workspace unreachable).
* ``no_groups`` — ``/Me`` answered fine and the user genuinely belongs to no groups.
* ``no_mapping`` — the user has groups, but none of them is mapped to any report.

## Known limitation — flat groups only

``/Me`` returns **direct** memberships. A user who is only a member of a group that
is *nested inside* a mapped group will NOT see the report. Map the group the users
are actually in.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Iterable, TypeVar

from .config import Settings
from .identity import UserIdentity
from .permissions_source import PermissionsSourceError, fetch_report_permissions

log = logging.getLogger("alv_reports.entitlements")


# --- TTL cache ------------------------------------------------------------------
class _TtlCache:
    """Minimal thread-safe keyed TTL cache.

    Deliberately NOT an ``lru_cache``: the user entries are per-identity, and a
    keyless cache (as in :func:`alv_app.databricks_client.get_workspace_client`,
    which caches a single SP client) would let one user's groups be served to
    another. Entries expire by wall clock; there is no background eviction — the
    key space is bounded by the number of app users.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, tuple[float, object]] = {}

    def get(self, key: str) -> object | None:
        """Return the cached value for *key*, or None when absent/expired."""
        now = time.monotonic()
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                return None
            expires_at, value = entry
            if expires_at <= now:
                del self._entries[key]
                return None
            return value

    def put(self, key: str, value: object, ttl_seconds: float) -> None:
        """Cache *value* under *key* for *ttl_seconds* (a non-positive TTL skips)."""
        if ttl_seconds <= 0:
            return
        with self._lock:
            self._entries[key] = (time.monotonic() + ttl_seconds, value)

    def clear(self) -> None:
        """Drop every entry (used by tests and a future admin-reload)."""
        with self._lock:
            self._entries.clear()


# Process-wide caches: one keyed by user, one single-entry for the mapping table.
_user_groups_cache = _TtlCache()
_permission_map_cache = _TtlCache()
_MAP_CACHE_KEY = "report_permissions"


def clear_caches() -> None:
    """Clear both permission caches (tests; a future admin-reload endpoint)."""
    _user_groups_cache.clear()
    _permission_map_cache.clear()


# --- user groups (read as the END USER via their OBO token) ---------------------
@dataclass(frozen=True)
class UserGroups:
    """A user's group memberships as reported by ``/Me``.

    Attributes:
        groups: The user's **direct** group display names (empty on any failure).
        ok: True only when ``/Me`` actually answered. False means we never learned
            the user's groups — distinct from "answered, and there were none".
        reason: Diagnosis code for the logs: ``ok`` / ``no_user_token`` /
            ``me_failed`` / ``no_groups``. See the module docstring.
        detail: Free-text error detail when ``ok`` is False (never the token).
    """

    groups: frozenset[str]
    ok: bool
    reason: str
    detail: str | None = None


def _fetch_groups_from_me(host: str | None, user_token: str) -> frozenset[str]:
    """Call ``current_user.me()`` as the END USER and return their group names.

    Builds a short-lived user-scoped :class:`WorkspaceClient` from the app's host
    plus the user's OBO token (on-behalf-of), so ``/Me`` returns the **user's** own
    SCIM record — including the ``groups`` list, which needs no admin rights. The
    client is intentionally not cached (the token is per-request and short-lived);
    the resulting group set is what gets cached.

    Args:
        host: Workspace URL. ``None`` lets the SDK resolve it from the environment
            (``DATABRICKS_HOST``, auto-injected on a deployed app).
        user_token: The user's OBO access token. **Secret** — never logged.

    Returns:
        The set of the user's direct group display names (possibly empty).

    Raises:
        Exception: any SDK/transport failure; the caller turns it into
            ``ok=False, reason="me_failed"``.
    """
    from databricks.sdk import WorkspaceClient

    client = (
        WorkspaceClient(host=host, token=user_token, auth_type="pat")
        if host
        else WorkspaceClient(token=user_token, auth_type="pat")
    )
    me = client.current_user.me()

    names: set[str] = set()
    for g in getattr(me, "groups", None) or []:
        # SCIM group refs carry `display`; fall back to `value` (the id) only if a
        # display name is missing, so a mapping can still be written against it.
        name = getattr(g, "display", None) or getattr(g, "value", None)
        if name:
            names.add(str(name))
    return frozenset(names)


def _user_cache_key(ident: UserIdentity) -> str:
    """Stable per-user cache key from the proxy-supplied identity.

    Uses the email, else the stable ``X-Forwarded-User`` id. These headers are set by
    the Databricks proxy and cannot be reached around by the client, so they are a
    trustworthy cache key. The token itself is never part of the key (it would defeat
    the cache on rotation and risks landing a secret in a key space).
    """
    return f"user:{ident.email or ident.user_id or 'unknown'}"


def resolve_user_groups(settings: Settings, ident: UserIdentity) -> UserGroups:
    """Return the user's group memberships, cached per user with a TTL.

    Fails CLOSED and never raises: any problem yields an empty group set with a
    ``reason`` the operator can act on (see the module docstring). A successful
    lookup — **including an empty one** — is cached, so a user with genuinely no
    groups does not re-hit SCIM on every request.

    Args:
        settings: App settings (TTL + the SDK host).
        ident: The resolved SSO identity, carrying the OBO token when present.

    Returns:
        A :class:`UserGroups`.
    """
    if not ident.user_token:
        # No OBO token: user authorization is off, or the header was not injected.
        # We cannot learn this user's groups at all → deny, and say why.
        return UserGroups(
            groups=frozenset(),
            ok=False,
            reason="no_user_token",
            detail=(
                "no X-Forwarded-Access-Token on the request; user authorization (OBO) "
                "is not enabled on the app, so the user's groups cannot be read"
            ),
        )

    key = _user_cache_key(ident)
    cached = _user_groups_cache.get(key)
    if isinstance(cached, UserGroups):
        return cached

    host = _sdk_host(settings)
    try:
        groups = _fetch_groups_from_me(host, ident.user_token)
    except Exception as exc:  # noqa: BLE001 - the gate must never raise; fail closed
        # The token value is NOT in the message: SDK errors carry the host/endpoint,
        # not the credential.
        log.warning(
            "could not read groups for %s via /Me (failing closed): %s",
            key,
            exc,
        )
        return UserGroups(
            groups=frozenset(), ok=False, reason="me_failed", detail=str(exc)
        )

    resolved = UserGroups(
        groups=groups,
        ok=True,
        reason="ok" if groups else "no_groups",
        detail=None,
    )
    _user_groups_cache.put(key, resolved, settings.permissions_user_ttl_seconds)
    log.info(
        "resolved %d group(s) for %s via /Me (cached %ds)",
        len(groups),
        key,
        settings.permissions_user_ttl_seconds,
    )
    return resolved


def _sdk_host(settings: Settings) -> str | None:
    """Resolve the workspace URL for the user-scoped client, or None to let the SDK.

    On a deployed app ``DATABRICKS_HOST`` is auto-injected and the SDK's own
    ``Config()`` picks it up, so we normally pass ``None`` and let it resolve. This
    helper exists as the single seam tests patch.
    """
    import os

    return os.environ.get("DATABRICKS_HOST") or None


# --- report → principals mapping (read as the App SP) ---------------------------
@dataclass(frozen=True)
class PermissionMap:
    """The ``report_permissions`` mapping, split by principal kind.

    A grant names a **group** (matched against the user's ``/Me`` groups) or a **user**
    (matched against the caller's lower-cased email). Both are OR: a report is visible
    if any group grant OR any user grant permits the caller.

    Attributes:
        groups_by_report_key: report_key → allowed group display names (active only).
        users_by_report_key: report_key → allowed user emails, **lower-cased** (active
            only). A ``report_key`` absent from BOTH dicts is visible to nobody (deny
            by default).
        ok: False when the mapping could not be read; the caller then denies
            everything rather than degrading open.
        detail: Error detail when ``ok`` is False.
    """

    groups_by_report_key: dict[str, frozenset[str]] = field(default_factory=dict)
    users_by_report_key: dict[str, frozenset[str]] = field(default_factory=dict)
    ok: bool = True
    detail: str | None = None


def report_permission_map(settings: Settings) -> PermissionMap:
    """Return the report→principals mapping, cached with a TTL (user-independent).

    Read as the **App SP** via :func:`alv_app.permissions_source.fetch_report_permissions`.
    Inactive rows (``is_active = false``) are dropped, so revoking a grant is a single
    UPDATE. Group grants are indexed by display name; user grants by lower-cased email.
    Never raises: a warehouse failure yields ``ok=False`` and the caller denies
    everything (fail closed) — unlike the catalogue, which degrades to an empty list,
    because relaxing a security control on error is not acceptable.

    A failed read is NOT cached, so the mapping recovers on the next request once the
    warehouse is reachable again.
    """
    cached = _permission_map_cache.get(_MAP_CACHE_KEY)
    if isinstance(cached, PermissionMap):
        return cached

    try:
        rows = fetch_report_permissions(settings)
    except PermissionsSourceError as exc:
        log.error("report_permissions read failed (denying all reports): %s", exc)
        return PermissionMap(ok=False, detail=str(exc))

    groups_by_key: dict[str, set[str]] = {}
    users_by_key: dict[str, set[str]] = {}
    for row in rows:
        if not row.get("is_active"):
            continue
        report_key = row.get("report_key")
        principal_type = row.get("principal_type")
        principal_name = row.get("principal_name")
        if not report_key or not principal_name:
            log.warning("skipping report_permissions row with a blank key: %r", row)
            continue
        if principal_type == "group":
            groups_by_key.setdefault(str(report_key), set()).add(str(principal_name))
        elif principal_type == "user":
            # Emails are matched case-folded; store lower-cased.
            users_by_key.setdefault(str(report_key), set()).add(str(principal_name).lower())
        else:
            log.warning(
                "skipping report_permissions row with unknown principal_type %r: %r",
                principal_type,
                row,
            )

    resolved = PermissionMap(
        groups_by_report_key={k: frozenset(v) for k, v in groups_by_key.items()},
        users_by_report_key={k: frozenset(v) for k, v in users_by_key.items()},
        ok=True,
    )
    _permission_map_cache.put(
        _MAP_CACHE_KEY, resolved, settings.permissions_map_ttl_seconds
    )
    log.info(
        "report_permissions map loaded: %d group-mapped + %d user-mapped report(s) "
        "(cached %ds)",
        len(resolved.groups_by_report_key),
        len(resolved.users_by_report_key),
        settings.permissions_map_ttl_seconds,
    )
    return resolved


# --- the gate -------------------------------------------------------------------
def permission_bypass_active(settings: Settings) -> bool:
    """Whether the local-dev permission bypass is in effect (logs loudly when it is).

    Two conditions must BOTH hold, so this cannot ship open by accident:
    ``dev_bypass_permissions`` explicitly on **and** ``dev_mode`` on. A deployed
    ``app.yaml`` sets ``DEV_MODE=false``, so even a stray
    ``DEV_BYPASS_PERMISSIONS=true`` there is refused (and logged as such).
    """
    if not settings.dev_bypass_permissions:
        return False
    if not settings.dev_mode:
        log.error(
            "DEV_BYPASS_PERMISSIONS is set but DEV_MODE is off — REFUSING to bypass "
            "report permissions. Unset DEV_BYPASS_PERMISSIONS in the deployed config."
        )
        return False
    log.warning(
        "DEV_BYPASS_PERMISSIONS is ACTIVE: report_permissions is NOT enforced and "
        "every report is visible. This is for LOCAL DEV ONLY — never deploy with it on."
    )
    return True


def _caller_email(ident: UserIdentity) -> str | None:
    """The caller's email, lower-cased, for matching ``user`` grants (or None).

    The email comes from the proxy-injected ``X-Forwarded-Email`` header — as
    trustworthy as the OBO-derived groups and, unlike them, available even when the
    OBO token is absent. So a ``user`` grant is honoured independently of the group
    read: ad-hoc user access does not require user-authorization (OBO) to be enabled.
    """
    return ident.email.lower() if ident.email else None


def permitted_report_keys(settings: Settings, ident: UserIdentity) -> frozenset[str]:
    """Return the ``report_key`` s this user may see (empty = sees nothing).

    The gate, in one place. A report is permitted when EITHER:

    * a **group** grant matches — one of the user's ``/Me`` groups is mapped to it, OR
    * a **user** grant matches — the caller's (lower-cased) email is mapped to it.

    The two are unioned (OR). A ``report_key`` with no active grant of either kind is
    never included — deny by default. User grants are evaluated even when the group
    read failed or returned nothing (they key on the trustworthy email header, not on
    ``/Me``), so ad-hoc access is robust to OBO being off. A mapping-read failure still
    denies everything (fail closed).

    Every deny path logs at WARNING with a ``reason`` so causes stay diagnosable
    (module docstring). Never raises.
    """
    key = _user_cache_key(ident)

    # Group grants require the /Me read. A failure/empty there is not fatal on its own —
    # the user may still hold a direct user grant — so we note the reason and continue.
    user = resolve_user_groups(settings, ident)
    if not user.ok:
        log.warning(
            "no group grants for %s: reason=%s detail=%s (user grants still checked)",
            key, user.reason, user.detail,
        )
    elif not user.groups:
        log.warning(
            "no group grants for %s: reason=no_groups (/Me answered, but the user is a "
            "member of no groups; user grants still checked)",
            key,
        )

    mapping = report_permission_map(settings)
    if not mapping.ok:
        log.warning(
            "denying all reports for %s: reason=permission_map_unreadable detail=%s",
            key, mapping.detail,
        )
        return frozenset()

    permitted: set[str] = set()

    # Group grants: intersect the user's groups with each report's allowed groups.
    if user.ok and user.groups:
        for report_key, allowed in mapping.groups_by_report_key.items():
            if allowed & user.groups:
                permitted.add(report_key)

    # User grants: match the caller's lower-cased email against each report's allowed users.
    email = _caller_email(ident)
    if email:
        for report_key, allowed in mapping.users_by_report_key.items():
            if email in allowed:
                permitted.add(report_key)

    if not permitted:
        log.warning(
            "denying all reports for %s: reason=no_mapping (no group or user grant "
            "matches; %d group(s), email=%s)",
            key, len(user.groups), "present" if email else "absent",
        )
    return frozenset(permitted)


def is_report_permitted(
    settings: Settings, ident: UserIdentity, report_key: str | None
) -> bool:
    """Whether this user may see the report identified by *report_key*.

    Used by the write/read paths that hold a single report identity (submit, preview,
    download) — they return **404** rather than 403 on False, so the existence of a
    report the user may not see is not disclosed.

    A ``None``/blank ``report_key`` (a malformed catalogue row) is denied.
    """
    if permission_bypass_active(settings):
        return True
    if not report_key:
        log.warning("denying a report with no report_key (cannot be mapped)")
        return False
    return report_key in permitted_report_keys(settings, ident)


_R = TypeVar("_R")


def filter_permitted_reports(
    settings: Settings, ident: UserIdentity, reports: Iterable[_R]
) -> list[_R]:
    """Filter cached reports down to the ones this user may see.

    The single enforcement funnel for the read path: every catalogue endpoint routes
    its ``active_reports()`` output through here, so a report is filtered out of the
    home-page cards, the nav tree, and the form lookup together. Order is preserved.

    Args:
        settings: App settings.
        ident: The resolved SSO identity (carries the OBO token).
        reports: Cached reports, each exposing a ``report_key`` attribute.

    Returns:
        The permitted subset, in input order (empty when the user may see nothing).
    """
    reports = list(reports)
    if permission_bypass_active(settings):
        return reports
    permitted = permitted_report_keys(settings, ident)
    if not permitted:
        return []
    return [r for r in reports if getattr(r, "report_key", None) in permitted]
