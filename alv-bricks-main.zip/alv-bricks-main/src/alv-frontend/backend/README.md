# ALV-Bricks App — backend (FastAPI, thin)

Skeleton backend for tasks **1.1 / 1.2**. Endpoints only; no business logic.

- `GET /api/health` — liveness.
- `GET /api/me` — current user's Databricks SSO identity (from injected
  `X-Forwarded-*` headers) + an app service-principal auth-check.

## Run locally (uv)

```bash
cd src/alv-frontend/backend
uv sync                      # create .venv + install from uv.lock
uv run uvicorn alv_app.main:app --reload --port 8000
# health:   curl localhost:8000/api/health
# identity: curl localhost:8000/api/me
```

Tests: `uv run pytest`.

## Layout

```
alv_app/
  main.py               FastAPI app + /api/health, /api/me
  config.py             env-var settings (pydantic-settings)
  identity.py           SSO header contract -> UserIdentity
  databricks_client.py  app service-principal WorkspaceClient + auth_check()
  db.py                 psycopg (Lakebase) connection factory — documented, no queries
  models.py             response models
```

See `app/README.md` (parent) for the SSO-header contract, env vars, and the
Databricks Apps deployment model.
