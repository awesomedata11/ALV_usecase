"""Endpoint + cache tests against the real report specs (tasks 3.1/3.2).

Most tests here use the single-report ``client`` (14 retail_ledger rows). The
``two_report_client`` block at the bottom drives the realistic 28-row, two-report cache
— the shape that exposed the report-routing bug.
"""

from __future__ import annotations

_RETAIL_SELECTIONS = ["detail", "sequence_wise", "time_wise", "agent_closing_balance"]
_RETAIL_COUNTS = {
    "detail": 3,
    "sequence_wise": 5,
    "time_wise": 5,
    "agent_closing_balance": 1,
}


def test_reports_catalogue_shape(client):
    resp = client.get("/api/reports")
    assert resp.status_code == 200
    body = resp.json()
    # A cache holding ONE report_key ⇒ the tree is unambiguously that report. (Under a
    # two-report cache these are null, and the tree must be scoped with ?report_key= to
    # identify it — see test_scoped_catalogue_identifies_the_report.)
    assert body["report_key"] == "retail_ledger"
    assert body["report_label"] == "Retail Ledger"

    selections = body["selections"]
    # 4 selections: Detail, Sequence Wise, Time Wise, Agent Closing Balance.
    assert [s["selection_id"] for s in selections] == _RETAIL_SELECTIONS
    # Report-type counts per selection: 3, 5, 5, 1 (14 total leaves).
    counts = {s["selection_id"]: len(s["report_types"]) for s in selections}
    assert counts == _RETAIL_COUNTS
    total_leaves = sum(len(s["report_types"]) for s in selections)
    assert total_leaves == 14


def test_report_types_ordered(client):
    body = client.get("/api/reports").json()
    detail = next(s for s in body["selections"] if s["selection_id"] == "detail")
    assert [rt["report_type_order"] for rt in detail["report_types"]] == [1, 2, 3]
    assert detail["report_types"][0]["report_type_label"] == "Agent Item"
    assert detail["report_types"][0]["alv_id"] == "retail_ledger__detail__agent_item"


def test_closing_balance_has_null_report_type(client):
    body = client.get("/api/reports").json()
    cb = next(s for s in body["selections"] if s["selection_id"] == "agent_closing_balance")
    assert len(cb["report_types"]) == 1
    leaf = cb["report_types"][0]
    assert leaf["report_type_code"] is None
    assert leaf["alv_id"] == "retail_ledger__agent_closing_balance"


def test_form_def_detail_agent_item(client):
    resp = client.get("/api/reports/retail_ledger__detail__agent_item")
    assert resp.status_code == 200
    body = resp.json()
    assert body["selection_id"] == "detail"
    assert body["report_type_code"] == "agent_item"

    fields = body["fields"]
    # Ordered by display_order: 6 fields (date_range, 4 text, time_range).
    assert [f["display_order"] for f in fields] == [1, 2, 3, 4, 5, 6]

    date_field = fields[0]
    assert date_field["kind"] == "composite"
    assert date_field["control"] == "date_range"
    assert date_field["mandatory"] is True
    assert date_field["parts"]["from"]["param_name"] == "transaction_date_from"
    assert date_field["parts"]["to"]["param_name"] == "transaction_date_to"
    rules = {v["rule"] for v in date_field["validations"]}
    assert {"from_lte_to", "max_offset_from_today", "max_span"} <= rules

    time_field = fields[-1]
    assert time_field["control"] == "time_range"
    assert time_field["parts"]["from"]["default"] == "00:00:00"

    agent = fields[1]
    assert agent["kind"] == "scalar"
    assert agent["param_name"] == "agent"
    assert agent["control"] == "text"
    assert agent["selection_type"] == "single"
    assert agent["mandatory"] is False
    # Forward-looking allowed_values is absent in the pilot spec.
    assert agent.get("allowed_values") is None


def test_form_def_closing_balance_single_date(client):
    body = client.get("/api/reports/retail_ledger__agent_closing_balance").json()
    fields = body["fields"]
    assert len(fields) == 1
    f = fields[0]
    assert f["kind"] == "scalar"
    assert f["control"] == "date"
    assert f["data_type"] == "date"
    assert f["mandatory"] is True
    assert f["param_name"] == "transaction_date"
    assert f["validations"][0]["rule"] == "max_offset_from_today"


def test_all_14_reports_resolve(client):
    body = client.get("/api/reports").json()
    alv_ids = [rt["alv_id"] for s in body["selections"] for rt in s["report_types"]]
    assert len(alv_ids) == 14
    for alv_id in alv_ids:
        r = client.get(f"/api/reports/{alv_id}")
        assert r.status_code == 200, alv_id
        assert r.json()["alv_id"] == alv_id


def test_unknown_report_404(client):
    resp = client.get("/api/reports/does_not_exist")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Two reports in the cache — the realistic shape, and the one the report-routing
# bug needed. The two manifests are clones apart from report_key / report_label:
# identical selection_ids, report_type_codes, selection_order and report_type_order.
# So every assertion here fails under the old code, which keyed selections on
# selection_id alone (merging both reports into one bucket) and labelled the whole
# tree from reports[0].
# ---------------------------------------------------------------------------
_KEYS = ("retail_ledger", "cc_recharge")
_LABELS = {"retail_ledger": "Retail Ledger", "cc_recharge": "CC Recharge Data"}


def test_unscoped_two_report_catalogue_keeps_reports_separate(two_report_client):
    """8 selections (4 per report), 28 leaves — never 4 merged selections / 6 types."""
    body = two_report_client.get("/api/reports").json()
    selections = body["selections"]
    assert len(selections) == 8
    assert sum(len(s["report_types"]) for s in selections) == 28
    # The pre-fix defect signature: "detail" appearing ONCE with 6 report types.
    details = [s for s in selections if s["selection_id"] == "detail"]
    assert len(details) == 2
    assert [len(s["report_types"]) for s in details] == [3, 3]


def test_unscoped_two_report_catalogue_has_no_tree_level_report(two_report_client):
    """Spanning tree ⇒ report_key/report_label are null, not an arbitrary row's."""
    body = two_report_client.get("/api/reports").json()
    assert body["report_key"] is None
    assert body["report_label"] is None


def test_no_selection_bucket_mixes_report_keys(two_report_client):
    """No cross-report bleed: every report type in a bucket shares one report_key.

    Resolved per leaf through GET /api/reports/{alv_id} (the authority on a row's
    report_key) rather than by parsing alv_id, whose shape is a seeding convention.
    """
    body = two_report_client.get("/api/reports").json()
    for sel in body["selections"]:
        keys = set()
        for rt in sel["report_types"]:
            form = two_report_client.get(f"/api/reports/{rt['alv_id']}").json()
            keys.add(form["report_key"])
        assert len(keys) == 1, f"selection {sel['selection_id']} mixes {keys}"


def test_scoped_catalogue_returns_exactly_that_report(two_report_client):
    """?report_key= ⇒ that report's 14 rows / 4 selections / 3 detail report types."""
    for key in _KEYS:
        body = two_report_client.get(f"/api/reports?report_key={key}").json()
        assert body["report_key"] == key
        assert body["report_label"] == _LABELS[key]

        selections = body["selections"]
        assert [s["selection_id"] for s in selections] == _RETAIL_SELECTIONS
        counts = {s["selection_id"]: len(s["report_types"]) for s in selections}
        assert counts == _RETAIL_COUNTS
        assert sum(len(s["report_types"]) for s in selections) == 14
        assert len([s for s in selections if s["selection_id"] == "detail"]) == 1

        # Every leaf really belongs to the requested report.
        for sel in selections:
            for rt in sel["report_types"]:
                form = two_report_client.get(f"/api/reports/{rt['alv_id']}").json()
                assert form["report_key"] == key


def test_scoped_catalogue_auto_pick_lands_in_the_requested_report(two_report_client):
    """The frontend's auto-pick — selections[0].report_types[0] — stays in-report.

    THE regression guard for the reported bug: clicking 'Retail Ledger' opened
    'CC Recharge Data' because that index-based pick ran against an unscoped tree where
    all 28 rows tie on both order columns.
    """
    for key in _KEYS:
        body = two_report_client.get(f"/api/reports?report_key={key}").json()
        first = body["selections"][0]["report_types"][0]
        form = two_report_client.get(f"/api/reports/{first['alv_id']}").json()
        assert form["report_key"] == key


def test_scoped_catalogue_unknown_report_key_404s(two_report_client):
    resp = two_report_client.get("/api/reports?report_key=no_such_report")
    assert resp.status_code == 404


def test_blank_report_key_is_treated_as_absent(two_report_client):
    """?report_key= (empty / whitespace) ⇒ the unscoped tree, not a 404."""
    for raw in ("", "%20"):
        resp = two_report_client.get(f"/api/reports?report_key={raw}")
        assert resp.status_code == 200
        assert len(resp.json()["selections"]) == 8


def test_active_reports_sort_is_report_key_tiebroken(two_report_catalog_rows, monkeypatch):
    """The sort is intentional, not incidentally alphabetical on alv_id."""
    import alv_app.cache as cache_mod

    monkeypatch.setattr(
        cache_mod, "fetch_catalog_rows", lambda settings: two_report_catalog_rows
    )
    cache = cache_mod.MetadataCache(cache_mod.Settings())
    cache.load(force=True)
    rows = cache.active_reports()
    assert len(rows) == 28
    # Mirrors active_reports' key (None orders sort last, as there).
    keys = [
        (
            r.selection_order if r.selection_order is not None else 1_000_000,
            r.report_type_order if r.report_type_order is not None else 1_000_000,
            str(r.report_key or ""),
            r.alv_id,
        )
        for r in rows
    ]
    assert keys == sorted(keys)
    # report_key breaks the tie BEFORE alv_id: the two clones' 'detail/agent_item' rows
    # (identical orders) are adjacent and ordered cc_recharge → retail_ledger by KEY.
    first_two = [str(r.report_key) for r in rows[:2]]
    assert first_two == ["cc_recharge", "retail_ledger"]


def test_catalogue_graceful_when_load_fails(monkeypatch):
    """A warehouse failure ⇒ empty catalogue, not a 500 (graceful cache-miss)."""
    import alv_app.cache as cache_mod
    from alv_app.catalog_source import CatalogSourceError

    def boom(settings):
        raise CatalogSourceError("warehouse down")

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", boom)

    from fastapi.testclient import TestClient

    from alv_app import main

    main._cache = main.MetadataCache(main.get_settings())
    main._cache.load(force=True)
    with TestClient(main.app) as c:
        resp = c.get("/api/reports")
        assert resp.status_code == 200
        assert resp.json()["selections"] == []
        assert c.get("/api/reports/retail_ledger__detail__agent_item").status_code == 404
