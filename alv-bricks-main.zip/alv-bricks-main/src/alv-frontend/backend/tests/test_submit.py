"""Tests for the submit path (tasks 7.1 / 7.2 / 7.4 / 7.5).

Pure payload/hash logic is unit-tested directly; the endpoint is tested end-to-end
with the warehouse writes + run-now mocked (``submit_client`` fixture), so no live
workspace is needed.
"""

from __future__ import annotations

import json

from alv_app.fields import parse_input_fields
from alv_app.submit import (
    build_param_payload,
    canonical_param_json,
    param_hash,
)

_AGENT_ITEM = "retail_ledger__detail__agent_item"
_CLOSING_BALANCE = "retail_ledger__agent_closing_balance"


# --- 7.1 payload build ----------------------------------------------------------
def _scalar(**over):
    base = {
        "param_name": "agent",
        "display_label": "Agent",
        "display_order": 2,
        "control": "text",
        "data_type": "string",
        "selection_type": "single",
        "mandatory": False,
        "omit_if_blank": True,
        "normalize": ["trim", "uppercase"],
    }
    base.update(over)
    return base


def _fields(*raw):
    return parse_input_fields({"schema_version": 1, "fields": list(raw)})


def test_payload_normalizes_present_values():
    fields = _fields(_scalar())
    payload = build_param_payload(fields, {"agent": "  ab12  "})
    # trim then uppercase.
    assert payload == {"agent": "AB12"}


def test_payload_omits_blank_when_omit_if_blank():
    fields = _fields(_scalar(omit_if_blank=True))
    payload = build_param_payload(fields, {"agent": "   "})
    assert "agent" not in payload


def test_payload_uses_default_when_blank_and_not_omit():
    fields = _fields(_scalar(omit_if_blank=False, default="DFLT"))
    payload = build_param_payload(fields, {"agent": ""})
    assert payload["agent"] == "DFLT"


def test_payload_blank_not_omit_no_default_is_none():
    fields = _fields(_scalar(omit_if_blank=False, default=None))
    payload = build_param_payload(fields, {})
    assert payload["agent"] is None


def test_payload_composite_parts():
    date_range = {
        "control": "date_range",
        "display_label": "Transaction Date",
        "display_order": 1,
        "data_type": "date",
        "mandatory": True,
        "parts": {
            "from": {"param_name": "transaction_date_from", "display_label": "From"},
            "to": {"param_name": "transaction_date_to", "display_label": "To"},
        },
    }
    fields = _fields(date_range)
    payload = build_param_payload(
        fields, {"transaction_date_from": "2026-01-01", "transaction_date_to": "2026-01-15"}
    )
    assert payload == {
        "transaction_date_from": "2026-01-01",
        "transaction_date_to": "2026-01-15",
    }


def test_composite_default_used_when_blank_and_not_omit():
    time_range = {
        "control": "time_range",
        "display_label": "Transaction Time",
        "display_order": 1,
        "data_type": "time",
        "mandatory": False,
        "omit_if_blank": False,
        "parts": {
            "from": {"param_name": "t_from", "display_label": "From", "default": "00:00:00"},
            "to": {"param_name": "t_to", "display_label": "To", "default": "00:00:00"},
        },
    }
    fields = _fields(time_range)
    payload = build_param_payload(fields, {})
    assert payload == {"t_from": "00:00:00", "t_to": "00:00:00"}


# --- 7.2 canonicalization + hash ------------------------------------------------
def test_canonical_json_is_key_order_stable():
    a = build_param_payload(_fields(_scalar()), {"agent": "x"})
    # Same content, insertion order should not matter: canonical sorts keys.
    j1 = canonical_param_json({"b": "2", "a": "1"})
    j2 = canonical_param_json({"a": "1", "b": "2"})
    assert j1 == j2 == '{"a":"1","b":"2"}'
    assert json.loads(canonical_param_json(a)) == {"agent": "X"}


def test_param_hash_is_deterministic_and_order_independent():
    h1 = param_hash(canonical_param_json({"a": "1", "b": "2"}))
    h2 = param_hash(canonical_param_json({"b": "2", "a": "1"}))
    assert h1 == h2
    assert len(h1) == 64  # sha-256 hex
    # Different content ⇒ different hash.
    assert h1 != param_hash(canonical_param_json({"a": "9", "b": "2"}))


# --- 7.4 / 7.5 endpoint ---------------------------------------------------------
def test_submit_inserts_and_triggers(submit_client):
    client, rec = submit_client
    resp = client.post(
        f"/api/reports/{_AGENT_ITEM}/submit",
        json={
            "values": {
                "transaction_date_from": "2026-01-01",
                "transaction_date_to": "2026-01-10",
                "agent": " ag01 ",
            }
        },
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["alv_id"] == _AGENT_ITEM
    assert body["status"] == "QUEUED"
    assert body["run_id"] == 987654321
    assert body["request_no"].startswith("REQ-")
    assert len(body["param_hash"]) == 64

    # One INSERT, one run-now, one run_id UPDATE.
    assert len(rec["inserts"]) == 1
    assert len(rec["runs"]) == 1
    assert len(rec["updates"]) == 1

    ins = rec["inserts"][0]
    assert ins["alv_id"] == _AGENT_ITEM
    assert ins["request_no"] == body["request_no"]
    assert ins["param_hash"] == body["param_hash"]
    # param_payload_json is the canonical JSON that was hashed.
    assert param_hash(ins["param_payload_json"]) == body["param_hash"]
    # agent normalized (trim+uppercase); date parts present.
    payload = json.loads(ins["param_payload_json"])
    assert payload["agent"] == "AG01"
    assert payload["transaction_date_from"] == "2026-01-01"

    run = rec["runs"][0]
    assert run["job_id"] == 1000  # first bound row
    assert run["job_parameters"]["agent"] == "AG01"
    # Correlation params passed to the Job (CONTRACT.md: form values + request_no).
    assert run["job_parameters"]["request_no"] == body["request_no"]
    assert run["job_parameters"]["alv_id"] == _AGENT_ITEM
    # run-now param values are all strings.
    assert all(isinstance(v, str) for v in run["job_parameters"].values())

    upd = rec["updates"][0]
    assert upd["request_no"] == body["request_no"]
    assert upd["run_id"] == 987654321


def test_submit_omits_blank_optional_from_job_params(submit_client):
    client, rec = submit_client
    resp = client.post(
        f"/api/reports/{_AGENT_ITEM}/submit",
        json={
            "values": {
                "transaction_date_from": "2026-01-01",
                "transaction_date_to": "2026-01-10",
                "agent": "",  # blank optional, omit_if_blank ⇒ dropped
            }
        },
    )
    assert resp.status_code == 200, resp.text
    payload = json.loads(rec["inserts"][0]["param_payload_json"])
    assert "agent" not in payload
    assert "agent" not in rec["runs"][0]["job_parameters"]


def test_submit_unbound_job_returns_409(catalog_rows):
    """A row whose job_id is NULL ⇒ clean 409, no crash (task 7.4)."""
    # The plain `catalog_rows` fixture carries no job_id → unbound.
    import alv_app.cache as cache_mod
    from unittest.mock import patch

    from fastapi.testclient import TestClient

    from alv_app import main

    with patch.object(cache_mod, "fetch_catalog_rows", lambda settings: catalog_rows):
        main._cache = main.MetadataCache(main.get_settings())
        main._cache.load(force=True)
        with TestClient(main.app) as c:
            resp = c.post(f"/api/reports/{_AGENT_ITEM}/submit", json={"values": {}})
            assert resp.status_code == 409
            assert "not bound to a job" in resp.json()["detail"]


def test_submit_unknown_report_404(submit_client):
    client, _ = submit_client
    resp = client.post("/api/reports/does_not_exist/submit", json={"values": {}})
    assert resp.status_code == 404


# --- submitted_by identity precedence -------------------------------------------
def _submit(client, headers):
    """Fire a minimal valid submit with the given SSO identity headers."""
    return client.post(
        f"/api/reports/{_AGENT_ITEM}/submit",
        json={
            "values": {
                "transaction_date_from": "2026-01-01",
                "transaction_date_to": "2026-01-10",
            }
        },
        headers=headers,
    )


def test_submitted_by_prefers_email_over_numeric_user_id(submit_client):
    """The human email wins over the opaque numeric X-Forwarded-User id."""
    client, rec = submit_client
    resp = _submit(
        client,
        {
            "X-Forwarded-Email": "idris.chakera@databricks.com",
            "X-Forwarded-Preferred-Username": "idris.chakera@databricks.com",
            "X-Forwarded-User": "8241774669268934",
        },
    )
    assert resp.status_code == 200, resp.text
    assert rec["inserts"][0]["submitted_by"] == "idris.chakera@databricks.com"


def test_submitted_by_falls_back_to_preferred_username_then_user_id(submit_client):
    """No email ⇒ preferred_username; neither ⇒ the numeric user_id last."""
    client, rec = submit_client

    # email absent, preferred_username present ⇒ preferred_username.
    resp = _submit(
        client,
        {
            "X-Forwarded-Preferred-Username": "idris.chakera",
            "X-Forwarded-User": "8241774669268934",
        },
    )
    assert resp.status_code == 200, resp.text
    assert rec["inserts"][0]["submitted_by"] == "idris.chakera"

    # email and preferred_username both absent ⇒ numeric user_id as last resort.
    resp = _submit(client, {"X-Forwarded-User": "8241774669268934"})
    assert resp.status_code == 200, resp.text
    assert rec["inserts"][1]["submitted_by"] == "8241774669268934"
