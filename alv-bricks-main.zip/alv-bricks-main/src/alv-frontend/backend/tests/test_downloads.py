"""Tests for the Downloads list + parameters info view.

Three layers, so a regression lands on the narrowest failing test:

* **SQL build (pure)** — :func:`alv_app.downloads.build_requests_sql`: the scope
  predicate, the ``alv_id`` allowlist, the sort allowlist, and the guarantee that every
  user-supplied value is BOUND (a quote / semicolon in ``q`` or the identity can never
  reach the statement text).
* **Query resolution** — the endpoint's trust boundary: scope/sort vocabularies, limit
  clamping, and the permission-aware ``alv_id`` allowlist that carries the search.
* **Endpoint** — ``GET /api/requests`` (shape, scope, search, pagination + the
  more-rows signal, degrade-on-failure) and ``GET /api/requests/{n}/params`` (shape and
  every malformed-payload path). The 404-on-deny gate for both lives in
  ``test_permissions.py``, next to the rest of the visibility matrix.

The warehouse is mocked throughout (``fetch_requests_page`` / ``fetch_request_params``
patched into main), so no live workspace is needed — mirroring the fixture style in
``conftest.py``.
"""

from __future__ import annotations

import json

import pytest

import alv_app.main as main_mod
from alv_app.config import Settings
from alv_app.downloads import (
    RequestPage,
    RequestQuery,
    build_requests_sql,
    clamp_limit,
    fetch_requests_page,
    identity_match_values,
    normalize_scope,
    normalize_sort,
)
from alv_app.identity import UserIdentity

_AGENT_ITEM = "retail_ledger__detail__agent_item"
_OTHER_ITEM = "retail_ledger__summary__agent"

# The identity conftest's dev fallback resolves to (see Settings.dev_user_email).
_DEV_EMAIL = "local.dev@example.com"


def _settings(**kw) -> Settings:
    return Settings(databricks_warehouse_id="wh-1", **kw)


def _ident(email="user@example.com", username=None, user_id="aad-1") -> UserIdentity:
    return UserIdentity(
        email=email,
        preferred_username=username if username is not None else email,
        user_id=user_id,
        real_ip="10.0.0.1",
        authenticated=True,
        has_user_token=True,
        user_token="obo",
    )


def _row(request_no="REQ-ABC123", alv_id=_AGENT_ITEM, submitted_by="someone", **kw):
    """One warehouse-shaped request_log row."""
    base = {
        "request_no": request_no,
        "alv_id": alv_id,
        "status": "COMPLETED",
        "submitted_by": submitted_by,
        "submitted_at": "2026-07-29T10:00:00Z",
        "run_id": 987654321,
        "output_path": "/Volumes/x/y/out.csv",
    }
    base.update(kw)
    return base


def _capture_page(monkeypatch, rows=(), has_more=False) -> dict:
    """Patch the warehouse read; record the RequestQuery it was handed."""
    seen: dict = {}

    def _fake(settings, query):
        seen["query"] = query
        return RequestPage(rows=list(rows), has_more=has_more)

    monkeypatch.setattr(main_mod, "fetch_requests_page", _fake)
    return seen


# ---------------------------------------------------------------------------
# SQL build (pure) — bound parameters + allowlists
# ---------------------------------------------------------------------------
def test_sql_orders_and_paginates_by_default():
    sql, params = build_requests_sql(
        RequestQuery(alv_ids=(_AGENT_ITEM,), limit=50, offset=0), _settings()
    )
    assert "ORDER BY submitted_at DESC, request_no DESC" in sql
    assert "LIMIT :row_limit OFFSET :row_offset" in sql
    bound = {p.name: p.value for p in params}
    # limit + 1 is fetched so has_more is exact without a second COUNT query.
    assert bound["row_limit"] == "51"
    assert bound["row_offset"] == "0"


def test_sql_asc_sort_comes_from_the_allowlist():
    sql, _ = build_requests_sql(
        RequestQuery(alv_ids=(_AGENT_ITEM,), sort="submitted_at_asc"), _settings()
    )
    assert "ORDER BY submitted_at ASC, request_no ASC" in sql


def test_sql_binds_the_alv_id_allowlist_as_one_json_param():
    """The report filter is ONE bound JSON array, not a marker per id.

    Keeps a user with many reports well clear of the statement API's 256-parameter cap.
    """
    sql, params = build_requests_sql(
        RequestQuery(alv_ids=(_AGENT_ITEM, _OTHER_ITEM)), _settings()
    )
    assert "array_contains(from_json(:alv_ids, 'array<string>'), alv_id)" in sql
    bound = [p for p in params if p.name == "alv_ids"]
    assert len(bound) == 1
    assert json.loads(bound[0].value) == [_AGENT_ITEM, _OTHER_ITEM]
    # The ids themselves never appear in the SQL text.
    assert _AGENT_ITEM not in sql


def test_sql_scope_mine_matches_every_identity_form_case_insensitively():
    """submitted_by has been written as email / preferred_username / user_id over time."""
    query = RequestQuery(
        alv_ids=(_AGENT_ITEM,),
        scope="mine",
        identities=("me@example.com", "me", "aad-99"),
    )
    sql, params = build_requests_sql(query, _settings())
    assert "lower(submitted_by) IN (:me0,:me1,:me2)" in sql
    bound = {p.name: p.value for p in params}
    assert bound["me0"] == "me@example.com"
    assert bound["me1"] == "me"
    assert bound["me2"] == "aad-99"


def test_sql_scope_accessible_has_no_owner_predicate():
    """Cross-user visibility is intended: `accessible` must not filter by submitter."""
    sql, params = build_requests_sql(
        RequestQuery(alv_ids=(_AGENT_ITEM,), scope="accessible", identities=("me@x",)),
        _settings(),
    )
    # submitted_by is SELECTed (the column is displayed) but never filtered on.
    assert "lower(submitted_by)" not in sql
    assert "WHERE" in sql and "submitted_by" not in sql.split("WHERE", 1)[1]
    assert not any(p.value == "me@x" for p in params)


def test_sql_scope_mine_without_an_identity_matches_nothing():
    """An unidentifiable caller owns nothing — never silently widened to every row."""
    sql, _ = build_requests_sql(
        RequestQuery(alv_ids=(_AGENT_ITEM,), scope="mine", identities=()), _settings()
    )
    assert "1 = 0" in sql


def test_sql_bypass_allowlist_none_omits_the_report_filter():
    sql, params = build_requests_sql(RequestQuery(alv_ids=None), _settings())
    assert "array_contains" not in sql
    assert not any(p.name == "alv_ids" for p in params)


@pytest.mark.parametrize(
    "hostile",
    [
        "'; DROP TABLE request_log; --",
        "x' OR '1'='1",
        'quote" and semi; colon',
        "-- comment\nUNION SELECT 1",
    ],
)
def test_hostile_search_and_identity_values_are_always_bound(hostile):
    """A quote/semicolon in a user value cannot break or alter the SQL.

    The search term reaches SQL only as resolved ``alv_id`` s (so a hostile term simply
    matches no report), and the identity reaches it only as a bound marker. Either way
    the raw string never appears in the statement text.
    """
    # As a (hypothetically matching) alv_id in the allowlist:
    sql, params = build_requests_sql(RequestQuery(alv_ids=(hostile,)), _settings())
    assert hostile not in sql
    assert hostile in json.loads(next(p.value for p in params if p.name == "alv_ids"))

    # And as an identity under scope=mine:
    sql2, params2 = build_requests_sql(
        RequestQuery(alv_ids=(_AGENT_ITEM,), scope="mine", identities=(hostile,)),
        _settings(),
    )
    assert hostile not in sql2
    assert any(p.value == hostile for p in params2)


def test_empty_allowlist_returns_an_empty_page_without_querying(monkeypatch):
    """No permitted/matching reports ⇒ answered locally, never by scanning the table."""
    import alv_app.downloads as downloads_mod

    def _boom(*a, **kw):
        raise AssertionError("no statement may be executed for an empty allowlist")

    monkeypatch.setattr(downloads_mod, "_execute", _boom)

    page = fetch_requests_page(_settings(), RequestQuery(alv_ids=()))
    assert page.rows == []
    assert page.has_more is False


def test_fetch_page_trims_the_extra_row_and_sets_has_more(monkeypatch):
    """The (limit+1)-th row proves a next page exists and is then dropped."""
    import alv_app.downloads as downloads_mod

    def _fake_execute(settings, sql, params, *, what):
        # Three rows returned for a limit of 2 ⇒ has_more, page trimmed to 2.
        return [
            [f"REQ-{i}", _AGENT_ITEM, "COMPLETED", "someone", "2026-07-29T10:00:00Z", "1", None]
            for i in range(3)
        ]

    monkeypatch.setattr(downloads_mod, "_execute", _fake_execute)

    page = fetch_requests_page(_settings(), RequestQuery(alv_ids=(_AGENT_ITEM,), limit=2))
    assert [r["request_no"] for r in page.rows] == ["REQ-0", "REQ-1"]
    assert page.has_more is True
    # run_id is coerced from the warehouse's string cell.
    assert page.rows[0]["run_id"] == 1


def test_fetch_page_exact_fill_is_not_more_rows(monkeypatch):
    """Exactly `limit` rows back means this was the last page, not a full one."""
    import alv_app.downloads as downloads_mod

    monkeypatch.setattr(
        downloads_mod,
        "_execute",
        lambda settings, sql, params, *, what: [
            [f"REQ-{i}", _AGENT_ITEM, "COMPLETED", "someone", "t", None, None]
            for i in range(2)
        ],
    )
    page = fetch_requests_page(_settings(), RequestQuery(alv_ids=(_AGENT_ITEM,), limit=2))
    assert len(page.rows) == 2
    assert page.has_more is False


# ---------------------------------------------------------------------------
# Query resolution — the trust boundary
# ---------------------------------------------------------------------------
def test_scope_and_sort_vocabularies_default_on_anything_unknown():
    assert normalize_scope(None) == "accessible"
    assert normalize_scope("mine") == "mine"
    assert normalize_scope("MINE") == "mine"
    assert normalize_scope("everyone") == "accessible"
    assert normalize_scope("submitted_at DESC; DROP TABLE x") == "accessible"

    assert normalize_sort(None) == "submitted_at_desc"
    assert normalize_sort("submitted_at_asc") == "submitted_at_asc"
    assert normalize_sort("row_count DESC") == "submitted_at_desc"


def test_limit_is_clamped_to_the_configured_maximum():
    s = _settings(downloads_page_size=50, downloads_max_page_size=200)
    assert clamp_limit(s, None) == 50
    assert clamp_limit(s, 10) == 10
    assert clamp_limit(s, 10_000) == 200  # hard cap
    assert clamp_limit(s, 0) == 1  # floor
    assert clamp_limit(s, -5) == 1


def test_identity_match_values_dedupes_and_folds_case():
    ident = _ident(email="Me@Example.COM", username="Me@Example.com", user_id="AAD-1")
    # email == preferred_username collapses to one entry; all folded lower.
    assert identity_match_values(ident) == ("me@example.com", "aad-1")

    assert identity_match_values(_ident(email=None, username=None, user_id="only-id")) == (
        "only-id",
    )
    assert identity_match_values(_ident(email=None, username=None, user_id=None)) == ()


def test_listable_alv_ids_filters_by_permission_then_search(client):
    """The allowlist is permission-first: search narrows it, never widens it."""
    ident = main_mod.resolve_identity  # sanity: patched resolver exists
    assert ident is not None

    cache = main_mod._cache
    settings = main_mod.get_settings()
    from alv_app.identity import UserIdentity as UI

    who = UI(
        email=_DEV_EMAIL,
        preferred_username=_DEV_EMAIL,
        user_id="local-dev-user",
        real_ip=None,
        authenticated=True,
        has_user_token=True,
        user_token="test-obo-token",
    )

    all_ids = cache.listable_alv_ids(settings, who)
    assert all_ids is not None and len(all_ids) == 14  # the 14 permitted pilot rows

    # A term matching the report label keeps them all (one report_key in the pilot).
    assert cache.listable_alv_ids(settings, who, search="retail") == all_ids
    # A term matching nothing yields an EMPTY allowlist (⇒ empty page, no query).
    assert cache.listable_alv_ids(settings, who, search="no-such-report") == ()
    # Case-insensitive.
    assert cache.listable_alv_ids(settings, who, search="RETAIL LEDGER") == all_ids
    # Blank / whitespace search is not a search.
    assert cache.listable_alv_ids(settings, who, search="   ") == all_ids


# ---------------------------------------------------------------------------
# GET /api/requests — endpoint
# ---------------------------------------------------------------------------
def test_requests_shape_and_label(client, monkeypatch):
    """Rows map to RequestOut and report_label resolves from the metadata cache."""
    _capture_page(monkeypatch, rows=[_row()])

    resp = client.get("/api/requests")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert len(body["requests"]) == 1

    first = body["requests"][0]
    assert first["request_no"] == "REQ-ABC123"
    assert first["alv_id"] == _AGENT_ITEM
    # Known alv_id ⇒ human label resolved from the cache (not just the id).
    assert first["report_label"] is not None
    assert first["status"] == "COMPLETED"
    assert first["run_id"] == 987654321
    assert first["output_path"] == "/Volumes/x/y/out.csv"


def test_requests_defaults_are_accessible_scope_and_submitted_at_desc(client, monkeypatch):
    seen = _capture_page(monkeypatch, rows=[_row()])
    body = client.get("/api/requests").json()

    query = seen["query"]
    assert query.scope == "accessible"
    assert query.sort == "submitted_at_desc"
    assert query.offset == 0
    # Echoed back so the UI can see what the server actually applied.
    assert body["scope"] == "accessible"
    assert body["sort"] == "submitted_at_desc"
    assert body["q"] is None


def test_requests_scope_mine_passes_the_callers_identities(client, monkeypatch):
    seen = _capture_page(monkeypatch, rows=[_row(submitted_by=_DEV_EMAIL)])
    body = client.get("/api/requests?scope=mine").json()

    query = seen["query"]
    assert query.scope == "mine"
    # The dev-fallback identity's email + user_id, folded and de-duplicated.
    assert _DEV_EMAIL in query.identities
    assert body["scope"] == "mine"


def test_requests_shows_another_users_row_in_accessible_scope(client, monkeypatch):
    """Cross-user visibility is intended and submitted_by is NOT masked."""
    _capture_page(monkeypatch, rows=[_row(submitted_by="someone.else@example.com")])

    body = client.get("/api/requests").json()
    assert len(body["requests"]) == 1
    assert body["requests"][0]["submitted_by"] == "someone.else@example.com"


def test_requests_unknown_scope_falls_back_to_the_default(client, monkeypatch):
    seen = _capture_page(monkeypatch, rows=[])
    body = client.get("/api/requests?scope=everyones-rows").json()
    assert seen["query"].scope == "accessible"
    assert body["scope"] == "accessible"


def test_requests_search_narrows_the_allowlist_in_the_query(client, monkeypatch):
    """Search is resolved to an alv_id allowlist server-side, never filtered client-side."""
    seen = _capture_page(monkeypatch, rows=[_row()])
    body = client.get("/api/requests?q=retail").json()
    assert seen["query"].alv_ids is not None
    assert len(seen["query"].alv_ids) == 14
    assert body["q"] == "retail"


def test_requests_search_with_no_match_serves_empty_without_querying(client, monkeypatch):
    """A non-matching search resolves to an empty allowlist ⇒ no statement at all.

    The REAL read runs here; patching the statement seam is what proves the
    short-circuit (an executed statement would mean the search had leaked past it).
    """
    import alv_app.downloads as downloads_mod

    def _should_not_execute(*a, **kw):
        raise AssertionError("a non-matching search must not execute a statement")

    monkeypatch.setattr(downloads_mod, "_execute", _should_not_execute)

    body = client.get("/api/requests?q=definitely-not-a-report").json()
    assert body["requests"] == []
    assert body["has_more"] is False
    assert body["q"] == "definitely-not-a-report"


def test_requests_pagination_signals_more_rows(client, monkeypatch):
    _capture_page(monkeypatch, rows=[_row(f"REQ-{i}") for i in range(5)], has_more=True)
    body = client.get("/api/requests?limit=5&offset=10").json()
    assert body["limit"] == 5
    assert body["offset"] == 10
    assert body["has_more"] is True
    assert len(body["requests"]) == 5


def test_requests_last_page_reports_no_more_rows(client, monkeypatch):
    _capture_page(monkeypatch, rows=[_row()], has_more=False)
    body = client.get("/api/requests?limit=5&offset=0").json()
    assert body["has_more"] is False


def test_requests_limit_is_clamped_and_negative_offset_floored(client, monkeypatch):
    seen = _capture_page(monkeypatch, rows=[])
    client.get("/api/requests?limit=99999&offset=-3")
    assert seen["query"].limit == 200  # downloads_max_page_size
    assert seen["query"].offset == 0


def test_requests_graceful_on_warehouse_failure(client, monkeypatch):
    """A warehouse error ⇒ empty page + 200 (never a 500), like the catalogue."""
    from alv_app.downloads import DownloadsSourceError

    def _boom(settings, query):
        raise DownloadsSourceError("warehouse unreachable")

    monkeypatch.setattr(main_mod, "fetch_requests_page", _boom)

    resp = client.get("/api/requests")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["requests"] == []
    assert body["has_more"] is False


def test_requests_drops_the_label_for_an_unresolvable_alv_id(client, monkeypatch):
    """A row the allowlist could not have matched still renders without a label.

    In practice the SQL allowlist means such a row never comes back; if one somehow
    does, it must not crash the page — and it gets no label (the FE shows the alv_id).
    """
    _capture_page(monkeypatch, rows=[_row(alv_id="does_not_exist")])
    body = client.get("/api/requests").json()
    assert body["requests"][0]["report_label"] is None


# ---------------------------------------------------------------------------
# GET /api/requests/{request_no}/params — the info view
# ---------------------------------------------------------------------------
def _patch_params(monkeypatch, payload, **overrides):
    row = {
        "request_no": "REQ-ABC123",
        "alv_id": _AGENT_ITEM,
        "param_payload_json": payload,
        "param_hash": "deadbeef",
        "submitted_at": "2026-07-29T10:00:00Z",
    }
    row.update(overrides)
    monkeypatch.setattr(main_mod, "fetch_request_params", lambda settings, request_no: row)


def test_params_returns_the_effective_payload(client, monkeypatch):
    _patch_params(monkeypatch, '{"agent_code":"A1","date_from":"2026-01-01"}')

    resp = client.get("/api/requests/REQ-ABC123/params")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["parse_ok"] is True
    assert body["parameters"] == {"agent_code": "A1", "date_from": "2026-01-01"}
    assert body["param_hash"] == "deadbeef"
    assert body["report_label"] is not None
    assert body["detail"] is None


def test_params_missing_row_is_404(client, monkeypatch):
    monkeypatch.setattr(main_mod, "fetch_request_params", lambda settings, request_no: None)
    resp = client.get("/api/requests/REQ-NOPE/params")
    assert resp.status_code == 404
    assert resp.json()["detail"] == "request not found: REQ-NOPE"


def test_params_unreadable_row_is_404(client, monkeypatch):
    from alv_app.downloads import DownloadsSourceError

    def _boom(settings, request_no):
        raise DownloadsSourceError("warehouse unreachable")

    monkeypatch.setattr(main_mod, "fetch_request_params", _boom)
    assert client.get("/api/requests/REQ-ABC123/params").status_code == 404


@pytest.mark.parametrize(
    "payload,expect_detail_contains",
    [
        (None, "no parameters"),
        ("", "no parameters"),
        ("   ", "no parameters"),
        ("{not json at all", "could not be read"),
        ("[1,2,3]", "expected shape"),
        ('"just a string"', "expected shape"),
        ("42", "expected shape"),
    ],
)
def test_params_malformed_payload_never_500s(
    client, monkeypatch, payload, expect_detail_contains
):
    """Null / empty / malformed param_payload_json is a data condition, not a fault."""
    _patch_params(monkeypatch, payload)

    resp = client.get("/api/requests/REQ-ABC123/params")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["parse_ok"] is False
    assert body["parameters"] == {}
    assert expect_detail_contains in body["detail"]


def test_params_preserves_nulls_and_renders_nested_values(client, monkeypatch):
    """A blank-but-sent param stays visible as null; nested structures are rendered."""
    _patch_params(
        monkeypatch, '{"blank":null,"count":3,"flag":true,"nested":{"a":1},"list":[1,2]}'
    )
    body = client.get("/api/requests/REQ-ABC123/params").json()
    assert body["parse_ok"] is True
    assert body["parameters"]["blank"] is None
    assert body["parameters"]["count"] == "3"
    assert body["parameters"]["flag"] == "True"
    assert body["parameters"]["nested"] == '{"a": 1}'
    assert body["parameters"]["list"] == "[1, 2]"
