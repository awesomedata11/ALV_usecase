"""Tests for status polling (task 8.x).

Covers the run-state → status vocabulary mapping (pure), the update_status
warehouse write (via the injected fake executor), and the status endpoint end-to-end
(status changed / unchanged / null run_id / run unreadable / missing row) — all with
the warehouse read + run-state read mocked, so no live workspace is needed.
"""

from __future__ import annotations

import alv_app.main as main_mod
from alv_app.databricks_client import RunStatus, _map_run_state

# The alv_id every faked request_log row belongs to. It must resolve in the metadata
# cache: the status endpoint reads the row's alv_id → report_key to enforce report
# visibility, and denies (404) a row it cannot attribute to a known report.
_AGENT_ITEM = "retail_ledger__detail__agent_item"


# --- run-state mapping (pure) ---------------------------------------------------
def test_map_pending_and_queued_to_queued():
    assert _map_run_state("PENDING", None) == "QUEUED"
    assert _map_run_state("BLOCKED", None) == "QUEUED"
    assert _map_run_state("QUEUED", None) == "QUEUED"
    assert _map_run_state("WAITING_FOR_RETRY", None) == "QUEUED"


def test_map_running_and_terminating_to_running():
    assert _map_run_state("RUNNING", None) == "RUNNING"
    assert _map_run_state("TERMINATING", None) == "RUNNING"


def test_map_terminated_success():
    assert _map_run_state("TERMINATED", "SUCCESS") == "SUCCESS"


def test_map_terminated_failure_variants():
    assert _map_run_state("TERMINATED", "FAILED") == "FAILED"
    assert _map_run_state("TERMINATED", "ERROR") == "FAILED"
    assert _map_run_state("TERMINATED", "TIMEDOUT") == "FAILED"


def test_map_terminated_cancelled():
    assert _map_run_state("TERMINATED", "CANCELED") == "CANCELLED"


def test_map_terminal_without_result_is_failed():
    # INTERNAL_ERROR / SKIPPED (or TERMINATED with an unknown result) ⇒ FAILED.
    assert _map_run_state("INTERNAL_ERROR", None) == "FAILED"
    assert _map_run_state("SKIPPED", None) == "FAILED"
    assert _map_run_state("TERMINATED", "MAXIMUM_CONCURRENT_RUNS_REACHED") == "FAILED"


def test_map_unknown_lifecycle_is_none():
    # Unrecognized, non-terminal lifecycle ⇒ no mapping (caller keeps stored status).
    assert _map_run_state("SOMETHING_NEW", None) is None
    assert _map_run_state(None, None) is None


# --- get_run_status (SDK read, degrade) -----------------------------------------
def test_get_run_status_degrades_when_sdk_raises(monkeypatch):
    from alv_app import databricks_client as dc

    def _boom():
        raise RuntimeError("no creds")

    monkeypatch.setattr(dc, "get_workspace_client", _boom)
    res = dc.get_run_status(123)
    assert res.ok is False
    assert res.status is None
    assert "no creds" in (res.detail or "")


def test_get_run_status_maps_from_sdk_run(monkeypatch):
    from alv_app import databricks_client as dc

    class _State:
        # mimic the SDK enums carrying a .value wire name.
        life_cycle_state = type("E", (), {"value": "TERMINATED"})()
        result_state = type("E", (), {"value": "SUCCESS"})()

    class _Run:
        state = _State()

    class _Client:
        class jobs:  # noqa: N801 - mimic client.jobs.get_run
            @staticmethod
            def get_run(run_id):
                return _Run()

    monkeypatch.setattr(dc, "get_workspace_client", lambda: _Client())
    res = dc.get_run_status(987)
    assert res.ok is True
    assert res.status == "SUCCESS"


# --- update_status warehouse write (injected fake executor) ---------------------
def test_update_status_executes_status_only(monkeypatch):
    from alv_app import request_log as rl
    from alv_app.config import Settings

    calls: list[dict[str, object]] = []

    def fake_execute(settings, statement, parameters):
        calls.append({"statement": statement, "parameters": parameters})

    monkeypatch.setattr(rl, "_execute", fake_execute)
    rl.update_status(Settings(), request_no="REQ-1", status="SUCCESS")

    assert len(calls) == 1
    stmt = calls[0]["statement"]
    assert "SET status = :status" in stmt
    assert "output_path" not in stmt  # status-only path
    names = {p["name"]: p["value"] for p in calls[0]["parameters"]}
    assert names == {"status": "SUCCESS", "request_no": "REQ-1"}


def test_update_status_includes_output_path_when_given(monkeypatch):
    from alv_app import request_log as rl
    from alv_app.config import Settings

    calls: list[dict[str, object]] = []
    monkeypatch.setattr(rl, "_execute", lambda s, statement, parameters: calls.append(
        {"statement": statement, "parameters": parameters}
    ))
    rl.update_status(Settings(), request_no="REQ-2", status="SUCCESS", output_path="/Volumes/x/out.csv")

    stmt = calls[0]["statement"]
    assert "output_path = :output_path" in stmt
    names = {p["name"]: p["value"] for p in calls[0]["parameters"]}
    assert names["output_path"] == "/Volumes/x/out.csv"


def test_update_status_includes_full_output_pointer(monkeypatch):
    """9.x: output_path + row_count + generated_at are all written when supplied."""
    from alv_app import request_log as rl
    from alv_app.config import Settings

    calls: list[dict[str, object]] = []
    monkeypatch.setattr(rl, "_execute", lambda s, statement, parameters: calls.append(
        {"statement": statement, "parameters": parameters}
    ))
    rl.update_status(
        Settings(),
        request_no="REQ-3",
        status="COMPLETED",
        output_path="/Volumes/x/out.csv",
        row_count=1234,
        generated_at="2026-07-30T00:00:00Z",
    )

    stmt = calls[0]["statement"]
    assert "output_path = :output_path" in stmt
    assert "row_count = :row_count" in stmt
    assert "generated_at = :generated_at" in stmt
    names = {p["name"]: p["value"] for p in calls[0]["parameters"]}
    assert names["row_count"] == "1234"
    assert names["generated_at"] == "2026-07-30T00:00:00Z"
    assert names["status"] == "COMPLETED"


# --- expires_at = generated_at + TTL --------------------------------------------
def test_update_status_sets_expires_at_from_generated_at_and_ttl(monkeypatch):
    """A captured output always gets a retention horizon, on the SAME statement.

    ``expires_at`` is derived in SQL from the same bound ``generated_at`` (which is an
    arbitrary Job-supplied string), so it cannot drift from it or be skipped.
    """
    from alv_app import request_log as rl
    from alv_app.config import Settings

    calls: list[dict[str, object]] = []
    monkeypatch.setattr(rl, "_execute", lambda s, statement, parameters: calls.append(
        {"statement": statement, "parameters": parameters}
    ))
    rl.update_status(
        Settings(),  # result_ttl_days defaults to 7
        request_no="REQ-4",
        status="COMPLETED",
        output_path="/Volumes/x/out.csv",
        generated_at="2026-07-30T00:00:00Z",
    )

    stmt = calls[0]["statement"]
    assert "expires_at = timestampadd(DAY, :ttl_days, :generated_at)" in stmt
    names = {p["name"]: p["value"] for p in calls[0]["parameters"]}
    assert names["ttl_days"] == "7"
    # Derived from the SAME bound timestamp that generated_at is written from.
    assert names["generated_at"] == "2026-07-30T00:00:00Z"
    types = {p["name"]: p["type"] for p in calls[0]["parameters"]}
    assert types["ttl_days"] == "INT"


def test_update_status_ttl_is_configurable(monkeypatch):
    """RESULT_TTL_DAYS drives the horizon — the 7 days is a default, not a constant."""
    from alv_app import request_log as rl
    from alv_app.config import Settings

    calls: list[dict[str, object]] = []
    monkeypatch.setattr(rl, "_execute", lambda s, statement, parameters: calls.append(
        {"statement": statement, "parameters": parameters}
    ))
    rl.update_status(
        Settings(result_ttl_days=30),
        request_no="REQ-5",
        status="COMPLETED",
        generated_at="2026-07-30T00:00:00Z",
    )
    names = {p["name"]: p["value"] for p in calls[0]["parameters"]}
    assert names["ttl_days"] == "30"


def test_update_status_without_generated_at_writes_no_expires_at(monkeypatch):
    """A bare status poll must not stamp (or clear) a retention horizon."""
    from alv_app import request_log as rl
    from alv_app.config import Settings

    calls: list[dict[str, object]] = []
    monkeypatch.setattr(rl, "_execute", lambda s, statement, parameters: calls.append(
        {"statement": statement, "parameters": parameters}
    ))
    rl.update_status(Settings(), request_no="REQ-6", status="RUNNING")

    assert "expires_at" not in calls[0]["statement"]
    assert not any(p["name"] == "ttl_days" for p in calls[0]["parameters"])


# --- status endpoint ------------------------------------------------------------
def test_status_endpoint_advances_when_changed(client, monkeypatch):
    """Non-terminal state differs from stored ⇒ persist + return live status, updated=True."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "QUEUED",
            "run_id": 987654321,
            "output_path": None,
        },
    )
    monkeypatch.setattr(
        main_mod, "get_run_status", lambda run_id: RunStatus(ok=True, status="RUNNING", detail=None)
    )
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-ABC123/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "RUNNING"
    assert body["run_id"] == 987654321
    assert body["updated"] is True
    # Persisted exactly once, status-only (output capture only happens on SUCCESS).
    assert len(updates) == 1
    assert updates[0] == {"request_no": "REQ-ABC123", "status": "RUNNING"}


def test_status_endpoint_unchanged_does_not_write(client, monkeypatch):
    """Live state equals stored ⇒ no UPDATE, updated=False."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "RUNNING",
            "run_id": 42,
            "output_path": None,
        },
    )
    monkeypatch.setattr(
        main_mod, "get_run_status", lambda run_id: RunStatus(ok=True, status="RUNNING", detail=None)
    )
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-X/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "RUNNING"
    assert body["updated"] is False
    assert updates == []  # unchanged ⇒ no write


def test_status_endpoint_null_run_id_returns_stored(client, monkeypatch):
    """run_id NULL ⇒ return the stored status unchanged, no run-state read/write."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "QUEUED",
            "run_id": None,
            "output_path": None,
        },
    )

    def _should_not_call(run_id):
        raise AssertionError("get_run_status must not be called when run_id is NULL")

    monkeypatch.setattr(main_mod, "get_run_status", _should_not_call)

    resp = client.get("/api/requests/REQ-NORUN/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "QUEUED"
    assert body["run_id"] is None
    assert body["updated"] is False


def test_status_endpoint_unreadable_run_keeps_stored(client, monkeypatch):
    """Run state unreadable (ok=False) ⇒ keep stored status, no write."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "RUNNING",
            "run_id": 7,
            "output_path": None,
        },
    )
    monkeypatch.setattr(
        main_mod,
        "get_run_status",
        lambda run_id: RunStatus(ok=False, status=None, detail="no creds"),
    )
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-DEG/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "RUNNING"
    assert body["updated"] is False
    assert updates == []


def test_status_endpoint_missing_row_404(client, monkeypatch):
    monkeypatch.setattr(main_mod, "fetch_request", lambda settings, request_no: None)
    resp = client.get("/api/requests/REQ-NOPE/status")
    assert resp.status_code == 404
