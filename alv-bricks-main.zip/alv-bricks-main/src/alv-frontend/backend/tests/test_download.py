"""Tests for the output download (task 9.x — CONTRACT mechanism (a) + §4.2).

Two seams, both mocked so no live workspace is touched:

* **Output-pointer parse** — :func:`get_run_output` resolves the task run id,
  reads ``notebook_output.result`` and parses the frozen JSON pointer. Covers the
  happy path, ``truncated=true``, a ``FAILED`` payload, malformed JSON, and SDK
  failure (all degrade to ``ok=False`` rather than raising).
* **Status seam capture (9.x fits into 8.x)** — a SUCCESS run captures the pointer,
  persists ``output_path``/``row_count``/``generated_at`` and settles the row to
  ``COMPLETED``; a truncated/failed payload settles to ``FAILED`` with no path.
* **Download endpoint** — output present ⇒ streams the bytes as an attachment; no
  output ⇒ 409; non-Volume path ⇒ 422; read error ⇒ 502; missing row ⇒ 404.
"""

from __future__ import annotations

import io

import alv_app.main as main_mod
from alv_app.databricks_client import RunOutput, RunStatus, VolumeDownloadError

# The alv_id every faked request_log row belongs to. It must resolve in the metadata
# cache: the status/download endpoints read the row's alv_id → report_key to enforce
# report visibility, and deny (404) a row they cannot attribute to a known report.
_AGENT_ITEM = "retail_ledger__detail__agent_item"


# --- get_run_output: parse the returned pointer (CONTRACT mechanism (a)) ---------
class _NotebookOutput:
    def __init__(self, result, truncated=False):
        self.result = result
        self.truncated = truncated


class _RunOut:
    def __init__(self, notebook_output):
        self.notebook_output = notebook_output


class _Task:
    def __init__(self, run_id):
        self.run_id = run_id


class _Run:
    def __init__(self, tasks):
        self.tasks = tasks


def _client_returning(run_tasks, run_output):
    """A fake WorkspaceClient whose jobs.get_run / get_run_output are canned."""

    class _Jobs:
        @staticmethod
        def get_run(run_id):
            return _Run(run_tasks)

        @staticmethod
        def get_run_output(run_id):
            return run_output

    class _Client:
        jobs = _Jobs()

    return _Client()


def test_get_run_output_parses_valid_pointer(monkeypatch):
    from alv_app import databricks_client as dc

    payload = (
        '{"status": "COMPLETED", "output_path": "/Volumes/c/s/alv_outputs/out.csv", '
        '"row_count": 1234, "generated_at": "2026-07-30T00:00:00Z"}'
    )
    client = _client_returning([_Task(555)], _RunOut(_NotebookOutput(payload)))
    monkeypatch.setattr(dc, "get_workspace_client", lambda: client)

    out = dc.get_run_output(987)
    assert out.ok is True
    assert out.status == "COMPLETED"
    assert out.output_path == "/Volumes/c/s/alv_outputs/out.csv"
    assert out.row_count == 1234
    assert out.generated_at == "2026-07-30T00:00:00Z"


def test_get_run_output_row_count_optional(monkeypatch):
    from alv_app import databricks_client as dc

    payload = '{"status": "COMPLETED", "output_path": "/Volumes/c/s/o.csv"}'
    client = _client_returning([_Task(1)], _RunOut(_NotebookOutput(payload)))
    monkeypatch.setattr(dc, "get_workspace_client", lambda: client)

    out = dc.get_run_output(1)
    assert out.ok is True
    assert out.output_path == "/Volumes/c/s/o.csv"
    assert out.row_count is None
    assert out.generated_at is None


def test_get_run_output_truncated_degrades(monkeypatch):
    from alv_app import databricks_client as dc

    # truncated=true ⇒ RIL returned data not a pointer (>~5 MB); we never parse it.
    client = _client_returning([_Task(1)], _RunOut(_NotebookOutput("{...}", truncated=True)))
    monkeypatch.setattr(dc, "get_workspace_client", lambda: client)

    out = dc.get_run_output(1)
    assert out.ok is False
    assert out.output_path is None
    assert "truncated" in (out.detail or "")


def test_get_run_output_failed_payload(monkeypatch):
    from alv_app import databricks_client as dc

    payload = '{"status": "FAILED", "error_message": "boom"}'
    client = _client_returning([_Task(1)], _RunOut(_NotebookOutput(payload)))
    monkeypatch.setattr(dc, "get_workspace_client", lambda: client)

    out = dc.get_run_output(1)
    # Parseable, so ok=True, but status is FAILED and there's no output_path.
    assert out.ok is True
    assert out.status == "FAILED"
    assert out.output_path is None


def test_get_run_output_malformed_json(monkeypatch):
    from alv_app import databricks_client as dc

    client = _client_returning([_Task(1)], _RunOut(_NotebookOutput("not json{")))
    monkeypatch.setattr(dc, "get_workspace_client", lambda: client)

    out = dc.get_run_output(1)
    assert out.ok is False
    assert "malformed" in (out.detail or "")


def test_get_run_output_no_tasks(monkeypatch):
    from alv_app import databricks_client as dc

    client = _client_returning([], _RunOut(_NotebookOutput("{}")))
    monkeypatch.setattr(dc, "get_workspace_client", lambda: client)

    out = dc.get_run_output(1)
    assert out.ok is False
    assert "no tasks" in (out.detail or "")


def test_get_run_output_degrades_when_sdk_raises(monkeypatch):
    from alv_app import databricks_client as dc

    def _boom():
        raise RuntimeError("no creds")

    monkeypatch.setattr(dc, "get_workspace_client", _boom)
    out = dc.get_run_output(1)
    assert out.ok is False
    assert "no creds" in (out.detail or "")


# --- status seam: SUCCESS captures the pointer + settles to COMPLETED (9.x) ------
def test_status_success_captures_output_and_completes(client, monkeypatch):
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "RUNNING",
            "run_id": 987654321,
            "output_path": None,
        },
    )
    monkeypatch.setattr(
        main_mod, "get_run_status", lambda run_id: RunStatus(ok=True, status="SUCCESS", detail=None)
    )
    monkeypatch.setattr(
        main_mod,
        "get_run_output",
        lambda run_id: RunOutput(
            ok=True,
            status="COMPLETED",
            output_path="/Volumes/c/s/alv_outputs/out.csv",
            row_count=1234,
            generated_at="2026-07-30T00:00:00Z",
            detail=None,
        ),
    )
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-DONE/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "COMPLETED"
    assert body["output_path"] == "/Volumes/c/s/alv_outputs/out.csv"
    assert body["updated"] is True
    # Persisted with the full pointer.
    assert len(updates) == 1
    assert updates[0] == {
        "request_no": "REQ-DONE",
        "status": "COMPLETED",
        "output_path": "/Volumes/c/s/alv_outputs/out.csv",
        "row_count": 1234,
        "generated_at": "2026-07-30T00:00:00Z",
    }


def test_status_success_already_captured_normalizes_to_completed(client, monkeypatch):
    """A prior poll captured the pointer ⇒ no re-fetch, status settles COMPLETED."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "SUCCESS",
            "run_id": 1,
            "output_path": "/Volumes/c/s/out.csv",
        },
    )
    monkeypatch.setattr(
        main_mod, "get_run_status", lambda run_id: RunStatus(ok=True, status="SUCCESS", detail=None)
    )

    def _should_not_call(run_id):
        raise AssertionError("get_run_output must not be called once already captured")

    monkeypatch.setattr(main_mod, "get_run_output", _should_not_call)
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-CAP/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "COMPLETED"
    assert body["output_path"] == "/Volumes/c/s/out.csv"
    # Normalized SUCCESS→COMPLETED with a status-only write.
    assert updates == [{"request_no": "REQ-CAP", "status": "COMPLETED"}]


def test_status_success_truncated_output_reflects_failure(client, monkeypatch):
    """SUCCESS run but a truncated/unreadable pointer ⇒ FAILED, output_path stays NULL."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "RUNNING",
            "run_id": 7,
            "output_path": None,
        },
    )
    monkeypatch.setattr(
        main_mod, "get_run_status", lambda run_id: RunStatus(ok=True, status="SUCCESS", detail=None)
    )
    monkeypatch.setattr(
        main_mod,
        "get_run_output",
        lambda run_id: RunOutput(False, None, None, None, None, "notebook exit value was truncated"),
    )
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-TRUNC/status")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["status"] == "FAILED"
    assert body["output_path"] is None
    assert updates == [{"request_no": "REQ-TRUNC", "status": "FAILED"}]


def test_status_success_failed_payload_reflects_failure(client, monkeypatch):
    """SUCCESS lifecycle but the payload declares FAILED ⇒ FAILED, no output_path."""
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "RUNNING",
            "run_id": 7,
            "output_path": None,
        },
    )
    monkeypatch.setattr(
        main_mod, "get_run_status", lambda run_id: RunStatus(ok=True, status="SUCCESS", detail=None)
    )
    monkeypatch.setattr(
        main_mod,
        "get_run_output",
        lambda run_id: RunOutput(True, "FAILED", None, None, None, None),
    )
    updates: list[dict[str, object]] = []
    monkeypatch.setattr(main_mod, "update_status", lambda settings, **kw: updates.append(kw))

    resp = client.get("/api/requests/REQ-JOBFAIL/status")
    assert resp.status_code == 200, resp.text
    assert resp.json()["status"] == "FAILED"
    assert updates == [{"request_no": "REQ-JOBFAIL", "status": "FAILED"}]


# --- download endpoint ----------------------------------------------------------
def test_download_streams_when_output_present(client, monkeypatch):
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "COMPLETED",
            "run_id": 1,
            "output_path": "/Volumes/c/s/alv_outputs/retail_ledger.csv",
        },
    )
    monkeypatch.setattr(
        main_mod, "download_volume_file", lambda path: io.BytesIO(b"a,b,c\n1,2,3\n")
    )

    resp = client.get("/api/requests/REQ-DL/download")
    assert resp.status_code == 200, resp.text
    assert resp.content == b"a,b,c\n1,2,3\n"
    # Attachment with the derived filename; .csv ⇒ text/csv. Raw path never leaked.
    cd = resp.headers["content-disposition"]
    assert 'filename="retail_ledger.csv"' in cd
    assert "/Volumes/" not in cd
    assert resp.headers["content-type"].startswith("text/csv")


def test_download_409_when_no_output(client, monkeypatch):
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "RUNNING",
            "run_id": 1,
            "output_path": None,
        },
    )
    resp = client.get("/api/requests/REQ-PENDING/download")
    assert resp.status_code == 409


def test_download_404_when_missing_row(client, monkeypatch):
    monkeypatch.setattr(main_mod, "fetch_request", lambda settings, request_no: None)
    resp = client.get("/api/requests/REQ-NOPE/download")
    assert resp.status_code == 404


def test_download_422_when_not_a_volume(client, monkeypatch):
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "COMPLETED",
            "run_id": 1,
            "output_path": "abfss://container@acct.dfs.core.windows.net/out.csv",
        },
    )
    resp = client.get("/api/requests/REQ-ADLS/download")
    assert resp.status_code == 422


def test_download_502_when_read_fails(client, monkeypatch):
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "COMPLETED",
            "run_id": 1,
            "output_path": "/Volumes/c/s/out.csv",
        },
    )

    def _boom(path):
        raise VolumeDownloadError("file gone")

    monkeypatch.setattr(main_mod, "download_volume_file", _boom)
    resp = client.get("/api/requests/REQ-ERR/download")
    assert resp.status_code == 502


def test_download_404_when_read_source_error(client, monkeypatch):
    """A warehouse read failure on the row lookup ⇒ 404 (can't confirm the request)."""
    from alv_app.downloads import DownloadsSourceError

    def _boom(settings, request_no):
        raise DownloadsSourceError("warehouse unreachable")

    monkeypatch.setattr(main_mod, "fetch_request", _boom)
    resp = client.get("/api/requests/REQ-WH/download")
    assert resp.status_code == 404
