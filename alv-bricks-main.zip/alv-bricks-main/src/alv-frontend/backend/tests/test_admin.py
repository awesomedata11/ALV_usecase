"""Tests for the admin console: the admin gate + the grant/revoke write path.

The admin surface is a **new write path**, so the suite drives the real gate and the
real endpoint logic, mocking only the two outer seams:

* the ``/Me`` group read (for the admin group check + the report gate), and
* ``alv_app.admin._execute`` — the warehouse statement seam (grant/revoke/list), so
  no live workspace is needed. A tiny in-memory table stands in for
  ``report_permissions`` and records every statement.

Covered: the ALV_ADMINS gate (email, group, none-configured, fail-closed 404 for a
non-admin), grant of a comma-separated user+group list, the classify heuristic,
idempotent re-grant, revoke (soft-delete), immediate cache invalidation, and that a
freshly-granted user then passes the report gate.
"""

from __future__ import annotations

from dataclasses import replace

import pytest

import alv_app.admin as admin_mod
import alv_app.entitlements as ent
import alv_app.main as main_mod
from alv_app.config import Settings
from alv_app.identity import UserIdentity

_AGENT_ITEM = "retail_ledger__detail__agent_item"
_ADMIN_GROUP = "alv-admins"


# ---------------------------------------------------------------------------
# A fake report_permissions table behind admin._execute
# ---------------------------------------------------------------------------
class _FakeTable:
    """Minimal stand-in for report_permissions: parses the statements admin.py emits.

    Only the shapes this module produces are handled (MERGE upsert, UPDATE revoke,
    SELECT list) — enough to prove the endpoint logic without a warehouse.
    """

    def __init__(self):
        # (report_key, principal_type, principal_name) -> {is_active, granted_by}
        self.rows: dict[tuple[str, str, str], dict[str, object]] = {}
        self.statements: list[str] = []

    def execute(self, settings, statement, parameters):
        self.statements.append(statement)
        p = {item["name"]: item.get("value") for item in parameters}
        s = statement.strip()
        if s.startswith("MERGE"):
            key = (p["report_key"], p["ptype"], p["pname"])
            self.rows[key] = {"is_active": True, "granted_by": p.get("granted_by")}
            return []
        if s.startswith("UPDATE"):
            key = (p["report_key"], p["ptype"], p["pname"])
            if key in self.rows:
                self.rows[key]["is_active"] = False
            return []
        if s.startswith("SELECT"):
            rk = p["report_key"]
            out = []
            for (r, ptype, pname), meta in sorted(self.rows.items()):
                if r != rk:
                    continue
                out.append([r, ptype, pname, "true" if meta["is_active"] else "false", meta["granted_by"]])
            return out
        raise AssertionError(f"unexpected statement: {s[:40]}")


@pytest.fixture
def fake_table(monkeypatch):
    """Patch admin._execute onto an in-memory table; yield it for assertions."""
    t = _FakeTable()
    monkeypatch.setattr(admin_mod, "_execute", t.execute)
    yield t


# ---------------------------------------------------------------------------
# Identity + client helpers
# ---------------------------------------------------------------------------
def _admin_settings(**kw) -> Settings:
    base = {
        "catalog": "cat",
        "schema_name": "sch",
        "databricks_warehouse_id": "wh-1",
        "alv_admins": f"admin@example.com,{_ADMIN_GROUP}",
        "dev_bypass_permissions": False,
    }
    base.update(kw)
    return Settings(**base)


def _ident(email="admin@example.com", groups=frozenset(), token="obo") -> UserIdentity:
    return UserIdentity(
        email=email,
        preferred_username=email,
        user_id="aad-admin",
        real_ip="10.0.0.1",
        authenticated=True,
        has_user_token=token is not None,
        user_token=token,
    )


# ---------------------------------------------------------------------------
# The admin gate (unit)
# ---------------------------------------------------------------------------
def test_is_admin_by_email(monkeypatch):
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, token: frozenset())
    ent.clear_caches()
    assert admin_mod.is_admin(_admin_settings(), _ident(email="admin@example.com")) is True
    # Case-insensitive on the email.
    assert admin_mod.is_admin(_admin_settings(), _ident(email="ADMIN@example.com")) is True


def test_is_admin_by_group(monkeypatch):
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, token: frozenset({_ADMIN_GROUP}))
    ent.clear_caches()
    assert admin_mod.is_admin(_admin_settings(), _ident(email="someone@else.com")) is True


def test_not_admin_when_neither_matches(monkeypatch):
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, token: frozenset({"other-group"}))
    ent.clear_caches()
    assert admin_mod.is_admin(_admin_settings(), _ident(email="nobody@else.com")) is False


def test_no_admins_configured_denies_everyone():
    """Empty ALV_ADMINS ⇒ nobody is an admin (fail closed)."""
    assert admin_mod.is_admin(_admin_settings(alv_admins=""), _ident()) is False


def test_classify_token_heuristic():
    assert admin_mod.classify_token("alice@example.com") == ("user", "alice@example.com")
    assert admin_mod.classify_token("Alice@Example.COM") == ("user", "alice@example.com")
    assert admin_mod.classify_token("alv-report_ledger_group") == ("group", "alv-report_ledger_group")


# ---------------------------------------------------------------------------
# The write seam (unit, against the fake table)
# ---------------------------------------------------------------------------
def test_upsert_then_list(fake_table):
    s = _admin_settings()
    admin_mod.upsert_grant(s, report_key="retail_ledger", principal_type="user",
                           principal_name="User@Example.com", granted_by="admin@example.com")
    grants = admin_mod.list_report_grants(s, "retail_ledger")
    assert len(grants) == 1
    assert grants[0].principal_type == "user"
    assert grants[0].principal_name == "user@example.com"  # lower-cased
    assert grants[0].is_active is True


def test_revoke_soft_deletes(fake_table):
    s = _admin_settings()
    admin_mod.upsert_grant(s, report_key="retail_ledger", principal_type="group",
                           principal_name="grp", granted_by=None)
    admin_mod.revoke_grant(s, report_key="retail_ledger", principal_type="group", principal_name="grp")
    grants = admin_mod.list_report_grants(s, "retail_ledger")
    assert grants[0].is_active is False  # row still present, just inactive


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------
def _client(monkeypatch, fake_table, catalog_rows, *, caller_email, caller_groups,
            admins=f"admin@example.com,{_ADMIN_GROUP}"):
    """A TestClient whose cache holds catalog_rows and whose caller identity is fixed."""
    import alv_app.cache as cache_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: catalog_rows)
    ent.clear_caches()
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, token: frozenset(caller_groups))

    from alv_app.identity import resolve_identity as real_resolve

    def _resolve(request, settings):
        ident = real_resolve(request, settings)
        return replace(ident, email=caller_email, user_token="obo", has_user_token=True)

    monkeypatch.setattr(main_mod, "resolve_identity", _resolve)

    # The endpoints take Settings via Depends(get_settings); override that dependency
    # (patching the module attr would not reach the callable FastAPI captured at
    # route-definition time).
    from alv_app.config import get_settings as _get_settings

    settings = _admin_settings(alv_admins=admins)
    main_mod.app.dependency_overrides[_get_settings] = lambda: settings

    from fastapi.testclient import TestClient

    main_mod._cache = main_mod.MetadataCache(settings)
    main_mod._cache.load(force=True)
    return TestClient(main_mod.app)


@pytest.fixture(autouse=True)
def _clear_overrides():
    """Drop any dependency overrides this module set, after each test."""
    yield
    main_mod.app.dependency_overrides.clear()


def test_non_admin_gets_404_on_every_admin_route(monkeypatch, fake_table, catalog_rows):
    c = _client(monkeypatch, fake_table, catalog_rows, caller_email="nobody@x.com", caller_groups=set())
    assert c.get("/api/admin/permissions/retail_ledger").status_code == 404
    assert c.post("/api/admin/permissions/retail_ledger/grant",
                  json={"principals": "a@x.com"}).status_code == 404
    assert c.post("/api/admin/permissions/retail_ledger/revoke",
                  json={"principal_type": "user", "principal_name": "a@x.com"}).status_code == 404


def test_admin_grants_a_mixed_list(monkeypatch, fake_table, catalog_rows):
    c = _client(monkeypatch, fake_table, catalog_rows, caller_email="admin@example.com", caller_groups=set())
    resp = c.post(
        "/api/admin/permissions/retail_ledger/grant",
        json={"principals": "alice@example.com, alv-report_ledger_group"},
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    outcomes = {(r["principal_type"], r["principal_name"]): r["outcome"] for r in body["results"]}
    assert outcomes == {("user", "alice@example.com"): "granted", ("group", "alv-report_ledger_group"): "granted"}
    # Both land in the refreshed grant list.
    kinds = {(g["principal_type"], g["principal_name"]) for g in body["grants"]}
    assert kinds == {("user", "alice@example.com"), ("group", "alv-report_ledger_group")}


def test_grant_unknown_report_404s(monkeypatch, fake_table, catalog_rows):
    c = _client(monkeypatch, fake_table, catalog_rows, caller_email="admin@example.com", caller_groups=set())
    assert c.post("/api/admin/permissions/no_such/grant",
                  json={"principals": "a@x.com"}).status_code == 404


def test_grant_then_revoke_roundtrip(monkeypatch, fake_table, catalog_rows):
    c = _client(monkeypatch, fake_table, catalog_rows, caller_email="admin@example.com", caller_groups=set())
    c.post("/api/admin/permissions/retail_ledger/grant", json={"principals": "bob@example.com"})
    resp = c.post("/api/admin/permissions/retail_ledger/revoke",
                  json={"principal_type": "user", "principal_name": "bob@example.com"})
    assert resp.status_code == 200
    grants = {(g["principal_name"], g["is_active"]) for g in resp.json()["grants"]}
    assert ("bob@example.com", False) in grants


def test_grant_invalidates_the_permission_cache(monkeypatch, fake_table, catalog_rows):
    """After a grant, a freshly-granted user sees the report without waiting for the TTL."""
    cleared = {"n": 0}
    real_clear = ent.clear_caches

    def _counting_clear():
        cleared["n"] += 1
        real_clear()

    monkeypatch.setattr(main_mod, "clear_caches", _counting_clear)
    c = _client(monkeypatch, fake_table, catalog_rows, caller_email="admin@example.com", caller_groups=set())
    c.post("/api/admin/permissions/retail_ledger/grant", json={"principals": "carol@example.com"})
    assert cleared["n"] == 1


def test_me_reports_is_admin_flag(monkeypatch, fake_table, catalog_rows):
    admin = _client(monkeypatch, fake_table, catalog_rows, caller_email="admin@example.com", caller_groups=set())
    assert admin.get("/api/me").json()["is_admin"] is True
    non = _client(monkeypatch, fake_table, catalog_rows, caller_email="nobody@x.com", caller_groups=set())
    assert non.get("/api/me").json()["is_admin"] is False


def test_admin_reports_lists_all_seeded_reports(monkeypatch, fake_table, two_report_catalog_rows):
    """The console's report picker sees every seeded report, unfiltered by permission."""
    c = _client(monkeypatch, fake_table, two_report_catalog_rows,
                caller_email="admin@example.com", caller_groups=set())
    body = c.get("/api/admin/reports").json()
    keys = {g["report_key"] for g in body["groups"]}
    assert keys == {"retail_ledger", "cc_recharge"}


def test_admin_reports_404s_for_non_admin(monkeypatch, fake_table, catalog_rows):
    c = _client(monkeypatch, fake_table, catalog_rows, caller_email="nobody@x.com", caller_groups=set())
    assert c.get("/api/admin/reports").status_code == 404


def test_granted_user_then_passes_the_report_gate(monkeypatch, fake_table, catalog_rows):
    """End-to-end: an admin grants a user, who then sees the report through the gate.

    Proves the write path and the read gate agree on the (principal_type, email) shape,
    and that clearing the cache makes the grant effective within the same client.
    """
    import alv_app.cache as cache_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: catalog_rows)
    ent.clear_caches()
    # The report permission map is read through the same fake table the admin writes to.
    monkeypatch.setattr(
        ent, "fetch_report_permissions",
        lambda settings: [
            {"report_key": rk, "principal_type": pt, "principal_name": pn,
             "is_active": meta["is_active"]}
            for (rk, pt, pn), meta in fake_table.rows.items()
        ],
    )
    # The granted user is in no group; only the user grant can let them in.
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, token: frozenset())

    from alv_app.identity import resolve_identity as real_resolve

    def _resolve(request, settings):
        ident = real_resolve(request, settings)
        return replace(ident, email="admin@example.com", user_token="obo", has_user_token=True)

    monkeypatch.setattr(main_mod, "resolve_identity", _resolve)
    from alv_app.config import get_settings as _get_settings

    settings = _admin_settings()
    main_mod.app.dependency_overrides[_get_settings] = lambda: settings
    from fastapi.testclient import TestClient

    main_mod._cache = main_mod.MetadataCache(settings)
    main_mod._cache.load(force=True)
    with TestClient(main_mod.app) as c:
        # target user cannot see the report yet
        gate = __import__("alv_app.entitlements", fromlist=["permitted_report_keys"])
        target = replace(_ident(email="carol@example.com", token="obo"))
        assert "retail_ledger" not in gate.permitted_report_keys(settings, target)
        # admin grants carol
        r = c.post("/api/admin/permissions/retail_ledger/grant",
                   json={"principals": "carol@example.com"})
        assert r.status_code == 200, r.text
        # now the gate lets carol in (cache was cleared by the grant)
        assert "retail_ledger" in gate.permitted_report_keys(settings, target)
