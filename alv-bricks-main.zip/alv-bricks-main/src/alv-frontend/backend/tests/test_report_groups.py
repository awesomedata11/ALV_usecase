"""Tests for the home-page report-groups endpoint (report cards)."""

from __future__ import annotations


def test_report_groups_shape(client):
    resp = client.get("/api/report-groups")
    assert resp.status_code == 200
    body = resp.json()
    assert "groups" in body
    # The pilot seeds a single report_key (retail_ledger) across all 14 rows.
    assert len(body["groups"]) == 1
    g = body["groups"][0]
    assert g["report_key"] == "retail_ledger"
    assert g["report_label"] == "Retail Ledger"
    # The fixture rows carry no job_id (placeholders seed NULL), so nothing is
    # runnable yet — count is 0 until the deploy-time job-binding step.
    assert g["runnable_count"] == 0


def test_report_groups_counts_bound_jobs(client_with_jobs):
    body = client_with_jobs.get("/api/report-groups").json()
    g = body["groups"][0]
    assert g["report_key"] == "retail_ledger"
    # client_with_jobs binds a job_id on every active row → all 14 runnable.
    assert g["runnable_count"] == 14


def test_report_groups_two_distinct_cards(two_report_client):
    """Both seeded reports get their OWN card with their own label (28-row cache).

    The home page renders one card per entry, and each card's report_key is what the
    click hands to the router — so two cards with correct, distinct labels is the
    precondition for clicking 'Retail Ledger' opening Retail Ledger.
    """
    body = two_report_client.get("/api/report-groups").json()
    groups = {g["report_key"]: g for g in body["groups"]}
    assert set(groups) == {"retail_ledger", "cc_recharge"}
    assert groups["retail_ledger"]["report_label"] == "Retail Ledger"
    assert groups["cc_recharge"]["report_label"] == "CC Recharge Data"
    # No job_id on the fixture rows ⇒ nothing runnable yet, for both.
    assert [g["runnable_count"] for g in groups.values()] == [0, 0]


def test_report_groups_two_reports_count_bound_jobs_separately(two_report_client_with_jobs):
    """14 runnable each — not 28 on one card (which is what a merged tree would give)."""
    body = two_report_client_with_jobs.get("/api/report-groups").json()
    groups = {g["report_key"]: g["runnable_count"] for g in body["groups"]}
    assert groups == {"retail_ledger": 14, "cc_recharge": 14}


def test_report_groups_graceful_when_load_fails(monkeypatch):
    """A warehouse failure ⇒ empty groups, not a 500 (home page still renders)."""
    import alv_app.cache as cache_mod
    from alv_app.catalog_source import CatalogSourceError

    def boom(settings):
        raise CatalogSourceError("warehouse down")

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", boom)

    from fastapi.testclient import TestClient

    from alv_app import main

    main._cache = main.MetadataCache(main.get_settings())
    main._cache.load(force=True)
    with TestClient(main.app) as c:
        resp = c.get("/api/report-groups")
        assert resp.status_code == 200
        assert resp.json()["groups"] == []
