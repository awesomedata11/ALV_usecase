"""Tests for the sample-data preview feature.

Covers:
- ``parse_sample_query`` validation (valid block + negatives → SpecError).
- ``build_preview_sql`` PARAMETERIZED SQL generation (``:`` bind markers + the
  returned BoundParam list; user values are never concatenated into the SQL text).
- ``run_preview`` binds parameters and uses a plain WorkspaceClient (App SP, not OBO).
- ``POST /api/reports/{alv_id}/preview`` endpoint (404, 409, 200 success, truncated).
- A schema-contract test: the real 14-row retail_ledger manifest validates cleanly
  through the library parser/seeder with jsonschema importable.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from alv_app.fields import SpecError
from alv_app.preview import (
    BoundParam,
    ColumnDef,
    ParamMapping,
    SampleQuerySpec,
    build_preview_sql,
    parse_sample_query,
    run_preview,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CATALOG = "classic_stable_lakebase_catalog"
_SCHEMA = "alv_metadata"
_TABLE = f"`{_CATALOG}`.`{_SCHEMA}`.`retail_ledger_sample`"

# A minimal SampleQuerySpec shared across SQL-builder tests.
_SPEC = SampleQuerySpec(
    columns=[
        ColumnDef(display_name="Transaction Date", column_name="transaction_date"),
        ColumnDef(display_name="Agent Code", column_name="agent_code"),
    ],
    param_mappings=[
        ParamMapping(param_name="transaction_date_from", column_name="transaction_date", operator=">="),
        ParamMapping(param_name="transaction_date_to", column_name="transaction_date", operator="<="),
        ParamMapping(param_name="agent", column_name="agent_code", operator="IN"),
    ],
    default_limit=100,
)


def _params_by_name(params: list[BoundParam]) -> dict[str, BoundParam]:
    return {p.name: p for p in params}


# ---------------------------------------------------------------------------
# parse_sample_query — valid
# ---------------------------------------------------------------------------
def test_parse_sample_query_valid():
    """A well-formed block parses into a fully-typed SampleQuerySpec."""
    blob = {
        "columns": [
            {"display_name": "Transaction Date", "column_name": "transaction_date"},
            {"display_name": "Agent Code", "column_name": "agent_code"},
        ],
        "param_mappings": [
            {"param_name": "transaction_date_from", "column_name": "transaction_date", "operator": ">="},
            {"param_name": "agent", "column_name": "agent_code", "operator": "IN"},
        ],
        "default_limit": 50,
    }
    spec = parse_sample_query(blob)
    assert spec is not None
    assert [c.column_name for c in spec.columns] == ["transaction_date", "agent_code"]
    assert spec.param_mappings[1].operator == "IN"
    assert spec.default_limit == 50


def test_parse_sample_query_none_returns_none():
    """Absent block (None) → None (report has no preview)."""
    assert parse_sample_query(None) is None


# ---------------------------------------------------------------------------
# parse_sample_query — negatives (all → SpecError)
# ---------------------------------------------------------------------------
def test_parse_sample_query_non_dict():
    with pytest.raises(SpecError):
        parse_sample_query(["not", "a", "dict"])


def test_parse_sample_query_empty_columns():
    with pytest.raises(SpecError):
        parse_sample_query(
            {
                "columns": [],
                "param_mappings": [
                    {"param_name": "a", "column_name": "agent_code", "operator": "="}
                ],
            }
        )


def test_parse_sample_query_missing_column_name():
    with pytest.raises(SpecError):
        parse_sample_query(
            {
                "columns": [{"display_name": "Agent"}],  # no column_name
                "param_mappings": [
                    {"param_name": "a", "column_name": "agent_code", "operator": "="}
                ],
            }
        )


def test_parse_sample_query_bad_operator():
    with pytest.raises(SpecError):
        parse_sample_query(
            {
                "columns": [{"display_name": "Agent", "column_name": "agent_code"}],
                "param_mappings": [
                    {"param_name": "a", "column_name": "agent_code", "operator": "LIKE"}
                ],
            }
        )


def test_parse_sample_query_non_identifier_column_name():
    """A column_name that is not a strict SQL identifier → SpecError."""
    with pytest.raises(SpecError):
        parse_sample_query(
            {
                "columns": [
                    {"display_name": "Bad", "column_name": "agent_code; DROP TABLE x"}
                ],
                "param_mappings": [
                    {"param_name": "a", "column_name": "agent_code", "operator": "="}
                ],
            }
        )


def test_parse_sample_query_non_identifier_param_mapping_column():
    """A param_mapping column_name that is not an identifier → SpecError."""
    with pytest.raises(SpecError):
        parse_sample_query(
            {
                "columns": [{"display_name": "Agent", "column_name": "agent_code"}],
                "param_mappings": [
                    {"param_name": "a", "column_name": "agent_code`--", "operator": "="}
                ],
            }
        )


# ---------------------------------------------------------------------------
# build_preview_sql — parameterized output
# ---------------------------------------------------------------------------
def test_build_preview_sql_date_range():
    """Both date params provided → >= / <= bind markers + DATE-typed params."""
    values = {
        "transaction_date_from": "2025-01-01",
        "transaction_date_to": "2025-01-31",
    }
    sql, params, cols = build_preview_sql(_SPEC, values, _CATALOG, _SCHEMA)

    assert cols == ["transaction_date", "agent_code"]
    # Explicit, backtick-quoted projection (never SELECT *).
    assert sql.startswith(
        f"SELECT `transaction_date`, `agent_code` FROM {_TABLE}"
    )
    assert "WHERE" in sql
    assert "`transaction_date` >= :p0" in sql
    assert "`transaction_date` <= :p1" in sql
    assert "LIMIT 100" in sql
    # No inlined literals: the raw dates never appear in the SQL text.
    assert "2025-01-01" not in sql
    assert "2025-01-31" not in sql
    by_name = _params_by_name(params)
    assert by_name["p0"].value == "2025-01-01" and by_name["p0"].type == "DATE"
    assert by_name["p1"].value == "2025-01-31" and by_name["p1"].type == "DATE"


def test_build_preview_sql_in_single():
    """Single agent value → ``agent_code IN (:pN)`` with one bound STRING param."""
    values = {"agent": "AG001"}
    sql, params, _ = build_preview_sql(_SPEC, values, _CATALOG, _SCHEMA)

    assert "WHERE" in sql
    assert "`agent_code` IN (:p0)" in sql
    assert "AG001" not in sql
    assert params == [BoundParam(name="p0", value="AG001", type="STRING")]


def test_build_preview_sql_in_multi():
    """Comma-separated agents → one bind marker + one bound param per element."""
    values = {"agent": "AG001,AG002"}
    sql, params, _ = build_preview_sql(_SPEC, values, _CATALOG, _SCHEMA)

    assert "`agent_code` IN (:p0,:p1)" in sql
    assert [p.value for p in params] == ["AG001", "AG002"]
    assert all(p.type == "STRING" for p in params)


def test_build_preview_sql_in_element_cap():
    """An IN filter beyond the element cap → SpecError."""
    spec = SampleQuerySpec(
        columns=[ColumnDef(display_name="Agent", column_name="agent_code")],
        param_mappings=[
            ParamMapping(param_name="agent", column_name="agent_code", operator="IN")
        ],
        default_limit=100,
    )
    big = ",".join(f"AG{i:04d}" for i in range(201))
    with pytest.raises(SpecError):
        build_preview_sql(spec, {"agent": big}, _CATALOG, _SCHEMA)


def test_build_preview_sql_blank_skipped():
    """A blank param value must not appear as a condition."""
    values = {
        "transaction_date_from": "2025-01-01",
        "transaction_date_to": "",  # blank — must be skipped
    }
    sql, params, _ = build_preview_sql(_SPEC, values, _CATALOG, _SCHEMA)

    assert "WHERE" in sql
    assert ">=" in sql
    assert "<=" not in sql  # blank <= was skipped
    assert len(params) == 1


def test_build_preview_sql_no_params():
    """All params blank / absent → no WHERE clause at all."""
    sql, params, _ = build_preview_sql(_SPEC, {}, _CATALOG, _SCHEMA)

    assert "WHERE" not in sql
    assert f"FROM {_TABLE}" in sql
    assert "LIMIT 100" in sql
    assert params == []


def test_build_preview_sql_unknown_keys_ignored():
    """Keys not present in the spec's param_mappings are ignored (endpoint hygiene)."""
    values = {"agent": "AG001", "not_a_param": "whatever", "evil": "1 OR 1=1"}
    sql, params, _ = build_preview_sql(_SPEC, values, _CATALOG, _SCHEMA)

    assert "`agent_code` IN (:p0)" in sql
    assert [p.value for p in params] == ["AG001"]
    assert "1 OR 1=1" not in sql


def test_build_preview_sql_limit_cap():
    """default_limit=600 should be capped to 500 in the generated SQL."""
    spec = SampleQuerySpec(
        columns=[ColumnDef(display_name="Date", column_name="transaction_date")],
        param_mappings=[
            ParamMapping(param_name="transaction_date_from", column_name="transaction_date", operator=">="),
        ],
        default_limit=600,
    )
    sql, _, _ = build_preview_sql(spec, {}, _CATALOG, _SCHEMA)
    assert "LIMIT 500" in sql
    assert "LIMIT 600" not in sql


# ---------------------------------------------------------------------------
# build_preview_sql — injection: user value is BOUND, never concatenated
# ---------------------------------------------------------------------------
def test_build_preview_sql_injection_is_bound_not_concatenated():
    """A malicious value is carried as a bound parameter, never in the SQL text."""
    evil = "AG001'); DROP TABLE x;--"
    sql, params, _ = build_preview_sql(_SPEC, {"agent": evil}, _CATALOG, _SCHEMA)

    # The dangerous payload must NOT appear anywhere in the SQL string...
    assert "DROP TABLE" not in sql
    assert "';" not in sql
    assert evil not in sql
    # ...it appears ONLY as a bound parameter value.
    assert any(p.value == evil for p in params)
    # And the query shape is a single bind marker (no injected extra conditions).
    assert "`agent_code` IN (:p0)" in sql


# ---------------------------------------------------------------------------
# run_preview — binds params + uses WorkspaceClient (App SP, not OBO)
# ---------------------------------------------------------------------------
def _fake_settings():
    from alv_app.config import Settings

    return Settings(
        catalog=_CATALOG,
        schema_name=_SCHEMA,
        databricks_warehouse_id="wh-123",
    )


def _mock_statement_response(rows, state="SUCCEEDED"):
    from databricks.sdk.service.sql import StatementState

    resp = MagicMock()
    resp.status.state = getattr(StatementState, state)
    resp.status.error = None
    resp.result.data_array = rows
    return resp


def test_run_preview_binds_parameters_and_uses_app_sp():
    """run_preview passes StatementParameterListItem params + a plain WorkspaceClient."""
    spec = SampleQuerySpec(
        columns=[ColumnDef(display_name="Agent", column_name="agent_code")],
        param_mappings=[
            ParamMapping(param_name="agent", column_name="agent_code", operator="IN")
        ],
        default_limit=100,
    )
    fake_client = MagicMock()
    fake_client.statement_execution.execute_statement.return_value = _mock_statement_response(
        [["AG001"]]
    )

    with patch("databricks.sdk.WorkspaceClient", return_value=fake_client) as wc:
        result = run_preview(_fake_settings(), spec, {"agent": "AG001,AG002"})

    # App SP path: a plain WorkspaceClient() (no on-behalf-of user token).
    wc.assert_called_once_with()

    call = fake_client.statement_execution.execute_statement.call_args
    assert call.kwargs["warehouse_id"] == "wh-123"
    passed = call.kwargs["parameters"]
    # Two bound params (AG001, AG002); values live only in the parameter list.
    assert [p.value for p in passed] == ["AG001", "AG002"]
    assert "AG001" not in call.kwargs["statement"]
    assert result["row_count"] == 1


def test_run_preview_truncated_true_at_cap():
    """row_count hits the applied limit → truncated=True."""
    spec = SampleQuerySpec(
        columns=[ColumnDef(display_name="Agent", column_name="agent_code")],
        param_mappings=[
            ParamMapping(param_name="agent", column_name="agent_code", operator="IN")
        ],
        default_limit=3,
    )
    fake_client = MagicMock()
    fake_client.statement_execution.execute_statement.return_value = _mock_statement_response(
        [["AG001"], ["AG002"], ["AG003"]]  # exactly the limit
    )

    with patch("databricks.sdk.WorkspaceClient", return_value=fake_client):
        result = run_preview(_fake_settings(), spec, {})

    assert result["row_count"] == 3
    assert result["truncated"] is True


def test_run_preview_not_truncated_below_cap():
    """row_count below the limit → truncated=False."""
    spec = SampleQuerySpec(
        columns=[ColumnDef(display_name="Agent", column_name="agent_code")],
        param_mappings=[
            ParamMapping(param_name="agent", column_name="agent_code", operator="IN")
        ],
        default_limit=100,
    )
    fake_client = MagicMock()
    fake_client.statement_execution.execute_statement.return_value = _mock_statement_response(
        [["AG001"], ["AG002"]]
    )

    with patch("databricks.sdk.WorkspaceClient", return_value=fake_client):
        result = run_preview(_fake_settings(), spec, {})

    assert result["row_count"] == 2
    assert result["truncated"] is False


# ---------------------------------------------------------------------------
# Endpoint helpers
# ---------------------------------------------------------------------------

def _client_with_rows(monkeypatch, rows):
    """Build a TestClient whose metadata cache is seeded with *rows* (no warehouse)."""
    import alv_app.cache as cache_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: rows)

    from fastapi.testclient import TestClient
    from alv_app import main

    main._cache = main.MetadataCache(main.get_settings())
    main._cache.load(force=True)
    return TestClient(main.app)


# ---------------------------------------------------------------------------
# Endpoint: 404 / 409 / 200
# ---------------------------------------------------------------------------
def test_preview_endpoint_404(monkeypatch, catalog_rows):
    """An unknown alv_id → 404."""
    with _client_with_rows(monkeypatch, catalog_rows) as client:
        resp = client.post(
            "/api/reports/does_not_exist__nowhere/preview",
            json={"values": {}},
        )
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"]


def test_preview_endpoint_409_no_query(monkeypatch, catalog_rows):
    """A real report without a sample_query block → 409.

    Row 0 (agent_item) now carries a sample_query in the manifest; use row 1 which
    has none, so its cached ``sample_query`` is None.
    """
    no_query_alv_id = catalog_rows[1]["alv_id"]

    with _client_with_rows(monkeypatch, catalog_rows) as client:
        resp = client.post(
            f"/api/reports/{no_query_alv_id}/preview",
            json={"values": {}},
        )
    assert resp.status_code == 409
    assert "no sample query" in resp.json()["detail"]


def test_preview_endpoint_success(monkeypatch, catalog_rows):
    """A successful preview: mock run_preview → 200 with expected shape.

    Row 0 (agent_item) carries a real sample_query in the manifest, so it parses
    into the cache without any injection here.
    """
    first_alv_id = catalog_rows[0]["alv_id"]

    import alv_app.cache as cache_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: catalog_rows)

    from fastapi.testclient import TestClient
    from alv_app import main

    main._cache = main.MetadataCache(main.get_settings())
    main._cache.load(force=True)
    assert main._cache.get(first_alv_id).sample_query is not None  # parsed from manifest

    mock_result = {
        "columns": ["Transaction Date"],
        "rows": [["2026-07-01"]],
        "row_count": 1,
        "truncated": False,
        "bound_param_count": 1,
    }

    with patch("alv_app.main.run_preview", return_value=mock_result):
        with TestClient(main.app) as client:
            resp = client.post(
                f"/api/reports/{first_alv_id}/preview",
                json={"values": {"transaction_date_from": "2026-07-01"}},
            )

    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["columns"] == ["Transaction Date"]
    assert body["rows"] == [["2026-07-01"]]
    assert body["row_count"] == 1
    assert body["truncated"] is False


# ---------------------------------------------------------------------------
# Schema contract: the real 14-row manifest validates through the library
# ---------------------------------------------------------------------------
def test_retail_ledger_manifest_validates_through_library():
    """With jsonschema importable, the full manifest (incl. the sample_query row)
    validates cleanly through the library parser/seeder.

    This is the test whose absence hid the schema bug: the top-level schema had
    ``additionalProperties: false`` with no ``sample_query`` property, so the seed
    path rejected the agent_item row with jsonschema installed.
    """
    jsonschema = pytest.importorskip("jsonschema")  # noqa: F841
    import json
    from pathlib import Path

    # Import the library parser directly from src/alv-backend/ (repo root, not synced to
    # Apps). This test file lives at src/alv-frontend/backend/tests/, so parents[4] is
    # the true repo root: the library is at <root>/src/alv-backend and the authoring specs
    # are at <root>/src/report_specs.
    import sys

    repo_root = Path(__file__).resolve().parents[4]
    lib_root = str(repo_root / "src/alv-backend")
    if lib_root not in sys.path:
        sys.path.insert(0, lib_root)

    from dbx_alv_reports.spec_parser.input_fields_parser import (  # type: ignore
        JSONSCHEMA_AVAILABLE,
        InputFieldsParser,
        load_schema,
    )
    from dbx_alv_reports.seed.report_seeder import ReportSeeder  # type: ignore

    assert JSONSCHEMA_AVAILABLE, "jsonschema must be importable for this contract test"
    load_schema.cache_clear()

    manifest_path = repo_root / "src" / "report_specs" / "retail_ledger.input_fields.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert len(manifest["catalog_rows"]) == 14

    errors, _ = ReportSeeder.validate_manifest(manifest)
    assert errors == [], errors

    # The sample_query row (agent_item) specifically validates through the parser.
    row0 = manifest["catalog_rows"][0]["input_fields_json"]
    assert "sample_query" in row0
    parser = InputFieldsParser(row0, source="agent_item")
    assert parser.validate(), parser.get_errors()
