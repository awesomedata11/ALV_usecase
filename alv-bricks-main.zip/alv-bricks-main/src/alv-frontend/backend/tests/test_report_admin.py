"""Tests for admin report onboarding: paste-a-manifest → alv_catalog MERGE.

The onboarding surface is a **new admin write path**, so this drives the real validation,
the real row derivation, the real endpoint logic and the real bound-parameter MERGE builder,
mocking only the outer seams:

* ``alv_app.report_admin._execute`` — the warehouse statement seam. A tiny in-memory
  ``alv_catalog`` stands in for it, records every statement + parameter set (so we can
  assert the MERGE is bound, not interpolated), and reconstructs the merged rows so the
  reloaded cache can serve them; and
* ``alv_app.cache.fetch_catalog_rows`` — fed the initial rows PLUS whatever the fake
  ``_execute`` has merged, so the "report becomes visible" assertion exercises the real
  cache refresh the endpoint triggers.

Covered: the pure validate/derive helpers (valid manifest, every negative — bad JSON,
non-object, empty/missing keys, duplicate alv_id, bad input_fields_json — collect-all),
placeholder job_id → NULL, the admin gate (non-admin → 404, never 403), a valid onboard
inserting rows + refreshing the cache + the new report showing in /api/admin/reports, an
invalid manifest → 422 with the full error list, and that user values are BOUND (never
interpolated into the statement).
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

import pytest

import alv_app.cache as cache_mod
import alv_app.entitlements as ent
import alv_app.main as main_mod
import alv_app.report_admin as ra
from alv_app.config import Settings, get_settings

_ADMIN_GROUP = "alv-admins"
_REPO_ROOT = Path(__file__).resolve().parents[3]
_MANIFEST = _REPO_ROOT / "report_specs" / "retail_ledger.input_fields.json"


def _real_manifest() -> dict:
    return json.loads(_MANIFEST.read_text(encoding="utf-8"))


def _small_manifest(report_key: str = "brand_new_report") -> dict:
    """A minimal but valid one-row manifest for a fresh report."""
    return {
        "catalog_rows": [
            {
                "report_key": report_key,
                "report_label": "Brand New",
                "selection_id": "detail",
                "selection_label": "Detail",
                "selection_order": 1,
                "report_type_code": "main",
                "report_type_label": "Main",
                "report_type_order": 1,
                "job_id": "JOB_PLACEHOLDER_X",
                "input_fields_json": {
                    "schema_version": 1,
                    "fields": [
                        {
                            "param_name": "agent",
                            "display_label": "Agent",
                            "display_order": 1,
                            "control": "text",
                            "data_type": "string",
                            "selection_type": "single",
                            "mandatory": False,
                            "validations": [],
                        }
                    ],
                },
            }
        ]
    }


# ---------------------------------------------------------------------------
# Pure validation
# ---------------------------------------------------------------------------
def test_validate_real_manifest_is_valid():
    assert ra.validate_manifest(_real_manifest()) == []


def test_validate_rejects_empty_or_missing_catalog_rows():
    assert ra.validate_manifest({}) == ["manifest: 'catalog_rows' must be a non-empty array."]
    assert ra.validate_manifest({"catalog_rows": []})[0].startswith("manifest:")


def test_validate_collects_missing_keys_across_rows():
    """Collect-all: every missing-key problem, on every row, in one pass."""
    manifest = {"catalog_rows": [{"report_key": "r"}, {"selection_id": "s"}]}
    errors = ra.validate_manifest(manifest)
    # Both rows contribute several missing-key errors (never stops at the first).
    assert any("catalog_rows[0]" in e and "missing required key" in e for e in errors)
    assert any("catalog_rows[1]" in e and "missing required key" in e for e in errors)
    assert len(errors) >= 2


def test_validate_flags_duplicate_alv_id():
    m = _small_manifest()
    m["catalog_rows"].append(json.loads(json.dumps(m["catalog_rows"][0])))  # exact clone
    errors = ra.validate_manifest(m)
    assert any("duplicate alv_id" in e for e in errors)


def test_validate_flags_bad_input_fields_json_rule():
    m = _small_manifest()
    m["catalog_rows"][0]["input_fields_json"]["fields"][0]["validations"] = [
        {"rule": "no_such_rule", "message_key": "X"}
    ]
    errors = ra.validate_manifest(m)
    assert any("unknown validation rule" in e for e in errors)


def test_validate_flags_bad_schema_version():
    m = _small_manifest()
    m["catalog_rows"][0]["input_fields_json"]["schema_version"] = 999
    errors = ra.validate_manifest(m)
    assert any("schema_version" in e for e in errors)


def test_load_and_validate_bad_json():
    manifest, errors = ra.load_and_validate("{not valid json")
    assert manifest is None
    assert errors and "not valid JSON" in errors[0]


def test_load_and_validate_non_object():
    manifest, errors = ra.load_and_validate("[1, 2, 3]")
    assert manifest is None
    assert errors and "top-level value must be a JSON object" in errors[0]


# ---------------------------------------------------------------------------
# Pure derivation
# ---------------------------------------------------------------------------
def test_derive_rows_slug_name_and_placeholder_job_id():
    rows, warnings = ra.derive_rows(_small_manifest())
    assert len(rows) == 1
    row = rows[0]
    assert row["alv_id"] == "brand_new_report__detail__main"  # slug from identity cols
    assert row["alv_name"] == "Brand New — Detail — Main"  # em-dash join
    # Placeholder job_id → NULL (unbound), with a warning (mirrors the seeder).
    assert row["job_id"] is None
    assert warnings and "placeholder" in warnings[0]
    assert row["is_active"] is True
    assert row["job_run_mode"] == "run_now"


def test_derive_rows_serializes_input_fields_compactly():
    rows, _ = ra.derive_rows(_small_manifest())
    blob = rows[0]["input_fields_json"]
    assert isinstance(blob, str)
    assert ", " not in blob and ": " not in blob  # compact separators
    assert json.loads(blob)["schema_version"] == 1


def test_derive_rows_keeps_numeric_job_id():
    m = _small_manifest()
    m["catalog_rows"][0]["job_id"] = "12345"
    rows, warnings = ra.derive_rows(m)
    assert rows[0]["job_id"] == 12345
    assert warnings == []


# ---------------------------------------------------------------------------
# A fake alv_catalog behind report_admin._execute
# ---------------------------------------------------------------------------
class _FakeCatalog:
    """In-memory alv_catalog: applies the MERGE report_admin emits, records statements."""

    def __init__(self):
        self.by_id: dict[str, dict[str, object]] = {}
        self.statements: list[str] = []
        self.param_sets: list[dict[str, object]] = []

    def execute(self, settings, statement, parameters):
        self.statements.append(statement)
        p = {item["name"]: item.get("value") for item in parameters}
        self.param_sets.append(p)
        s = statement.strip()
        if not s.startswith("MERGE"):
            raise AssertionError(f"unexpected statement: {s[:40]}")
        self.by_id[p["alv_id"]] = {
            "alv_id": p["alv_id"],
            "report_key": p["report_key"],
            "report_label": p["report_label"],
            "selection_id": p["selection_id"],
            "selection_label": p["selection_label"],
            "selection_order": int(p["selection_order"]) if p["selection_order"] is not None else None,
            "report_type_code": p["report_type_code"],
            "report_type_label": p["report_type_label"],
            "report_type_order": int(p["report_type_order"]) if p["report_type_order"] is not None else None,
            "alv_name": p["alv_name"],
            "description": p["description"],
            "job_id": int(p["job_id"]) if p["job_id"] is not None else None,
            "job_run_mode": p["job_run_mode"],
            "input_fields_json": p["input_fields_json"],
            "is_active": p["is_active"] == "true",
        }
        return []

    def rows(self):
        return list(self.by_id.values())


def _admin_settings(**kw) -> Settings:
    base = {
        "catalog": "cat",
        "schema_name": "sch",
        "databricks_warehouse_id": "wh-1",
        "alv_admins": f"admin@example.com,{_ADMIN_GROUP}",
        "dev_bypass_permissions": False,
    }
    base.update(kw)
    return Settings(**base)


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    main_mod.app.dependency_overrides.clear()


def _client(monkeypatch, fake, initial_rows, *, caller_email, admins=f"admin@example.com,{_ADMIN_GROUP}"):
    """A TestClient whose alv_catalog is the fake, cache reloads from initial + merged rows."""
    monkeypatch.setattr(ra, "_execute", fake.execute)
    # The cache reads the initial rows PLUS whatever the fake has merged so far, so a
    # cache.load(force=True) after onboarding surfaces the new report (real refresh path).
    monkeypatch.setattr(
        cache_mod, "fetch_catalog_rows", lambda settings: list(initial_rows) + fake.rows()
    )
    ent.clear_caches()
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, token: frozenset())

    from alv_app.identity import resolve_identity as real_resolve

    def _resolve(request, settings):
        ident = real_resolve(request, settings)
        return replace(ident, email=caller_email, user_token="obo", has_user_token=True)

    monkeypatch.setattr(main_mod, "resolve_identity", _resolve)

    settings = _admin_settings(alv_admins=admins)
    main_mod.app.dependency_overrides[get_settings] = lambda: settings

    from fastapi.testclient import TestClient

    main_mod._cache = main_mod.MetadataCache(settings)
    main_mod._cache.load(force=True)
    return TestClient(main_mod.app)


# ---------------------------------------------------------------------------
# Endpoint: gate
# ---------------------------------------------------------------------------
def test_non_admin_gets_404_on_onboard(monkeypatch, catalog_rows):
    fake = _FakeCatalog()
    c = _client(monkeypatch, fake, catalog_rows, caller_email="nobody@x.com")
    resp = c.post("/api/admin/reports", json={"manifest": json.dumps(_small_manifest())})
    assert resp.status_code == 404
    # Nothing was written.
    assert fake.by_id == {}


# ---------------------------------------------------------------------------
# Endpoint: happy path
# ---------------------------------------------------------------------------
def test_onboard_valid_inserts_and_becomes_visible(monkeypatch, catalog_rows):
    fake = _FakeCatalog()
    c = _client(monkeypatch, fake, catalog_rows, caller_email="admin@example.com")

    resp = c.post("/api/admin/reports", json={"manifest": json.dumps(_small_manifest())})
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["ok"] is True
    assert body["row_count"] == 1
    assert body["report_keys"] == ["brand_new_report"]
    assert body["alv_ids"] == ["brand_new_report__detail__main"]
    # Placeholder job_id → a surfaced warning; and the message tells the admin to grant.
    assert body["warnings"] and "placeholder" in body["warnings"][0]
    assert "hidden from everyone" in body["detail"]

    # The row landed in the (fake) catalog...
    assert "brand_new_report__detail__main" in fake.by_id
    assert fake.by_id["brand_new_report__detail__main"]["job_id"] is None  # placeholder → NULL

    # ...and the cache refresh made it show in the admin report picker.
    picker = c.get("/api/admin/reports").json()
    keys = {g["report_key"] for g in picker["groups"]}
    assert "brand_new_report" in keys


def test_onboard_binds_parameters_not_interpolated(monkeypatch, catalog_rows):
    """Every user value is a bound parameter — never interpolated into the statement."""
    fake = _FakeCatalog()
    c = _client(monkeypatch, fake, catalog_rows, caller_email="admin@example.com")
    c.post("/api/admin/reports", json={"manifest": json.dumps(_small_manifest("secret_rk"))})

    assert len(fake.statements) == 1
    stmt = fake.statements[0]
    # The user-supplied report_key / labels appear ONLY as bound values, never in the SQL.
    assert "secret_rk" not in stmt
    assert "Brand New" not in stmt
    assert "brand_new_report" not in stmt  # the derived alv_id is bound too
    assert ":report_key" in stmt and ":alv_id" in stmt and ":input_fields_json" in stmt
    # The value did travel as a bound parameter.
    assert fake.param_sets[0]["report_key"] == "secret_rk"


# ---------------------------------------------------------------------------
# Endpoint: invalid input
# ---------------------------------------------------------------------------
def test_onboard_invalid_manifest_returns_422_with_errors(monkeypatch, catalog_rows):
    fake = _FakeCatalog()
    c = _client(monkeypatch, fake, catalog_rows, caller_email="admin@example.com")

    # Bad JSON shape: missing keys + a bad rule in one paste (collect-all).
    bad = {
        "catalog_rows": [
            {
                "report_key": "x",
                # missing report_label / selection_label / selection_order
                "selection_id": "s",
                "input_fields_json": {
                    "schema_version": 1,
                    "fields": [
                        {
                            "control": "text",
                            "data_type": "string",
                            "display_label": "A",
                            "display_order": 1,
                            "mandatory": False,
                            "param_name": "a",
                            "validations": [{"rule": "bogus", "message_key": "K"}],
                        }
                    ],
                },
            }
        ]
    }
    resp = c.post("/api/admin/reports", json={"manifest": json.dumps(bad)})
    assert resp.status_code == 422, resp.text
    detail = resp.json()["detail"]
    assert detail["detail"] == "the manifest is not valid"
    errors = detail["errors"]
    assert any("missing required key" in e for e in errors)
    assert any("unknown validation rule" in e for e in errors)
    # Nothing was written on the invalid path.
    assert fake.by_id == {}


def test_onboard_bad_json_text_returns_422(monkeypatch, catalog_rows):
    fake = _FakeCatalog()
    c = _client(monkeypatch, fake, catalog_rows, caller_email="admin@example.com")
    resp = c.post("/api/admin/reports", json={"manifest": "not json at all {"})
    assert resp.status_code == 422
    assert any("not valid JSON" in e for e in resp.json()["detail"]["errors"])
    assert fake.by_id == {}
