"""Unit tests for the render-ready input_fields parser (task 3.1)."""

import pytest

from alv_app.fields import SpecError, parse_input_fields


def _scalar(**over):
    base = {
        "param_name": "agent",
        "display_label": "Agent",
        "display_order": 2,
        "control": "text",
        "data_type": "string",
        "selection_type": "single",
        "mandatory": False,
    }
    base.update(over)
    return base


def _date_range(**over):
    base = {
        "control": "date_range",
        "display_label": "Transaction Date",
        "display_order": 1,
        "data_type": "date",
        "mandatory": True,
        "parts": {
            "from": {"param_name": "transaction_date_from", "display_label": "From"},
            "to": {"param_name": "transaction_date_to", "display_label": "To"},
        },
        "validations": [
            {"rule": "from_lte_to", "message_key": "ALV_DATE_FROM_GT_TO"},
            {"rule": "max_span", "unit": "days", "value": 31, "message_key": "ALV_DATE_SPAN_EXCEEDED"},
        ],
    }
    base.update(over)
    return base


def test_orders_by_display_order():
    blob = {"schema_version": 1, "fields": [_scalar(display_order=3), _date_range(display_order=1)]}
    fields = parse_input_fields(blob)
    assert [f.display_order for f in fields] == [1, 3]


def test_scalar_and_composite_kinds():
    blob = {"schema_version": 1, "fields": [_date_range(), _scalar()]}
    fields = parse_input_fields(blob)
    comp = next(f for f in fields if f.control == "date_range")
    scal = next(f for f in fields if f.control == "text")
    assert comp.kind == "composite"
    assert comp.parts["from"].param_name == "transaction_date_from"
    assert scal.kind == "scalar"
    assert scal.param_name == "agent"


def test_validations_resolved():
    field = parse_input_fields({"schema_version": 1, "fields": [_date_range()]})[0]
    rules = {v.rule: v for v in field.validations}
    assert rules["max_span"].unit == "days"
    assert rules["max_span"].value == 31
    assert rules["from_lte_to"].message_key == "ALV_DATE_FROM_GT_TO"


def test_bad_schema_version_fails_fast():
    with pytest.raises(SpecError, match="schema_version"):
        parse_input_fields({"schema_version": 2, "fields": [_scalar()]})


def test_unknown_rule_fails_load():
    bad = _scalar(validations=[{"rule": "made_up", "message_key": "X"}])
    with pytest.raises(SpecError, match="unknown validation rule"):
        parse_input_fields({"schema_version": 1, "fields": [bad]})


def test_missing_rule_param_fails():
    bad = _date_range(validations=[{"rule": "max_span", "unit": "days", "message_key": "X"}])
    with pytest.raises(SpecError, match="requires param 'value'"):
        parse_input_fields({"schema_version": 1, "fields": [bad]})


def test_duplicate_param_name_fails():
    blob = {"schema_version": 1, "fields": [_scalar(), _scalar()]}
    with pytest.raises(SpecError, match="duplicate param_name"):
        parse_input_fields(blob)


def test_unknown_control_fails():
    bad = {"control": "slider", "display_label": "x", "display_order": 1, "data_type": "string", "mandatory": False}
    with pytest.raises(SpecError, match="unknown control"):
        parse_input_fields({"schema_version": 1, "fields": [bad]})


def test_empty_fields_fails():
    with pytest.raises(SpecError, match="non-empty array"):
        parse_input_fields({"schema_version": 1, "fields": []})
