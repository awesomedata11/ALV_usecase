"""Smoke tests for the thin backend (no Databricks workspace required)."""

from fastapi.testclient import TestClient

from alv_app.main import app

client = TestClient(app)


def test_health():
    resp = client.get("/api/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["app"] == "alv-bricks-app"


def test_me_dev_fallback():
    # No SSO headers + dev_mode default -> local dev fallback identity.
    resp = client.get("/api/me")
    assert resp.status_code == 200
    body = resp.json()
    assert body["authenticated"] is False
    assert body["email"] == "local.dev@example.com"
    # SDK auth-check degrades gracefully with no workspace creds locally.
    assert body["service_principal_ok"] in (True, False)
    # The OBO token is never echoed back — only the presence flag.
    assert "access_token" not in body


def test_me_reads_sso_headers():
    resp = client.get(
        "/api/me",
        headers={
            "X-Forwarded-Email": "raveesh.singh@example.com",
            "X-Forwarded-Preferred-Username": "raveesh.singh",
            "X-Forwarded-User": "1234-aad-object-id",
            "X-Forwarded-Access-Token": "secret-obo-token",
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["authenticated"] is True
    assert body["email"] == "raveesh.singh@example.com"
    assert body["user_id"] == "1234-aad-object-id"
    assert body["has_user_token"] is True
    # Token value must not leak into the response.
    assert "secret-obo-token" not in resp.text
