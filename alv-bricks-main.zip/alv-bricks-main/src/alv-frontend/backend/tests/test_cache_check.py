"""Tests for the result-cache reuse lookup (task 7.3).

The pure SQL builder + the ``find_cached_run`` mapping are unit-tested with a fake
executor; the endpoint is tested end-to-end with the warehouse lookup mocked (patching
``alv_app.main.find_cached_run``), so no live workspace is needed.

Covers the hit definition, the "latest wins" ordering (the added edge case: a third user
is pointed at the newest matching file, not an older one), the permission gate (404), and
the degrade-to-no-reuse behaviour on a warehouse failure.
"""

from __future__ import annotations

import alv_app.cache_source as cs
import alv_app.main as main_mod
from alv_app.cache_source import (
    CacheSourceError,
    build_cache_lookup_sql,
    find_cached_run,
)
from alv_app.config import get_settings

_AGENT_ITEM = "retail_ledger__detail__agent_item"


def _hit_row(**over):
    row = {
        "request_no": "REQ-LATEST",
        "alv_id": _AGENT_ITEM,
        "submitted_by": "someone.else@databricks.com",
        "generated_at": "2026-08-15T10:00:00Z",
        "expires_at": "2026-08-22T10:00:00Z",
        "output_path": "/Volumes/cat/sch/alv_outputs/REQ-LATEST.csv",
        "row_count": 42,
    }
    row.update(over)
    return row


# --- SQL builder ----------------------------------------------------------------
def test_lookup_sql_binds_key_and_never_interpolates():
    settings = get_settings()
    sql, params = build_cache_lookup_sql(
        settings, alv_id=_AGENT_ITEM, param_hash="deadbeef"
    )
    # alv_id + param_hash are bound, not formatted into the text.
    assert ":alv_id" in sql and ":param_hash" in sql
    assert _AGENT_ITEM not in sql
    assert "deadbeef" not in sql
    names = {p.name: p.value for p in params}
    assert names == {"alv_id": _AGENT_ITEM, "param_hash": "deadbeef"}


def test_lookup_sql_encodes_the_hit_definition_and_latest_wins():
    sql, _ = build_cache_lookup_sql(get_settings(), alv_id="a", param_hash="h")
    assert "status = 'COMPLETED'" in sql
    assert "output_path IS NOT NULL" in sql
    assert "expires_at > current_timestamp()" in sql
    # Latest wins: newest generated output first, then a stable tiebreak, LIMIT 1.
    assert "ORDER BY generated_at DESC" in sql
    assert "LIMIT 1" in sql


# --- find_cached_run mapping ----------------------------------------------------
def test_find_returns_none_on_no_rows(monkeypatch):
    monkeypatch.setattr(cs, "_execute", lambda settings, sql, params: [])
    assert find_cached_run(get_settings(), alv_id="a", param_hash="h") is None


def test_find_maps_row_and_coerces_row_count(monkeypatch):
    arr = [[
        "REQ-1", _AGENT_ITEM, "u@x", "2026-08-15T10:00:00Z",
        "2026-08-22T10:00:00Z", "/Volumes/x.csv", "42",
    ]]
    monkeypatch.setattr(cs, "_execute", lambda settings, sql, params: arr)
    row = find_cached_run(get_settings(), alv_id=_AGENT_ITEM, param_hash="h")
    assert row["request_no"] == "REQ-1"
    assert row["output_path"] == "/Volumes/x.csv"
    assert row["row_count"] == 42  # coerced from the warehouse string


def test_find_returns_the_first_row_the_ordered_query_yields(monkeypatch):
    """The DB orders newest-first (LIMIT 1); the helper returns that single row.

    The fake executor returns what the ORDER BY would put first — the latest run — so
    a third user reusing already-cached parameters gets the newest file (the added edge
    case), never an older one.
    """
    latest = ["REQ-LATEST", _AGENT_ITEM, "u@x", "2026-08-15", "2026-08-22", "/v/new.csv", "9"]
    monkeypatch.setattr(cs, "_execute", lambda settings, sql, params: [latest])
    row = find_cached_run(get_settings(), alv_id=_AGENT_ITEM, param_hash="h")
    assert row["request_no"] == "REQ-LATEST"


def test_find_raises_on_missing_warehouse():
    settings = get_settings()
    # No warehouse id configured in the test env ⇒ the seam raises, which the endpoint
    # turns into "no reuse".
    if settings.databricks_warehouse_id:
        return  # skip when a warehouse happens to be configured locally
    try:
        find_cached_run(settings, alv_id="a", param_hash="h")
    except CacheSourceError:
        return
    raise AssertionError("expected CacheSourceError when the warehouse id is unset")


# --- endpoint -------------------------------------------------------------------
def test_cache_check_returns_hit(client_with_jobs, monkeypatch):
    monkeypatch.setattr(main_mod, "find_cached_run", lambda settings, **k: _hit_row())
    resp = client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/cache-check",
        json={"values": {"transaction_date_from": "2026-01-01", "transaction_date_to": "2026-01-10"}},
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["alv_id"] == _AGENT_ITEM
    assert len(body["param_hash"]) == 64
    hit = body["hit"]
    assert hit["request_no"] == "REQ-LATEST"
    assert hit["submitted_by"] == "someone.else@databricks.com"
    assert hit["row_count"] == 42
    assert hit["has_output"] is True
    # The raw storage path must NEVER be exposed.
    assert "output_path" not in hit


def test_cache_check_no_hit(client_with_jobs, monkeypatch):
    monkeypatch.setattr(main_mod, "find_cached_run", lambda settings, **k: None)
    resp = client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/cache-check", json={"values": {}}
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["hit"] is None
    assert len(body["param_hash"]) == 64


def test_cache_check_degrades_to_no_hit_on_warehouse_failure(client_with_jobs, monkeypatch):
    """A cache-read failure must never block a submission — it returns hit=None (200)."""
    def _boom(settings, **k):
        raise CacheSourceError("warehouse unreachable")

    monkeypatch.setattr(main_mod, "find_cached_run", _boom)
    resp = client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/cache-check", json={"values": {}}
    )
    assert resp.status_code == 200, resp.text
    assert resp.json()["hit"] is None


def test_cache_check_hash_matches_submit(submit_client, monkeypatch):
    """The cache-check param_hash equals what submit computes for identical values —
    proving the hash has a single server-side source of truth (decision 6)."""
    client, _rec = submit_client
    monkeypatch.setattr(main_mod, "find_cached_run", lambda settings, **k: None)
    values = {
        "transaction_date_from": "2026-01-01",
        "transaction_date_to": "2026-01-10",
        "agent": " ag01 ",
    }
    check = client.post(f"/api/reports/{_AGENT_ITEM}/cache-check", json={"values": values})
    submit = client.post(f"/api/reports/{_AGENT_ITEM}/submit", json={"values": values})
    assert check.status_code == 200 and submit.status_code == 200
    assert check.json()["param_hash"] == submit.json()["param_hash"]


def test_cache_check_unknown_report_404(client_with_jobs):
    resp = client_with_jobs.post("/api/reports/does_not_exist/cache-check", json={"values": {}})
    assert resp.status_code == 404


def test_cache_check_denied_report_404(client_with_jobs, monkeypatch):
    """A report the caller may not see returns 404 — the same as a missing one — so the
    check never discloses that runs exist for it (gate runs before any warehouse read)."""
    monkeypatch.setattr(main_mod, "is_report_permitted", lambda settings, ident, rk: False)
    # If the gate were bypassed this would call find_cached_run; make that loud.
    def _should_not_run(settings, **k):
        raise AssertionError("permission gate did not run before the cache lookup")

    monkeypatch.setattr(main_mod, "find_cached_run", _should_not_run)
    resp = client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/cache-check", json={"values": {}}
    )
    assert resp.status_code == 404
