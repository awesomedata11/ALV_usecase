"""Tests for the output-file preview (docs/OUTPUT_FILE_PREVIEW_APPROACH.md).

Two layers:

* **Pure parser** (:func:`alv_app.output_preview.build_output_preview`) — CSV parse,
  raw-text fallback, binary guard, the partial-last-line drop on byte truncation, and
  the row-cap / byte-cap ``truncated`` flag. No SDK, no workspace.
* **Endpoint** (``GET /api/requests/{request_no}/output-preview``) — happy path, and the
  404 / 409 / 422 / 502 guards, all mocked so no live Volume is touched. Same gate and
  guards as the download endpoint.
"""

from __future__ import annotations

import alv_app.main as main_mod
from alv_app.databricks_client import VolumeDownloadError
from alv_app.output_preview import build_output_preview

# Must resolve in the metadata cache so the permission gate can attribute the row.
_AGENT_ITEM = "retail_ledger__detail__agent_item"


# --- pure parser ----------------------------------------------------------------
def test_parse_csv_header_and_rows():
    data = b"agent,amount,circle\nAG001,100,MH\nAG002,200,DL\n"
    out = build_output_preview(data, byte_truncated=False, filename="out.csv", max_rows=1000)
    assert out["format"] == "csv"
    assert out["columns"] == ["agent", "amount", "circle"]
    assert out["rows"] == [["AG001", "100", "MH"], ["AG002", "200", "DL"]]
    assert out["row_count"] == 2
    assert out["truncated"] is False
    assert out["filename"] == "out.csv"
    assert out["text"] is None


def test_parse_csv_row_cap_truncates():
    data = b"a,b\n1,1\n2,2\n3,3\n4,4\n"
    out = build_output_preview(data, byte_truncated=False, filename="f.csv", max_rows=2)
    assert out["row_count"] == 2
    assert out["rows"] == [["1", "1"], ["2", "2"]]
    assert out["truncated"] is True


def test_parse_csv_quoted_field_with_comma():
    data = b'name,note\n"Doe, John",hello\n'
    out = build_output_preview(data, byte_truncated=False, filename="f.csv", max_rows=10)
    assert out["rows"] == [["Doe, John", "hello"]]


def test_byte_truncation_drops_partial_last_row():
    # File continues past the cap; the final line is a partial row and must be dropped.
    data = b"a,b\n1,1\n2,2\n3,"
    out = build_output_preview(data, byte_truncated=True, filename="f.csv", max_rows=1000)
    assert out["rows"] == [["1", "1"], ["2", "2"]]
    assert out["truncated"] is True


def test_text_fallback_for_non_csv():
    data = b"just some log lines\nwithout commas\nline three\n"
    out = build_output_preview(data, byte_truncated=False, filename="log.txt", max_rows=1000)
    assert out["format"] == "text"
    assert out["columns"] == []
    assert out["rows"] == []
    assert out["text"] == "just some log lines\nwithout commas\nline three"
    assert out["row_count"] == 3
    assert out["truncated"] is False


def test_text_fallback_row_cap():
    data = b"one\ntwo\nthree\nfour\n"
    out = build_output_preview(data, byte_truncated=False, filename="log.txt", max_rows=2)
    assert out["text"] == "one\ntwo"
    assert out["truncated"] is True


def test_binary_guard_nul_byte():
    data = b"PK\x03\x04\x00\x00some zip bytes"
    out = build_output_preview(data, byte_truncated=False, filename="x.zip", max_rows=1000)
    assert out["format"] == "binary"
    assert out["columns"] == []
    assert out["rows"] == []
    assert out["text"] is None
    assert out["row_count"] == 0


def test_empty_file():
    out = build_output_preview(b"", byte_truncated=False, filename="empty.csv", max_rows=1000)
    assert out["row_count"] == 0
    assert out["truncated"] is False


# --- endpoint -------------------------------------------------------------------
def _row(**over):
    base = {
        "request_no": "REQ-1",
        "alv_id": _AGENT_ITEM,
        "status": "COMPLETED",
        "run_id": 1,
        "output_path": "/Volumes/c/s/alv_outputs/out.csv",
    }
    base.update(over)
    return base


def test_endpoint_previews_csv(client, monkeypatch):
    monkeypatch.setattr(main_mod, "fetch_request", lambda settings, request_no: _row())
    monkeypatch.setattr(
        main_mod,
        "read_volume_prefix",
        lambda path, max_bytes: (b"a,b\n1,2\n3,4\n", False),
    )
    resp = client.get("/api/requests/REQ-1/output-preview")
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["format"] == "csv"
    assert body["columns"] == ["a", "b"]
    assert body["rows"] == [["1", "2"], ["3", "4"]]
    assert body["filename"] == "out.csv"


def test_endpoint_404_missing_row(client, monkeypatch):
    monkeypatch.setattr(main_mod, "fetch_request", lambda settings, request_no: None)
    resp = client.get("/api/requests/REQ-NOPE/output-preview")
    assert resp.status_code == 404


def test_endpoint_409_no_output(client, monkeypatch):
    monkeypatch.setattr(
        main_mod, "fetch_request", lambda settings, request_no: _row(output_path=None)
    )
    resp = client.get("/api/requests/REQ-PENDING/output-preview")
    assert resp.status_code == 409


def test_endpoint_422_non_volume(client, monkeypatch):
    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: _row(
            output_path="abfss://c@a.dfs.core.windows.net/out.csv"
        ),
    )
    resp = client.get("/api/requests/REQ-ADLS/output-preview")
    assert resp.status_code == 422


def test_endpoint_502_read_fails(client, monkeypatch):
    monkeypatch.setattr(main_mod, "fetch_request", lambda settings, request_no: _row())

    def _boom(path, max_bytes):
        raise VolumeDownloadError("file gone")

    monkeypatch.setattr(main_mod, "read_volume_prefix", _boom)
    resp = client.get("/api/requests/REQ-ERR/output-preview")
    assert resp.status_code == 502


def test_endpoint_404_when_read_source_error(client, monkeypatch):
    from alv_app.downloads import DownloadsSourceError

    def _boom(settings, request_no):
        raise DownloadsSourceError("warehouse unreachable")

    monkeypatch.setattr(main_mod, "fetch_request", _boom)
    resp = client.get("/api/requests/REQ-WH/output-preview")
    assert resp.status_code == 404
