"""Unit tests for the dynamic-template preset resolver + save-time validation port.

Pure helpers — no warehouse, no wall clock (``now`` / ``today`` are injected), so these
run fast and deterministically. Covers every preset, ± n days (incl. negative + string),
month-length + year-rollover edges, the parse/validation contract (unknown preset, missing
/ extra n, a preset on a non-date field), and that the server-side validation port agrees
with the frontend rules on the key cases.
"""

from __future__ import annotations

from datetime import date

import pytest

from alv_app.dynamic_values import (
    DynamicSpec,
    DynamicValueError,
    Preset,
    merged_values,
    parse_value_kinds,
    resolve,
)
from alv_app.fields import FormField, FieldPart, FieldValidation
from alv_app.template_validation import validate_values


# --- fixtures: a scalar date field + a date_range field -------------------------
def _date_field(param="as_on_date", mandatory=False, validations=None):
    return FormField(
        kind="scalar",
        control="date",
        data_type="date",
        display_label="As-on date",
        display_order=1,
        mandatory=mandatory,
        validations=validations or [],
        param_name=param,
    )


def _date_range(frm="date_from", to="date_to", mandatory=False, validations=None):
    return FormField(
        kind="composite",
        control="date_range",
        data_type="date",
        display_label="Transaction date",
        display_order=1,
        mandatory=mandatory,
        validations=validations or [],
        parts={
            "from": FieldPart(param_name=frm, display_label="From"),
            "to": FieldPart(param_name=to, display_label="To"),
        },
    )


def _text_field(param="agent_id"):
    return FormField(
        kind="scalar", control="text", data_type="string",
        display_label="Agent", display_order=2, mandatory=False, param_name=param,
    )


NOW = date(2026, 8, 8)  # a Saturday in Aug (31-day month) — arbitrary fixed "now"


# --- resolve: every preset ------------------------------------------------------
@pytest.mark.parametrize(
    "preset,n,expected",
    [
        (Preset.TODAY, None, date(2026, 8, 8)),
        (Preset.CUR_DATE_PLUS_N_DAYS, -1, date(2026, 8, 7)),
        (Preset.CUR_DATE_PLUS_N_DAYS, 5, date(2026, 8, 13)),
        (Preset.FIRST_DAY_CUR_MONTH, None, date(2026, 8, 1)),
        (Preset.LAST_DAY_CUR_MONTH, None, date(2026, 8, 31)),
        (Preset.FIRST_DAY_NEXT_MONTH, None, date(2026, 9, 1)),
        (Preset.LAST_DAY_NEXT_MONTH, None, date(2026, 9, 30)),
        (Preset.FIRST_DAY_PREV_MONTH, None, date(2026, 7, 1)),
        (Preset.LAST_DAY_PREV_MONTH, None, date(2026, 7, 31)),
    ],
)
def test_resolve_presets(preset, n, expected):
    assert resolve(DynamicSpec(preset=preset, n=n), NOW) == expected


def test_resolve_february_last_day_non_leap():
    assert resolve(DynamicSpec(Preset.LAST_DAY_CUR_MONTH), date(2027, 2, 15)) == date(2027, 2, 28)


def test_resolve_february_last_day_leap():
    assert resolve(DynamicSpec(Preset.LAST_DAY_CUR_MONTH), date(2028, 2, 10)) == date(2028, 2, 29)


def test_resolve_next_month_year_rollover():
    # December -> next month is January of the next year.
    assert resolve(DynamicSpec(Preset.FIRST_DAY_NEXT_MONTH), date(2026, 12, 20)) == date(2027, 1, 1)
    assert resolve(DynamicSpec(Preset.LAST_DAY_NEXT_MONTH), date(2026, 12, 20)) == date(2027, 1, 31)


def test_resolve_prev_month_year_rollover():
    # January -> previous month is December of the prior year.
    assert resolve(DynamicSpec(Preset.FIRST_DAY_PREV_MONTH), date(2026, 1, 5)) == date(2025, 12, 1)
    assert resolve(DynamicSpec(Preset.LAST_DAY_PREV_MONTH), date(2026, 1, 5)) == date(2025, 12, 31)


def test_resolve_plus_n_days_crosses_month():
    assert resolve(DynamicSpec(Preset.CUR_DATE_PLUS_N_DAYS, 30), date(2026, 8, 20)) == date(2026, 9, 19)


# --- parse_value_kinds: the contract --------------------------------------------
def test_parse_none_is_all_static():
    assert parse_value_kinds(None, [_date_range()]) == {}


def test_parse_valid_map():
    fields = [_date_range()]
    specs = parse_value_kinds(
        {
            "date_from": {"kind": "dynamic", "preset": "FIRST_DAY_CUR_MONTH"},
            "date_to": {"kind": "dynamic", "preset": "TODAY"},
        },
        fields,
    )
    assert specs["date_from"].preset is Preset.FIRST_DAY_CUR_MONTH
    assert specs["date_to"].preset is Preset.TODAY


def test_parse_n_days_requires_int_n():
    fields = [_date_field()]
    ok = parse_value_kinds({"as_on_date": {"kind": "dynamic", "preset": "CUR_DATE_PLUS_N_DAYS", "n": -1}}, fields)
    assert ok["as_on_date"] == DynamicSpec(Preset.CUR_DATE_PLUS_N_DAYS, -1)
    # string int is accepted (the FE may send "-1")
    ok2 = parse_value_kinds({"as_on_date": {"kind": "dynamic", "preset": "CUR_DATE_PLUS_N_DAYS", "n": "5"}}, fields)
    assert ok2["as_on_date"].n == 5


def test_parse_n_days_missing_n_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds({"as_on_date": {"kind": "dynamic", "preset": "CUR_DATE_PLUS_N_DAYS"}}, [_date_field()])


def test_parse_n_on_non_param_preset_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds({"as_on_date": {"kind": "dynamic", "preset": "TODAY", "n": 3}}, [_date_field()])


def test_parse_bool_n_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds(
            {"as_on_date": {"kind": "dynamic", "preset": "CUR_DATE_PLUS_N_DAYS", "n": True}},
            [_date_field()],
        )


def test_parse_unknown_preset_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds({"as_on_date": {"kind": "dynamic", "preset": "NEXT_FULL_MOON"}}, [_date_field()])


def test_parse_bad_kind_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds({"as_on_date": {"kind": "static", "preset": "TODAY"}}, [_date_field()])


def test_parse_preset_on_non_date_field_rejected():
    # agent_id is a text field — cannot be dynamic.
    with pytest.raises(DynamicValueError):
        parse_value_kinds({"agent_id": {"kind": "dynamic", "preset": "TODAY"}}, [_text_field()])


def test_parse_unknown_field_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds({"nope": {"kind": "dynamic", "preset": "TODAY"}}, [_date_field()])


def test_parse_non_object_rejected():
    with pytest.raises(DynamicValueError):
        parse_value_kinds([1, 2, 3], [_date_field()])


# --- merged_values --------------------------------------------------------------
def test_merged_values_dynamic_overrides_static_slot():
    fields = [_date_range()]
    specs = parse_value_kinds(
        {"date_from": {"kind": "dynamic", "preset": "FIRST_DAY_CUR_MONTH"}}, fields
    )
    merged = merged_values({"date_from": "IGNORED", "date_to": "2026-08-20", "agent_id": "AG001"}, specs, NOW)
    assert merged["date_from"] == "2026-08-01"  # resolved, static slot ignored
    assert merged["date_to"] == "2026-08-20"    # static, kept
    assert merged["agent_id"] == "AG001"


# --- validate_values: the save-time port ----------------------------------------
def test_validate_from_lte_to_flags_reversed_range():
    field = _date_range(validations=[FieldValidation(rule="from_lte_to", message_key="ALV_DATE_FROM_GT_TO")])
    errors = validate_values([field], {"date_from": "2026-08-20", "date_to": "2026-08-01"}, NOW)
    assert "date_from" in errors


def test_validate_max_span_flags_wide_range():
    field = _date_range(validations=[FieldValidation(rule="max_span", message_key="ALV_DATE_SPAN_EXCEEDED", unit="days", value=31)])
    # 1 Jan .. 15 Feb is > 31 inclusive days.
    errors = validate_values([field], {"date_from": "2026-01-01", "date_to": "2026-02-15"}, NOW)
    assert errors.get("date_from")


def test_validate_max_span_ok_at_boundary():
    field = _date_range(validations=[FieldValidation(rule="max_span", message_key="ALV_DATE_SPAN_EXCEEDED", unit="days", value=31)])
    # 1 Aug .. 31 Aug inclusive = 31 days exactly → OK.
    errors = validate_values([field], {"date_from": "2026-08-01", "date_to": "2026-08-31"}, NOW)
    assert errors == {}


def test_validate_mandatory_scalar():
    field = _date_field(mandatory=True)
    assert validate_values([field], {"as_on_date": ""}, NOW).get("as_on_date")
    assert validate_values([field], {"as_on_date": "2026-08-08"}, NOW) == {}


def test_validate_max_offset_from_today():
    field = _date_field(validations=[FieldValidation(rule="max_offset_from_today", message_key="ALV_DATE_TOO_OLD", unit="months", value=12)])
    # 2 years before NOW → too old.
    assert validate_values([field], {"as_on_date": "2024-08-08"}, NOW).get("as_on_date")
    # within a year → OK.
    assert validate_values([field], {"as_on_date": "2026-01-08"}, NOW) == {}


def test_validate_resolved_dynamic_range_passes():
    # A "from month start to today" dynamic range resolves to 1 Aug .. 8 Aug — within span.
    field = _date_range(validations=[FieldValidation(rule="max_span", message_key="ALV_DATE_SPAN_EXCEEDED", unit="days", value=31)])
    specs = parse_value_kinds(
        {
            "date_from": {"kind": "dynamic", "preset": "FIRST_DAY_CUR_MONTH"},
            "date_to": {"kind": "dynamic", "preset": "TODAY"},
        },
        [field],
    )
    merged = merged_values({}, specs, NOW)
    assert validate_values([field], merged, NOW) == {}
