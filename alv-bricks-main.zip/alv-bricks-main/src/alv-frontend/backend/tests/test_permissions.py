"""Tests for report visibility by group (report_permissions → the enforcement gate).

This is a **security** feature, so the suite covers the allow/deny matrix directly
rather than relying on the happy-path fixtures:

* the gate (:mod:`alv_app.entitlements`) — in group / not in group / unmapped report /
  multiple groups (OR) / no token / ``/Me`` error / mapping unreadable;
* the TTL cache — hit, expiry, and per-user keying (no cross-user leakage);
* the dev bypass — off by default, refused when ``dev_mode`` is off;
* the endpoints — all three catalogue reads filter, and submit / preview / status /
  download return **404** (not 403) for a report the caller may not see;
* the OBO token never reaching a log record or a response body.

Every test here drives the REAL gate logic, mocking only its two outer seams: the
``/Me`` group read (normally the end user's OBO-scoped SDK call) and the
``report_permissions`` warehouse read (normally the App SP).
"""

from __future__ import annotations

import logging
from dataclasses import replace

import pytest

import alv_app.entitlements as ent
from alv_app.config import Settings
from alv_app.identity import UserIdentity
from alv_app.permissions_source import PermissionsSourceError

_AGENT_ITEM = "retail_ledger__detail__agent_item"
# The group the shipped report_specs/report_permissions.json maps both pilot reports
# to (and which conftest's autouse fixture puts the default test user in).
_LEDGER_GROUP = "alv-report_ledger_group"
_OTHER_GROUP = "alv-some_other_group"


def permission_rows(
    report_keys=("retail_ledger", "cc_recharge"), group_name=_LEDGER_GROUP
) -> list[dict[str, object]]:
    """``report_permissions`` group-grant rows in warehouse-return shape.

    New schema: (report_key, principal_type, principal_name, is_active). See
    :mod:`alv_app.permissions_source`.
    """
    return [
        {
            "report_key": rk,
            "principal_type": "group",
            "principal_name": group_name,
            "is_active": True,
        }
        for rk in report_keys
    ]


def group_row(report_key, group_name, is_active=True) -> dict[str, object]:
    """One group grant row (warehouse-return shape)."""
    return {
        "report_key": report_key,
        "principal_type": "group",
        "principal_name": group_name,
        "is_active": is_active,
    }


def user_row(report_key, email, is_active=True) -> dict[str, object]:
    """One user grant row (warehouse-return shape); email stored lower-cased."""
    return {
        "report_key": report_key,
        "principal_type": "user",
        "principal_name": email.lower(),
        "is_active": is_active,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _ident(email="user@example.com", token="obo-token-value") -> UserIdentity:
    """A deployed-shaped identity carrying an OBO token."""
    return UserIdentity(
        email=email,
        preferred_username=email,
        user_id="aad-1",
        real_ip="10.0.0.1",
        authenticated=True,
        has_user_token=token is not None,
        user_token=token,
    )


def _settings(**kw) -> Settings:
    """Settings with permissions enforced (bypass off) unless a test says otherwise."""
    base = {
        "catalog": "cat",
        "schema_name": "sch",
        "databricks_warehouse_id": "wh-1",
        "dev_bypass_permissions": False,
    }
    base.update(kw)
    return Settings(**base)


@pytest.fixture
def gate(monkeypatch):
    """Drive the real gate with controllable ``/Me`` groups + permission rows.

    Overrides the autouse ``_permitted_user`` fixture's patches (same seams, applied
    after it) and yields a small control object:

    * ``gate.set_groups({...})`` — what ``/Me`` returns for this user.
    * ``gate.set_rows([...])``   — the ``report_permissions`` rows the SP reads.
    * ``gate.me_calls`` / ``gate.row_reads`` — call counts, for the cache tests.
    """

    class _Gate:
        def __init__(self):
            self.groups = frozenset({_LEDGER_GROUP})
            self.rows = permission_rows()
            self.me_calls: list[str] = []
            self.row_reads = 0
            self.me_error: Exception | None = None
            self.rows_error: Exception | None = None

        def set_groups(self, groups):
            self.groups = frozenset(groups)

        def set_rows(self, rows):
            self.rows = rows

    g = _Gate()

    def _fake_me(host, user_token):
        g.me_calls.append(user_token)
        if g.me_error:
            raise g.me_error
        return g.groups

    def _fake_rows(settings):
        g.row_reads += 1
        if g.rows_error:
            raise g.rows_error
        return g.rows

    ent.clear_caches()
    monkeypatch.setattr(ent, "_fetch_groups_from_me", _fake_me)
    monkeypatch.setattr(ent, "fetch_report_permissions", _fake_rows)
    yield g
    ent.clear_caches()


# ---------------------------------------------------------------------------
# The gate: allow / deny matrix
# ---------------------------------------------------------------------------
def test_user_in_mapped_group_sees_the_report(gate):
    """Member of a mapped group ⇒ the report is permitted."""
    gate.set_groups({_LEDGER_GROUP})
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset(
        {"retail_ledger", "cc_recharge"}
    )
    assert ent.is_report_permitted(_settings(), _ident(), "retail_ledger") is True


def test_user_not_in_group_sees_nothing(gate):
    """Groups that match no mapping ⇒ nothing is permitted."""
    gate.set_groups({_OTHER_GROUP})
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()
    assert ent.is_report_permitted(_settings(), _ident(), "retail_ledger") is False


def test_report_with_no_mapping_is_hidden(gate):
    """The closed default: an unmapped report_key is visible to nobody."""
    gate.set_groups({_LEDGER_GROUP})
    # Only retail_ledger is mapped; cc_recharge has no row at all.
    gate.set_rows(permission_rows(report_keys=("retail_ledger",)))
    permitted = ent.permitted_report_keys(_settings(), _ident())
    assert permitted == frozenset({"retail_ledger"})
    assert ent.is_report_permitted(_settings(), _ident(), "cc_recharge") is False


def test_no_mappings_at_all_hides_everything(gate):
    """An empty report_permissions table hides every report (deny by default)."""
    gate.set_groups({_LEDGER_GROUP})
    gate.set_rows([])
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()


def test_multiple_groups_are_or_semantics(gate):
    """A report mapped to several groups is visible to a member of ANY of them."""
    gate.set_rows(
        [
            group_row("retail_ledger", "group-a"),
            group_row("retail_ledger", "group-b"),
        ]
    )
    for member_of in ({"group-a"}, {"group-b"}, {"group-a", "group-b"}):
        ent.clear_caches()
        gate.set_groups(member_of)
        assert ent.permitted_report_keys(_settings(), _ident()) == frozenset(
            {"retail_ledger"}
        ), member_of

    # ...and to a member of neither.
    ent.clear_caches()
    gate.set_groups({"group-c"})
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()


def test_user_in_one_of_several_groups_sees_only_the_matching_report(gate):
    """The intersection is per-report, not all-or-nothing."""
    gate.set_rows(
        [
            group_row("retail_ledger", _LEDGER_GROUP),
            group_row("cc_recharge", _OTHER_GROUP),
        ]
    )
    gate.set_groups({_LEDGER_GROUP})
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset({"retail_ledger"})


def test_inactive_mapping_does_not_grant(gate):
    """is_active=false revokes a mapping without deleting the row."""
    gate.set_groups({_LEDGER_GROUP})
    gate.set_rows([group_row("retail_ledger", _LEDGER_GROUP, is_active=False)])
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()


def test_blank_report_key_is_denied(gate):
    """A report with no report_key cannot be mapped, so it is denied."""
    assert ent.is_report_permitted(_settings(), _ident(), None) is False
    assert ent.is_report_permitted(_settings(), _ident(), "") is False


# ---------------------------------------------------------------------------
# Ad-hoc USER grants (principal_type='user') — the new path
# ---------------------------------------------------------------------------
def test_user_grant_alone_permits_the_report(gate):
    """A user grant naming the caller's email permits the report with no group match."""
    gate.set_groups({_OTHER_GROUP})  # in no mapped group
    gate.set_rows([user_row("retail_ledger", "user@example.com")])
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset({"retail_ledger"})
    assert ent.is_report_permitted(_settings(), _ident(), "retail_ledger") is True


def test_user_grant_is_matched_case_folded(gate):
    """The stored email is lower-cased; a caller whose email differs only in case matches."""
    gate.set_groups(set())
    gate.set_rows([user_row("retail_ledger", "USER@Example.com")])  # helper lower-cases it
    assert ent.permitted_report_keys(
        _settings(), _ident(email="User@EXAMPLE.com")
    ) == frozenset({"retail_ledger"})


def test_user_grant_works_without_obo_token(gate):
    """A user grant is honoured even with OBO off — it keys on the email header, not /Me."""
    gate.set_rows([user_row("retail_ledger", "user@example.com")])
    # No token ⇒ groups cannot be read, but the email header still identifies the user.
    permitted = ent.permitted_report_keys(_settings(), _ident(token=None))
    assert permitted == frozenset({"retail_ledger"})
    assert gate.me_calls == []  # /Me was never attempted


def test_group_and_user_grant_do_not_double_count(gate):
    """A report granted BOTH by group and by user appears once (set union)."""
    gate.set_groups({_LEDGER_GROUP})
    gate.set_rows(
        [
            group_row("retail_ledger", _LEDGER_GROUP),
            user_row("retail_ledger", "user@example.com"),
        ]
    )
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset({"retail_ledger"})


def test_user_and_group_grants_union_across_reports(gate):
    """Group grant on one report + user grant on another ⇒ the user sees both."""
    gate.set_groups({_LEDGER_GROUP})
    gate.set_rows(
        [
            group_row("retail_ledger", _LEDGER_GROUP),
            user_row("cc_recharge", "user@example.com"),
        ]
    )
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset(
        {"retail_ledger", "cc_recharge"}
    )


def test_inactive_user_grant_does_not_permit(gate):
    """is_active=false on a user grant revokes it."""
    gate.set_groups(set())
    gate.set_rows([user_row("retail_ledger", "user@example.com", is_active=False)])
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()


def test_user_grant_for_a_different_email_does_not_leak(gate):
    """A grant naming someone else's email does not permit this caller."""
    gate.set_groups(set())
    gate.set_rows([user_row("retail_ledger", "someone.else@example.com")])
    assert ent.permitted_report_keys(_settings(), _ident(email="user@example.com")) == frozenset()


def test_caller_without_email_gets_no_user_grants(gate):
    """A caller with no email header cannot match any user grant (fails closed)."""
    gate.set_groups(set())
    gate.set_rows([user_row("retail_ledger", "user@example.com")])
    no_email = replace(_ident(), email=None)
    assert ent.permitted_report_keys(_settings(), no_email) == frozenset()


def test_map_splits_group_and_user_grants(gate):
    """The mapping indexes the two principal kinds separately."""
    gate.set_rows(
        [
            group_row("retail_ledger", _LEDGER_GROUP),
            user_row("cc_recharge", "user@example.com"),
        ]
    )
    m = ent.report_permission_map(_settings())
    assert m.groups_by_report_key == {"retail_ledger": frozenset({_LEDGER_GROUP})}
    assert m.users_by_report_key == {"cc_recharge": frozenset({"user@example.com"})}


def test_unknown_principal_type_is_skipped(gate):
    """A row with a bad principal_type is ignored (not granted, not a crash)."""
    gate.set_groups({_LEDGER_GROUP})
    gate.set_rows(
        [
            {"report_key": "retail_ledger", "principal_type": "bogus",
             "principal_name": "x", "is_active": True},
            group_row("cc_recharge", _LEDGER_GROUP),
        ]
    )
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset({"cc_recharge"})


# ---------------------------------------------------------------------------
# Fail-closed paths + diagnosability (OBO off vs genuinely no groups)
# ---------------------------------------------------------------------------
def test_no_token_fails_closed_with_no_user_token_reason(gate):
    """No OBO token ⇒ deny, reason=no_user_token, and /Me is never called."""
    result = ent.resolve_user_groups(_settings(), _ident(token=None))
    assert result.ok is False
    assert result.reason == "no_user_token"
    assert result.groups == frozenset()
    assert gate.me_calls == []  # cannot even attempt the lookup
    assert ent.permitted_report_keys(_settings(), _ident(token=None)) == frozenset()


def test_me_error_fails_closed_with_me_failed_reason(gate):
    """A /Me failure ⇒ deny, reason=me_failed (distinct from 'no groups')."""
    gate.me_error = RuntimeError("401 Unauthorized")
    result = ent.resolve_user_groups(_settings(), _ident())
    assert result.ok is False
    assert result.reason == "me_failed"
    assert "401" in (result.detail or "")
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()


def test_genuinely_no_groups_is_distinguishable_from_obo_off(gate):
    """/Me answered with zero groups ⇒ ok=True, reason=no_groups — not 'OBO off'."""
    gate.set_groups(set())
    result = ent.resolve_user_groups(_settings(), _ident())
    assert result.ok is True  # the lookup DID work
    assert result.reason == "no_groups"
    assert result.groups == frozenset()
    # The two deny causes carry different reason codes, which is the whole point.
    assert result.reason != ent.resolve_user_groups(
        _settings(), _ident(email="other@example.com", token=None)
    ).reason


def test_deny_reasons_are_logged(gate, caplog):
    """Every deny path logs a WARNING naming its reason, so it is diagnosable."""
    with caplog.at_level(logging.WARNING, logger="alv_reports.entitlements"):
        ent.permitted_report_keys(_settings(), _ident(token=None))
    assert "no_user_token" in caplog.text

    caplog.clear()
    gate.set_groups(set())
    with caplog.at_level(logging.WARNING, logger="alv_reports.entitlements"):
        ent.permitted_report_keys(_settings(), _ident())
    assert "no_groups" in caplog.text

    caplog.clear()
    ent.clear_caches()
    gate.set_groups({_OTHER_GROUP})
    with caplog.at_level(logging.WARNING, logger="alv_reports.entitlements"):
        ent.permitted_report_keys(_settings(), _ident())
    assert "no_mapping" in caplog.text


def test_permission_map_read_failure_fails_closed(gate):
    """A warehouse failure on report_permissions denies everything (never degrades open)."""
    gate.rows_error = PermissionsSourceError("warehouse down")
    mapping = ent.report_permission_map(_settings())
    assert mapping.ok is False
    assert mapping.groups_by_report_key == {}
    assert mapping.users_by_report_key == {}
    assert ent.permitted_report_keys(_settings(), _ident()) == frozenset()


def test_failed_permission_map_is_not_cached(gate):
    """A failed mapping read must retry next request (so the app recovers)."""
    gate.rows_error = PermissionsSourceError("warehouse down")
    assert ent.report_permission_map(_settings()).ok is False
    gate.rows_error = None
    assert ent.report_permission_map(_settings()).ok is True
    assert gate.row_reads == 2  # the failure was retried, not served from cache


# ---------------------------------------------------------------------------
# TTL cache behaviour
# ---------------------------------------------------------------------------
def test_user_groups_cache_hit_avoids_second_me_call(gate):
    """Within the TTL, a repeat request serves the cached group set (SCIM is 255/min)."""
    s = _settings(permissions_user_ttl_seconds=300)
    ent.resolve_user_groups(s, _ident())
    ent.resolve_user_groups(s, _ident())
    assert len(gate.me_calls) == 1


def test_user_groups_cache_expires(gate, monkeypatch):
    """Past the TTL the group set is re-read from /Me."""
    clock = {"t": 1000.0}
    monkeypatch.setattr(ent.time, "monotonic", lambda: clock["t"])

    s = _settings(permissions_user_ttl_seconds=300)
    ent.resolve_user_groups(s, _ident())
    clock["t"] += 299  # still inside the window
    ent.resolve_user_groups(s, _ident())
    assert len(gate.me_calls) == 1

    clock["t"] += 2  # now past it
    ent.resolve_user_groups(s, _ident())
    assert len(gate.me_calls) == 2


def test_user_groups_cache_is_keyed_per_user(gate):
    """Two users must not share a cache entry (the bug a keyless cache would cause)."""
    s = _settings()
    alice = _ident(email="alice@example.com")
    bob = _ident(email="bob@example.com")

    gate.set_groups({_LEDGER_GROUP})
    assert ent.permitted_report_keys(s, alice) == frozenset({"retail_ledger", "cc_recharge"})

    # Bob is in no mapped group. If the cache were keyless he would inherit Alice's.
    gate.set_groups({_OTHER_GROUP})
    assert ent.permitted_report_keys(s, bob) == frozenset()
    assert len(gate.me_calls) == 2

    # ...and Alice still sees hers, from her own cache entry.
    assert ent.permitted_report_keys(s, alice) == frozenset({"retail_ledger", "cc_recharge"})


def test_permission_map_cache_hit_avoids_second_warehouse_read(gate):
    """The mapping is user-independent and read once per TTL, not per user."""
    s = _settings(permissions_map_ttl_seconds=300)
    ent.permitted_report_keys(s, _ident(email="a@example.com"))
    ent.permitted_report_keys(s, _ident(email="b@example.com"))
    assert gate.row_reads == 1


def test_permission_map_cache_expires(gate, monkeypatch):
    """Past the TTL the mapping is re-read, so a re-seed takes effect."""
    clock = {"t": 500.0}
    monkeypatch.setattr(ent.time, "monotonic", lambda: clock["t"])

    s = _settings(permissions_map_ttl_seconds=60)
    assert ent.report_permission_map(s).groups_by_report_key.keys() == {
        "retail_ledger",
        "cc_recharge",
    }
    gate.set_rows(permission_rows(report_keys=("retail_ledger",)))
    clock["t"] += 30
    assert gate.row_reads == 1  # cached — the re-seed is not visible yet

    clock["t"] += 31
    assert ent.report_permission_map(s).groups_by_report_key.keys() == {"retail_ledger"}
    assert gate.row_reads == 2


def test_zero_ttl_disables_caching(gate):
    """A zero TTL means every request re-reads (an escape hatch, not the default)."""
    s = _settings(permissions_user_ttl_seconds=0)
    ent.resolve_user_groups(s, _ident())
    ent.resolve_user_groups(s, _ident())
    assert len(gate.me_calls) == 2


# ---------------------------------------------------------------------------
# Dev bypass — must be impossible to ship open
# ---------------------------------------------------------------------------
def test_bypass_is_off_by_default():
    """The default Settings value is the SAFE one."""
    assert Settings().dev_bypass_permissions is False
    assert ent.permission_bypass_active(_settings()) is False


def test_bypass_requires_dev_mode(caplog):
    """With dev_mode off (as a deployed app.yaml sets it) the bypass is REFUSED."""
    s = _settings(dev_bypass_permissions=True, dev_mode=False)
    with caplog.at_level(logging.ERROR, logger="alv_reports.entitlements"):
        assert ent.permission_bypass_active(s) is False
    assert "REFUSING" in caplog.text


def test_bypass_when_active_permits_everything_and_logs_loudly(gate, caplog):
    """dev_mode + explicit bypass ⇒ everything visible, with a loud WARNING."""
    s = _settings(dev_bypass_permissions=True, dev_mode=True)
    with caplog.at_level(logging.WARNING, logger="alv_reports.entitlements"):
        assert ent.permission_bypass_active(s) is True
        # No token, no groups, no mapping — and still permitted, because of the bypass.
        assert ent.is_report_permitted(s, _ident(token=None), "anything_at_all") is True
    assert "DEV_BYPASS_PERMISSIONS is ACTIVE" in caplog.text


def test_bypass_skips_filtering_entirely(gate):
    """filter_permitted_reports passes everything through under the bypass."""

    class _R:
        def __init__(self, key):
            self.report_key = key

    reports = [_R("retail_ledger"), _R("never_mapped")]
    s = _settings(dev_bypass_permissions=True, dev_mode=True)
    assert ent.filter_permitted_reports(s, _ident(token=None), reports) == reports


# ---------------------------------------------------------------------------
# filter_permitted_reports
# ---------------------------------------------------------------------------
def test_filter_keeps_order_and_drops_unpermitted(gate):
    class _R:
        def __init__(self, key):
            self.report_key = key

        def __repr__(self):  # nicer assertion output
            return f"_R({self.report_key})"

    gate.set_groups({_LEDGER_GROUP})
    gate.set_rows(permission_rows(report_keys=("retail_ledger",)))
    reports = [_R("retail_ledger"), _R("cc_recharge"), _R("retail_ledger")]
    kept = ent.filter_permitted_reports(_settings(), _ident(), reports)
    assert [r.report_key for r in kept] == ["retail_ledger", "retail_ledger"]


def test_filter_returns_empty_when_nothing_permitted(gate):
    class _R:
        report_key = "retail_ledger"

    gate.set_groups({_OTHER_GROUP})
    assert ent.filter_permitted_reports(_settings(), _ident(), [_R()]) == []


# ---------------------------------------------------------------------------
# The token is a secret: never logged, never in a response
# ---------------------------------------------------------------------------
def test_identity_repr_does_not_contain_the_token():
    """The dataclass repr suppresses the token, so log.info('%s', ident) is safe."""
    ident = _ident(token="super-secret-obo")
    assert "super-secret-obo" not in repr(ident)
    assert ident.user_token == "super-secret-obo"  # still available to the gate


def test_token_never_appears_in_entitlement_logs(gate, caplog):
    """No log record from the gate contains the token — on success or on failure."""
    secret = "super-secret-obo-token"
    ident = _ident(token=secret)

    with caplog.at_level(logging.DEBUG, logger="alv_reports.entitlements"):
        ent.permitted_report_keys(_settings(), ident)  # success path
        ent.clear_caches()
        gate.me_error = RuntimeError("token rejected by workspace")
        ent.permitted_report_keys(_settings(), ident)  # failure path
    assert secret not in caplog.text


def test_token_not_echoed_by_me_endpoint(client):
    """/api/me exposes has_user_token but never the token itself (existing contract)."""
    secret = "another-secret-token"
    resp = client.get(
        "/api/me",
        headers={
            "X-Forwarded-Email": "user@example.com",
            "X-Forwarded-User": "aad-1",
            "X-Forwarded-Access-Token": secret,
        },
    )
    assert resp.status_code == 200
    assert resp.json()["has_user_token"] is True
    assert secret not in resp.text


def test_token_not_echoed_in_a_403_style_deny(monkeypatch, catalog_rows):
    """A denied request's 404 body carries no token either."""
    import alv_app.entitlements as e
    import alv_app.cache as cache_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: catalog_rows)
    monkeypatch.setattr(e, "_fetch_groups_from_me", lambda host, token: frozenset())
    monkeypatch.setattr(e, "fetch_report_permissions", lambda settings: permission_rows())

    from fastapi.testclient import TestClient
    from alv_app import main

    main._cache = main.MetadataCache(main.get_settings())
    main._cache.load(force=True)
    secret = "leak-me-if-you-can"
    with TestClient(main.app) as c:
        resp = c.get(
            f"/api/reports/{_AGENT_ITEM}",
            headers={
                "X-Forwarded-Email": "nobody@example.com",
                "X-Forwarded-Access-Token": secret,
            },
        )
    assert resp.status_code == 404
    assert secret not in resp.text


# ---------------------------------------------------------------------------
# identity.py — the token VALUE is retained (and presence still works)
# ---------------------------------------------------------------------------
def test_resolve_identity_captures_the_token_value():
    from starlette.requests import Request as StarletteRequest
    from alv_app.identity import resolve_identity

    def _req(headers: dict[str, str]) -> StarletteRequest:
        raw = [(k.lower().encode(), v.encode()) for k, v in headers.items()]
        return StarletteRequest({"type": "http", "headers": raw, "client": None})

    ident = resolve_identity(
        _req(
            {
                "X-Forwarded-Email": "user@example.com",
                "X-Forwarded-User": "aad-1",
                "X-Forwarded-Access-Token": "the-token",
            }
        ),
        Settings(),
    )
    assert ident.user_token == "the-token"
    assert ident.has_user_token is True  # existing behaviour preserved
    assert ident.authenticated is True


def test_resolve_identity_blank_token_counts_as_absent():
    """A whitespace-only header must not be handed to the SDK as a credential."""
    from starlette.requests import Request as StarletteRequest
    from alv_app.identity import resolve_identity

    req = StarletteRequest(
        {
            "type": "http",
            "headers": [
                (b"x-forwarded-email", b"user@example.com"),
                (b"x-forwarded-access-token", b"   "),
            ],
            "client": None,
        }
    )
    ident = resolve_identity(req, Settings())
    assert ident.user_token is None
    assert ident.has_user_token is False


def test_dev_fallback_identity_has_no_token():
    """Local dev has no OBO token, so it fails closed unless the bypass is on."""
    from starlette.requests import Request as StarletteRequest
    from alv_app.identity import resolve_identity

    req = StarletteRequest({"type": "http", "headers": [], "client": None})
    ident = resolve_identity(req, Settings(dev_mode=True))
    assert ident.user_token is None
    assert ident.has_user_token is False


# ---------------------------------------------------------------------------
# Endpoints: the three catalogue reads filter
# ---------------------------------------------------------------------------
def _client(monkeypatch, rows, groups, perm_rows):
    """A TestClient with the cache fed *rows* and the gate fed *groups*/*perm_rows*."""
    import alv_app.cache as cache_mod
    import alv_app.entitlements as e
    import alv_app.main as main_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: rows)
    e.clear_caches()
    monkeypatch.setattr(e, "_fetch_groups_from_me", lambda host, token: frozenset(groups))
    monkeypatch.setattr(e, "fetch_report_permissions", lambda settings: perm_rows)

    # Stand in the OBO token the deployed proxy would inject.
    from alv_app.identity import resolve_identity as real_resolve

    def _resolve(request, settings):
        ident = real_resolve(request, settings)
        return replace(ident, user_token="test-obo", has_user_token=True)

    monkeypatch.setattr(main_mod, "resolve_identity", _resolve)

    from fastapi.testclient import TestClient

    main_mod._cache = main_mod.MetadataCache(main_mod.get_settings())
    main_mod._cache.load(force=True)
    return TestClient(main_mod.app)


@pytest.fixture
def denied_client(monkeypatch, catalog_rows):
    """A client whose user is in NO mapped group ⇒ sees nothing."""
    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        yield c


@pytest.fixture
def unmapped_client(monkeypatch, catalog_rows):
    """A client in the right group, but retail_ledger has NO mapping (closed default)."""
    with _client(monkeypatch, catalog_rows, {_LEDGER_GROUP}, []) as c:
        yield c


def test_report_groups_endpoint_filters(denied_client):
    resp = denied_client.get("/api/report-groups")
    assert resp.status_code == 200  # empty state, not an error
    assert resp.json()["groups"] == []


def test_reports_endpoint_filters(denied_client):
    resp = denied_client.get("/api/reports")
    assert resp.status_code == 200
    assert resp.json()["selections"] == []


def test_report_form_endpoint_404s_when_not_permitted(denied_client):
    resp = denied_client.get(f"/api/reports/{_AGENT_ITEM}")
    assert resp.status_code == 404
    # Identical body to a genuinely unknown report ⇒ existence is not disclosed.
    assert resp.json()["detail"] == denied_client.get(
        "/api/reports/no_such_report"
    ).json()["detail"].replace("no_such_report", _AGENT_ITEM)


def test_all_three_catalogue_endpoints_hide_unmapped_reports(unmapped_client):
    """The closed default reaches all three endpoints together."""
    assert unmapped_client.get("/api/report-groups").json()["groups"] == []
    assert unmapped_client.get("/api/reports").json()["selections"] == []
    assert unmapped_client.get(f"/api/reports/{_AGENT_ITEM}").status_code == 404


def test_catalogue_endpoints_allow_a_permitted_user(monkeypatch, catalog_rows):
    """The positive control: the same rows ARE visible to a mapped-group member."""
    with _client(monkeypatch, catalog_rows, {_LEDGER_GROUP}, permission_rows()) as c:
        assert len(c.get("/api/report-groups").json()["groups"]) == 1
        assert len(c.get("/api/reports").json()["selections"]) == 4
        assert c.get(f"/api/reports/{_AGENT_ITEM}").status_code == 200


# ---------------------------------------------------------------------------
# GET /api/reports?report_key= — the scoped catalogue is gated identically
# ---------------------------------------------------------------------------
def test_scoped_catalogue_404s_for_an_unpermitted_report_key(denied_client):
    """?report_key= must not disclose a report the caller may not see.

    404 (never 403), with the SAME detail as a genuinely unknown key — matching the
    deny shape of ``GET /api/reports/{alv_id}`` above.
    """
    resp = denied_client.get("/api/reports?report_key=retail_ledger")
    assert resp.status_code == 404
    assert resp.json()["detail"] == denied_client.get(
        "/api/reports?report_key=no_such_report"
    ).json()["detail"].replace("no_such_report", "retail_ledger")


def test_scoped_catalogue_404s_for_an_unmapped_report_key(unmapped_client):
    """The closed default reaches the scoped read too (no mapping ⇒ invisible)."""
    assert unmapped_client.get("/api/reports?report_key=retail_ledger").status_code == 404


def test_scoped_catalogue_cannot_reach_another_users_report(monkeypatch, two_report_catalog_rows):
    """Permitted for ONE report ⇒ the other's key 404s even though it is in the cache.

    The gate is what decides, not the ``report_key`` filter: scoping must narrow WITHIN
    what the caller may see, never widen to a report the gate excluded.
    """
    perms = permission_rows(report_keys=("retail_ledger",))
    with _client(monkeypatch, two_report_catalog_rows, {_LEDGER_GROUP}, perms) as c:
        assert c.get("/api/reports?report_key=retail_ledger").status_code == 200
        assert c.get("/api/reports?report_key=cc_recharge").status_code == 404
        # The unscoped tree shows only the permitted report (4 selections, not 8).
        assert len(c.get("/api/reports").json()["selections"]) == 4


def test_scoped_catalogue_allows_a_permitted_report_key(monkeypatch, two_report_catalog_rows):
    """Positive control: both keys resolve for a user permitted both."""
    with _client(
        monkeypatch, two_report_catalog_rows, {_LEDGER_GROUP}, permission_rows()
    ) as c:
        for key, label in (("retail_ledger", "Retail Ledger"), ("cc_recharge", "CC Recharge Data")):
            body = c.get(f"/api/reports?report_key={key}").json()
            assert body["report_key"] == key
            assert body["report_label"] == label
            assert len(body["selections"]) == 4


# ---------------------------------------------------------------------------
# Endpoints: the write paths return 404
# ---------------------------------------------------------------------------
def test_submit_404s_when_not_permitted(monkeypatch, catalog_rows_bound):
    """Submit must not run a job for a report the user cannot see."""
    import alv_app.main as main_mod

    triggered: list[object] = []
    monkeypatch.setattr(main_mod, "insert_request_log", lambda s, **kw: triggered.append(kw))
    monkeypatch.setattr(
        main_mod, "trigger_job_run", lambda job_id, job_parameters: triggered.append(job_id)
    )

    with _client(monkeypatch, catalog_rows_bound, {_OTHER_GROUP}, permission_rows()) as c:
        resp = c.post(f"/api/reports/{_AGENT_ITEM}/submit", json={"values": {}})

    assert resp.status_code == 404
    # Nothing was written and no job was triggered — the gate ran FIRST.
    assert triggered == []


def test_submit_404_takes_precedence_over_409_unbound_job(monkeypatch, catalog_rows):
    """An unpermitted+unbound report gives 404, not the 409 that would reveal it exists."""
    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        resp = c.post(f"/api/reports/{_AGENT_ITEM}/submit", json={"values": {}})
    assert resp.status_code == 404


def test_preview_404s_when_not_permitted(monkeypatch, catalog_rows):
    """Preview returns real rows, so it must be gated too."""
    import alv_app.main as main_mod

    def _should_not_run(*a, **kw):
        raise AssertionError("run_preview must not be reached for a denied report")

    monkeypatch.setattr(main_mod, "run_preview", _should_not_run)

    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        resp = c.post(f"/api/reports/{_AGENT_ITEM}/preview", json={"values": {}})
    assert resp.status_code == 404


def test_status_404s_when_not_permitted(monkeypatch, catalog_rows):
    import alv_app.main as main_mod

    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "COMPLETED",
            "run_id": 1,
            "output_path": "/Volumes/c/s/out.csv",
        },
    )

    def _should_not_read(run_id):
        raise AssertionError("the run state must not be read for a denied report")

    monkeypatch.setattr(main_mod, "get_run_status", _should_not_read)

    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        resp = c.get("/api/requests/REQ-X/status")
    assert resp.status_code == 404


def test_download_404s_when_not_permitted(monkeypatch, catalog_rows):
    """A user must not be able to fetch the OUTPUT of a report they cannot see."""
    import alv_app.main as main_mod

    monkeypatch.setattr(
        main_mod,
        "fetch_request",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "status": "COMPLETED",
            "run_id": 1,
            "output_path": "/Volumes/c/s/out.csv",
        },
    )

    def _should_not_read(path):
        raise AssertionError("the volume file must not be read for a denied report")

    monkeypatch.setattr(main_mod, "download_volume_file", _should_not_read)

    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        resp = c.get("/api/requests/REQ-X/download")
    assert resp.status_code == 404


def test_downloads_list_filters_unpermitted_rows(monkeypatch, catalog_rows):
    """An unpermitted user gets an empty page — and the table is never even queried.

    The report filter is now an ``alv_id`` allowlist resolved BEFORE the SQL runs, so
    "this user may see nothing" is answered locally: the REAL read runs and must
    short-circuit on the empty allowlist without executing any statement. Patching the
    statement seam (not the read) is what proves that — a warehouse round-trip here
    would mean the filter had slipped back after the query, the bug this replaced.
    """
    import alv_app.downloads as downloads_mod

    def _should_not_execute(*args, **kwargs):
        raise AssertionError("no request_log statement may run for an unpermitted user")

    monkeypatch.setattr(downloads_mod, "_execute", _should_not_execute)

    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        body = c.get("/api/requests").json()
    assert body["requests"] == []
    assert body["has_more"] is False

    # Same in the `mine` scope — permission filtering is not scope-dependent.
    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        assert c.get("/api/requests?scope=mine").json()["requests"] == []


def test_downloads_params_denied_for_unpermitted_report(monkeypatch, catalog_rows):
    """The params info view is gated exactly like download: 404, same message shape."""
    import alv_app.main as main_mod

    monkeypatch.setattr(
        main_mod,
        "fetch_request_params",
        lambda settings, request_no: {
            "request_no": request_no,
            "alv_id": _AGENT_ITEM,
            "param_payload_json": '{"agent_code":"A1"}',
            "param_hash": "abc",
            "submitted_at": "2026-07-29T10:00:00Z",
        },
    )
    with _client(monkeypatch, catalog_rows, {_OTHER_GROUP}, permission_rows()) as c:
        resp = c.get("/api/requests/REQ-X/params")
    assert resp.status_code == 404
    assert resp.json()["detail"] == "request not found: REQ-X"
    # And nothing about the parameters leaked into the deny response.
    assert "agent_code" not in resp.text


def test_write_paths_allow_a_permitted_user(monkeypatch, catalog_rows_bound):
    """Positive control on the write path: a permitted user CAN submit."""
    import alv_app.main as main_mod

    monkeypatch.setattr(main_mod, "insert_request_log", lambda s, **kw: None)
    monkeypatch.setattr(main_mod, "update_run_id", lambda s, **kw: None)
    monkeypatch.setattr(main_mod, "trigger_job_run", lambda job_id, job_parameters: 4242)

    with _client(monkeypatch, catalog_rows_bound, {_LEDGER_GROUP}, permission_rows()) as c:
        resp = c.post(f"/api/reports/{_AGENT_ITEM}/submit", json={"values": {}})
    assert resp.status_code == 200, resp.text
    assert resp.json()["run_id"] == 4242


# ---------------------------------------------------------------------------
# permissions_source: row coercion
# ---------------------------------------------------------------------------
def test_permissions_source_requires_a_warehouse_id():
    from alv_app.permissions_source import fetch_report_permissions

    with pytest.raises(PermissionsSourceError, match="DATABRICKS_WAREHOUSE_ID"):
        fetch_report_permissions(Settings(databricks_warehouse_id=None))


def test_permissions_source_coerces_is_active(monkeypatch):
    """data_array returns strings; is_active must come back as a real bool."""
    from unittest.mock import MagicMock, patch
    from databricks.sdk.service.sql import StatementState
    from alv_app.permissions_source import fetch_report_permissions

    resp = MagicMock()
    resp.status.state = StatementState.SUCCEEDED
    resp.status.error = None
    resp.result.data_array = [
        ["retail_ledger", "group", "g1", "true"],
        ["retail_ledger", "group", "g2", "false"],
        ["cc_recharge", "user", "a@example.com", None],  # NULL ⇒ treated as active
    ]
    fake = MagicMock()
    fake.statement_execution.execute_statement.return_value = resp

    with patch("databricks.sdk.WorkspaceClient", return_value=fake):
        rows = fetch_report_permissions(
            Settings(catalog="c", schema_name="s", databricks_warehouse_id="wh")
        )
    assert [r["is_active"] for r in rows] == [True, False, True]
    assert [r["principal_type"] for r in rows] == ["group", "group", "user"]


def test_permissions_source_reads_as_the_app_sp(monkeypatch):
    """The mapping table is read with a plain WorkspaceClient (the SP), not OBO."""
    from unittest.mock import MagicMock, patch
    from databricks.sdk.service.sql import StatementState
    from alv_app.permissions_source import fetch_report_permissions

    resp = MagicMock()
    resp.status.state = StatementState.SUCCEEDED
    resp.status.error = None
    resp.result.data_array = []
    fake = MagicMock()
    fake.statement_execution.execute_statement.return_value = resp

    with patch("databricks.sdk.WorkspaceClient", return_value=fake) as wc:
        fetch_report_permissions(
            Settings(catalog="c", schema_name="s", databricks_warehouse_id="wh")
        )
    wc.assert_called_once_with()  # no token kwarg ⇒ App SP
