"""Tests for parameter templates (variants) — the owner-scoped read/write path.

Templates are a new report-scoped, owner-private surface, so the suite drives the real
endpoint logic + the real report-permission gate, mocking only the warehouse statement
seam (``alv_app.templates._execute``) with a tiny in-memory table that parses the
statements ``templates.py`` emits.

Covered: list/save/load/rename/delete round-trips; owner isolation (a second user never
sees or loads the first user's rows); name-overwrite (upsert) vs new-name insert; the
report-permission gate (404 for an unpermitted report, checked before any owner logic);
the no-email caller (404, fail closed); and name validation (blank/too-long/rename clash).
"""

from __future__ import annotations

import json

import pytest

import alv_app.entitlements as ent
import alv_app.main as main_mod
import alv_app.templates as tpl_mod
from alv_app.config import Settings

_AGENT_ITEM = "retail_ledger__detail__agent_item"
_OTHER = "retail_ledger__detail__agent_detail_payment_gateway"

# agent_item has a MANDATORY transaction_date_from/to range (with max_span 31 days and
# max_offset_from_today 12 months). Since save is validation-gated (decision 10), every
# success-path save must include a valid range. Computed relative to today so the tests
# never rot: a 7-day span ending today is inside both the span cap and the 12-month floor.
def _valid(**extra):
    from datetime import date, timedelta

    today = date.today()
    base = {
        "transaction_date_from": (today - timedelta(days=7)).isoformat(),
        "transaction_date_to": today.isoformat(),
    }
    base.update(extra)
    return base


# ---------------------------------------------------------------------------
# A fake report_templates table behind templates._execute
# ---------------------------------------------------------------------------
class _FakeTable:
    """In-memory stand-in for report_templates parsing the statements templates.py emits.

    Handles just the shapes this module produces: MERGE (upsert on
    owner+alv_id+name), UPDATE ... is_active=false (delete), UPDATE ... template_name
    (rename), and the SELECTs (list, load-by-id, id-for-name). Enough to prove the
    endpoint + owner logic without a warehouse.
    """

    def __init__(self):
        # template_id -> row dict
        self.rows: dict[str, dict[str, object]] = {}
        self._seq = 0

    def execute(self, settings, statement, parameters):
        p = {item["name"]: item.get("value") for item in parameters}
        s = " ".join(statement.split())  # normalize whitespace for matching

        if s.startswith("MERGE"):
            key = (p["alv_id"], p["owner"], p["name"])
            existing = self._find_active(key)
            if existing is not None:
                existing["param_values_json"] = p["values_json"]
                existing["value_kinds_json"] = p.get("kinds_json")
                existing["is_active"] = True
                self._seq += 1
                existing["updated_at"] = f"t{self._seq}"
            else:
                self._seq += 1
                self.rows[p["new_id"]] = {
                    "template_id": p["new_id"],
                    "alv_id": p["alv_id"],
                    "owner": p["owner"],
                    "template_name": p["name"],
                    "param_values_json": p["values_json"],
                    "value_kinds_json": p.get("kinds_json"),
                    "is_active": True,
                    "created_at": f"t{self._seq}",
                    "updated_at": f"t{self._seq}",
                }
            return []

        if s.startswith("UPDATE") and "is_active = false" in s:
            row = self.rows.get(p["template_id"])
            if row and row["alv_id"] == p["alv_id"] and row["owner"] == p["owner"]:
                row["is_active"] = False
            return []

        if s.startswith("UPDATE") and "template_name = :name" in s:
            row = self.rows.get(p["template_id"])
            if (
                row
                and row["alv_id"] == p["alv_id"]
                and row["owner"] == p["owner"]
                and row["is_active"]
            ):
                row["template_name"] = p["name"]
            return []

        if s.startswith("SELECT template_id FROM"):
            key = (p["alv_id"], p["owner"], p["name"])
            row = self._find_active(key)
            return [[row["template_id"]]] if row else []

        if "param_values_json" in s and "WHERE template_id" in s:
            # load-by-id (owner + alv scoped)
            row = self.rows.get(p["template_id"])
            if (
                row
                and row["alv_id"] == p["alv_id"]
                and row["owner"] == p["owner"]
                and row["is_active"]
            ):
                return [[
                    row["template_id"], row["alv_id"], row["template_name"],
                    row["param_values_json"], row["value_kinds_json"],
                ]]
            return []

        if s.startswith("SELECT") and "ORDER BY updated_at" in s:
            # report-wide list: owner-scoped, active, alv_id in the bound JSON array.
            import json as _json

            allowed = set(_json.loads(p["alv_ids"])) if p.get("alv_ids") else set()
            out = []
            for row in self.rows.values():
                if row["alv_id"] in allowed and row["owner"] == p["owner"] and row["is_active"]:
                    out.append([
                        row["template_id"], row["alv_id"], row["template_name"],
                        row["created_at"], row["updated_at"], row["value_kinds_json"],
                    ])
            out.sort(key=lambda r: r[4], reverse=True)  # updated_at DESC
            return out

        raise AssertionError(f"unexpected statement: {s[:60]}")

    def _find_active(self, key):
        alv_id, owner, name = key
        for row in self.rows.values():
            if (
                row["alv_id"] == alv_id
                and row["owner"] == owner
                and row["template_name"] == name
                and row["is_active"]
            ):
                return row
        return None


@pytest.fixture
def fake_table(monkeypatch):
    """Patch templates._execute onto an in-memory table; yield it for assertions."""
    t = _FakeTable()
    monkeypatch.setattr(tpl_mod, "_execute", t.execute)
    yield t


def _as_user(monkeypatch, email: str | None):
    """Force resolve_identity (as imported into main) to a fixed email identity.

    Overrides the autouse conftest token-forcing wrapper with one that also sets the
    email, so template ownership is deterministic. ``None`` email models the
    unidentifiable caller.
    """
    from alv_app.identity import UserIdentity

    ident = UserIdentity(
        email=email,
        preferred_username=email,
        user_id="uid-" + (email or "anon"),
        real_ip=None,
        authenticated=True,
        has_user_token=True,
        user_token="test-obo-token",
    )
    monkeypatch.setattr(main_mod, "resolve_identity", lambda request, settings: ident)


# ---------------------------------------------------------------------------
# Happy-path round-trips
# ---------------------------------------------------------------------------
def test_save_then_list_and_load(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs

    r = c.post(
        f"/api/reports/{_AGENT_ITEM}/templates",
        json={"template_name": "Last Month", "values": _valid(agent="AG001")},
    )
    assert r.status_code == 200, r.text
    tid = r.json()["template_id"]
    assert tid.startswith("TPL-")

    lst = c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()
    assert lst["alv_id"] == _AGENT_ITEM
    assert [t["template_name"] for t in lst["templates"]] == ["Last Month"]

    loaded = c.get(f"/api/reports/{_AGENT_ITEM}/templates/{tid}").json()
    assert loaded["values"] == _valid(agent="AG001")  # static template ⇒ values round-trip
    assert loaded["alv_id"] == _AGENT_ITEM


def test_resave_same_name_overwrites(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    r1 = c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                json={"template_name": "Q1", "values": _valid(agent="AG001")})
    tid1 = r1.json()["template_id"]
    r2 = c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                json={"template_name": "Q1", "values": _valid(agent="AG002")})
    tid2 = r2.json()["template_id"]
    assert tid1 == tid2  # same name → same row (upsert), not a duplicate
    lst = c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()
    assert len(lst["templates"]) == 1
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates/{tid1}").json()["values"] == _valid(agent="AG002")


def test_new_name_inserts_new_row(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    c.post(f"/api/reports/{_AGENT_ITEM}/templates", json={"template_name": "A", "values": _valid()})
    c.post(f"/api/reports/{_AGENT_ITEM}/templates", json={"template_name": "B", "values": _valid()})
    names = {t["template_name"] for t in c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()["templates"]}
    assert names == {"A", "B"}


def test_rename_template(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    tid = c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                 json={"template_name": "old", "values": _valid()}).json()["template_id"]
    r = c.post(f"/api/reports/{_AGENT_ITEM}/templates/{tid}/rename", json={"template_name": "new"})
    assert r.status_code == 200, r.text
    names = [t["template_name"] for t in c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()["templates"]]
    assert names == ["new"]


def test_delete_template(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    tid = c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                 json={"template_name": "gone", "values": _valid()}).json()["template_id"]
    r = c.delete(f"/api/reports/{_AGENT_ITEM}/templates/{tid}")
    assert r.status_code == 200 and r.json()["status"] == "deleted"
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()["templates"] == []
    # A deleted template loads as 404.
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates/{tid}").status_code == 404


# ---------------------------------------------------------------------------
# Owner isolation — the core privacy guarantee
# ---------------------------------------------------------------------------
def test_a_user_never_sees_or_loads_another_users_templates(client_with_jobs, fake_table, monkeypatch):
    c = client_with_jobs

    _as_user(monkeypatch, "alice@example.com")
    tid = c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                 json={"template_name": "alice-only", "values": _valid(agent="AG001")}).json()["template_id"]

    # Bob is permitted the report but must not see or load Alice's template.
    _as_user(monkeypatch, "bob@example.com")
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()["templates"] == []
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates/{tid}").status_code == 404
    # Nor delete it.
    c.delete(f"/api/reports/{_AGENT_ITEM}/templates/{tid}")

    # Alice still has it (Bob's delete matched nothing).
    _as_user(monkeypatch, "alice@example.com")
    assert len(c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()["templates"]) == 1


def test_owner_email_matched_case_folded(client_with_jobs, fake_table, monkeypatch):
    c = client_with_jobs
    _as_user(monkeypatch, "Alice@Example.com")
    c.post(f"/api/reports/{_AGENT_ITEM}/templates", json={"template_name": "T", "values": _valid()})
    # Same user, different casing on the header → same owner key → sees the template.
    _as_user(monkeypatch, "alice@example.com")
    assert len(c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()["templates"]) == 1


def test_templates_are_report_wide(client_with_jobs, fake_table, monkeypatch):
    """The list spans the whole report: a template saved under one report type shows when
    viewing another report type of the SAME report, tagged with its own alv_id."""
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    c.post(f"/api/reports/{_AGENT_ITEM}/templates", json={"template_name": "here", "values": _valid()})
    # Viewing a different report type of the same report still lists it (report-wide).
    listed = c.get(f"/api/reports/{_OTHER}/templates").json()["templates"]
    assert [t["template_name"] for t in listed] == ["here"]
    assert listed[0]["alv_id"] == _AGENT_ITEM  # carries its own report type


# ---------------------------------------------------------------------------
# Gates — report permission + identity, checked before owner logic
# ---------------------------------------------------------------------------
def test_unpermitted_report_is_404(client_with_jobs, fake_table, monkeypatch):
    """A report the caller may not see 404s on every template verb (before owner logic)."""
    _as_user(monkeypatch, "alice@example.com")
    # Deny everything: the gate reads no groups / no mapping.
    monkeypatch.setattr(ent, "_fetch_groups_from_me", lambda host, user_token: frozenset())
    monkeypatch.setattr(ent, "fetch_report_permissions", lambda settings: [])
    ent.clear_caches()
    c = client_with_jobs
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates").status_code == 404
    assert c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                  json={"template_name": "x", "values": {}}).status_code == 404
    assert c.get(f"/api/reports/{_AGENT_ITEM}/templates/TPL-XYZ").status_code == 404
    assert c.delete(f"/api/reports/{_AGENT_ITEM}/templates/TPL-XYZ").status_code == 404


def test_unknown_report_is_404(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    assert client_with_jobs.get("/api/reports/nope__x__y/templates").status_code == 404


def test_no_email_caller_is_404(client_with_jobs, fake_table, monkeypatch):
    """An unidentifiable caller (no email) is refused — templates are owned by email."""
    _as_user(monkeypatch, None)
    assert client_with_jobs.get(f"/api/reports/{_AGENT_ITEM}/templates").status_code == 404


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def test_blank_name_is_422(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    r = client_with_jobs.post(f"/api/reports/{_AGENT_ITEM}/templates",
                              json={"template_name": "   ", "values": {}})
    assert r.status_code == 422


def test_too_long_name_is_422(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    r = client_with_jobs.post(f"/api/reports/{_AGENT_ITEM}/templates",
                              json={"template_name": "x" * 200, "values": {}})
    assert r.status_code == 422


def test_rename_onto_existing_name_is_422(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    c.post(f"/api/reports/{_AGENT_ITEM}/templates", json={"template_name": "A", "values": _valid()})
    tid_b = c.post(f"/api/reports/{_AGENT_ITEM}/templates",
                   json={"template_name": "B", "values": _valid()}).json()["template_id"]
    r = c.post(f"/api/reports/{_AGENT_ITEM}/templates/{tid_b}/rename", json={"template_name": "A"})
    assert r.status_code == 422


def test_rename_unknown_template_is_404(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    r = client_with_jobs.post(f"/api/reports/{_AGENT_ITEM}/templates/TPL-NOPE/rename",
                              json={"template_name": "x"})
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# Storage detail — raw values, canonicalized
# ---------------------------------------------------------------------------
def test_values_stored_as_raw_map(client_with_jobs, fake_table, monkeypatch):
    """The stored blob is the raw form map, key-sorted — not the normalized job payload."""
    _as_user(monkeypatch, "alice@example.com")
    # Include the mandatory range (save is validation-gated) plus two extra keys whose
    # ordering we assert. The stored blob is the whole raw map, key-sorted.
    values = _valid(zeta="2", alpha="1")
    client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/templates",
        json={"template_name": "T", "values": values},
    )
    stored = next(iter(fake_table.rows.values()))["param_values_json"]
    assert stored == json.dumps(values, sort_keys=True, separators=(",", ":"))


# ---------------------------------------------------------------------------
# Dynamic templates (relative-date presets) — save-validate + load-resolve
# ---------------------------------------------------------------------------
def test_save_dynamic_then_load_resolves(client_with_jobs, fake_table, monkeypatch):
    """A dynamic 'from month start to today' range saves, then LOADS as concrete dates."""
    from datetime import date

    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    r = c.post(
        f"/api/reports/{_AGENT_ITEM}/templates",
        json={
            "template_name": "MTD",
            # static slots ignored for the dynamic fields; kinds drive the resolution.
            "values": {"transaction_date_from": "", "transaction_date_to": ""},
            "value_kinds": {
                "transaction_date_from": {"kind": "dynamic", "preset": "FIRST_DAY_CUR_MONTH"},
                "transaction_date_to": {"kind": "dynamic", "preset": "TODAY"},
            },
        },
    )
    assert r.status_code == 200, r.text
    assert r.json()["is_dynamic"] is True
    tid = r.json()["template_id"]

    loaded = c.get(f"/api/reports/{_AGENT_ITEM}/templates/{tid}").json()
    today = date.today()
    assert loaded["values"]["transaction_date_from"] == today.replace(day=1).isoformat()
    assert loaded["values"]["transaction_date_to"] == today.isoformat()
    # The raw kinds map round-trips so the UI can badge + re-edit.
    assert loaded["value_kinds"]["transaction_date_to"]["preset"] == "TODAY"
    # The list flags it dynamic.
    lst = c.get(f"/api/reports/{_AGENT_ITEM}/templates").json()
    assert lst["templates"][0]["is_dynamic"] is True


def test_save_fails_validation_returns_422_with_field_errors(client_with_jobs, fake_table, monkeypatch):
    """A template whose values fail the report's validations cannot be saved (decision 10)."""
    _as_user(monkeypatch, "alice@example.com")
    c = client_with_jobs
    # Reversed range → from_lte_to fails; also blank would fail mandatory. Use reversed.
    r = c.post(
        f"/api/reports/{_AGENT_ITEM}/templates",
        json={
            "template_name": "bad",
            "values": {"transaction_date_from": "2026-08-20", "transaction_date_to": "2026-08-01"},
        },
    )
    assert r.status_code == 422
    body = r.json()["detail"]
    assert body["errors"].get("transaction_date_from")
    # Nothing was written.
    assert fake_table.rows == {}


def test_save_missing_mandatory_range_is_422(client_with_jobs, fake_table, monkeypatch):
    """Blank mandatory range is refused at save — the base feature no longer saves it."""
    _as_user(monkeypatch, "alice@example.com")
    r = client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/templates",
        json={"template_name": "empty", "values": {}},
    )
    assert r.status_code == 422


def test_save_bad_preset_is_422(client_with_jobs, fake_table, monkeypatch):
    _as_user(monkeypatch, "alice@example.com")
    r = client_with_jobs.post(
        f"/api/reports/{_AGENT_ITEM}/templates",
        json={
            "template_name": "x",
            "values": _valid(),
            "value_kinds": {"transaction_date_from": {"kind": "dynamic", "preset": "NOPE"}},
        },
    )
    assert r.status_code == 422
