"""Test fixtures: build the 14 alv_catalog rows from the REAL retail_ledger spec.

We drive the cache/endpoints off the actual authoring source
(``report_specs/retail_ledger.input_fields.json``, the 14 rows) rather than a
hand-written stub, so the tests exercise the real metadata shape without needing
a live workspace. Rows are derived exactly as the warehouse would return them
(``alv_id`` slug, ``alv_name``, ``input_fields_json`` serialized as a string),
matching ``docs/METADATA_TABLE.md`` and the live table probe.

**Report visibility.** Every report-scoped endpoint is gated on
``report_permissions`` group membership (:mod:`alv_app.entitlements`), which fails
CLOSED — with no permission context nothing is visible. The autouse
:func:`_permitted_user` fixture therefore stands in an authorized user for the whole
suite, so tests about catalogue / submit / preview / download behaviour keep testing
that behaviour. The gate's own allow/deny matrix is covered in
``test_permissions.py``, whose tests override this fixture explicitly.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

# report_specs/ lives under src/, three levels up from this test file:
# src/alv-frontend/backend/tests/conftest.py -> src/. (parents[3] is src/; the
# library lives separately at <repo-root>/alv-backend, but these tests only need
# the specs, not the library.)
_REPO_ROOT = Path(__file__).resolve().parents[3]
_SPECS = _REPO_ROOT / "report_specs"
_MANIFEST = _SPECS / "retail_ledger.input_fields.json"
# Every seeded report's manifest. The single-report fixture below loads only the pilot
# one, which is exactly why the report-routing bug shipped: with one report_key in the
# cache, code that resolved a report by array index or merged selections keyed on
# selection_id alone looked correct in every test. ``two_report_catalog_rows`` loads
# BOTH so cross-report defects are visible.
_ALL_MANIFESTS = (
    _SPECS / "retail_ledger.input_fields.json",
    _SPECS / "cc_recharge.input_fields.json",
)


def _slug(report_key: str, selection_id: str, report_type_code) -> str:
    parts = [report_key, selection_id]
    if report_type_code:
        parts.append(report_type_code)
    return "__".join(parts)


def _rows_from_manifest(path: Path = _MANIFEST) -> list[dict[str, object]]:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    rows: list[dict[str, object]] = []
    for row in manifest["catalog_rows"]:
        rk, sid, rtc = row["report_key"], row["selection_id"], row.get("report_type_code")
        alv_id = row.get("alv_id") or _slug(rk, sid, rtc)
        name = row.get("alv_name") or " — ".join(
            p
            for p in (row.get("report_label"), row.get("selection_label"), row.get("report_type_label"))
            if p
        )
        rows.append(
            {
                "alv_id": alv_id,
                "report_key": rk,
                "report_label": row.get("report_label"),
                "selection_id": sid,
                "selection_label": row.get("selection_label"),
                "selection_order": row.get("selection_order"),
                "report_type_code": rtc,
                "report_type_label": row.get("report_type_label"),
                "report_type_order": row.get("report_type_order"),
                "alv_name": name,
                "description": row.get("description"),
                "is_active": True,
                # The warehouse stores input_fields_json as a STRING blob.
                "input_fields_json": json.dumps(row["input_fields_json"]),
            }
        )
    return rows


# The test group every fixture user belongs to, mapped to both pilot reports below.
PERMITTED_GROUP = "alv-report_ledger_group"
PERMITTED_REPORT_KEYS = ("retail_ledger", "cc_recharge")


def permission_rows(
    report_keys=PERMITTED_REPORT_KEYS, group_name=PERMITTED_GROUP
) -> list[dict[str, object]]:
    """``report_permissions`` group-grant rows in warehouse-return shape.

    New schema: (report_key, principal_type, principal_name, is_active). See
    :mod:`alv_app.permissions_source`.
    """
    return [
        {
            "report_key": rk,
            "principal_type": "group",
            "principal_name": group_name,
            "is_active": True,
        }
        for rk in report_keys
    ]


def user_permission_rows(
    report_keys=PERMITTED_REPORT_KEYS, email="user@example.com"
) -> list[dict[str, object]]:
    """``report_permissions`` user-grant rows (principal_type='user')."""
    return [
        {
            "report_key": rk,
            "principal_type": "user",
            "principal_name": email.lower(),
            "is_active": True,
        }
        for rk in report_keys
    ]


@pytest.fixture(autouse=True)
def _permitted_user(monkeypatch):
    """Make the caller a member of the group mapped to both pilot reports.

    Autouse because the visibility gate fails CLOSED: without it every report-scoped
    endpoint would 404 and no other test could assert anything about its behaviour.

    Patches the two seams the gate reads — ``/Me`` group resolution and the
    ``report_permissions`` warehouse read — rather than the gate itself, so the real
    intersect / deny-by-default logic still runs on every request. The caches are
    cleared around each test so patched values can never leak between tests.
    """
    import alv_app.entitlements as ent

    ent.clear_caches()
    monkeypatch.setattr(
        ent, "_fetch_groups_from_me", lambda host, user_token: frozenset({PERMITTED_GROUP})
    )
    monkeypatch.setattr(
        ent, "fetch_report_permissions", lambda settings: permission_rows()
    )
    # A user token must be present for the gate to even attempt /Me; the dev identity
    # fallback has none, so inject one into every outgoing test request.
    _force_user_token(monkeypatch)
    yield
    ent.clear_caches()


def _force_user_token(monkeypatch):
    """Make TestClient requests carry an OBO token header (as the Apps proxy would).

    Patches ``resolve_identity`` to fill in ``user_token`` when the test request has no
    ``X-Forwarded-Access-Token`` — the deployed proxy always injects one when user
    authorization is on. Tests that set the header themselves are left untouched, and
    the rest of the identity resolution (email / authenticated / dev fallback) is the
    real thing.
    """
    import alv_app.main as main_mod
    from alv_app.identity import resolve_identity as real_resolve
    from dataclasses import replace

    def _resolve(request, settings):
        ident = real_resolve(request, settings)
        if ident.user_token is None:
            ident = replace(ident, user_token="test-obo-token", has_user_token=True)
        return ident

    monkeypatch.setattr(main_mod, "resolve_identity", _resolve)


@pytest.fixture
def catalog_rows() -> list[dict[str, object]]:
    """The 14 retail_ledger rows in warehouse-return shape.

    Deliberately kept SINGLE-report: most of the suite is about one report's behaviour
    (form shapes, submit, downloads), and a one-report cache keeps those assertions
    direct. Anything about how two reports coexist must use
    :func:`two_report_catalog_rows` instead.
    """
    return _rows_from_manifest()


@pytest.fixture
def two_report_catalog_rows() -> list[dict[str, object]]:
    """All 28 rows — BOTH seeded reports (retail_ledger + cc_recharge).

    The deployed cache holds every seeded report, so this is the realistic shape. The
    two manifests are near-identical clones (same selection_ids, same report_type_codes,
    same selection_order / report_type_order — they differ only in report_key /
    report_label), which makes this fixture the one that catches:

    * resolving a report by ARRAY INDEX — every row ties on both order columns, so
      "the first selection's first report type" is decided by a tiebreak, not by intent;
    * merging selections keyed on ``selection_id`` ALONE — "detail" exists under both
      reports, so a single-keyed dict silently fuses them and cross-links report types;
    * labelling a whole tree from ``reports[0]``.
    """
    rows: list[dict[str, object]] = []
    for path in _ALL_MANIFESTS:
        rows.extend(_rows_from_manifest(path))
    return rows


@pytest.fixture
def two_report_client(monkeypatch, two_report_catalog_rows):
    """A TestClient whose cache holds BOTH reports' rows (28 rows, no warehouse)."""
    with _client_with_rows(monkeypatch, two_report_catalog_rows) as c:
        yield c


@pytest.fixture
def two_report_client_with_jobs(monkeypatch, two_report_catalog_rows):
    """Both reports' rows with a bound ``job_id`` on every row (all 28 runnable)."""
    rows = [dict(r) for r in two_report_catalog_rows]
    for i, r in enumerate(rows):
        r["job_id"] = 2000 + i
        r["job_run_mode"] = "run_now"
    with _client_with_rows(monkeypatch, rows) as c:
        yield c


@pytest.fixture
def catalog_rows_bound(catalog_rows) -> list[dict[str, object]]:
    """The 14 rows with a bound ``job_id`` on every row (post job-binding step)."""
    rows = [dict(r) for r in catalog_rows]
    for i, r in enumerate(rows):
        r["job_id"] = 1000 + i  # any non-null bigint → runnable
        r["job_run_mode"] = "run_now"
    return rows


def _client_with_rows(monkeypatch, rows):
    """Build a TestClient whose metadata cache is fed ``rows`` (no warehouse)."""
    import alv_app.cache as cache_mod

    monkeypatch.setattr(cache_mod, "fetch_catalog_rows", lambda settings: rows)

    from fastapi.testclient import TestClient

    from alv_app import main

    # Rebuild the process cache against the patched reader and force a load.
    main._cache = main.MetadataCache(main.get_settings())
    main._cache.load(force=True)
    return TestClient(main.app)


@pytest.fixture
def client(monkeypatch, catalog_rows):
    """A TestClient whose metadata cache is fed the fixture rows (no warehouse)."""
    with _client_with_rows(monkeypatch, catalog_rows) as c:
        yield c


@pytest.fixture
def client_with_jobs(monkeypatch, catalog_rows_bound):
    """A TestClient whose cache rows all have a bound job_id (runnable)."""
    with _client_with_rows(monkeypatch, catalog_rows_bound) as c:
        yield c


@pytest.fixture
def submit_client(monkeypatch, catalog_rows_bound):
    """A TestClient for the submit path: bound job_ids + mocked warehouse writes + run-now.

    Records the request_log INSERT/UPDATE calls and the run-now trigger on
    ``recorder`` so tests can assert the payload, param_hash, and run_id wiring
    without a live workspace. Yields ``(client, recorder)``.
    """
    import alv_app.main as main_mod

    recorder: dict[str, object] = {"inserts": [], "updates": [], "runs": []}

    def fake_insert(settings, **kwargs):
        recorder["inserts"].append(kwargs)

    def fake_update(settings, **kwargs):
        recorder["updates"].append(kwargs)

    def fake_trigger(job_id, job_parameters):
        recorder["runs"].append({"job_id": job_id, "job_parameters": job_parameters})
        return 987654321  # deterministic run_id

    # Patch the names as imported into main (they're bound at import time).
    monkeypatch.setattr(main_mod, "insert_request_log", fake_insert)
    monkeypatch.setattr(main_mod, "update_run_id", fake_update)
    monkeypatch.setattr(main_mod, "trigger_job_run", fake_trigger)

    with _client_with_rows(monkeypatch, catalog_rows_bound) as c:
        yield c, recorder
