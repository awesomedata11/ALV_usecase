# CLAUDE.md — agent onboarding + framework guidelines for `alv-bricks`

Dense orientation **and** the house-style guide for AI agents and new humans.
This file absorbs the former `FRAMEWORK_GUIDELINES.md` — read it at the start of
a session to match conventions. Keep it in sync with the code.

This doc has **two layers**: **descriptive** (the _why_ — patterns and reasoning)
and **prescriptive** (the _how_ — the **✅ Do this** blocks and the
[Playbooks](#playbooks)).

## What this is

The **metadata framework** for ALV-on-Databricks-Apps (pilot report: Retail Ledger).
Metadata-driven: reports onboard by **configuration, not code**. This repo currently
implements the **metadata layer** (tasks 2.1–2.6); the App (Phase 2) and the backend
Jobs (built by the customer, RIL) are out of scope here.

> **What the framework is.** A metadata-driven module that (1) owns the metadata
> tables describing ALV reports and their parameters, (2) validates report specs
> and seeds them into `alv_catalog`, and (3) is read by a Databricks App that
> renders each report's form and triggers its Job. New reports onboard by
> **configuration, not code**.

> **Deployment is DAB-only — never a wheel.** See [Bundle, jobs & parameterization](#bundle-jobs--parameterization)
> and [Versioning & local dev](#versioning--local-dev). This is the single biggest
> deviation from generic Databricks-framework packaging advice; the rest of this
> guide assumes it.

Read first: `README.md`, `docs/input_fields_json_design.md`,
`docs/metadata_tables_example.md`, `docs/METADATA_TABLE.md`,
`docs/CONFIGURATION_GUIDE.md`.

## The mental model

Three layers, strictly separated. Internalize this before writing code.

```
┌──────────────────────────────────────────────────────────────────┐
│  CONFIG (JSON)        what to do, per report — no code             │
│    · src/report_specs/*.input_fields.json (the authoring source)      │
│    · validated against a JSON Schema; seeded into alv_catalog     │
├──────────────────────────────────────────────────────────────────┤
│  LIBRARY (dbx_alv_reports)  how to do it — generic, reusable       │
│    · classes: MetadataTables, InputFieldsParser, ReportSeeder     │
│    · zero per-report logic; everything is spec-driven             │
├──────────────────────────────────────────────────────────────────┤
│  DRIVER (notebook)    the thin glue that runs on Databricks        │
│    · reads widgets, sys.path-bootstraps, calls ONE class          │
│    · contains no business logic                                   │
└──────────────────────────────────────────────────────────────────┘
```

**Behavior lives in config (the metadata table), mechanism lives in the library,
execution lives in a generic notebook.** The metadata table _is_ config-as-data
persisted: a report's JSON spec is validated and written into `alv_catalog`; the
App reads the table; the run driver reads a row and dispatches its `job_id`.
Adding report #47 means adding a spec entry, **not** editing Python.

## Layout

Single unified module (not the framework/samples/template triad) — one bundle for
the whole thing. The metadata **library + driver notebooks** live in `src/alv-backend/`;
the **App, specs, env params, and library tests** live under `src/` (the App at
`src/alv-frontend/`). The specs stay outside `src/alv-backend/` so they're obviously
"data, not code."

```
src/alv-backend/dbx_alv_reports/  # the library (import: dbx_alv_reports, dist: dbx-alv-reports)
  metadata/metadata_tables.py # SINGLE SOURCE OF TRUTH for table DDL (alv_catalog,
                              #   request_log, report_permissions, auth_map)
  spec_parser/                # InputFieldsParser — loader/validator for input_fields_json
  data_objects/               # InputFieldsSpec / Field / ValidationRule (typed view)
  seed/report_seeder.py       # ReportSeeder — validate manifest + MERGE into alv_catalog
  seed/permission_seeder.py   # PermissionSeeder — same, for report_permissions
  common/utilities/           # logging, err_utils (error-dict), uc_utils (Spark)
  json_specifications/        # input_fields.schema.json (contract) + catalog_rows.schema.json
  VERSION                     # single-sourced semver
src/alv-backend/*.ipynb           # thin driver notebooks (provision_metadata, seed_reports,
                              #   seed_report_permissions, seed_sample_data)
src/alv-frontend/             # the Databricks App — backend/ (FastAPI alv_app, deploy root)
                              #   + frontend/ (React/Vite SPA → backend/static)
src/report_specs/             # authoring source (retail_ledger.input_fields.json = 14 rows,
                              #   report_permissions.json = the visibility map)
src/env_parameters/           # {dev,prod}_parameters.yaml (catalog/schema)
src/tests/unit/               # no-Spark library unit tests
resources/*.job.yml + databricks.yml   # the DAB
```

✅ **Do this**
- Import package is `dbx_alv_reports` (underscores); the `pyproject.toml` name is
  `dbx-alv-reports` but **only for local editable installs** — we never ship a dist.
- Put the metadata-table schema/DDL in **exactly one module** (`metadata_tables.py`)
  so the table contract has a single source of truth.
- Grouping subpackages are plural (`utilities/`); JSON Schemas live in
  `json_specifications/` and travel with the package (synced as workspace files).
- Re-export the few classes an outside caller (notebook, App, tests) needs from the
  top-level `__init__.py`; keep everything else internal.

## Build & run

**Deployment is DAB-only — never a wheel.** The bundle syncs `src/alv-backend/` + `src/report_specs/`
as workspace files; the driver notebooks add `${bundle_source_path}/src/alv-backend` to `sys.path`
and `import dbx_alv_reports`. `pyproject.toml` is for **local dev/test only**.

Use a **venv** for tests/lint, and install through the Databricks pip proxy:

```bash
python3 -m venv .venv && source .venv/bin/activate
export HOMEBREW_PIP_INDEX_URL="https://pypi-proxy.cloud.databricks.com/simple"
pip install --index-url "$HOMEBREW_PIP_INDEX_URL" -e ".[dev]"   # LOCAL ONLY: editable install for tests/lint
pytest -m unit                   # unit tests (no cluster)
python -m compileall src/alv-backend # quick syntax check
```

`.venv/` is git-ignored. If a bare `pip`/`pytest` isn't on PATH, create the venv
first — don't fall back to compile-only unless the proxy is unreachable.

**Package proxies (both public registries are firewalled in this environment).**
Default `pypi.org` and `npmjs.org` are blocked — install through the Databricks
mirrors:

| Tool | Proxy | How |
|---|---|---|
| pip / uv (Python) | `https://pypi-proxy.cloud.databricks.com/simple` | `export HOMEBREW_PIP_INDEX_URL=...` (pip) or `export UV_DEFAULT_INDEX=...` (uv) |
| npm (frontend) | `https://npm-proxy.cloud.databricks.com/` | `npm install --registry=https://npm-proxy.cloud.databricks.com/` |

The App backend (`src/alv-frontend/backend/`, uv-managed) and frontend (`src/alv-frontend/frontend/`, npm)
both rely on these mirrors.

Drivers run on Databricks via the bundle jobs (`databricks bundle deploy -t dev`,
then run `provision_alv_metadata` and `seed_alv_reports`). Nothing is deployed yet —
the current state is author-only; set real `catalog`/`schema`/`host`/SPN before deploy.

## Class design patterns

Match the surrounding style: Google-style docstrings (`Args:`/`Returns:`/`Raises:`),
type hints on signatures, `>>>` usage examples in class docstrings.

### Orchestrator with explicit dependency injection — the default

The "do the work" class receives its dependencies explicitly (`spark`, `catalog`,
`schema`, optional `log`). It builds its own helpers; it never reaches for globals.

```python
class MetadataTables:
    def __init__(self, spark, catalog, schema, log=None):
        self.spark = spark
        self.catalog, self.schema = catalog, schema
        self.log = log or get_log("metadata")     # always injectable, never required
        self.uc = UnityCatalogUtils(spark=spark, log=self.log)

    def ensure_all(self, include_auth_map=False): ...
```

### Dataclass "spec" objects

A parsed config entry is a typed `@dataclass` mirroring the JSON keys 1:1
(`snake_case`), so `InputFieldsSpec.from_dict(blob)` works. Required fields first,
optionals via `field(default_factory=…)`, helper methods that derive views
(`ordered_fields()`, `all_param_names()`). See `data_objects/input_fields.py`.

### Validate-in-constructor "worker" classes

A class that does one job parses config into attributes, then a single public
method does the work and reports a result. `InputFieldsParser` collects errors
(doesn't throw on the first) and exposes `validate()` / `get_spec()` /
`get_errors()` / `summary()`.

### Registry factory — reach for it only when report types diverge

We do **not** have one yet. If reports ever need distinct _run_ behavior (e.g.
`sql_report` vs `notebook_report`), add a `ReportRunnerFactory` with a class-level
registry dict + `@classmethod create(...)` that raises `ValueError` listing
supported types. Don't build it speculatively.

## Configuration: JSON → validated object

The backbone pattern: **authored JSON → JSON-Schema validation → normalized Python
object.** The flow (see `spec_parser/input_fields_parser.py`):

1. **Load** the report spec / manifest JSON.
2. **Validate** against `json_specifications/input_fields.schema.json` (Draft-07):
   - resolve the schema **relative to the package** (`Path(__file__)...`);
   - **degrade gracefully** if `jsonschema` isn't importable (`JSONSCHEMA_AVAILABLE`
     flag) — an always-on **semantic pass** still enforces the contract;
   - **collect all errors** (never fail on the first) so an author sees every
     problem in one pass;
   - **fail the load on an unknown validation rule** — never silently skip (D-IFJ-10).
3. **Consume** the parsed `InputFieldsSpec` in the orchestrator / App.

✅ **Do this**
- **Write/extend the JSON Schema first** — it is the contract for what a spec may
  contain. It ships with the package (synced as a workspace file, loaded at runtime).
- Keep env-specific values (catalog, schema) **out of the spec**; supply them via
  `src/env_parameters/<env>_parameters.yaml` and job parameters.
- No inline user-facing message text in specs — rules carry a `message_key`
  resolved against the message catalogue (D-IFJ-9).

> **The `input_fields_json` contract** (newer flat model) is documented in
> `docs/input_fields_json_design.md` and `docs/CONFIGURATION_GUIDE.md`. `selection`
> and `report_type` are **catalog identity columns, not fields** (D-IFJ-8).

## The notebook → object driver pattern

Drivers live in `src/alv-backend/*.ipynb`, are generic, and contain **zero business logic**.
Because we deploy **DAB-only (no wheel)**, the driver must put the synced package on
`sys.path` before importing it. The fixed six steps:

```python
# 1. widgets (the job passes these) — always include bundle_source_path
dbutils.widgets.text("env", "dev")
dbutils.widgets.text("catalog", ""); dbutils.widgets.text("schema", "")
dbutils.widgets.text("bundle_source_path", "")

# 2. read widgets
catalog = dbutils.widgets.get("catalog"); schema = dbutils.widgets.get("schema")
bundle_source_path = dbutils.widgets.get("bundle_source_path")

# 3. bootstrap import path (DAB-synced workspace files) + stdout logger
import sys, logging
sys.path.insert(0, f"{bundle_source_path}/src/alv-backend")          # <- the no-wheel bootstrap
logger = logging.getLogger("alv_reports"); logger.setLevel(logging.INFO)

# 4. import ONE class from the synced package
from dbx_alv_reports import MetadataTables

# 5. instantiate with spark, log, params
# 6. run; raise on a returned error-dict so the job run is marked failed
```

✅ **Do this**
- One notebook = one class = one call. A second distinct operation → a second
  notebook (we have `provision` + `seed`), not a branch inside one.
- Standard widgets: `env`, `catalog`, `schema`, `bundle_source_path` (+ per-driver
  extras like `manifest_path`, `include_auth_map`).
- `raise` on a returned error-dict so the Databricks run is marked failed.

## Bundle, jobs & parameterization

**DAB-only. No wheel, ever.** The bundle **syncs the framework source and specs as
workspace files**; drivers import them via the `sys.path` bootstrap above.

`databricks.yml` conventions:
- `include: - resources/*.yml`.
- a **`sync.include`** block for `src/alv-backend/**`, `src/report_specs/**`, `src/env_parameters/**`
  so the package + specs upload as workspace files.
- a `variables:` block: `logical_env`, `catalog`, `schema`, `bundle_source_path`
  (= `${workspace.file_path}`), `framework_source_path` (= `${workspace.file_path}/src`).
- `targets: dev` (`mode: development`, `default: true`) and `prod`
  (`mode: production`, `permissions: CAN_MANAGE`), each overriding `catalog`/`schema`
  and setting `workspace.host` + `root_path`.

A job points its task at a **synced notebook** and passes params — its env spec
declares only **third-party** deps (no framework wheel):

```yaml
tasks:
  - task_key: provision_metadata
    notebook_task:
      notebook_path: ${var.framework_source_path}/provision_metadata
      source: WORKSPACE
    environment_key: default_env
parameters:
  - { name: env,     default: ${var.logical_env} }
  - { name: catalog, default: ${var.catalog} }
  - { name: schema,  default: ${var.schema} }
  - { name: bundle_source_path, default: ${var.bundle_source_path} }
environments:
  - environment_key: default_env
    spec:
      dependencies: [pyyaml, jsonschema]   # third-party only — framework is synced, not installed
      environment_version: "4"
```

✅ **Do this**
- Parameterize `bundle_source_path`/`framework_source_path` from
  `${workspace.file_path}` so the same bundle deploys per-user/per-target with no edits.
- Put catalog/schema in `src/env_parameters/<env>_parameters.yaml` (and/or bundle vars),
  never in specs.
- For the App-triggered run (later phase), the App calls the Jobs API with
  `report_id` + user values as job parameters; prefer **one parameterized "run
  report" job** the App triggers with different rows over one job per report.

## Utilities, logging & error handling

`common/utilities/` splits by whether Spark is needed:
- **Module-level functions** (no Spark): `err_utils.get_exception` (the error-dict shape).
- **Class utilities** holding `spark`/`log` (constructor `(spark, log=None)`):
  `UnityCatalogUtils` (`schema_exists`, `table_exists`, `run`).

**Logging** — `logging.py`: a named `alv_reports` app logger with **idempotent**
handler setup + a `get_log(module_name=None)` child accessor. Every class does
`self.log = log or get_log()`. Format:
`"%(asctime)s - %(name)s - %(levelname)s - %(message)s"` to `sys.stdout`.

**Error handling — two coexisting styles:**
1. **Error-dict / return-value** (`get_exception`) for the **runtime execution path**:
   `seed()` returns `{"error_code", "error_message", "log_level", "error_at"}` (or `None`);
   the notebook raises on it.
2. **Raise-early** for **programmer/config errors**: bad spec / unknown rule fails
   loud at parse/build time (`ValueError`), listing every problem.

✅ **Do this** — raise-early for config errors; error-dict for the run path; always
accept an optional `log`; never `print`.

## Versioning & local dev

- **No wheel is ever built or shipped.** `pyproject.toml` exists **only** so you can
  `pip install -e ".[dev]"` locally to run the unit tests and lint/format (black,
  flake8, mypy, pytest config).
- **Version** is single-sourced in `src/alv-backend/dbx_alv_reports/VERSION` and read via the
  `VERSION`-file fallback in `__init__._read_version()`. Bump it with each notable
  change; keep it in step with `CHANGELOG.md` (semver).
- The framework reaches Databricks **as synced workspace files**, so package data
  (the JSON Schemas) must live inside the package dir — they do (`json_specifications/`).

## Documentation conventions

Hand-written Markdown with a table of contents and emoji-free section headers. The
doc set we maintain:

- **`README.md`** — high-level overview + repo layout + status + **the changelog /
  progression log** (folded in — see its Changelog section).
- **`CLAUDE.md`** — this file: dense agent/newcomer onboarding **and** the framework
  guidelines. **Keep it current** — highest leverage for humans and AI agents.
- **`docs/CONFIGURATION_GUIDE.md`** — how report metadata is authored, validated,
  seeded; the `input_fields_json` field + validation reference.
- **`docs/METADATA_TABLE.md`** — the metadata table **contract the App depends on**.
  Treat a column rename/removal as a **breaking change** with a `CHANGELOG` entry.
- **`docs/SECURITY_AND_PERMISSIONS.md`** — the **security reference** for reviews:
  the two-identity model (**user OBO token for authorization, App SP for data**),
  the `report_permissions` gate, all 17 safeguards, **why** the SQL group functions
  and SCIM lookups were rejected, known limitations, and how to verify the deny path.
  Update it whenever an auth path, identity, or safeguard changes.
- **`docs/input_fields_json_design.md`** / **`docs/metadata_tables_example.md`** —
  the design deep-dives + decision logs (D-IFJ-*).
- **`CHANGELOG.md`** — canonical "Keep a Changelog" file, reverse-chronological
  `## [x.y.z] - YYYY-MM-DD` with `### Added / Changed / Fixed`; mirrored into README.

## Testing & hygiene

- **pytest, `unit/` vs `integration/` split.** `unit/` needs no Spark and runs in
  CI; keep the root `tests/conftest.py` minimal (no Databricks imports) so unit
  tests import cleanly. Spark fixtures belong under `tests/integration/conftest.py`
  (Databricks Connect) when added.
- Unit-test the **pure** logic with no Spark: the JSON Schema, the parser (valid +
  every negative: unknown rule, duplicate `param_name`, bad `schema_version`,
  missing part, …), the DDL builders, and row derivation (`build_rows`).
  Integration-test `ensure_all()` / `seed()` against a real catalog/schema.
- `pytest.ini` config lives in `pyproject.toml` (`pythonpath = ["src"]`,
  `--strict-markers`, `unit`/`integration` markers).
- Use **Conventional Commit** messages (`feat:`, `fix:`, `docs:`, …).
- `scratch/` holds personal notebooks and is git-ignored.

> **Offline note:** if no package index is reachable, the parser degrades without
> `jsonschema` (the semantic pass covers the contract), and the unit tests can be
> run through a tiny zero-dependency pytest shim — but the normal path is
> `pip install -e ".[dev]" && pytest -m unit`.

## Key decisions baked in

- Newer **flat 14-row** model: one `alv_catalog` row per (selection × report_type),
  each with its own flat `input_fields_json`; `selection`/`report_type` are **catalog
  columns, not form fields** (D-IFJ-7, D-IFJ-8). Supersedes `ALV_App_Task_Breakdown.md` §3.2.
- `message_key` (not inline `message`) — D-IFJ-9.
- `auth_map` **deferred** (D19) — DDL present, not created by default. **Superseded for
  report visibility** by `report_permissions` (below); its grain was *data-row* filtering
  by business dimension, a different concern. Do not delete it (tests cover the DDL);
  nothing reads it.
- **Report visibility by group** — `report_permissions` maps `report_key` → group name;
  a user sees a report if they are in ANY mapped group (OR), and a report with **no
  mapping is hidden from everyone** (deny by default). Gating is whole-report, enforced
  on read AND write paths, and a denied report returns **404** (never 403 — that would
  disclose it exists). The App reads the *user's* groups from `/Me` with their injected
  OBO token (the only route that works for a non-admin SP) and the mapping table as the
  App SP; both are TTL-cached because workspace SCIM is capped at 255 GET/min. **Direct
  memberships only** — group nesting is not resolved. See
  `src/alv-frontend/backend/alv_app/entitlements.py` and `docs/METADATA_TABLE.md`.
- **Cross-user run access is INTENDED** (decided 2026-08-04). If you hold a report's
  permission you can see **and download** that report's runs whoever submitted them, and
  `submitted_by` is **displayed, not masked**. The `report_permissions` group gate is the
  **only** authorization control on the request-list / status / params / download paths.
  Do **not** add a `submitted_by == caller` restriction — the Downloads `scope=mine`
  filter is a convenience, explicitly *not* a control. See
  `docs/SECURITY_AND_PERMISSIONS.md` §8, which previously listed this as an open bug and
  now records the decision.
- **The Downloads list filters in SQL, before its limit** (`src/alv-frontend/backend/alv_app/downloads.py`).
  Visibility + scope + search are `WHERE` predicates; the report-name search is resolved
  to an `alv_id` allowlist from the metadata cache (the label is not a `request_log`
  column) and bound as one JSON array. Never filter this list in Python after a `LIMIT`,
  and never interpolate a sort key — that was the bug this replaced.
- `job_id`s and catalog/schema names are **placeholders** pending the RIL contract
  (`input_fields_json_design.md` Open items #1, #4).
- **Output-path layout is Job-owned, per-run:** a report Job writes to
  `/Volumes/<cat>/<schema>/<vol>/<YYYYMMDD>/<alv_id>/<request_no>/<file>` — it stamps the
  date itself (in the `report_timezone` param) and composes the path from the `alv_id` +
  `request_no` it already receives on `run-now` (no App change, no new job param; `alv_id`
  is an opaque segment, never split). The App stores/serves the returned `output_path`
  verbatim. Compose it via the shared pure helper `dbx_alv_reports.build_output_dir`. A
  daily `alv_output_cleanup` job prunes `<YYYYMMDD>` folders older than
  `output_retention_days` (`databricks.yml`, default 30) via `expired_date_dirs`. See
  `docs/OUTPUT_PATH_LAYOUT_APPROACH.md` + `docs/APP_PREREQUISITES.md` §2a/§2b.

## Playbooks

The recurring tasks a new session will do. **Work schema-first, collect-all,
fail-loud on config errors.**

### Add a new validation rule
1. Add it to the schema enum + per-rule `required` in
   `json_specifications/input_fields.schema.json`.
2. Add it to `KNOWN_RULES` (+ `_RULE_REQUIRED_PARAMS` if it takes params) in
   `spec_parser/input_fields_parser.py`, and any semantic check it needs.
3. Add a unit test in `tests/unit/test_input_fields_parser.py`.
4. Document it in `docs/CONFIGURATION_GUIDE.md` and note it in `CHANGELOG.md` + README.

### Add / change a metadata-table column
1. Edit the `TableDef` in `metadata/metadata_tables.py` (the **single source of truth**).
2. Update `docs/METADATA_TABLE.md` — it's the App's contract; a rename is **breaking**.
3. Update the seeder (`_SEED_COLUMNS` / `build_rows` / the Spark `StructType`) if the
   column is seeded.
4. Add/adjust unit tests in `tests/unit/test_metadata_tables.py`; `CHANGELOG.md` + README entry.

### Onboard a new report
1. Author `src/report_specs/<report>.input_fields.json` (identity columns + a `job_id` +
   its own flat `input_fields_json` per runnable row). Validate it (the seeder does).
2. Confirm the `param_name` ↔ Job-key contract with the customer (D6) and the real
   `job_id`s (placeholders seed as `NULL`).
3. Seed it via the `seed_reports` job (or `ReportSeeder(...).seed(path)`).
4. **Add its `report_key` to `src/report_specs/report_permissions.json`** and run
   `seed_alv_report_permissions` — visibility is deny-by-default, so an unmapped report
   stays invisible no matter what else is correct.
5. No library/App code changes — that's the point.

### Grant / revoke a report for a group
1. Edit `src/report_specs/report_permissions.json` (one entry per `report_key` +
   `group_name`; several groups on one report = OR). Use the group's **display name**
   exactly, and the group users are **directly** in (nesting is not resolved).
2. Run the `seed_alv_report_permissions` job. It MERGEs — it never deletes a mapping
   that dropped out of the manifest, so to revoke either set `is_active: false` and
   re-seed, or `DELETE` the row.
3. The App picks it up within `PERMISSIONS_MAP_TTL_SECONDS` (default 300s); restart for
   immediate effect.

### Build order (if starting a new capability from scratch)
JSON Schema → dataclass spec → parser → single-source table DDL → orchestrator
classes (DI + error-dict `run`) → public API re-export → thin driver notebook →
bundle job → unit tests → docs (`CONFIGURATION_GUIDE` + `METADATA_TABLE` +
`CHANGELOG` + README + `CLAUDE`).

---

_Maintenance: keep this guide in sync with the code. When a convention changes,
update the relevant section and add a `CHANGELOG`/README note._
