# Changelog

All notable changes to `dbx-alv-reports` are documented here. This is the canonical
changelog; `README.md` mirrors it as a progression log — update both together.
Format follows [Keep a Changelog](https://keepachangelog.com/); versions are semver
and match `src/dbx_alv_reports/VERSION`.

## [Unreleased] — App deploy as a DAB job (feat/app-deploy-job)

> **Tooling only** — no App/library behavior change, no schema/migration/grant change, no
> `VERSION` bump. **Not yet run/deployed.** Makes the App deploy/update DAB-native so it
> runs like the seeder/cleanup jobs instead of the manual CLI flow in
> `docs/APP_DEPLOY_RUNBOOK.md`.

### Added — `alv_deploy_app` job + `deploy_app` driver notebook

- **`src/alv-backend/deploy_app.py`** (notebook-source driver, adapted from a foreign
  reference the user supplied) — creates/reuses the App, starts its compute, `w.apps.deploy`s
  the code from the synced workspace source, floors the SQL-warehouse auto-stop
  (best-effort, default 60 min so the first query doesn't cold-start), and prints the
  App-SP grants with the SP + this target's catalog/schema/volume filled in.
- **`resources/alv_deploy_app.job.yml`** — job `alv_deploy_app` (serverless,
  `environment_version: "4"`, `databricks-sdk` dep). Params: `env`/`catalog`/`schema`/
  `bundle_source_path` (standard) + `app_name` (`alv-bricks`), `app_source_path`,
  `warehouse_id`, `volume` (`alv_outputs`), `warehouse_min_autostop_mins` (`60`).
- **`databricks.yml`** — `sync.include` now also uploads `src/alv-frontend/backend/**`
  (with `sync.exclude` for `.venv`/`tests`/`__pycache__`), so the job deploys the App from
  `<bundle_source_path>/src/alv-frontend/backend` with no separate `databricks sync` step.
  Full flow: `databricks bundle deploy -t dev` then `databricks bundle run alv_deploy_app -t dev`.
  New `warehouse_id` variable (dev `f399753196bda967`, prod `REPLACE_ME`).

### Changed — grants printed are ALV's, not the reference's

- The reference notebook granted `system.*` schemas (needs an **account admin**). ALV
  touches **no `system.*`**: the printed block is now catalog/schema
  `USE CATALOG`/`USE SCHEMA`/`SELECT`/`MODIFY` + volume `READ VOLUME`/`WRITE VOLUME` (SQL,
  runnable by a **Unity Catalog admin / catalog owner**), plus warehouse `CAN_USE` and
  per-bound-job `CAN_MANAGE_RUN` (permissions-API CLI, not SQL). The bound `job_id`s are
  read live from `alv_catalog` so the `CAN_MANAGE_RUN` lines are concrete. Matches
  `docs/APP_PREREQUISITES.md`.

### Verified

- `databricks bundle validate -t dev` **OK**; `deploy_app.py` compiles; both YAMLs parse.
  Not yet run — `bundle deploy` / `bundle run alv_deploy_app` pending Idris' go-ahead
  (running it cuts the live app's source path over to the bundle-synced path).

## [Unreleased] — structured output paths + retention cleanup (feat/structured-output-paths)

> **Deployed 2026-08-19** to `fevm-classic-stable-lakebase` (profile `fevm-lakebase`);
> not yet merged — awaiting live validation. **Job/library-layer only** — no App/frontend
> change, **no schema / migration / new grant**, no library `VERSION` bump. Design +
> decisions: `docs/OUTPUT_PATH_LAYOUT_APPROACH.md`.

### Changed — per-run output subfolders (was a flat directory)

- **Report-run output now lands under per-run subfolders** instead of one flat directory:
  `/Volumes/<cat>/<schema>/<vol>/<YYYYMMDD>/<alv_id>/<request_no>/<file>`. The Job owns the
  layout — it stamps the run date itself (in `report_timezone`) and composes the path from
  the `alv_id` + `request_no` it **already receives** on `run-now`, so **no App-side change
  and no new job parameter**. `alv_id` is used as an opaque folder segment (never split
  into its `report_key__…` parts). The `output_dir` job param is removed.
- **The stand-in jobs now write via Spark** (`df.coalesce(1).write.csv(dir)`) into the
  per-run folder and return the concrete globbed `part-*.csv` path — a single-file
  `output_path`, so **Download + output-preview are unchanged** (they read the returned
  path verbatim). `report_timezone` job param added (default `Asia/Kolkata`); the dummy job
  gains `bundle_source_path` (it now imports the shared helper).
- **`dbx_alv_reports.build_output_dir(base, alv_id, request_no, now)`** (new, Spark-free,
  pure, re-exported) composes the directory; `now` is injected so it is unit-tested with no
  cluster. Lives in `common/utilities/output_path.py`.
- **Existing rows keep working** — their stored flat paths still resolve; only new runs get
  nested paths. `request_log.output_path` is unchanged in shape (just longer values).

### Added — daily output retention cleanup job

- **`alv_output_cleanup` job** (`resources/alv_output_cleanup.job.yml`) — a serverless job
  scheduled **daily at 01:00 Asia/Kolkata** that deletes `<YYYYMMDD>` output folders older
  than **`output_retention_days`** (new `databricks.yml` variable, default **30**), keeping
  the most recent N days. Auto-paused in the dev target; unpaused in prod. Supports
  `dry_run=true` (logs, deletes nothing).
- **`dbx_alv_reports.expired_date_dirs` / `parse_date_dir`** (new, pure, re-exported) — pick
  the expired folders (strictly older than `today − N`); **anything not a `YYYYMMDD` folder
  is ignored**, so old flat files / stray dirs are never touched. The notebook
  (`src/alv-backend/alv_output_cleanup.ipynb`) does only the I/O (`dbutils.fs.ls` / `rm`).
- **Prereq:** the cleanup run-as identity needs `WRITE VOLUME` on `alv_outputs`
  (`docs/APP_PREREQUISITES.md` §2b).

### Tests / verification

- **+26 library unit tests** (`src/tests/unit/test_output_path.py`): `build_output_dir`
  (layout order, timezone-correct date stamp, opaque `alv_id` segment, base-slash hygiene,
  blank-input guards) and the retention helpers (cutoff strictness, retention 0, non-date
  names ignored, order preserved, negative-retention guard). **106 library unit tests pass**,
  `compileall` clean, `bundle validate` OK.
- **Live-smoke-tested on `fevm-lakebase`:** the dummy job wrote to
  `…/20260819/retail_ledger__detail__agent_item/REQ-SMOKE-0001/part-*.csv` (3 rows) and the
  sample job to `…/REQ-SMOKE-0002/part-*.csv` (200 rows, real Spark query) — job ids
  unchanged, so `alv_catalog.job_id` bindings intact. Cleanup: a dry-run flagged today's
  folder without deleting; a real run (retention 30) deleted a seeded `20250101/` folder and
  kept `20260819/`.

## [Unreleased] — result cache reuse (feat/result-cache-reuse)

> **App-only change** (no library `VERSION` bump). Task **7.3**. Built to the approved
> defaults in `docs/RESULT_CACHE_REUSE_APPROACH.md`. **No schema / migration / grant change** —
> `request_log` already carries every column read and the App SP already `SELECT`s it. Not
> yet deployed / merged.

### Added — pre-submit result-cache lookup + reuse popup

- **`POST /api/reports/{alv_id}/cache-check`** (`alv_app/main.py`) — given the same form
  values a submit would send, computes the `param_hash` **server-side** (via the submit
  builders — the single source of truth for the hash) and looks for an identical, still-valid
  prior run to offer for reuse. Returns `{alv_id, param_hash, hit|null}`. Applies the SAME
  `report_permissions` gate as submit (**404** on deny, *before* any warehouse read), so it
  never discloses runs for a report the caller may not see.
- **`alv_app/cache_source.py`** (new) — the reuse-candidate read over the same warehouse
  statement-exec seam / App SP as `downloads.py`. `build_cache_lookup_sql` is pure + bound
  (directly testable; `alv_id` / `param_hash` are `:markers`, never interpolated).
  **Hit definition:** `status='COMPLETED'` AND `output_path IS NOT NULL` AND
  `expires_at > current_timestamp()` (strict — a just-expired row is not a hit). Not cached
  (reuse must reflect the live table).
- **Latest wins (the added edge case).** When several runs qualify, the lookup orders
  `generated_at DESC, submitted_at DESC, request_no DESC` and takes `LIMIT 1`, so a user is
  always offered the **newest** cached output, never an older one.
- **Reuse is Option A — point to the existing run.** No new `request_log` row is created;
  "Reuse output" downloads the existing run's file via the same App-proxied
  `GET /api/requests/{request_no}/download`. Cross-user reuse is intended (a candidate may be
  another permitted user's run — `submitted_by` shown, not masked, per
  `SECURITY_AND_PERMISSIONS.md` §8). The raw `output_path` is **never** returned — only
  `has_output`.
- **Optional / never blocking.** A warehouse failure in the lookup degrades to `hit=null`
  (200), so a cache-read problem falls through to a normal (re)run rather than blocking the
  submission.
- **Models** — `CacheHitOut` / `CacheCheckOut` (`models.py`).
- **Frontend** — `useCacheCheck` runs on Submit *before* triggering the run; a hit opens a new
  `ReuseRunModal` (Reuse output / Run the job again / Cancel). No hit — or a failed check —
  submits normally, so the flow is backward-compatible. New `CacheHit` / `CacheCheck` types.

### Tests

- **+12 backend** (`tests/test_cache_check.py`): SQL-builder binding + hit-definition +
  latest-wins ordering, `find_cached_run` mapping / row_count coercion, and the endpoint
  matrix (hit, no-hit, degrade-to-no-hit on warehouse failure, `param_hash` == submit's,
  unknown report 404, permission-denied 404 with the gate proven to run before the lookup).
- **+4 vitest** (`ReuseRun.test.tsx`): reuse offered → Run again submits; Reuse output
  downloads and does not submit; no-hit submits directly; a failed check degrades to submit.
- **307 backend + 1 skipped**, **19 vitest**, `tsc -b` + `vite build` clean.

## [Unreleased] — output-file preview (feat/output-file-preview)

> **Deployed 2026-08-18** to `fevm-classic-stable-lakebase` (profile `fevm-lakebase`);
> not yet merged — awaiting live validation. App-layer only; library `VERSION`
> unchanged. Design + decisions: `docs/OUTPUT_FILE_PREVIEW_APPROACH.md`.

### Added — view a completed run's output file on-screen (Downloads page)

- **A new "Preview" action on each Downloads row**, between **Parameters** and
  **Download**, enabled on the SAME gate as Download (run `COMPLETED` with a captured
  `output_path`). It opens a **routed screen** (`/downloads/:requestNo/preview`) showing
  the first rows of the file the run produced on the UC Volume. This is the **read-only,
  on-screen twin of Download** — it runs **NO SQL**, unlike the report form's "Preview
  Sample Data" (`alv_app/preview.py`), which queries a sample table.
- **Backend `GET /api/requests/{request_no}/output-preview`** — mirrors the download
  endpoint: the SAME `_require_request_permission` gate (**404** on deny), the SAME
  guards (`409` no output / `422` non-`/Volumes/` path / `502` read failure). It reads a
  **bounded byte prefix** off the Volume (never the whole file), parses it, and returns a
  **capped, parsed** payload — the raw file bytes never reach the browser.
- **`alv_app/output_preview.py`** (new, Spark-free, pure) — `build_output_preview(bytes,
  byte_truncated, filename, max_rows)`. **CSV-first** (the first non-blank line's comma
  decides): a header row → `columns`, data rows capped at the row cap; **raw-text
  fallback** for non-CSV text (first-N-lines block); a **binary guard** (NUL byte / >30%
  non-text ⇒ `format="binary"`, no body). A byte-level truncation drops the partial last
  line/row so no corrupt row is shown. `truncated` reports either cap biting.
- **`alv_app/databricks_client.py`** — `read_volume_prefix(output_path, max_bytes)`:
  reuses the App-SP Files-API seam (`download_volume_file`) but reads only `max_bytes+1`
  and closes immediately, so previewing a 1,000,000-row export never buffers in the App
  tier. Returns `(data, truncated)`.
- **Model `OutputPreviewOut`** — `format` (`csv`|`text`|`binary`), `columns`, `rows`,
  `text`, `row_count`, `truncated`, `filename`. Dedicated shape (PreviewOut fields plus
  `format`/`text`/`filename`) so the screen renders table / text / notice from one field.
- **Config** — `output_preview_max_rows` (**1000**) and `output_preview_max_bytes`
  (**8 MiB**); commented `OUTPUT_PREVIEW_*` entries in `app.yaml` (code defaults are the
  intended values).
- **Frontend** — `useOutputPreview` hook; `OutputPreviewPage.tsx` (breadcrumb
  `Home › Downloads › Preview`, client-paginated CSV table reusing the existing
  `preview-*` styling, a raw-text `<pre>` block, a binary notice, and a "Download full
  file" link + a truncation note); the `PreviewAction` control on the Downloads row;
  `outputPreviewPath()` + route in `App.tsx`; `.preview-text-block` CSS.

### Security

- Same posture as the download path, **stricter**: identical permission gate (404 on
  deny, checked before any byte is read), App-SP-only Volume read, `/Volumes/`-only
  path guard, and now a **bounded read** (byte + row caps) so a huge file cannot exhaust
  App memory. Only parsed, capped rows leave the server — never the raw bytes or the
  storage path. **No new grants** (App SP already holds `READ VOLUME` on `alv_outputs`).

### Tests

- **14 backend** (`tests/test_output_preview.py`): the pure parser (CSV, row-cap
  truncation, quoted-comma field, byte-truncation partial-row drop, text fallback + its
  cap, binary guard, empty file) and the endpoint (happy path + 404/409/422/502 guards).
  **321 backend pass, 1 skipped.**
- **5 vitest** (`OutputPreview.test.tsx`): the screen renders CSV / text / binary; the
  Downloads "Preview" control links to the screen when COMPLETED-with-output and is
  disabled otherwise. **24 vitest pass**; `tsc -b` + `vite build` clean.

## [Unreleased] — repository reorganization (feat/repo-reorg)

> **Structural only — no code behavior change, no library `VERSION` bump.** Branched
> from `main` (which already carries templates). App re-deployed to the **new workspace
> source path** `alv-frontend-src` for UI validation; not yet merged.

### Changed — folder layout

- **The metadata library + driver notebooks moved to `alv-backend/`** (was `src/`). Import
  package stays `dbx_alv_reports`.
- **The Databricks App moved to `src/alv-frontend/`** (was `app/`) — its FastAPI backend
  (`src/alv-frontend/backend/`, the Apps deploy source root) and React frontend
  (`src/alv-frontend/frontend/`) travel together. Vite still emits into `backend/static`
  (relative `outDir`, unchanged).
- **`report_specs/`, `env_parameters/`, and the library `tests/` moved under `src/`**
  (`src/report_specs/`, `src/env_parameters/`, `src/tests/`).

### Changed — path-dependent config (the reason this is more than a `mv`)

- **`databricks.yml`** — `sync.include` now lists `alv-backend/**`, `src/report_specs/**`,
  `src/env_parameters/**`; `framework_source_path` default is
  `${workspace.file_path}/alv-backend`. The `resources/*.job.yml` `notebook_path`s reference
  that variable, so they self-corrected.
- **Root `pyproject.toml`** — `package-dir`, `packages.find.where`, the `VERSION` file path
  and `pytest` `pythonpath` all point at `alv-backend`; `norecursedirs` excludes
  `alv-frontend` (was `app`).
- **5 driver notebooks** — the `sys.path` bootstrap changed `${bundle_source_path}/src` →
  `${bundle_source_path}/alv-backend`.
- **3 seed job YAMLs** — `manifest_path` default `…/report_specs/…` → `…/src/report_specs/…`.
- **Tests** — `src/alv-frontend/backend/tests/test_preview.py` now resolves the library at
  `<repo-root>/alv-backend` and the manifest at `<repo-root>/src/report_specs` (they no
  longer share one `repo_root`). The two `conftest.py` path derivations still resolve
  correctly by construction (specs moved under `src/` alongside the tests).

### Deploy

- **App workspace source path cut over** `alv-bricks-src` → `alv-frontend-src`
  (`--source-code-path`); the old path is removed after cutover. App URL and service
  principal are unchanged.

### Verified

- Library unit **80 pass**; App backend **279 pass, 1 skipped** (the jsonschema contract
  test, skipped without `jsonschema` in the App venv — unchanged); **12 vitest**; frontend
  `tsc -b` + `vite build` clean; `databricks bundle validate -t dev` **OK**.

## [Unreleased] — parameter templates / variants (feat/report-templates)

> **Deployed 2026-08-08** to `fevm-classic-stable-lakebase` (profile `fevm-lakebase`).
> The `report_templates` table was created by re-running `provision_alv_metadata`
> (it is in `PILOT_TABLES`); **no migration** — it is a brand-new table. Not yet merged
> to `main` — awaiting validation on the live app. This section covers BOTH the base
> (static) templates and the **dynamic (relative-date) templates** built on top of them.

### Fixed / Changed — Templates screen is report-wide (+ breadcrumb link)

- **The Templates screen now lists every template for the whole report** (all selections /
  report types under its `report_key`), not just the one report type you opened it from —
  superseding the earlier per-`alv_id` scoping. Each row shows its **Selection** and
  **Report** and **Load** navigates to that row's own report type (fills its form). Backend
  `list_templates_for_report` binds the report's `alv_id`s as one JSON array (same
  parameter-cap-safe technique as the Downloads list); `TemplateSummaryOut` gains `alv_id`
  + `selection_label` / `report_type_label` (resolved from the metadata cache);
  rename/delete target the row's own `alv_id`.
- **Fixed: the "Retail Ledger" breadcrumb on the Templates screen didn't navigate.** It
  linked to `` `#${path}` `` — but under HashRouter a react-router `<Link to>` takes a
  plain path, so the `#`-prefixed value never matched and only "Home" worked. Now links to
  the plain report path. A regression vitest clicks the crumb and asserts the resulting hash.

### Added — dynamic templates (relative date presets)

- **A template's date fields can be DYNAMIC** — instead of a literal date, a field stores a
  named relative-date **preset** that resolves against "now" when the template is loaded, so
  e.g. a "first day of previous month" field always fills the right date. Reuses the
  reserved **`value_kinds_json`** column on `report_templates` — **no migration, no new
  table**.
- **8 presets** (`alv_app/dynamic_values.py`, a closed set; unknown ⇒ rejected):
  `TODAY`, `CUR_DATE_PLUS_N_DAYS` (± n days), first/last day of current/next/previous
  month. Plus a UI **"from month start to today"** one-click range shortcut (sets a
  `date_range`'s two sides to `FIRST_DAY_CUR_MONTH` / `TODAY`). **No work-day / holiday
  logic** — the two work-day presets from the original wish-list were dropped (they need a
  holiday calendar that is out of scope for the pilot). Dynamic applies to **date fields
  only**; `time_range` stays static.
- **Resolved server-side at load** in the report timezone (`REPORT_TIMEZONE`, default
  **`Asia/Kolkata`**). `GET …/templates/{id}` returns concrete dates (dynamic merged over
  static) plus the raw `value_kinds` map so the UI can badge dynamic fields and re-open the
  editor with the right presets. The resolver is a **pure, injected-clock** helper.
- **Validation moved to SAVE, for BOTH static and dynamic templates** (a change from the
  base feature, which saved un-validated). `POST …/templates` resolves any dynamic presets
  against "now", merges over the static values, and runs the report's field-validation
  vocabulary; a template that would fail **cannot be saved** and returns **422** with a
  `{param: message}` map. A server-side port of the rule checks
  (`alv_app/template_validation.py`) + a backend `messages.py` mirror the frontend
  `validation.ts` / `messages.ts` so the 422 reads identically to a client-side error.
  **Known limitation:** a dynamic template is validated against *today's* resolved dates,
  so it can still resolve to a failure in a later month (surfaced at submit by the existing
  form validation).
- **Frontend** — "Save as template" now opens a **modal** (`SaveTemplateModal.tsx`): a name
  field + a Static | Dynamic toggle per date field, a preset dropdown (± n days reveals a
  number input), the range shortcut, and a live "resolves to today" preview. It
  **validates before saving** (resolving dynamic → today) and refuses on error; the backend
  re-validates. Loaded dynamic fields and the Templates list carry a **"dynamic"** badge.
  New `dynamicPresets.ts` (labels + local preview resolver); `config.py` gains
  `report_timezone`; `app.yaml` sets `REPORT_TIMEZONE`.
- **Tests** — +20 backend (`test_dynamic_values.py`: every preset, ± n days incl. negative,
  Feb / 30-31-day / Jan-Dec rollover edges, the parse contract, and the validation port;
  plus dynamic save→load-resolves, save-fails-validation-422, and mandatory-blank-422 in
  `test_templates.py`) and +1 vitest (dynamic save via the modal posts `value_kinds`).
  **279 backend + 79 library + 11 vitest pass.**

### Added — save a report's parameters as a reusable, owner-private template

### Added — save a report's parameters as a reusable, owner-private template

- **New metadata table `report_templates`** (`metadata_tables.py`, added to
  `PILOT_TABLES`). Grain **(`owner`, `alv_id`, `template_name`)**; PK `template_id`, FK
  `alv_id` → `alv_catalog`. Stores the **RAW `{param_name: value}` form map** (exactly
  what submit/preview receive) — **not** the normalized job payload, so a load refills
  the form faithfully. `owner` is the user's **email, lower-cased** and matched
  case-folded (same identity model as the `report_permissions` user grants). Soft-delete
  via `is_active`. `value_kinds_json` column is **reserved groundwork** for a later
  dynamic-template feature (relative `D-1` / `T-1hour` values) — the pilot writes it NULL
  and treats every value as static.
- **`alv_app/templates.py`** (new) — the owner-scoped bound-SQL App-SP seam (mirrors
  `admin.py`): `list_templates` / `get_template` / `save_template` (MERGE upsert on the
  name) / `rename_template` / `delete_template` (soft). Every query carries
  `owner = :owner`; a foreign / guessed id simply doesn't match, so it reads as "not
  found". Every user value is a bound parameter; `param_values_json` is never
  interpolated.
- **Endpoints** under `/api/reports/{alv_id}/templates` — `GET` (list, no values), `POST`
  (save/overwrite), `GET .../{template_id}` (load with values), `POST .../{id}/rename`,
  `DELETE .../{id}`. Each applies the **report-permission gate first** (`report_permissions`,
  **404** on deny — never 403), **then** the owner gate. An **unidentifiable caller (no
  email) 404s** too, so the template surface never leaks for an anonymous request. Reads
  degrade to an empty list on a warehouse failure (never 500), matching the other paths.
- **Models** — `TemplateSummaryOut` / `TemplatesListOut` / `TemplateDetailOut` /
  `SaveTemplateIn` / `RenameTemplateIn`.
- **Frontend** — a **contextual "Templates" left-nav item** shown only while a report
  type is open (route-derived), opening a **Templates screen**
  (`/report/:reportKey/:alvId/templates`) scoped to that report type: list, **Load** (fills
  the form via the shared `FormDraftProvider` draft, then navigates to the form), **Rename**
  in place, **Delete**. A **"Save as template"** control on the report form (inline name +
  save) — deliberately **not** validation-gated, since a template is a convenience snapshot.
  New hooks (`useTemplates` / `fetchTemplate` / `useSaveTemplate` / `useRenameTemplate` /
  `useDeleteTemplate`) + `apiDelete`; CSS reuses existing design tokens.
- **Removed the "Validate" button** from the report form (per product decision — it added
  no value over the always-on Submit-time validation).

### Tests

- **16 new backend cases** (`tests/test_templates.py`): save→list→load round-trips,
  name-overwrite (upsert) vs new-name insert, rename, delete + soft-delete-then-404,
  **owner isolation** (a second permitted user never sees / loads / deletes the first's
  rows), case-folded email match, `alv_id` scoping, the report-permission + no-email gate
  matrix (404s), and validation (blank / too-long / rename-clash). **+1 library DDL test**.
  **259 backend + 80 library pass.**
- **3 new vitest** (`Templates.test.tsx`): the nav item shows only with a report open,
  save-from-form → load-back fills the field, and the screen lists saved templates.
  **10 vitest pass**; tsc + vite build clean.

### Notes / decisions (2026-08-08)

- **Scope resolves to `alv_id`, listed via the contextual nav item.** Templates are
  keyed to one runnable report type (its field set differs per report type). The
  "Templates" nav item is contextual — it appears once a report is open and lists that
  report type's templates. `(owner, alv_id, template_name)` uniqueness gives "same name
  overwrites within the same report".
- **Raw form values, not the effective payload** — the effective payload
  (normalize / omit-if-blank / default) is lossy for reload. Submit still re-derives it
  from the field defs at run time, unchanged.
- **Dynamic (relative date/time) templates are explicitly future.** The `value_kinds_json`
  column is reserved so the later feature needs no migration; the pilot is static-only.
- **No new grants** — the App SP already holds schema-level `MODIFY`/`SELECT`.

## [Unreleased] — admin console + ad-hoc user permissions (feat/admin-console-user-permissions)

> **Not yet deployed.** Needs a **one-time migration** of the live `report_permissions`
> table before deploy (see below) — `ensure_all()` only CREATEs, never ALTERs.

### Changed — `report_permissions` generalized to principals (group **or** user)

- Table grain went from (`report_key`, `group_name`) to **(`report_key`,
  `principal_type`, `principal_name`)**. `principal_type` is `'group'` or `'user'`;
  `group_name` was renamed to `principal_name`. A `user` grant stores the email
  **lower-cased** and is matched case-folded. Single table, one read, one cache — chosen
  over a second table for runtime efficiency.
- **The gate unions the two** (`entitlements.py`): a report is permitted if a group grant
  matches the user's `/Me` groups **OR** a user grant matches the caller's
  `X-Forwarded-Email`. A report granted by both appears once (set union). **User grants
  work even when OBO is off** — they key on the trustworthy email header, not `/Me` — so a
  groupless user still gets their direct grants. Deny-by-default, fail-closed, and
  404-on-deny are unchanged.
- Seeder + manifest use the explicit `principal_type`/`principal_name` pair; the **legacy
  `group_name` key is still accepted** (treated as a group grant), so an older manifest
  still seeds. The seed job is now a **one-time bootstrap** — after setup the admin console
  owns grants.

### Added — admin console (grant/revoke report access from the UI)

- **`alv_app/admin.py`** (new) — the admin gate + the `report_permissions` write seam.
  `is_admin` decides admin status from the **`ALV_ADMINS`** config (comma-separated emails
  and/or group names; email OR a `/Me` group must match; fails closed). Grants are
  **not** stored in the grant table, so admin rights cannot be self-granted through the
  console they gate. Bound-SQL `upsert_grant` (MERGE, re-activates), `revoke_grant`
  (soft-delete `is_active=false`), and `list_report_grants` (active + inactive) as the App SP.
- **Endpoints** — `GET /api/admin/reports` (all seeded reports, unfiltered, for the
  picker), `GET /api/admin/permissions/{report_key}` (list grants),
  `POST …/grant` (comma-separated principals; `@` ⇒ user, else group; per-token results),
  `POST …/revoke`. Each is admin-gated and returns **404** to a non-admin (existence
  hidden). **Every write clears the permission cache**, so a grant/revoke takes effect
  immediately rather than after the 300s TTL. `/api/me` now returns **`is_admin`** for nav
  gating.
- **Frontend** — an **Admin** left-nav item shown only when `/api/me` reports `is_admin`;
  an admin screen (`AdminPage.tsx`) with a report dropdown, a comma-separated principal
  input (mixed emails + groups), per-token grant feedback, a current-access table with
  per-row revoke, and a collapsed list of previously-revoked grants. Styled from existing
  design tokens.
- **Config** — `ALV_ADMINS` (default empty = no admins). Wired in `app.yaml`
  (bootstrap admin: `idris.chakera@databricks.com`).
- **Tests** — +10 backend user-grant cases + 16 admin cases (gate matrix, grant of a mixed
  list, classify heuristic, revoke roundtrip, immediate cache invalidation, unfiltered
  reports list, and an **end-to-end grant→gate** proof) + 7 library seeder cases;
  **227 backend + 79 library pass**, 7 vitest pass, tsc + vite clean.
- **Docs** — `docs/METADATA_TABLE.md` and `docs/SECURITY_AND_PERMISSIONS.md` updated for
  the principal model, the admin gate, and the runtime write surface;
  `docs/ADMIN_CONSOLE_AND_USER_PERMISSIONS_APPROACH.md` records the finalized decisions.

### Migration (run ONCE against the deployed table, before deploy)

```sql
ALTER TABLE <catalog>.<schema>.report_permissions RENAME COLUMN group_name TO principal_name;
ALTER TABLE <catalog>.<schema>.report_permissions ADD COLUMN principal_type STRING;
UPDATE  <catalog>.<schema>.report_permissions SET principal_type = 'group' WHERE principal_type IS NULL;
```

Preserves the 2 existing group grants. (Composite-PK re-statement is not required — the
table already stores the rows; the App reads by column name.)

## [Unreleased] — report routing (feat/report-group-permissions)

> **Deployed 2026-08-07** to `fevm-classic-stable-lakebase` (profile `fevm-lakebase`) and
> validated on the live app. **`feat/report-group-permissions` merged to `main`** (merge
> `567087e`, `--no-ff`) — this merge also lands the two `[Unreleased]` sections below
> (Downloads filters/search/pagination + report visibility by group).

### Fixed — every report card opened the same report

Clicking the **Retail Ledger** card opened **CC Recharge Data**. Three independent
defects, each sufficient on its own once a second report was seeded:

- **The reportKey argument was dropped.** `App.tsx`'s `openReport` was declared
  `() => navigate("/report")`, discarding the `reportKey` `HomePage` passes it. The prop
  type says `(reportKey: string) => void`, but a **zero-arg function is assignable** to
  it in TypeScript, so there was no compile error — every card navigated to the same
  report-agnostic `/report`.
- **`/report` was then resolved by ARRAY INDEX** — `selections[0].report_types[0]` —
  against a catalogue spanning **every** permitted report. Because the two report specs
  are byte-identical clones apart from `report_key` / `report_label`, all 28 rows tie on
  `(selection_order, report_type_order)`, so the winner fell out of `alv_id`
  **alphabetical** ordering: `cc_recharge__…` sorts before `retail_ledger__…`.
- **The catalogue collapsed two reports into one tree.** `build_catalogue` was
  single-report code: it took `report_key` / `report_label` from `reports[0]`, labelling
  the whole tree "CC Recharge Data", and keyed `selections` by **`selection_id` alone**.
  A `selection_id` is only unique *within* a report ("detail" exists under both), so both
  reports' rows merged into one bucket — 28 rows collapsing to 4 selections with 6 report
  types each, and a selection radio that could silently cross-navigate into the other
  report. `GET /api/reports` had no way to ask for one report.

**Fixed:**

- **Report-scoped URLs.** `openReport` passes the key through and the report view is
  routed as `/report/:reportKey/:alvId?` — the report key **first**, the `alv_id` an
  optional **second** segment. Two segments in a fixed order, so react-router matches on
  *position*; a single shared segment disambiguated by shape was rejected because
  `alv_id`'s `report_key__…` form is a **seeding convention, not a contract**. The legacy
  one-segment `/report/<alv_id>` deep link still works — it resolves its segment by
  asking the backend (as a `report_key`, then as an `alv_id`), never by parsing it — and
  bare `/report` redirects home.
- **Every frontend resolution is scoped to the routed report.** The catalogue is fetched
  scoped, so the auto-pick, the owning-selection derivation (previously a `.find()` over
  the merged tree) and the selection→first-report-type jump all operate on one report's
  rows and cannot cross into another's. An `alv_id` absent from the routed report's
  catalogue replace-navigates to that report's first report type instead of rendering a
  context-less form.
- **`build_catalogue` takes an optional `report_key` filter**, applied **before** grouping
  (no-arg behaviour preserved for back-compat), and keys selections by
  **(`report_key`, `selection_id`)** so two reports' identically-named selections can
  never merge. The emitted `selection_id` stays the bare id — the contract the frontend
  and `GET /api/reports/{alv_id}` share.
- **`CatalogueOut.report_key` / `report_label` are now nullable** and are `null` when the
  tree spans several reports, instead of being taken from an arbitrary row. Breadcrumb and
  title derive from the **resolved report's own row** — the same cached
  `GET /api/reports/{alv_id}` response `ReportForm` renders its heading from — so the two
  can no longer name different reports on one screen (the old fallback chain ended in a
  hardcoded `"Retail Ledger"`, wrong for every report but one).
- **`MetadataCache.active_reports` sorts with an explicit `report_key` tiebreak**, so
  ordering is intentional rather than incidentally alphabetical on `alv_id`.

### Added — `GET /api/reports?report_key=…`

- Optional, server-validated (trimmed, length-capped; blank counts as absent). Scopes the
  nav tree to one report so its `report_key` / `report_label` always identify it.
- **The entitlements gate is unchanged and unweakened.** Scoping narrows *within* what the
  caller may already see — it is applied after `visible_reports`, never instead of it. A
  `report_key` that resolves to nothing visible returns **404**, *identically* for a
  report that does not exist, one the caller may not see, and one whose rows are missing
  because the catalogue could not load. Never 403 (§7 of
  `docs/SECURITY_AND_PERMISSIONS.md`); no auth path changed, so that doc is untouched.
- The **unscoped** call still degrades to an empty `selections` list rather than 404-ing,
  so the app shell always renders.

### Added — tests that would have caught this

- **A two-report backend fixture** (`two_report_catalog_rows` — all 28 rows from **both**
  manifests). `tests/conftest.py` loaded only the retail manifest, which is precisely why
  the bug shipped: with one `report_key` in the cache, index-based resolution and
  `selection_id`-keyed merging both looked correct. The single-report fixture is retained.
- **Backend**: 14 new cases — `?report_key=` returns exactly that report's 14 rows /
  4 selections / 3 `detail` report types; no selection bucket mixes `report_key`s; the
  index-based auto-pick lands in the requested report; two distinct cards with correct
  labels and counts (14 each, not 28 on one); the sort tiebreak; and the deny path
  (unpermitted / unmapped `report_key` ⇒ 404, and a user permitted one report cannot
  reach the other by scoping). 187 → **201 passing**.
- **Vitest set up for `app/frontend`** (`npm test`) with a routing regression suite that
  renders the real `App` over a fake two-report API, clicks a card by its visible label,
  and asserts the resolved `alv_id` belongs to the clicked report — for **both** reports.
  Deliberately black-box: this bug class has recurred across five identity keys, so the
  guard targets the end-to-end invariant rather than any one link. **7 tests**; 5 fail
  against the pre-fix code with the exact reported symptom.

## [Unreleased] — Downloads filters/search/pagination + params view (feat/downloads-filters-params)

### Fixed — the Downloads list filtered AFTER its limit

- `GET /api/requests` ran `ORDER BY submitted_at DESC LIMIT 100` and **then** filtered
  by permitted `report_key` in Python. Two consequences, both now gone: a user could
  receive far fewer than 100 rows with **no way to reach page 2**, and any search would
  only ever have seen the newest 100 rows across all users. The permission filter,
  scope, search and ordering now all run **in SQL, before the limit**.

### Added — server-side filtering, search, sort and pagination

- **`alv_app/downloads.py`** — `fetch_requests_page(settings, RequestQuery)` replaces
  `fetch_recent_requests`. Returns a `RequestPage` (rows + an exact `has_more`, derived
  by fetching `limit + 1` and dropping the extra — no second `COUNT(*)`). Every
  user-supplied value is a **bound parameter**; the `ORDER BY` comes from a fixed
  allowlist (`_SORT_KEYS`) and `limit`/`offset` are bound ints, so nothing
  user-controlled is ever formatted into the statement.
- **New query params** on `GET /api/requests`, all optional and server-validated:
  `scope` (`accessible` default / `mine`), `q` (report-name search), `sort`
  (`submitted_at_desc` default / `submitted_at_asc`), `limit` (default 50, hard max
  200), `offset`. Unknown `scope`/`sort` fall back to the default; the response echoes
  what the server actually applied.
- **Response shape** gains `limit` / `offset` / `has_more` / `scope` / `sort` / `q`
  alongside `requests` (additive — existing fields unchanged).
- **The report filter is an `alv_id` allowlist**, not string surgery on `alv_id` and not
  a label column duplicated into `request_log`. `MetadataCache.listable_alv_ids()`
  resolves the ids that are BOTH permitted and label-matching from the in-memory
  catalogue — the same `alv_id` → `report_key` mapping the per-request gate uses — and
  the query binds them as **one** JSON-array parameter (`array_contains(from_json(...))`),
  keeping a many-report user clear of the statement API's 256-parameter cap. An **empty
  allowlist serves an empty page without running any query**.
- **`scope=mine` matches `submitted_by` robustly.** It is written as
  `email or preferred_username or user_id` by precedence, and that precedence has varied
  over the table's life, so the predicate matches all three, folded lower. No change to
  how new rows are written; **no data migration**.

### Added — run parameters info view

- **`GET /api/requests/{request_no}/params`** — the effective job payload one run was
  dispatched with. A dedicated endpoint rather than a column on every list row: the
  payload is unbounded free text and only ever wanted for one expanded row. Behind the
  **same `_require_request_permission` gate** as status/download (**404** on deny, same
  message shape) — parameters are as sensitive as the file.
- `param_payload_json` is parsed **defensively**: null / empty / non-JSON / non-object
  all degrade to `parse_ok=false` with a reason and an empty map — an old or
  half-written row can never 500 the view.
- The UI labels it **"Parameters sent to the job"** (with a note that it is normalized
  and omits blank optional params) — it is the payload the Job received, never presented
  as a transcript of what the user typed.

### Added — `expires_at` is now populated

- `expires_at = generated_at + RESULT_TTL_DAYS` (default **7**, configurable via
  `Settings.result_ttl_days`) is written on the **same UPDATE** that captures
  `generated_at`, derived in SQL (`timestampadd`) from the same bound timestamp — so a
  COMPLETED run can never end up with an output and no retention horizon. Existing rows
  are **not** backfilled. Groundwork for the later result-cache feature; **no cache
  lookup or reuse is implemented**.

### Added — Downloads page UI

- Scope toggle (**"Accessible by me"** default / "Owned by me"), a debounced
  report-name search, a sort selector, pagination controls, and a per-row expandable
  parameters panel. All wired to the new server-side query params — **nothing is
  filtered client-side**. Existing columns (including `submitted_by`) are unchanged.

### Fixed — stale `request_log.submitted_by` DDL comment

- Said "User AAD object ID", which contradicted the code. Now records the real
  precedence (email → preferred_username → user id) and that historical rows may mix
  forms. Comment + `docs/METADATA_TABLE.md` only — no schema change.

### New settings (all optional, code defaults are the intended values)

| Env var | Default | Notes |
|---|---|---|
| `RESULT_TTL_DAYS` | `7` | `expires_at = generated_at + this`. |
| `DOWNLOADS_PAGE_SIZE` | `50` | Default page size. |
| `DOWNLOADS_MAX_PAGE_SIZE` | `200` | Hard cap a client `?limit=` is clamped to. |

> Cross-user visibility **and** cross-user download remain intended and unchanged: no
> owner-only restriction was added to the download or status paths, and `submitted_by`
> is not masked. The `report_permissions` group gate remains the only authorization
> control on those paths.

## [Unreleased] — report visibility by group (feat/report-group-permissions)

> **Breaking for operators:** report visibility now defaults to **CLOSED**. After
> deploying this, the App shows **no reports** until `report_permissions` is created
> (`provision_alv_metadata`) and seeded (`seed_alv_report_permissions`). See
> `docs/APP_PREREQUISITES.md` §6.

### Added — security reference doc

- **`docs/SECURITY_AND_PERMISSIONS.md`** (new) — the standing reference for security
  reviews. Records the **two-identity model** (the end user's **OBO token for
  authorization**, the **App SP for all data access** — "selective OBO"), the
  `report_permissions` gate, **13 safeguards**, the **rejected alternatives with the
  live evidence** (`is_account_group_member` / `is_member` evaluate the *session* user
  and read different group types; SCIM Groups/Users need workspace admin and silently
  strip `members` for a non-admin SP), preview query safety (bound parameters,
  identifier allowlist, no `SELECT *`, caps), known limitations, and how to verify the
  deny path. Also carries the **open** output-ownership item (§8). Linked from `README.md`
  and `CLAUDE.md`.

### Validated (2026-08-04)

- The gate was validated **two independent ways** on the deployed app: (a) setting
  `is_active = false` on a mapping, and (b) **removing the user from the group itself**.
  Both correctly hid the reports. (b) is the stronger proof — it confirms the gate reads
  the **end user's** groups through OBO, since an SP-identity check would not react to
  removing that user from a group.

### Added — report visibility by group

- **New metadata table `report_permissions`** (`metadata_tables.py`) — grain: one row
  per (`report_key`, `group_name`); columns `report_key` / `group_name` (composite PK) /
  `is_active` / `granted_at` / `granted_by`. Added to `PILOT_TABLES`, so
  `MetadataTables.ensure_all()` creates it. Contract documented in
  `docs/METADATA_TABLE.md`.
- **`PermissionSeeder`** (`seed/permission_seeder.py`) — validates a permissions manifest
  (collect-all errors, fail-loud on build) and MERGEs on (`report_key`, `group_name`) so
  re-seeding is idempotent. Re-exported from the package root.
- **`report_specs/report_permissions.json`** — the authoring source. Ships
  `retail_ledger` → `alv-report_ledger_group` and `cc_recharge` → `alv-report_ledger_group`.
- **`src/seed_report_permissions.ipynb` + `resources/seed_report_permissions.job.yml`** —
  the thin driver + DAB job (`seed_alv_report_permissions`).
- **`alv_app/entitlements.py`** (new) — the gate. Reads the **end user's** groups from
  `current_user.me()` with their injected OBO token (the only route that works: a
  non-admin SP has SCIM membership fields silently stripped, and
  `is_account_group_member` evaluates the SP, not the user), intersects them with the
  mapping table read as the **App SP**. OR semantics across groups; a report with no
  active mapping is visible to nobody. Both lookups sit behind a per-key TTL cache
  (`_TtlCache`, not a keyless `lru_cache`) because workspace SCIM is capped at
  255 GET/min. Fails **closed** on every error with a distinct `reason` code
  (`no_user_token` = OBO off / `me_failed` / `no_groups` / `no_mapping`) logged at
  WARNING, so an empty catalogue is always diagnosable.
- **`alv_app/permissions_source.py`** (new) — the `report_permissions` warehouse read,
  same statement-execution seam as `catalog_source.py`. A read failure denies everything
  rather than degrading open, and is **not** cached, so the App recovers on the next request.
- **Enforcement on every report-scoped endpoint** — the three catalogue reads
  (`/api/report-groups`, `/api/reports`, `/api/reports/{alv_id}`) filter through the new
  `MetadataCache.visible_reports()` funnel; **submit, preview, status, download, and the
  downloads list enforce independently** (hiding a card is not a control). A denied report
  returns **404, not 403**, so its existence is never disclosed — and the gate runs
  *before* any write, job trigger, query, or file read.
- **`config.py`** — `permissions_user_ttl_seconds` / `permissions_map_ttl_seconds`
  (default 300) and `dev_bypass_permissions` (default **False** = safe). The bypass is
  additionally refused unless `dev_mode` is also on (a deployed `app.yaml` sets
  `DEV_MODE=false`), and logs a loud WARNING whenever it is active.
- **Frontend** — `HomePage` shows a minimal "No reports available to you" empty state
  when a user has zero permitted reports (reuses the existing `.empty-state` styling; no
  new CSS). Static bundle rebuilt.
- **48 new backend tests** (`tests/test_permissions.py`) covering the allow/deny matrix,
  the closed default, OR semantics, fail-closed paths, TTL hit/expiry, per-user cache
  keying, the dev bypass, all three catalogue endpoints, submit/preview/status/download
  404s, and that the OBO token never reaches a log record or a response body.
  **19 new library tests** (`tests/unit/test_permission_seeder.py` + `report_permissions`
  DDL assertions).

### Changed — report visibility

- **`identity.py`** — `X-Forwarded-Access-Token` is now **retained** on
  `UserIdentity.user_token` (previously its presence was tested and the value discarded).
  It is a secret: `repr=False` on the field so a dataclass repr cannot leak it, and it is
  absent from every response model. A blank/whitespace header counts as absent.
  `has_user_token` behaviour is unchanged.
- **`downloads.py`** — `fetch_request` now also selects `alv_id`, so the status/download
  endpoints can resolve the row's `report_key` and enforce visibility on it.
- **`GET /api/requests`** — rows are filtered to reports the caller may see. A row whose
  `alv_id` no longer resolves in the catalogue is now **omitted** (it cannot be attributed
  to a report, so it fails closed) where it was previously listed with a null label.
- **`MetadataCache.report_groups()`** now takes `(settings, ident)` and filters; the
  startup cache itself remains SP-loaded and **user-independent** — all per-user filtering
  happens at request time.

### Notes / decisions — report visibility

- **D19 (`auth_map`) is superseded for report visibility.** Its grain was *data-row*
  filtering by business dimension, not "which reports may this user open". The DDL and its
  tests are retained untouched; nothing reads it.
- **Grain is whole-report** (`report_key`), not per report type: the card and every
  selection / report type under it move together.
- **`user_api_scopes` were deliberately NOT touched.** The deployed app already has
  effective `['iam.access-control:read', 'iam.current-user:read']` and a live
  `has_user_token: true`; a PATCH can silently purge them. The `sql` scope is not needed.
- **Limitation: flat groups only.** `/Me` returns direct memberships, so a user in a group
  merely *nested inside* a mapped group will not see the report.

## [Unreleased] — sample data preview + housekeeping

### Added — sample data preview (feat/sample-data-preview)

- **Backend `POST /api/reports/{alv_id}/preview`** — runs a parameterized SELECT against
  a dummy `retail_ledger_sample` Delta table as the App SP (no OBO needed; shared data).
  Returns `{columns, rows, row_count, truncated}`. `409` when no `sample_query` is defined;
  `404` unknown report; `502` warehouse failure. Hard cap 500 rows.
- **`alv_app/preview.py`** (new) — `SampleQuerySpec` / `ColumnDef` / `ParamMapping`
  dataclasses; `parse_sample_query`; `build_preview_sql` (server-side WHERE construction:
  `>=`/`<=` for dates, `IN` for comma-separated text fields; user values single-quoted,
  raw SQL never f-string interpolated); `run_preview` (same SDK statement-exec seam as
  catalog reads).
- **`sample_query` block in `input_fields_json`** (optional, report-level) — new contract
  field on `retail_ledger__detail__agent_item`. Carries `columns` (display_name +
  column_name), `param_mappings` (param_name → column + operator), `default_limit`.
  Absent on all other 13 rows → button greyed.
- **Cache** (`cache.py`) — `CachedReport.sample_query` + `has_sample_query` property;
  parsed at cache load (bad block skipped + logged, never crashes startup).
- **Models** (`models.py`) — `PreviewIn` / `PreviewOut`; `has_sample_query: bool` on
  `ReportFormOut` (defaults `False` for backward compat).
- **Frontend** — `usePreviewReport` hook; **"Preview Sample Data"** button in the form
  actions (gated: `has_sample_query` + same mandatory-field validation as Submit);
  paginated results table (rows-per-page selector: 10/25/50/100; prev/next); CSS tokens
  in `index.css`.
- **`src/seed_sample_data.ipynb`** — DAB driver notebook; creates + seeds
  `retail_ledger_sample` (300 deterministic synthetic telco rows: 5 agents, 6 item
  types, 4 circles, 2025-01-01 to 2025-06-30).
- **`resources/seed_sample_data.job.yml`** — DAB job resource for the seeder.
- **82 backend pytest pass** (9 new preview tests).

### Changed — preview security hardening (2026-08-03)

- **True parameterized (bound) queries.** `build_preview_sql` / `run_preview` no longer
  interpolate user values into the SQL string. The WHERE clause now emits `:pN` bind
  markers and passes values as `StatementParameterListItem` to `execute_statement`
  (dates typed `DATE`, text `STRING`). Replaces the old single-quote-stripping
  (`_safe_val`). An injection payload (e.g. `AG001'); DROP TABLE x;--`) rides only as a
  bound parameter and never reaches the SQL text.
- **Identifier allowlist + explicit projection.** Every `column_name` (in `columns` and
  `param_mappings`) is validated against `^[A-Za-z_][A-Za-z0-9_]*$` and every `operator`
  against the enum at `parse_sample_query` time (`SpecError` on violation). The SELECT
  lists the configured columns explicitly (backtick-quoted) — never `SELECT *`. `IN`
  lists are capped (200 elements). The table stays hardcoded/backtick-quoted from
  `settings.catalog`/`schema`.
- **Endpoint hygiene + audit log.** Unknown keys in the incoming values dict are ignored
  (only spec `param_name`s bind). Each preview dispatch emits an INFO audit line
  (`alv_id`, submitter identity, bound-param count, row_count) — raw user values are not
  logged.
- **JSON Schema fix (blocking).** `input_fields.schema.json` gained a typed, optional
  `sample_query` object (with `additionalProperties:false` sub-objects and an
  `identifier` regex). Before this, the top-level `additionalProperties:false` made
  `ReportSeeder.seed()` reject the `agent_item` row when `jsonschema` was installed (the
  seed job's declared dep) — the authoring/seed path rejected the very spec that enables
  the feature. **Library unit tests now 33 pass** (fixes the 6 schema failures).
- **Preview tests hardened** — parameterized-output assertions, an injection-via-bound-param
  test, `parse_sample_query` negatives, a schema-accepts-spec contract test over the full
  14-row manifest, truncation-at-cap, and an App-SP-not-OBO binding test. **97 backend
  pytest pass** (+15).

### Added — agent_item sample-data download job (coherent preview → download)

- **New download Job `alv_sample_report_run`** (job_id `307243391542499`) bound to
  **only** `retail_ledger__detail__agent_item`; the other 13 rows stay on the generic
  dummy job. It reads the **same `sample_query` block** from `alv_catalog`, builds the
  **same parameterized WHERE clause** as preview (bound args, `>=`/`<=`/`IN`, blank-skip),
  queries the same `retail_ledger_sample` table, writes a CSV to the `alv_outputs` UC
  Volume, and returns the pointer via `dbutils.notebook.exit` in the exact CONTRACT shape
  (`output_path` `/Volumes/…`, `row_count`, `generated_at`) the 8.x status seam parses.
  So **what the user previews equals what he downloads.** The download returns the full
  filtered result (safety ceiling 1,000,000 rows), not the preview's 500-row cap.
- **`src/alv_sample_report_run.ipynb`** (new) — thin six-step DAB driver that calls one
  helper. **`resources/alv_sample_report_run.job.yml`** (new) — serverless job resource
  (`environment_version: 4`).
- **`src/dbx_alv_reports/sample_query/`** (new) — a Spark-free pure helper
  (`parse_sample_query`, `build_sample_report_sql`, `build_exit_pointer`,
  `SampleQuerySpec`, `BoundArgs`) mirroring the preview builder's semantics/security;
  re-exported from the package `__init__`. Unit-tested (14 new tests) for date-range/IN/
  blank-skip, bound-not-interpolated output, injection-as-bound-param, and the exit-pointer
  shape.
- **No `submit.py` change needed** — the App already sends `alv_id` and `request_no` as
  job parameters, and the dummy notebook tolerates the same param set, so the 13 other
  rows are unaffected.

### Removed — housekeeping

- **`poc/` deleted** — the job-path-return POC work is fully absorbed into the
  production submit/status/download path; folder removed.

### Notes / decisions (2026-08-03)

- **OBO not used for preview** — the sample query is a shared, non-sensitive dataset;
  App SP auth (`WorkspaceClient()` default chain) is correct. OBO reserved for
  per-user data access (audit-critical paths).
- **`poc/` housekeeping only** — `CHANGELOG.md` and `CLAUDE.md` stay at repo root
  (auto-discovery convention + Keep-a-Changelog convention); other directories
  (`app/`, `env_parameters/`, `report_specs/`, `tests/`) stay at root per CLAUDE.md
  design intent ("specs outside src/ are obviously data, not code").
- **Operator set**: `>=`/`<=` for date range params; `IN` for all text fields
  (user input is comma-separated multi-value). SQL injection defence: single-quotes
  stripped from all user values before embedding.
- **Preview button gate**: same as Submit (all mandatory fields must pass validation).
- **`retail_ledger_sample` table**: 1000 deterministic rows dated **July 2026**; query
  with dates `2026-07-01` to `2026-07-31`, agent `AG001` (or `AG001,AG002`), and
  transaction type `CREDIT`/`DEBIT` to get non-empty results (the seed uses `CREDIT`/
  `DEBIT`, not `RECHARGE`).

### Notes / decisions — security + download job (2026-08-03)

- **Security posture (data-exposing feature):** preview **and** download both use true
  bound parameters (never string interpolation), an identifier allowlist on column names,
  an explicit column projection (no `SELECT *`), and a hardcoded backtick-quoted table.
  Config is trusted, so the allowlist is defense-in-depth; the real protection is that
  every user value is a bound parameter.
- **Auth = App SP, not OBO** — the sample table is shared, non-sensitive data. OBO stays
  reserved for per-user data-access paths.
- **`agent_item` alone gets the telco download job** so the demo is coherent; the other 13
  rows keep the generic dummy job. Bindings after deploy: 13 → dummy `1044615550343710`,
  1 (`agent_item`) → `307243391542499`.
- **Re-seed caveat:** `seed_alv_reports` MERGEs the manifest whose `job_id`s are
  placeholder NULLs, so **running the seed job resets all `job_id` bindings to NULL**.
  After any re-seed, re-apply the `job_id` bindings (dummy for the 13, the sample job for
  `agent_item`) and restart the App so `cache.py` reloads them.

---

## [Unreleased] — App Phase 2 (home cards + submit + downloads + UI polish) + first workspace deploy

_App-layer work; the library `VERSION` is unchanged (still `0.1.1`). Bump `VERSION`
and cut a versioned section when the App path stabilises._

### Added — home report cards

- **Backend `GET /api/report-groups`** — distinct seeded reports
  `(report_key, report_label, runnable_count)` served from the startup metadata
  cache (no SQL on render). `runnable_count` = active rows with a bound `job_id`.
  New `ReportGroupsOut` model; `cache.report_groups()` + `catalogue.build_report_groups()`.
- **Frontend home card grid** — data-driven active **Retail Ledger** card (from
  report-groups) opens the existing catalogue UI one level down. Greyed,
  non-clickable **"coming soon"** placeholders (frontend-static): BNP ABAP ALV -
  Spark Configuration Parameters, CI Recharge Data, Estel Recharge Data, CC
  Recharge Data, BLAI Wise Statement of Account - RJIL. View routing in `App.tsx`
  (home ↔ report); header brand links home.

### Added — submit path (tasks 7.1 / 7.2 / 7.4 / 7.5)

- **`POST /api/reports/{alv_id}/submit`** — builds the `{param: value}` payload
  (normalize / `omit_if_blank` / `default`) → canonical JSON + **SHA-256
  `param_hash`** → **INSERT `request_log` `QUEUED`** row (warehouse statement-exec
  as the App SP, parameterized) → **`jobs run-now`** on the bound `job_id` (SP
  `WorkspaceClient`) → UPDATE `run_id` → return `request_no`. Clean **409** when
  `job_id` is NULL. New modules `submit.py`, `request_log.py`; `trigger_job_run` in
  `databricks_client.py`; `catalog_source`/`cache` now carry `job_id`/`job_run_mode`.
- **No task 7.3 (result-cache lookup)** this pass — every submit runs the job; the
  `param_hash` is persisted so 7.3 can be layered on later. **No 8.x polling / 9.x
  download** yet.
- **Frontend Submit wired** (was a disabled placeholder) — shows `request_no` +
  `QUEUED`; client-side validation still gates submit.

### Added — dummy backend Job (stand-in for the RIL Job)

- **`resources/alv_dummy_report_run.job.yml`** (serverless, `environment_version: 4`)
  + **`src/alv_dummy_report_run.ipynb`** (six-step driver). **One parameterized job
  for all 14 rows** (catalog / schema / volume / output_dir params — no hardcoded
  volume); writes a dummy CSV to a **UC Volume** and returns its pointer via
  `dbutils.notebook.exit(json.dumps(pointer))` per `poc/job_path_return/CONTRACT.md`.
- **UC Volume `alv_outputs`** (`classic_stable_lakebase_catalog.alv_metadata.alv_outputs`)
  as the output target.

### Added — operator prerequisites

- **`docs/APP_PREREQUISITES.md`** — the definitive App-SP grant checklist for the
  end-to-end path, with exact CLI/SQL and the `UPDATE alv_catalog … job_id` bind.

### Added — Downloads page

- **Backend `GET /api/requests`** — most-recent `request_log` rows
  (`request_no`, `alv_id`, `status`, `submitted_by`, `submitted_at`, `run_id`,
  `output_path`), ordered `submitted_at` DESC, capped at 100, read via the same
  warehouse statement-exec seam as the read/write paths (`downloads.py`,
  `DownloadsSourceError` → graceful empty list, never a 500). New `RequestRow` /
  `RequestsOut` models; `report_label` resolved from the metadata cache.
- **Frontend Downloads page** — flat table (Request No, Report, Status, Submitted
  By, Submitted At + a **disabled "Download" stub**) reachable from the header nav.
  The real UC-Volume proxy download is a later task (9.x); the button stays disabled.

### Added — persistent top navigation

- **Header rendered once at the app-shell level** (outside the per-view switch) so
  its nav is present on **every** view and **back-navigation works from any view**.
  Nav links moved to the **right**, positioned just **before** "Welcome, {user}",
  with **active-view highlighting** (`aria-current`). The brand doubles as a
  back-to-home link. View routing (`home ↔ report ↔ downloads`) stays in `App.tsx`;
  no router library.

### Changed — header text

- **Removed the "Databricks SSO · SP ✓" header text.** Identity still resolves from
  the Databricks Apps `X-Forwarded-*` headers; only the redundant badge line is gone.

### Added — UI polish (design system)

- **Design tokens** in `index.css` — a single `:root` set of CSS custom properties
  for color, type scale, spacing, radius, and shadow; components inherit from them
  with no per-component values. **Databricks lava (`#FF3621`)** is the accent, used
  sparingly.
- Polished **header, report cards, form, and downloads table**; **QUEUED** status
  badges; **loading skeletons/spinners** and **empty states** across the views.

### Added — dark mode

- **Sun/moon theme toggle** (top-right in the header). The dark theme re-declares
  **only** the color tokens under `[data-theme="dark"]`, so the whole UI (text,
  surfaces, inputs) inverts with no per-component overrides. The choice is
  **persisted in `localStorage`**; an inline script in `index.html` applies the
  stored/preferred theme **before first paint** to avoid a flash-of-wrong-theme
  (respects OS `prefers-color-scheme` on first load). New `theme.ts` (`useTheme`)
  and `ThemeToggle.tsx`.

### Deployed — workspace `fevm-classic-stable-lakebase`

- **App RUNNING** and live-tested end-to-end: submitting a report round-trips a
  `request_no`, the dummy job runs **SUCCESS**, and a CSV lands in the Volume.
- **All 14 `alv_catalog.job_id`** bound to the single dummy job
  **`1044615550343710`** (`job_run_mode = run_now`).
- **App SP grants applied:** `MODIFY` on schema `alv_metadata` (request_log writes),
  `READ VOLUME` / `WRITE VOLUME` on `alv_outputs`, `CAN_MANAGE_RUN` on the dummy job
  (on top of the read-path grants: `USE CATALOG`/`USE SCHEMA`/`SELECT`, warehouse
  `CAN_USE`).

### Notes / decisions

- **Git flow:** `feat/ui-polish-darkmode` was merged into `feat/app-skeleton-and-deploy`,
  which was then merged into `main`. **`main` is now the mainline** — it contains the
  App skeleton, the metadata read path, the submit → `request_log` path, the Downloads
  page, and the UI polish + dark mode. Both feature branches are **retained on origin**.
- **One parameterized job for all 14 rows** (per CLAUDE.md — prefer one "run report"
  job the App triggers with different rows over one job per report).
- **`submitted_by` currently logs the numeric SSO subject, not the email** — known
  follow-up (resolve to email/UPN).
- **`message_key` stopgap** — the 6 pilot keys are still hardcoded in the frontend
  (`messages.ts`) with a graceful fallback; the catalogue delivery is pending.
- **`allowed_values` dropdown hook is forward-looking** — the current contract has
  no enumerated-options field (D-IFJ-8), so the pilot has zero dropdowns; the
  `<select>` path is built for when `allowed_values` appears.
- **Status stays `QUEUED`** — there is **no status polling yet** (task 8.x), so the
  Downloads page shows submitted runs as `QUEUED`; the Download action is a disabled
  stub until the output proxy (9.x) lands.
- **Cosmetic:** the dummy notebook logs `run_id = 'interactive'` in one spot — a
  display-only bug, no functional impact (the real `run_id` is captured in `request_log`).
- Verified locally: backend **37 pytest pass** (incl. the Downloads endpoint), frontend
  `npm run build` passes, `backend/static` rebuilt.

### Added — submitted_by email (follow-up 1)

- **`submitted_by` now logs the human identity** — new `_submitted_by(ident)` helper
  prefers `email`, then `preferred_username`, then falls back to the numeric `user_id`.
  Replaces the previous `user_id or email` (id-first) logic. Applies to **new**
  submissions; pre-fix rows kept their numeric id until purged (see below).

### Added — status polling / task 8.x (follow-up 2)

- **`GET /api/requests/{request_no}/status`** — reads the live job run state via the SDK
  (`get_run_status()`, never raises), maps
  QUEUED/RUNNING/SUCCESS/FAILED/CANCELLED, and **persists** the resolved status back to
  `request_log` (`update_status()`). Unreadable/NULL run_id keeps the stored status;
  missing row → 404. New `RequestStatusOut` model.
- **Frontend `useRequestStatus`** polls non-terminal Downloads rows (~5s), stops on a
  terminal state, and reflects it in the existing status badge — so **QUEUED→SUCCESS
  advances in the UI without a manual refresh**.

### Added — selection-in-main + left-nav app navigation

- **Selection moved into the main page** — the report view now stacks **Selection** then
  **Reports** then the form in the main area (matching the reference screenshot), instead
  of the selection living in the left navbar. Fields update as the selection changes.
- **Auto-select** the first selection **and** its first report type on load / selection
  switch, so the form renders immediately (no "choose a report" placeholder).
- **Left navbar repurposed for app nav** — hosts **Home** + **Downloads** (moved off the
  top bar), now **collapsible** to an icon-only rail and **drag-resizable**; collapsed
  state + width persisted to `localStorage`.
- Landing-page pilot notice text removed.

### Added — routing, breadcrumb, nav polish

- **Client-side routing** via `react-router-dom` **HashRouter** (`/`, `/downloads`,
  `/report/:alvId`) so **browser Back/Forward walk the in-app view history**. HashRouter
  chosen so deep links + reloads work with **no backend change** (FastAPI serves the SPA).
- **Preserved unsubmitted form state** — a session `FormDraftProvider` (keyed by `alv_id`)
  keeps the user's selection + typed field values across navigation/unmount; the TanStack
  Query cache prevents refetch flash on return.
- **Breadcrumb header** — `Home › <report>` with **Home** clickable; the report name is a
  plain trailing label (fixes the unintuitive "clicking the title goes home").
- **Collapse toggle centered** in the narrow rail; **default nav width reduced 240 → 160px**
  (still resizable).

### Changed — deploy / data hygiene

- **Redeployed `main`** so the submitted_by-email fix + status polling + all UI work are
  live together — a prior UI-branch deploy (cut before the follow-ups) had **reverted** the
  email fix on the live app; re-deploying `main` restored it.
- **`request_log` purged of test rows** — deleted the 6 rows whose `submitted_by` was the
  numeric SSO subject (pre-fix test submits); kept the 2 real-email rows.

### Added — output download / task 9.x (App-proxied UC Volume)

- **`GET /api/requests/{request_no}/download`** — streams the run's output file from a
  **Unity Catalog Volume** to the browser as an attachment, read by the **App service
  principal** via the SDK Files API (`w.files.download`, 1 MB chunks). Content-Disposition
  carries the basename only (raw storage path never exposed). Guards: `409` no output yet,
  `422` non-Volume path (per §4.2 — only `/Volumes/...` is proxied), `502` read failure,
  `404` missing row. Covers tasks **9.1 / 9.2 / 9.3**.
- **Output-pointer capture folded into the 8.x status seam** (tasks **8.1 / 8.2 / 8.3**):
  when the status poll resolves a run to `SUCCESS`, the App resolves
  `tasks[0].run_id` → `get_run_output` → parses `notebook_output.result` JSON per
  CONTRACT mechanism (a), **persists** `output_path` / `row_count` / `generated_at` to
  `request_log`, and settles the row to **`COMPLETED`**. `SUCCESS` now normalizes to
  `COMPLETED` at the endpoint boundary. Truncated / missing / `FAILED` payload →
  status `FAILED`, `output_path` left NULL, never crashes. `RequestStatusOut` now carries
  `output_path`.
- **Frontend** — the Downloads Download button is now a real `<a download>`, enabled only
  when a row is `COMPLETED` with a captured `output_path`; disabled "no output yet"
  otherwise. Table / polling / breadcrumb / dark mode preserved.
- **Grants** — app SP already held `READ_VOLUME` on `alv_outputs`; no new grants.
- **73 pytest pass** (new `test_download.py`, updated `test_status.py`).

### Notes / decisions (later 2026-07-30)

- **Git flow (later):** `feat/followups-1-2` and `feat/ui-selection-in-main` merged into
  `main`; `feat/ui-routing-nav-polish` and `feat/download-functionality` merged into
  `main` (routing branch deleted). `main` is the mainline through all of the above.
- **Deployed + live-tested** — task 9.x deployed and verified end-to-end in the browser
  (submit → QUEUED → COMPLETED → CSV download). Pre-existing rows without an
  `output_path` stay download-disabled; only new submits light it up.
- **Cosmetic follow-up still open:** dummy notebook logs `run_id = 'interactive'` in one
  spot (display-only). **7.3 result-cache lookup** still to come; **8.4/8.5** (status-detail
  view, failure repair) and **9.4/9.5** (cross-user reuse, expiry) deferred.
- Gates through the pass: backend **73 pytest pass**; frontend `tsc` + `vite build` clean.

## [0.1.1] - 2026-07-02

### Changed
- **Seeder:** split `build_rows` into `derive_rows` (pure, returns `(rows,
  warnings)`) + a validating `build_rows`. `ReportSeeder.seed()` now validates the
  manifest **once** (was twice) and no longer stashes warnings on a class attribute.
- **Parser:** cache the JSON Schema (`lru_cache`) and compile the `Draft7Validator`
  once instead of per blob.

### Added
- **Parser:** validation rules are now checked for **applicability to their control**
  (e.g. `max_span` only on `date_range`, `regex` only on `text`) — a mismatch fails
  the load (`input_fields_json_design.md` §5).
- **Seeder:** `validate_manifest` now also requires the display/order columns
  (`report_label`, `selection_label`, `selection_order`) so rows can't seed silent
  `NULL`s the App's navigation needs.
- Unit tests for the above.

## [0.1.0] - 2026-07-02

### Added — metadata layer (pilot tasks 2.1–2.6)

- **Package scaffold** `src/dbx_alv_reports/` (setuptools, `src`-layout, dynamic
  version from `VERSION`), with `common/utilities` (logging, err-dict, Unity
  Catalog helpers).
- **JSON Schema** `json_specifications/input_fields.schema.json` — the contract for
  the flat, per-row `input_fields_json` (newer model; supersedes
  `ALV_App_Task_Breakdown.md` §3.2). Plus `catalog_rows.schema.json` for the seed
  manifest.
- **Loader/validator** `InputFieldsParser` (task 2.5): JSON-Schema pass (graceful
  degradation when `jsonschema` is absent) + always-on semantic pass that
  collects all errors and fails the load on an unknown rule (D-IFJ-10).
- **Typed spec** `InputFieldsSpec` / `Field` / `FieldPart` / `ValidationRule`.
- **Metadata-table DDL** (single source of truth) `metadata/metadata_tables.py`
  for `alv_catalog` (2.2) and `request_log` (2.4), with `MetadataTables.ensure_all()`
  (2.1). `auth_map` DDL is present but **deferred** (2.3 / D19) — not created by
  default.
- **Seeder** `ReportSeeder` (task 2.6): validates each `input_fields_json`, derives
  identity columns (`alv_id` slug, display name), and upserts via `MERGE INTO`
  (idempotent). Placeholder `job_id`s are seeded `NULL` (unbound) pending the RIL
  contract.
- **Drivers** `src/provision_metadata.ipynb`, `src/seed_reports.ipynb` (thin,
  six-step pattern).
- **Bundle** `databricks.yml` + `resources/*.job.yml` (dev/prod targets) and
  `env_parameters/{dev,prod}_parameters.yaml`.
- **Docs** `docs/METADATA_TABLE.md`, `docs/CONFIGURATION_GUIDE.md`, `CLAUDE.md`.
- **Unit tests** for the schema, parser, DDL, and seeder (no Spark).

### Notes

- **Deployment is DAB-only (no wheel).** The bundle syncs `src/` + `report_specs/`
  as workspace files; the driver notebooks add `${bundle_source_path}/src` to
  `sys.path` and import `dbx_alv_reports`. Job env specs declare only third-party
  deps (`pyyaml`, `jsonschema`). `pyproject.toml` is retained for local dev/test
  (`pip install -e ".[dev]"`) only.
- Catalog/schema names and `job_id`s are **placeholders** pending confirmation
  (`input_fields_json_design.md` Open items #1, #4). Nothing is deployed to a
  workspace yet — this release is author-only.
