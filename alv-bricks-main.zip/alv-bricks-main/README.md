# ALV-Bricks

> **Status:** early development — high-level overview, will evolve with the project.
> **Pilot report:** Retail Ledger. **Pilot customer:** Reliance Jio (RIL), via PNC / BNP.

Reproduce the SAP **ALV** (ABAP List Viewer) reporting experience on **Databricks
Apps** — same selection-screen-style inputs, validations, and report outputs — with
**no dependency on SAP** at run time. The framework is **metadata-driven**: new reports
are onboarded by **configuration, not code**.

---

## What it is

ALV-Bricks is a generic, metadata-driven reporting App. A single App renders every
report's catalogue entry, input form, and validation purely from metadata in Unity
Catalog — there is **no per-report UI code**. Submitting a form triggers a pre-built
Databricks **Job** that produces the output file; the App tracks the run and serves the
result (with caching for repeat requests).

```
        User
          │  pick report → fill inputs → submit
          ▼
   ┌───────────────────────────────────────────────┐
   │                  ALV-Bricks App                │
   │  • Catalogue (from alv_catalog, cached in-app) │
   │  • Generic input form + validation             │
   │    (driven by input_fields_json)               │
   │  • Submission handler + run tracking + cache    │
   └───────────────┬───────────────────────────────┘
                   │  run-now (job_id, params)
                   ▼
        Databricks Job  ── built by the customer (RIL) ──▶  output file (NAS/ADLS path)
                   │
                   ▼
        App polls run status, persists path/params to request_log, serves the file
```

---

## Scope boundary

| Built by **us** (App + framework) | Built by the **customer (RIL)** |
|---|---|
| Databricks App (UI + thin backend) | The backend Databricks **Job** (per report) |
| Metadata tables + their schema | The notebook / SQL the Job runs |
| Catalogue view | Cluster definition (inside the Job) |
| Metadata-driven input form + validation | Run-as SPN for the Job |
| Submission handler → triggers the Job | Output materialisation + returning its path |

The App never reverse-engineers the SAP ABAP UI — the customer supplies the parameters
and constraints; we model them as metadata (D21, D22).

---

## How it's metadata-driven

Each **runnable report** is one row in `alv_catalog`, binding:

- a **`job_id`** — the customer's pre-built Job to dispatch, and
- an **`input_fields_json`** — the ordered field definitions (labels, controls, data
  types, defaults, and a typed, extensible `validations` vocabulary) that the App
  renders and enforces, client-side **and** server-side, from the same rules.

Onboarding a new report = inserting/extending metadata rows. The App is generic and
unchanged.

### Worked example — Retail Ledger

The SAP Retail Ledger screen has four **selections** (Detail, Sequence Wise, Time Wise,
Agent Closing Balance), and each selection offers several **report types**. Every
*(selection × report type)* combination is backed by its **own Job**, so it is its own
`alv_catalog` row → **14 rows / 14 jobs** for Retail Ledger. Each row carries its **own
complete flat** `input_fields_json` (no shared forms / no inheritance — repetition is
accepted on purpose to keep the model flat).

---

## Metadata tables (pilot scope)

| Table | Grain | Purpose |
|---|---|---|
| `alv_catalog` | 1 row / runnable report | Catalogue display + report→Job binding (`job_id`) + `input_fields_json` |
| `request_log` | 1 row / submission | Run tracking (status, output path) + result cache (key = `alv_id` + `param_hash`) |
| `report_permissions` | 1 row / (`report_key`, `principal_type`, `principal_name`) | **Report visibility by principal (group or user).** Any matching grant ⇒ sees the report; **no mapping ⇒ hidden from everyone** (deny by default) |
| `report_templates` | 1 row / (`owner`, `alv_id`, `template_name`) | **Per-user saved parameter templates (variants).** A named snapshot of a report type's raw form values; a user sees only his own |

**Report visibility** gates the whole report (its card and every selection / report type),
on the read *and* write paths — a report the caller may not see returns **404**, never 403.
The App reads the user's own groups from `/Me` with their injected OBO token and the
mapping table as the App SP; both are TTL-cached. **Direct memberships only** — group
nesting is not resolved. Reports are invisible until `report_permissions` is seeded
(see [`docs/APP_PREREQUISITES.md`](docs/APP_PREREQUISITES.md) §6).

Row-level (data-row) authorisation `auth_map` remains **out of scope for the pilot**
(deferred, D19) and is **superseded for report visibility** by `report_permissions` — its
grain was filtering data rows by business dimension, a different concern.

See [`docs/metadata_tables_example.md`](docs/metadata_tables_example.md) for sample
records, row counts, and relations.

---

## Repository layout

```
alv-bricks/
├── README.md                                  ← you are here
├── CLAUDE.md                                  ← agent/newcomer onboarding + framework guidelines
├── src/                                       ← everything: library, App, specs, params, tests
│   ├── alv-backend/                           ← metadata library + DAB driver notebooks
│   │   ├── dbx_alv_reports/                   ← the library (metadata layer, tasks 2.1–2.6)
│   │   │   ├── metadata/metadata_tables.py    ← single source of truth for table DDL
│   │   │   ├── spec_parser/                   ← input_fields_json loader + validator
│   │   │   ├── data_objects/                  ← typed InputFieldsSpec / Field / ValidationRule
│   │   │   ├── seed/report_seeder.py          ← validate manifest + MERGE into alv_catalog
│   │   │   ├── seed/permission_seeder.py      ← validate manifest + MERGE into report_permissions
│   │   │   ├── common/utilities/              ← logging, error-dict, Unity Catalog helpers
│   │   │   └── json_specifications/           ← input_fields.schema.json (the contract)
│   │   ├── provision_metadata.ipynb           ← driver: create schema + tables
│   │   ├── seed_reports.ipynb                 ← driver: seed the catalog
│   │   └── seed_report_permissions.ipynb      ← driver: seed report visibility by group
│   ├── alv-frontend/                          ← the Databricks App
│   │   ├── backend/                           ← FastAPI (alv_app) — Apps deploy source root
│   │   └── frontend/                          ← React/Vite SPA (builds into backend/static)
│   ├── report_specs/retail_ledger.input_fields.json  ← authoring source (14 rows)
│   ├── report_specs/report_permissions.json   ← authoring source (report → group visibility)
│   ├── env_parameters/                        ← {dev,prod}_parameters.yaml (catalog/schema)
│   └── tests/unit/                            ← no-Spark library unit tests
├── resources/*.job.yml + databricks.yml       ← the DAB
└── docs/
    ├── input_fields_json_design.md            ← the input_fields_json contract (D-IFJ-1…12)
    ├── metadata_tables_example.md             ← metadata tables: sample records, counts, relations
    ├── METADATA_TABLE.md                      ← table contract the App depends on
    ├── CONFIGURATION_GUIDE.md                 ← how to author/validate/seed report metadata
    └── examples/retail_ledger.input_fields.json
```

The App (`src/alv-frontend/backend/` FastAPI + `src/alv-frontend/frontend/` React/Vite) and the
dummy backend Job (`resources/alv_dummy_report_run.job.yml` + `src/alv-backend/alv_dummy_report_run.ipynb`)
now live here too — Phase 2, deployed to `fevm-classic-stable-lakebase`. See `src/alv-frontend/README.md`.

---

## Status — metadata layer (tasks 2.1–2.6)

The metadata framework is **implemented, unit-tested, and deployed** to workspace
`fevm-classic-stable-lakebase` (catalog `classic_stable_lakebase_catalog.alv_metadata`:
`alv_catalog` 14 rows + `request_log`; `provision` + `seed` jobs ran SUCCESS):

| # | Task | Status |
|---|---|---|
| 2.1 | Provision the metadata schema | ✅ `MetadataTables.ensure_all()` |
| 2.2 | `alv_catalog` table (incl. `job_id` binding) | ✅ single-source DDL |
| 2.3 | `auth_map` table | ⏸️ **deferred (D19)** — DDL present, not created by default; superseded for report visibility |
| 2.4 | `request_log` table (run tracking + cache) | ✅ single-source DDL |
| 2.5 | `input_fields_json` schema + loader/validator | ✅ JSON Schema + `InputFieldsParser` |
| 2.6 | Seed the pilot Retail Ledger report | ✅ `ReportSeeder` → 14 rows via `MERGE` |
| — | `report_permissions` table + seeder (report visibility by group) | ✅ single-source DDL + `PermissionSeeder` → `MERGE` |

**Deployment model: DAB-only (no wheel).** The bundle syncs `src/alv-backend/` + `src/report_specs/`
as workspace files; the driver notebooks add `${bundle_source_path}/src/alv-backend` to `sys.path`
and `import dbx_alv_reports`. See `CLAUDE.md` (Bundle, jobs & parameterization).

Design decisions baked in: the **newer flat 14-row model** (one `alv_catalog` row per
`selection × report_type`, each with its own flat `input_fields_json`; `selection`/
`report_type` are catalog columns, not form fields — supersedes
`ALV_App_Task_Breakdown.md` §3.2), `message_key` (not inline text), and `job_id`s
seeded `NULL` until bound. All 14 are now bound to a single parameterized **dummy
Job** (stand-in for the RIL Job) for end-to-end testing; the real RIL `job_id`s
replace it later.

**Local dev / tests** (never a wheel — `pyproject.toml` is dev-only):
```bash
cd alv-bricks && pip install -e ".[dev]" && pytest -m unit
```

**Deploy (once placeholders are filled):** set `workspace.host` / SPN / real
`catalog`/`schema`, then `databricks bundle deploy -t dev` and run the
`provision_alv_metadata` then `seed_alv_reports` jobs.

---

## Project phases (high level)

1. **Phase 1 — Metadata framework & design.** Define how reports, inputs, validations,
   and run tracking are stored; model the Retail Ledger pilot. **Metadata layer done
   (2.1–2.6, above);** design docs in `docs/`.
2. **Phase 2 — The App.** Build the generic catalogue, input form, validation,
   submission handler, run tracking, and result caching against the metadata.
   **In progress + deployed:** home report cards, catalogue + metadata-driven form
   (read path), the submit path (persist `request_log` → trigger the Job → return
   `request_no`), and a **Downloads page** listing recent runs are live on workspace
   `fevm-classic-stable-lakebase` and tested end-to-end against the dummy backend Job.
   The UI has had a full **polish pass** (design tokens, Databricks-lava accent,
   persistent right-aligned header nav with active-view highlighting) and a
   **light/dark theme toggle**. Status polling (8.x) and output download/proxy (9.x) are
   done; **result-cache reuse (7.3)** is done on `feat/result-cache-reuse` (a pre-submit
   cache-check offers reuse of an identical prior run's output vs a fresh run).

---

## Key references

- **Onboarding + patterns:** `CLAUDE.md` (agents/newcomers + framework guidelines).
- **Author/validate/seed reports:** `docs/CONFIGURATION_GUIDE.md`.
- **Table contract the App depends on:** `docs/METADATA_TABLE.md`.
- **Security, auth model & permission safeguards:** `docs/SECURITY_AND_PERMISSIONS.md`
  (the reference for security discussions — selective OBO, deny-by-default report
  visibility, rejected alternatives, and known limitations).
- **Field-level contract & decisions:** `docs/input_fields_json_design.md` (D-IFJ-1…12).
- **Tables worked example:** `docs/metadata_tables_example.md`.
- **Source of truth:** *ALV on Databricks Apps — Pilot Approach Note v1.3*;
  `ALV_App_Task_Breakdown.md` (decision log D1–D22).

> This README is high-level and evolves as the App takes shape.

---

## Changelog (progression log)

Progression over time + key decisions. Mirrors `CHANGELOG.md` (the canonical
[Keep a Changelog](https://keepachangelog.com/) file); versions are semver and
match `src/alv-backend/dbx_alv_reports/VERSION`. Keep both in step.

### [Unreleased] — App deploy as a DAB job (feat/app-deploy-job)

_Tooling only (no App/library behavior change, no schema/migration/grant, no `VERSION`
bump). See `CHANGELOG.md` for the full entry. **Not yet run/deployed.**_

- **App deploy/update is now DAB-native.** New `deploy_app` driver
  (`src/alv-backend/deploy_app.py`) + `alv_deploy_app` job create/reuse the App, start it,
  `w.apps.deploy` from the bundle-synced source, floor the warehouse auto-stop, and print
  the App-SP grants filled in — replacing the manual `databricks sync` + `databricks apps
  deploy` flow. `databricks.yml` now syncs `src/alv-frontend/backend/**`, so
  `databricks bundle deploy -t dev && databricks bundle run alv_deploy_app -t dev` deploys
  the App end-to-end. New `warehouse_id` bundle var.
- **Grants corrected for ALV** — the reference notebook granted `system.*` (account admin);
  ALV needs none. The printed grants are catalog/schema `USE`/`SELECT`/`MODIFY` + volume
  `READ`/`WRITE` (SQL, UC admin) and warehouse `CAN_USE` + per-job `CAN_MANAGE_RUN` (CLI),
  with live `job_id`s read from `alv_catalog`. Matches `docs/APP_PREREQUISITES.md`.

### [Unreleased] — structured output paths + retention cleanup (feat/structured-output-paths)

_Job/library-layer only (no App/frontend change, no schema/migration/grant, no `VERSION`
bump). See `CHANGELOG.md` for the full entry. **Deployed 2026-08-19** to
`fevm-classic-stable-lakebase`; not yet merged — awaiting live validation._

- **Per-run output subfolders** replace the flat directory:
  `/Volumes/<cat>/<schema>/<vol>/<YYYYMMDD>/<alv_id>/<request_no>/<file>`. The **Job** owns
  the layout — it stamps the run date (in `report_timezone`) and builds the path from the
  `alv_id` + `request_no` it already receives, so there is **no App change and no new job
  param** (`output_dir` is removed). The stand-in jobs now write via Spark
  (`coalesce(1).write.csv`) and return the globbed `part-*.csv` — a single-file
  `output_path`, so **Download + Preview are unchanged**. New pure helper
  `dbx_alv_reports.build_output_dir`. Existing rows keep their flat paths and still resolve.
- **Daily retention cleanup job** (`alv_output_cleanup`) deletes `<YYYYMMDD>` folders older
  than `output_retention_days` (new `databricks.yml` var, default **30**), keeping the most
  recent N days; runs 01:00 Asia/Kolkata (auto-paused in dev), `dry_run` supported. Pure
  `expired_date_dirs` helper ignores anything that is not a `YYYYMMDD` folder.
- **Tests:** +26 library unit (106 total); live-smoke-tested end-to-end (both report jobs
  write the nested path; cleanup deletes an old folder and keeps the current one).

### [Unreleased] — result cache reuse (feat/result-cache-reuse)

_App-only change (no library `VERSION` bump). Task 7.3. **No schema / migration / grant
change.** See `CHANGELOG.md` for the full entry. Not yet deployed / merged._

- **Pre-submit result-cache lookup + reuse popup.** `POST /api/reports/{alv_id}/cache-check`
  computes the `param_hash` server-side (single source of truth) and looks for an identical,
  still-valid prior run (`COMPLETED` + captured output + within TTL) to offer for reuse. On a
  hit the frontend shows a modal: **reuse** that output (downloads the existing run via the
  App-proxied download) or **run the job again**. No hit — or a failed check — submits
  normally (backward-compatible, never blocking).
- **Latest wins** (the added edge case): when several runs qualify, the newest output
  (`ORDER BY generated_at DESC ... LIMIT 1`) is offered — never an older one.
- **Reuse points to the existing run** (no new `request_log` row); cross-user reuse is
  intended (per `SECURITY_AND_PERMISSIONS.md` §8). The raw output path is never exposed. The
  same `report_permissions` gate as submit runs first (404 on deny, before any warehouse read).
- **Tests** — +12 backend (`test_cache_check.py`) + 4 vitest (`ReuseRun.test.tsx`);
  307 backend + 19 vitest pass, build clean.

### [Unreleased] — output-file preview (feat/output-file-preview)

_App-only change (no library `VERSION` bump). See `CHANGELOG.md` for the full entry.
**Deployed 2026-08-18** to `fevm-classic-stable-lakebase`; awaiting live validation._

- **View a completed run's output file on-screen.** A new **Preview** action on each
  Downloads row (between Parameters and Download, same COMPLETED-with-output gate) opens
  a routed screen (`/downloads/:requestNo/preview`) showing the first rows of the file
  the run wrote to the UC Volume. The **read-only twin of Download** — it runs **no SQL**,
  unlike the report form's "Preview Sample Data".
- **Backend `GET /api/requests/{request_no}/output-preview`** mirrors the download
  endpoint (same permission gate, same 409/422/502 guards) but reads a **bounded byte
  prefix** and returns a **parsed, capped** payload (CSV table, raw-text fallback, or a
  binary notice) — raw bytes never reach the browser. Bounded by row cap (**1000**) and
  byte ceiling (**8 MiB**). **No new grants.**
- **Tests:** 14 backend (321 pass, 1 skipped) + 5 vitest (24 pass); build clean.
- **Multi-file is backlog** — the preview reads a single-file `output_path`, like
  Download; see `docs/MULTI_FILE_DOWNLOAD_APPROACH.md`.

### [Unreleased] — repository reorganization (feat/repo-reorg)

_Structural only — no code behavior change, no library `VERSION` bump. See `CHANGELOG.md`
for the full entry._

- **Library + driver notebooks → `src/alv-backend/`**; **App → `src/alv-frontend/`** (backend
  + frontend together); **`report_specs/`, `env_parameters/`, library `tests/` → under
  `src/`**.
- **Path-dependent config updated:** `databricks.yml` (`sync.include`,
  `framework_source_path`), root `pyproject.toml`, the 5 driver-notebook `sys.path`
  bootstraps (`/src` → `/src/alv-backend`), the 3 seed-job `manifest_path` defaults, and the
  app-test path resolution. App workspace source path cut over to `alv-frontend-src`.
- **Verified:** library 80, App backend 279 (+1 skipped), 12 vitest, frontend build clean,
  `bundle validate` OK.

### [Unreleased] — parameter templates / variants (feat/report-templates)

_New metadata table + App-layer work. See `CHANGELOG.md` for the full entry. **Deployed
2026-08-08** to `fevm-classic-stable-lakebase`; not yet merged to `main` — awaiting
live validation._

- **Save a report's parameters as a reusable, owner-private template.** New
  `report_templates` metadata table (grain `owner` × `alv_id` × `template_name`), created
  by re-running `provision_alv_metadata` (in `PILOT_TABLES`; **no migration** — new table).
  Stores the **raw form-values map** (not the normalized job payload) so a load refills the
  form faithfully. Owner = the user's lower-cased email; a user sees only his own templates.
- **App** — a contextual **Templates** left-nav item (shown while a report is open) opens a
  screen to list / load / rename / delete templates for that report type; a **Save as
  template** control on the form saves the current values (upsert on name). Every endpoint
  is gated by the report-permission check **then** the owner check (**404** on deny).
  **Removed the Validate button.**
- **Dynamic (relative-date) templates** — a template's date fields can store a named
  **preset** (current date; ± n days; first/last day of current/next/previous month; plus a
  "from month start to today" range shortcut) that **resolves at load** in the report
  timezone (`Asia/Kolkata`), reusing the reserved `value_kinds_json` column (**no
  migration**). No work-day/holiday logic (out of scope). **Save now validates** (both
  static and dynamic; 422 with field errors on failure). "Save as template" opens a modal
  with a Static | Dynamic toggle + preset dropdown + live preview; a **"dynamic"** badge
  marks such templates.
- **Tests** — 279 backend + 79 library + 11 vitest pass.

### [Unreleased] — report routing (feat/report-group-permissions)

_App-only change (no library `VERSION` bump). See `CHANGELOG.md` for the full entry.
**Deployed 2026-08-07 and validated on the live app; `feat/report-group-permissions`
merged to `main` (merge `567087e`)** — this merge also brings in the two sections below._

- **Fixed: every report card opened the same report.** Clicking **Retail Ledger** opened
  **CC Recharge Data**. Three independent defects, each sufficient once a second report
  was seeded:
  - `App.tsx`'s `openReport` was `() => navigate("/report")` — it **dropped the
    `reportKey`** argument `HomePage` passes. No compile error, because a zero-arg
    function is assignable to `(reportKey: string) => void` in TypeScript.
  - bare `/report` was then resolved by **array index** (`selections[0].report_types[0]`)
    against a tree spanning every permitted report. The two specs are byte-identical
    clones apart from their identity, so all 28 rows tie on both order columns and the
    winner fell out of `alv_id` **alphabetical** order — `cc_recharge` sorts first.
  - `build_catalogue` was **single-report code**: it labelled the whole tree from
    `reports[0]` and keyed selections by **`selection_id` alone**, which is unique only
    *within* a report — so both reports merged into one bucket (28 rows → 4 selections,
    6 report types each) and a selection radio could silently cross-navigate.
- **Report-scoped URLs** — `/report/:reportKey/:alvId?`, report key first and `alv_id` an
  optional second segment, matched on **position**. Shape-sniffing one shared segment was
  rejected: `alv_id`'s `report_key__…` form is a **seeding convention, not a contract**.
  The legacy `/report/<alv_id>` deep link still works (resolved by asking the backend, not
  by parsing); bare `/report` redirects home.
- **Every frontend resolution is scoped to the routed report** — auto-pick,
  owning-selection derivation, and the selection→first-report-type jump. An `alv_id`
  absent from the routed report redirects instead of rendering a context-less form.
- **`build_catalogue` gains an optional `report_key` filter** (applied before grouping;
  no-arg behaviour preserved) and keys selections by **(`report_key`, `selection_id`)**.
  `CatalogueOut.report_key` / `report_label` are now **nullable** — `null` for a spanning
  tree rather than an arbitrary row's. Breadcrumb and title derive from the **resolved
  report's own row**, so they can no longer disagree with the form heading.
- **`GET /api/reports?report_key=`** — optional, server-validated. The entitlements gate is
  **unchanged**: scoping narrows *within* what the caller may see, and an unresolvable key
  returns **404**, identical for unknown / unpermitted / unloaded. Never 403 — no auth path
  changed, so `docs/SECURITY_AND_PERMISSIONS.md` is untouched.
- **`active_reports` sorts with an explicit `report_key` tiebreak** — intentional ordering
  rather than incidentally alphabetical on `alv_id`.
- **Tests that would have caught it.** A **two-report backend fixture** (28 rows from both
  manifests — `conftest.py` previously loaded only the retail one, which is exactly why the
  bug shipped), 14 new backend cases (187 → **201 passing**), and **Vitest set up for
  `app/frontend`** with a black-box routing suite: render the real `App` over a fake
  two-report API, click a card, assert the resolved `alv_id` belongs to that report — for
  both. 7 tests; **5 fail against the pre-fix code** with the exact reported symptom.

### [Unreleased] — Downloads filters/search/pagination + params view (feat/downloads-filters-params)

_App-only change (no library `VERSION` bump — the one library edit is a DDL **comment**
fix). See `CHANGELOG.md` for the full entry. **Deployed 2026-08-07** (merged to `main`
via `567087e`)._

- **Fixed the Downloads list filtering AFTER its limit.** `GET /api/requests` ran
  `LIMIT 100` and then filtered by permitted report in Python, so a user could get far
  fewer than 100 rows with **no way to reach page 2**, and a search would only ever have
  seen the newest 100 rows across all users. Visibility, scope, search and ordering now
  all run **in SQL, before the limit**.
- **New query params** on `GET /api/requests`: `scope` (`accessible` default / `mine`),
  `q` (report-name search), `sort` (allowlisted), `limit` (50, hard max 200), `offset`.
  The response adds `limit` / `offset` / `has_more` / `scope` / `sort` / `q`; `has_more`
  is exact (fetch `limit + 1`, drop the extra — no second `COUNT(*)`).
- **The report filter is an `alv_id` allowlist** resolved from the permission-aware
  metadata cache (the report *label* lives there, not in `request_log`) and bound as one
  JSON array. Every user value is a **bound parameter**; an empty allowlist serves an
  empty page **without querying**.
- **`GET /api/requests/{request_no}/params`** — the effective job payload for one run,
  behind the **same permission gate** as status/download (404 on deny). Malformed / null
  payloads degrade to `parse_ok=false`, never a 500. Labelled honestly in the UI as
  "Parameters sent to the job" (normalized, blank optional params omitted).
- **`request_log.expires_at` is now populated** — `generated_at + RESULT_TTL_DAYS`
  (default 7) on the same UPDATE that captures `generated_at`. Groundwork only: **no
  cache lookup or reuse**. Existing rows are not backfilled.
- **Downloads UI** — scope toggle, debounced search, sort, pagination, expandable
  parameters panel. Nothing filtered client-side.
- **Cross-user visibility AND download are confirmed INTENDED** — the
  `report_permissions` gate stays the only control on those paths and `submitted_by` is
  not masked. `docs/SECURITY_AND_PERMISSIONS.md` §8 previously listed this as an open bug
  and now records the decision.

### [Unreleased] — report visibility by group (feat/report-group-permissions)

_Library `VERSION` → `0.2.0` (new metadata table + seeder). See `CHANGELOG.md` for the
full entry. **Deployed 2026-08-04, validated 2026-08-04; merged to `main` 2026-08-07
via `567087e`.**_

> **Breaking for operators:** visibility now defaults to **CLOSED**. After deploying,
> the App shows **no reports** until `report_permissions` is created
> (`provision_alv_metadata`) and seeded (`seed_alv_report_permissions`) —
> `docs/APP_PREREQUISITES.md` §6.

**Added**
- **`report_permissions` metadata table** — grain (`report_key`, `group_name`); a user
  sees a report if they are a member of **ANY** mapped group (OR), and a report with **no
  active mapping is hidden from everyone**. Created by `ensure_all()`; seeded by the new
  `seed_alv_report_permissions` job from `report_specs/report_permissions.json`
  (`retail_ledger` and `cc_recharge` → `alv-report_ledger_group`).
- **`PermissionSeeder`** + driver notebook + DAB job, mirroring the `ReportSeeder` pattern
  (validate collect-all, MERGE idempotently).
- **The gate (`alv_app/entitlements.py`)** — reads the **end user's** groups via
  `current_user.me()` with their injected OBO token (the only route that works for a
  non-admin SP) and the mapping table as the **App SP**, both behind per-key TTL caches
  (workspace SCIM is capped at 255 GET/min). Fails **closed** everywhere, with distinct
  logged reasons so "OBO off" (`no_user_token`) is always distinguishable from "the user
  genuinely has no groups" (`no_groups`).
- **Enforcement on all three catalogue endpoints AND the write paths** — submit, preview,
  status, download, and the downloads list each check independently; a denied report gets
  **404, not 403**, so its existence is never disclosed, and the check runs *before* any
  write, job trigger, query, or file read.
- **Dev escape** `DEV_BYPASS_PERMISSIONS` — default **false** (safe), refused unless
  `DEV_MODE` is also on, and logs a loud WARNING whenever active, so it cannot ship open.
- **Empty state** on the home page when a user has zero permitted reports.
- **67 new tests** (48 backend + 19 library): allow/deny matrix, closed default, OR
  semantics, fail-closed paths, TTL hit/expiry, per-user cache keying, the bypass, and
  that the OBO token never reaches a log record or a response.

**Notes**
- **D19 (`auth_map`) is superseded for report visibility** — its grain was data-row
  filtering by business dimension. DDL + tests retained; nothing reads it.
- **`user_api_scopes` deliberately untouched** — the deployed app's scopes already work;
  a PATCH can silently purge them.
- **Limitation: flat groups only** — `/Me` returns direct memberships, so nesting is not
  resolved.

### [Unreleased] — sample data preview + coherent download (feat/sample-data-preview)

_App-layer + config work; library `VERSION` unchanged (`0.1.1`). See `CHANGELOG.md` for
the full entry. Merged to `main` and deployed 2026-08-03; validated end-to-end._

**Added**
- **Sample data preview** — `POST /api/reports/{alv_id}/preview` runs a parameterized
  SELECT (WHERE stitched from the user's form inputs) against a shared dummy
  `retail_ledger_sample` table and shows up to 100 rows in a paginated UI table. Runs as
  the **App service principal (no OBO)** — the data is shared and non-sensitive. Gated by
  an optional `sample_query` block in `input_fields_json` (present on 1 of 14 rows); the
  **Preview** button greys out when absent. Each column carries a `display_name` (UI) and
  a real `column_name` (query).
- **Coherent download** — a new Job `alv_sample_report_run` bound to **only**
  `retail_ledger__detail__agent_item` reads the same `sample_query` block, applies the
  same filters, and writes a CSV of the same telco data, so **what the user previews is
  what he downloads**. The other 13 reports keep the generic dummy job.

**Security (data-exposing feature)** — preview and download both use **true bound
parameters** (never string interpolation), an identifier allowlist on column names, an
explicit column projection (no `SELECT *`), an `IN`-list cap, and a hardcoded
backtick-quoted table. Per-dispatch audit log; raw user values are not logged. The JSON
Schema was fixed so the authoring/seed path accepts `sample_query`.

**Tests** — 97 backend + 33 library unit tests pass.

### [Unreleased] — App Phase 2 (home cards + submit + downloads + UI polish) + first workspace deploy

_App-layer work; library `VERSION` unchanged (`0.1.1`). See `CHANGELOG.md` for the full entry._

**Added**
- **Home report cards** — `GET /api/report-groups` (distinct seeded reports from the
  cache, `runnable_count` = rows with a bound `job_id`); frontend card grid with the
  data-driven **Retail Ledger** card + greyed "coming soon" placeholders.
- **Submit path (7.1/7.2/7.4/7.5)** — `POST /api/reports/{alv_id}/submit`: payload
  build/normalize → SHA-256 `param_hash` → INSERT `request_log` `QUEUED` → `jobs
  run-now` on the bound `job_id` → return `request_no`. 409 when unbound. No 7.3
  cache-check, no 8.x polling / 9.x download yet.
- **Downloads page** — `GET /api/requests` (recent `request_log` rows, capped at 100,
  same warehouse seam, degrade-to-empty on failure) + a frontend table (Request No,
  Report, Status, Submitted By, Submitted At + a **disabled Download stub** pending 9.x).
- **Persistent top navigation** — the header is rendered **once at the app-shell level**
  so its nav is present on every view and **back-navigation works from anywhere**. Nav
  links moved to the **right**, just before "Welcome, {user}", with **active-view
  highlighting**. Removed the "Databricks SSO · SP ✓" header text.
- **UI polish** — a design-token system (color / type / spacing / radius / shadow) with
  **Databricks lava (`#FF3621`)** used sparingly; polished header/cards/form/downloads
  table, **QUEUED** status badges, loading skeletons/spinners, and empty states.
- **Dark mode** — a sun/moon toggle (top-right) that inverts the whole theme via the
  `[data-theme="dark"]` color tokens; **`localStorage`-persisted** with a
  before-paint inline script (no flash-of-wrong-theme).
- **Dummy backend Job** — one parameterized serverless job (`alv_dummy_report_run`)
  for all 14 rows; writes a dummy CSV to UC Volume `alv_outputs` and returns its
  pointer via `dbutils.notebook.exit` per `CONTRACT.md`.
- **`docs/APP_PREREQUISITES.md`** — App-SP grant checklist + the 14-row `job_id` bind.

**Deployed** — workspace `fevm-classic-stable-lakebase`, catalog
`classic_stable_lakebase_catalog.alv_metadata`: App **RUNNING** and live-tested end-to-end
(`request_no` round-trips, dummy job runs SUCCESS, CSV in the Volume); all 14 `job_id`s
bound to job **1044615550343710**; SP grants applied (schema `MODIFY`, Volume
`READ`/`WRITE`, job `CAN_MANAGE_RUN`).

**Git flow** — `feat/ui-polish-darkmode` → `feat/app-skeleton-and-deploy` → `main`;
`main` is now the mainline (skeleton + read path + submit → `request_log` + downloads +
UI polish + dark mode). Both feature branches are retained on origin.

**Notes** — one job for all 14 rows; `message_key` still a frontend stopgap;
`allowed_values` dropdown hook forward-looking (zero dropdowns in the pilot).

**Added (later 2026-07-30)**
- **submitted_by email (follow-up 1)** — `_submitted_by(ident)` prefers email →
  preferred_username → user_id (was id-first). New submissions log the human email.
- **Status polling / task 8.x (follow-up 2)** — `GET /api/requests/{request_no}/status`
  reads live job run state, maps + **persists** it to `request_log`; frontend
  `useRequestStatus` polls non-terminal rows so **QUEUED→SUCCESS advances live** in the UI.
- **Selection-in-main + left-nav app navigation** — Selection moved into the main page
  (Selection → Reports → form); **auto-select** first selection + report; left navbar now
  holds **Home/Downloads**, is **collapsible** (icon rail) + **drag-resizable** (persisted);
  pilot notice text removed.
- **Routing + breadcrumb + nav polish** — `react-router-dom` **HashRouter** (`/`,
  `/downloads`, `/report/:alvId`) gives working **browser Back/Forward**; a session
  `FormDraftProvider` **preserves unsubmitted form values** across nav; **breadcrumb**
  `Home › <report>` with Home clickable; collapse toggle centered; default nav width
  **240 → 160px**.

**Changed (later)** — **redeployed `main`** so email fix + polling + UI ship together (a
UI-branch deploy cut before the follow-ups had reverted the email fix live); **purged the
6 numeric-`submitted_by` test rows** from `request_log` (kept the 2 real-email rows).

**Added (task 9.x — output download)** — `GET /api/requests/{request_no}/download`
streams the run's output file from a **UC Volume** to the browser as the **app SP** (SDK
Files API); guards for no-output (`409`), non-Volume path (`422`), read-fail (`502`),
missing row (`404`); path never exposed. **Output capture folded into the 8.x status
seam**: on `SUCCESS` the App fetches the `notebook.exit` pointer, persists
`output_path`/`row_count`/`generated_at`, and settles the row to **`COMPLETED`**. Frontend
Download button enables only when a row is COMPLETED with an output. Covers tasks
**8.1/8.2/8.3 + 9.1/9.2/9.3**. Deployed + **live-tested end-to-end**. **73 pytest pass.**

**Git flow (later)** — `feat/followups-1-2` + `feat/ui-selection-in-main` merged to `main`;
`feat/ui-routing-nav-polish` + `feat/download-functionality` merged to `main` (routing
branch deleted). Still open: cosmetic `run_id = 'interactive'`; **7.3** cache lookup;
**8.4/8.5** (status-detail view, failure repair) and **9.4/9.5** (cross-user reuse, expiry).

### [0.1.1] - 2026-07-02

**Changed**
- **Seeder:** split `build_rows` into `derive_rows` (pure, returns `(rows,
  warnings)`) + a validating `build_rows`. `ReportSeeder.seed()` now validates the
  manifest **once** (was twice) and no longer stashes warnings on a class attribute.
- **Parser:** cache the JSON Schema (`lru_cache`) and compile the `Draft7Validator`
  once instead of per blob.

**Added**
- **Parser:** validation rules are now checked for **applicability to their control**
  (e.g. `max_span` only on `date_range`, `regex` only on `text`) — a mismatch fails
  the load (`input_fields_json_design.md` §5).
- **Seeder:** `validate_manifest` now also requires the display/order columns
  (`report_label`, `selection_label`, `selection_order`) so rows can't seed silent
  `NULL`s the App's navigation needs.
- Unit tests for the above.

### [0.1.0] - 2026-07-02 — metadata layer (pilot tasks 2.1–2.6)

**Added**
- **Package scaffold** `src/dbx_alv_reports/` (setuptools, `src`-layout, dynamic
  version from `VERSION`), with `common/utilities` (logging, err-dict, Unity
  Catalog helpers).
- **JSON Schema** `json_specifications/input_fields.schema.json` — the contract for
  the flat, per-row `input_fields_json` (newer model; supersedes
  `ALV_App_Task_Breakdown.md` §3.2). Plus `catalog_rows.schema.json` for the seed
  manifest.
- **Loader/validator** `InputFieldsParser` (task 2.5): JSON-Schema pass (graceful
  degradation when `jsonschema` is absent) + always-on semantic pass that
  collects all errors and fails the load on an unknown rule (D-IFJ-10).
- **Typed spec** `InputFieldsSpec` / `Field` / `FieldPart` / `ValidationRule`.
- **Metadata-table DDL** (single source of truth) `metadata/metadata_tables.py`
  for `alv_catalog` (2.2) and `request_log` (2.4), with `MetadataTables.ensure_all()`
  (2.1). `auth_map` DDL is present but **deferred** (2.3 / D19) — not created by
  default.
- **Seeder** `ReportSeeder` (task 2.6): validates each `input_fields_json`, derives
  identity columns (`alv_id` slug, display name), and upserts via `MERGE INTO`
  (idempotent). Placeholder `job_id`s are seeded `NULL` (unbound) pending the RIL
  contract.
- **Drivers** `src/provision_metadata.ipynb`, `src/seed_reports.ipynb` (thin,
  six-step pattern).
- **Bundle** `databricks.yml` + `resources/*.job.yml` (dev/prod targets) and
  `env_parameters/{dev,prod}_parameters.yaml`.
- **Docs** `docs/METADATA_TABLE.md`, `docs/CONFIGURATION_GUIDE.md`, `CLAUDE.md`.
- **Unit tests** for the schema, parser, DDL, and seeder (no Spark).

**Notes**
- **Deployment is DAB-only (no wheel).** The bundle syncs `src/` + `report_specs/`
  as workspace files; the driver notebooks add `${bundle_source_path}/src` to
  `sys.path` and import `dbx_alv_reports`. Job env specs declare only third-party
  deps (`pyyaml`, `jsonschema`). `pyproject.toml` is retained for local dev/test only.
- Catalog/schema names and `job_id`s are **placeholders** pending confirmation
  (`input_fields_json_design.md` Open items #1, #4). Nothing is deployed to a
  workspace yet — this release is author-only.


---

## License

Internal use only -- Reliance Jio.